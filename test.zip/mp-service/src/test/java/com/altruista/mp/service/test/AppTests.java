package com.altruista.mp.service.test;

import com.altruista.mp.services.UserService;
import com.altruista.mp.utils.CryptoHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * Unit test for simple App.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/applicationContext.xml"})
public class AppTests {
    @Autowired
    UserService userService;

    @Test
    public void testUserSuggestions() throws Exception {
        List<String> usernames = userService.getUserSuggestions("lona");
        for (String name : usernames) {
            System.out.println("Name: " + name);
        }

        assert (usernames.size() == 3);
    }

    @Test
    public void testPasswordCrypto() {
        CryptoHelper helper = new CryptoHelper();
        String cipher1 = helper.hashPassword("hello");
        String cipher2 = helper.hashPassword("hello");
        System.out.println("cipher1 :" + cipher1);
        System.out.println("cipher2" + cipher2);
        //assert(cipher1.equals(cipher2));
    }
}