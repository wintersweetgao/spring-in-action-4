package com.altruista.mp.service.test;

import com.altruista.mp.model.AssessmentRun;
import com.altruista.mp.repositories.AssessmentRunRepository;
import com.altruista.mp.services.AssessmentRunService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/applicationContext.xml"})
public class AlertTester {

    @Autowired
    public AssessmentRunService assessmentRunService;
    @Autowired
    public AssessmentRunRepository assessmentRunRepository;

    @Test
    public void testPendingAssessment() throws Exception {
        Collection<String> status = new ArrayList<String>();
        status.add("Completed");
        String memberId = "befb4b13-7b65-4f25-925a-ac5d8658f718";

        List<AssessmentRun> pendingStatus = assessmentRunService.findByMemberIdAndStatusNotIn(memberId, status);

        if (pendingStatus.size() > 0)
            System.out.println("pending :: " + pendingStatus.size());
        else
            System.out.println(" no pending :: " + pendingStatus.size());

    }
}
