package com.altruista.mp.service.test;

import com.altruista.mp.model.MemberIndex;
import com.altruista.mp.services.MemberIndexService;
import com.altruista.mp.utils.CryptoHelper;
import com.altruista.mp.utils.DateHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

/**
 * Created by mwixson on 10/2/15.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/applicationContext.xml"})
public class EnrollmentTester {
    @Autowired
    MemberIndexService indexService;

    @Test
    public void testDOB() throws Exception {
        String dob = "1970-01-01";
        int age = DateHelper.getAgeInYears("1970-01-01");

        System.out.println("AGE: " + age);

        Assert.isTrue(age > 40);
    }

    @Test
    public void testAutoHashBySSN() throws Exception {
        String plain = "123456789";
        String cryptoId1 = indexService.save(new MemberIndex("TEST123", "SUBSCRIBER_SSN", plain));
        MemberIndex cryptoIndex1 = indexService.get(cryptoId1);
        Assert.isTrue(CryptoHelper.checkPassword(plain, cryptoIndex1.getIndexValue()));

        // cleanup
        indexService.delete(cryptoId1);
    }

    @Test
    public void testAutoHashByType() throws Exception {
        String plain = "1234567890123456790";
        String cryptoId2 = indexService.save(new MemberIndex("TEST123", "MEDICAID_ID", plain, "S"));
        MemberIndex cryptoIndex2 = indexService.get(cryptoId2);
        Assert.isTrue(CryptoHelper.checkPassword(plain, cryptoIndex2.getIndexValue()));

        // cleanup
        indexService.delete(cryptoId2);
    }

    @Test
    public void testNoHash() throws Exception {
        String plain = "1234567890123456790123456";
        String plainId1 = indexService.save(new MemberIndex("TEST123", "MEMBER_ID", plain));
        MemberIndex plainIndex1 = indexService.get(plainId1);
        Assert.isTrue(plainIndex1.getIndexValue().equals(plain));

        // cleanup
        indexService.delete(plainId1);
    }
}