package com.altruista.mp.services;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.altruista.mp.model.PushNotificationRegistration;
import com.altruista.mp.repositories.PushNotificationRegistrationRepository;

/*
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by Prateek on 10/19/15
 */
public class PushNotificationRegistrationServiceImpl implements PushNotificationRegistrationService {
    private static final Logger LOGGER = LoggerFactory.getLogger(PushNotificationRegistrationServiceImpl.class);

    private PushNotificationRegistrationRepository repository;

    @Autowired
    public PushNotificationRegistrationServiceImpl(PushNotificationRegistrationRepository repository) {
        super();
        this.repository = repository;
    }

    public PushNotificationRegistrationServiceImpl() {
        // no arg constructor
    }

    @Override
    public String save(PushNotificationRegistration pushNotificationRegistration) {
        LOGGER.debug("Save Registration for Push Notification");
        if (pushNotificationRegistration.getCreatedOn() == null)
            pushNotificationRegistration.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        pushNotificationRegistration.setUpdatedOn(DateTime.now());

        pushNotificationRegistration = repository.save(pushNotificationRegistration);
        return pushNotificationRegistration.getId();
    }

    @Override
    public PushNotificationRegistration findByContactId(String contactId) {
        return repository.findOneByContactId(contactId);
    }
}
