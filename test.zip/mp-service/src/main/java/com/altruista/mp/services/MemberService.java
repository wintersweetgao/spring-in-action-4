package com.altruista.mp.services;

import com.altruista.mp.model.Member;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MemberService {
    String save(Member member, boolean value);

    String save(Member member);

    Member get(String key);

    List<Member> findByRefId(String refId);

    List<Member> findIdByRefId(String refId);

    List<Member> findByContactCode(String contactCode);

    List<Member> findByTest(Boolean test);

    List<Member> findMemberIdsToSync();

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    void delete(String id);

    List<Member> findById(String id);
}