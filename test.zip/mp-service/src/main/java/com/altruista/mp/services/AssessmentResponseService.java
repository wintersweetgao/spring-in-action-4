package com.altruista.mp.services;

import com.altruista.mp.model.AssessmentResponse;

import java.util.List;

public interface AssessmentResponseService {
    String save(AssessmentResponse assessmentResponse, boolean value);

    String save(AssessmentResponse assessmentResponse);

    void saveAssessmentResponses(List<AssessmentResponse> responses);

    List<AssessmentResponse> findByRunId(String runId);

    AssessmentResponse findOneByRunIdAndQuestionSequence(String runId, int sequenceId);

    boolean isSyncEnabled();

    AssessmentResponse get(String key);

    List<AssessmentResponse> findResponseIdsToSync();

    List<AssessmentResponse> findByRefId(String refId);

    List<String> findIdByRunId(String runId);

    void delete(AssessmentResponse response);

    void deleteByRunId(String runId);

    void setSyncEnabled(boolean syncEnabled);
}
