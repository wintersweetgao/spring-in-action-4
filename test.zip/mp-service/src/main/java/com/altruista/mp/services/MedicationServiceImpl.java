package com.altruista.mp.services;

import com.altruista.mp.model.Medication;
import com.altruista.mp.repositories.MedicationRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class MedicationServiceImpl extends MPService implements MedicationService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MedicationServiceImpl.class);

    private MedicationRepository repository = null;

    @Autowired
    public MedicationServiceImpl(MedicationRepository repository) {
        this.repository = repository;
    }

    public MedicationServiceImpl() {
        // no arg constructor
    }

    public String save(Medication Medication, boolean sync) {
        if (Medication.getCreatedOn() == null)
            Medication.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        Medication.setUpdatedOn(DateTime.now());


        if (!sync)
            Medication.setSyncedOn(DateTime.now());
        else
            Medication.setSyncedOn(getSyncNeededDate());

        Medication = repository.save(Medication);
        return Medication.getId();
    }

    public String save(Medication Medication) {
        if (Medication.getCreatedOn() == null)
            Medication.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        Medication.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            Medication.setSyncedOn(MPService.getSyncNeededDate());

        Medication = repository.save(Medication);
        return Medication.getId();
    }

    @Override
    public Medication get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Medication> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Medication> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Medication> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}