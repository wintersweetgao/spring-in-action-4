package com.altruista.mp.services;

import com.altruista.mp.model.Assessment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

/**
 * created by PRATEEK on 03/04/2015
 */
public class AssessmentNameServiceImpl implements AssessmentNameService {

    @Autowired
    private MongoTemplate template;

    public AssessmentNameServiceImpl() {
        // no argument constructor
    }

    @Override
    public List<Assessment> getAssessmentIdAndName() {
        Query q = new Query();
        q.fields().include("id");
        q.fields().include("name");

        List<Assessment> assessments = template.find(q, Assessment.class);
        return assessments;
    }

}
