package com.altruista.mp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.altruista.mp.model.PushNotificationRegistration;

public interface PushNotificationRegistrationRepository extends CrudRepository<PushNotificationRegistration, String> {
    PushNotificationRegistration findOneByContactId(String contactId);
}
