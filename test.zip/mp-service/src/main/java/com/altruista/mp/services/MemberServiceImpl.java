package com.altruista.mp.services;

import com.altruista.mp.model.Member;
import com.altruista.mp.repositories.MemberRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberServiceImpl extends MPService implements MemberService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberServiceImpl.class);
    private MemberRepository repository = null;

    @Autowired
    public MemberServiceImpl(MemberRepository repository) {
        this.repository = repository;
    }

    public MemberServiceImpl() {
        // no arg constructor
    }

    public String save(Member member, boolean sync) {
        // set the created on date if not provided
        if (member.getCreatedOn() == null)
            member.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        member.setUpdatedOn(DateTime.now());

        if (!sync)
            member.setSyncedOn(DateTime.now());
        else
            member.setSyncedOn(getSyncNeededDate());

        member = repository.save(member);
        return member.getId();
    }

    public String save(Member member) {
        // set the created on date if not provided
        if (member.getCreatedOn() == null)
            member.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        member.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            member.setSyncedOn(MPService.getSyncNeededDate());

        member = repository.save(member);
        return member.getId();
    }

    @Override
    public Member get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Member> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Member> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Member> findByContactCode(String contactCode) {
        return repository.findByContactCode(contactCode);
    }

    @Override
    public List<Member> findByTest(Boolean test) {
        return repository.findByTest(test);
    }

    @Override
    public List<Member> findMemberIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    @Override
    public List<Member> findById(String id) {
        return repository.findById(id);
    }

}