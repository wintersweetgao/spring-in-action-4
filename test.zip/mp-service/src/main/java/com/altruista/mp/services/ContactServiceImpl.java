package com.altruista.mp.services;

import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;
import com.altruista.mp.repositories.ContactRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Metrics;
import org.springframework.data.geo.Point;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

public class ContactServiceImpl extends MPService implements ContactService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContactServiceImpl.class);

    private ContactRepository repository = null;

    @Autowired
    public MongoTemplate mongoTemplate;

    @Autowired
    public ContactServiceImpl(ContactRepository repository) {
        this.repository = repository;
    }

    public ContactServiceImpl() {
        // no arg constructor
    }

    public String save(Contact contact, boolean sync) {
        // set the created on date if not provided
        if (contact.getCreatedOn() == null)
            contact.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        contact.setUpdatedOn(DateTime.now());

        if (!sync)
            contact.setSyncedOn(DateTime.now());
        else
            contact.setSyncedOn(getSyncNeededDate());

        contact = repository.save(contact);
        return contact.getId();
    }

    public String save(Contact contact) {
        // set the created on date if not provided
        if (contact.getCreatedOn() == null)
            contact.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        contact.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            contact.setSyncedOn(MPService.getSyncNeededDate());

        contact = repository.save(contact);
        return contact.getId();
    }

    @Override
    public Contact get(String key) {
        return repository.findOne(key);
    }

    @Override
    public void delete(String id) {
        LOGGER.debug("Contact is deleted");
        repository.delete(id);
    }

    @Override
    public List<Contact> findByRefIdAndContactType(String refId, ContactType contactType) {
        return repository.findByRefIdAndContactType(refId, contactType.name());
    }

    @Override
    public List<Contact> findIdByRefIdAndContactType(String refId, ContactType contactType) {
        return repository.findByRefIdAndContactType(refId, contactType.name());
    }

    @Override
    public List<Contact> findContactIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

    @Override
    public List<Contact> findByLocation(Double lat, Double lon, Double maxdistance) {
        //Criteria criteria = new Criteria("address.position").near(new Point(lon, lat)).maxDistance(getInKilometer(maxdistance));
        //List<Contact> contacts = mongoTemplate.find(new Query(criteria), Contact.class);
        Point point = new Point(lat, lon);
        return repository.findByAddress_PositionNear(point, new Distance(maxdistance, Metrics.MILES));
    }

    @Override
    public List<Contact> findProviderByLocation(Double lat, Double lon, Double maxdistance) {
        Point point = new Point(lat, lon);
        return repository.findByContactTypeAndAddress_PositionNear(ContactType.PHYSICIAN, point, new Distance(maxdistance, Metrics.MILES));
    }

    @Override
    public List<Contact> findProviderByPostalCode(String postalCode) {
        return repository.findByContactTypeAndAddress_PostalCode(ContactType.PHYSICIAN, postalCode);
    }

    @Override
    public List<Contact> findByContactCode(String contactCode) {
        return repository.findByContactCode(contactCode);
    }

    @Override
    public List<Contact> findById(String id) {
        return repository.findById(id);
    }
}
