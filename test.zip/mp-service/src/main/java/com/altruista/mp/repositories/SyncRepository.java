package com.altruista.mp.repositories;

import com.altruista.mp.model.Sync;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by mwixson on 10/15/14.
 */
public interface SyncRepository extends CrudRepository<Sync, String> {

}
