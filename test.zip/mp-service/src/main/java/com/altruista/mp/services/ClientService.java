package com.altruista.mp.services;

import com.altruista.mp.model.Client;
import com.altruista.mp.services.exceptions.ServiceException;

import java.util.List;

public interface ClientService {
    List<Client> getAllClients(int pageNumber, int pageSize) throws ServiceException;

    Client getClientById(String clientId) throws ServiceException;

    void save(Client client) throws ServiceException;
}