package com.altruista.mp.services;

import com.altruista.mp.model.Message;

import java.util.List;

/**
 * Created by mwixs_000 on 6/24/2014.
 */
public interface MessageService {
    String save(Message message, boolean value);

    String save(Message message);

    Message get(String key);

    List<Message> findBySenderId(String memberId);

    List<Message> findByRecipientId(String memberId);

    List<Message> findByMemberId(String memberId);

    List<Message> findByRefId(String refId);

    List<Message> findIdByRefId(String refId);

    List<Message> findMessageIdsToSync();

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
