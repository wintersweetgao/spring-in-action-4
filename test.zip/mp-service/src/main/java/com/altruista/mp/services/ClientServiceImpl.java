package com.altruista.mp.services;

import com.altruista.mp.model.Client;
import com.altruista.mp.repositories.ClientRepository;
import com.altruista.mp.services.exceptions.ServiceException;
import com.google.common.collect.FluentIterable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ClientServiceImpl implements ClientService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientServiceImpl.class);
    @Autowired
    private UserService userService;
    @Autowired
    private ClientRepository clientRepository;

    public List<Client> getAllClients(int pageNumber, int pageSize) throws ServiceException {
//      int offset = (pageNumber-1)*pageSize;
//      Query clientQuery = getRoleQuery(username);
//      List<Client> clients = mongoOperations.find( clientQuery.skip(offset).limit(pageSize), Client.class);

        List<Client> clients = FluentIterable.from(clientRepository.findAll()).toList();
        LOGGER.info("getAllClients(), returning #" + clients.size());
        return clients;
    }

    /**
     * Construct a configuration query based on the user's role
     *
     * @param username
     * @return Spring Data Query
     * @throws ServiceException
     */
//    private Query getRoleQuery(String username) throws ServiceException {
//        Query cfgQuery = new Query();
//        User user = userService.getUserByUsername(username);
//        Client client = clientRepository.findOne(new ObjectId(user.getClientId()));
//
//        if (user.hasAuthority("ROLE_SUBCLIENT")) {
//            LOGGER.info("Client ROLE_SUBCLIENT access");
//            List<String> children = new ArrayList<String>();
//            children.add(client.getId());
//
//            for (Client child : client.getSubclients())
//                children.add(child.getId());
//
//            // Limit configurations to configurations created for the same client and all subclients
//            cfgQuery.addCriteria(Criteria.where("_id").in(children));
//        }
//        else if (user.hasAuthority("ROLE_ADMIN")) {
//            LOGGER.info("Client ROLE_ADMIN access: "+client.getId());
//            // Limit configurations to configurations created for the same client
//            cfgQuery.addCriteria(Criteria.where("_id").is(client.getId()));
//        }
//        else {
//            LOGGER.info("Client standard user access");
//            // Limit configurations to configurations created by the user
//            cfgQuery.addCriteria(Criteria.where("createdBy").is(username));
//        }
//
//        return cfgQuery;
//    }
    @Override
    public Client getClientById(String clientId) throws ServiceException {
        LOGGER.debug("Loading client by clientId = " + clientId);

        Client client = clientRepository.findOne(clientId);

        if (client != null) {
            LOGGER.debug("Found client with name = " + client.getClientName());
        }

        return client;
    }

    @Override
    public void save(Client client) {
        clientRepository.save(client);
    }

}