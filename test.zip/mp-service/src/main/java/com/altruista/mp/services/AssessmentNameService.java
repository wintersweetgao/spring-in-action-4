package com.altruista.mp.services;

import com.altruista.mp.model.Assessment;

import java.util.List;

/**
 * created by PRATEEK on 03/04/2015
 */
public interface AssessmentNameService {

    List<Assessment> getAssessmentIdAndName();
}
