package com.altruista.mp.services;

import com.altruista.mp.model.Visit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * Created by mwixson on 6/20/14.
 */
public interface VisitService {
    String save(Visit visit, boolean value);

    String save(Visit visit);

    Visit get(String key);

    //List<Visit> findByMemberId(String memberId);
    // Added for Visit Pagination
    Page<Visit> findByMemberId(String memberId, Pageable page);

    List<Visit> findByRefId(String refId);

    List<Visit> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);

    List<Visit> getLastVisitByMemberIdAndVisitType(String id, String visitType);
}