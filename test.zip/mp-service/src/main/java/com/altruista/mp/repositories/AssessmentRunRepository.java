package com.altruista.mp.repositories;

import com.altruista.mp.model.AssessmentRun;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.Collection;
import java.util.List;

public interface AssessmentRunRepository extends CrudRepository<AssessmentRun, String> {
    /**
     * Additional custom finder method.
     */
    List<AssessmentRun> findByMemberId(String id);

    List<AssessmentRun> findByRefId(String id);

    List<AssessmentRun> findByAssessmentId(String id);

    List<AssessmentRun> findByMemberIdAndAssessmentId(String memberId, String assessmentId);

    List<AssessmentRun> findByAssessmentIdAndStatus(String assessmentId, String status);

    List<AssessmentRun> findBySyncedOn(DateTime syncedOn);

    List<AssessmentRun> findByMemberIdAndCreatedOnGreaterThan(String memberId, DateTime createdOn);

    List<AssessmentRun> findByFollowupRefId(String followupRefId);

    List<AssessmentRun> findByMemberIdAndStatusNotIn(String memberId, Collection<String> status);
}
