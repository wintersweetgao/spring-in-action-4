package com.altruista.mp.services;

import com.altruista.mp.model.MemberIndex;

import java.util.List;

/**
 * Created by mwixson on 9/24/15.
 */
public interface MemberIndexService {
    String save(MemberIndex index, boolean value);

    String save(MemberIndex index);

    MemberIndex get(String key);

    List<MemberIndex> findIdByRefIdAndIndexNameAndIndexValue(String refId, String indexName, String indexValue);

    List<MemberIndex> findByIndexNameInAndValue(List<String> indexNames, String indexValue);

    MemberIndex findOneByMemberIdAndIndexName(String memberId, String memberIndex);

    List<MemberIndex> findByMemberIndexesAndValue(String indexValue);

    void delete(String key);

    List<MemberIndex> findByRefId(String refId);
}
