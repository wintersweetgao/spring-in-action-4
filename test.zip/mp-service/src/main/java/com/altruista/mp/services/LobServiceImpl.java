package com.altruista.mp.services;

import com.altruista.mp.model.Lob;
import com.altruista.mp.repositories.LobRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class LobServiceImpl extends MPService implements LobService {
    private static final Logger LOGGER = LoggerFactory.getLogger(LobServiceImpl.class);

    private LobRepository repository = null;

    @Autowired
    public LobServiceImpl(LobRepository repository) {
        this.repository = repository;
    }

    public LobServiceImpl() {
        // no arg constructor
    }

    public String save(Lob lob, boolean sync) {
        if (lob.getCreatedOn() == null)
            lob.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        lob.setUpdatedOn(DateTime.now());

        if (!sync)
            lob.setSyncedOn(DateTime.now());
        else
            lob.setSyncedOn(getSyncNeededDate());

        lob = repository.save(lob);
        return lob.getId();
    }

    public String save(Lob lob) {
        if (lob.getCreatedOn() == null)
            lob.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        lob.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            lob.setSyncedOn(MPService.getSyncNeededDate());

        lob = repository.save(lob);
        return lob.getId();
    }

    @Override
    public Lob get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Lob> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Lob> findByRefId(String memberId) {
        return repository.findByRefId(memberId);
    }

    @Override
    public List<Lob> findIdByRefId(String memberId) {
        return repository.findByRefId(memberId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}