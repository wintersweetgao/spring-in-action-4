package com.altruista.mp.repositories;

import com.altruista.mp.model.TrackerRecord;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public interface TrackerRecordRepository extends CrudRepository<TrackerRecord, String> {
    List<TrackerRecord> findByRefId(String id);

    List<TrackerRecord> findByMemberIdAndTrackerId(String memberId, String trackerId);

    List<TrackerRecord> findBySyncedOn(DateTime syncedOn);

    List<TrackerRecord> findByMemberIdAndCreatedOnGreaterThan(String memberId, DateTime accessedOn);
}
