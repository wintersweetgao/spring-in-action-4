package com.altruista.mp.utils;

import org.joda.time.DateTime;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * Created by mwixson on 11/23/14.
 */
public class DateHelper {
    public static DateTime getDate(java.util.Date date) {
        if (date == null)
            return null;
        else
            return new DateTime(date);
    }

    public static String getDateString(java.util.Date date) {
        if (date == null)
            return null;
        else {
            DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyy-MM-dd");
            return dtf.print(new DateTime(date));
        }
    }

    public static int getAgeInYears(String dobStr) {
        DateTime dob = DateTime.parse(dobStr); // dob
        return Years.yearsBetween(dob, DateTime.now()).getYears();
    }
}


