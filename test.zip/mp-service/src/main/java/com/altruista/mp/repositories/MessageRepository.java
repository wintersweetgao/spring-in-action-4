package com.altruista.mp.repositories;

import com.altruista.mp.model.Message;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MessageRepository extends CrudRepository<Message, String> {

    /**
     * Additional custom finder method.
     */
    List<Message> findBySenderId(String id);

    List<Message> findByRecipientIds(String id);

    List<Message> findByMemberId(String id);

    List<Message> findByMemberIdAndCreatedOnGreaterThanAndViewed(
            String memberId, DateTime accessedOn, Boolean viewed);

    List<Message> findByRefId(String id);

    List<Message> findBySyncedOn(DateTime syncedOn);
}
