package com.altruista.mp.services;

import com.altruista.mp.model.AllergySensitivity;

import java.util.List;

/**
 * Created by mwixson on 10/16/14.
 */
public interface AllergySensitivityService {
    String save(AllergySensitivity allergy, boolean value);

    String save(AllergySensitivity allergy);

    AllergySensitivity get(String key);

    List<AllergySensitivity> findByMemberId(String memberId);

    List<AllergySensitivity> findByRefId(String refId);

    List<AllergySensitivity> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
