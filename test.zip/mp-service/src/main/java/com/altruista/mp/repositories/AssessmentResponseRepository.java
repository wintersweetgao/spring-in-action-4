package com.altruista.mp.repositories;

import com.altruista.mp.model.AssessmentResponse;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


/*
 * created by Prateek on 03/12/15
*/
public interface AssessmentResponseRepository extends CrudRepository<AssessmentResponse, String> {
    /**
     * Additional custom finder method.
     */
    List<AssessmentResponse> findByRunId(String id);

    AssessmentResponse findOneByRunIdAndQuestion_Sequence(String id, int sequence);

    List<AssessmentResponse> findByRefId(String id);

    List<AssessmentResponse> findBySyncedOn(DateTime time);

    Long deleteByRunId(String runId);
}
