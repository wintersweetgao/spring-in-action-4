package com.altruista.mp.services;

import com.altruista.mp.model.Sync;
import com.altruista.mp.repositories.SyncRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by mwixson on 10/15/14.
 */
public class SyncServiceImpl extends MPService implements SyncService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncServiceImpl.class);
    private SyncRepository repository = null;

    @Autowired
    public SyncServiceImpl(SyncRepository syncRepository) {
        this.repository = syncRepository;
    }

    public SyncServiceImpl() {
        // no arg constructor
    }

    @Override
    public String save(Sync sync) {
        sync = repository.save(sync);
        return sync.getId();
    }

    @Override
    public Sync get(String key) {
        return repository.findOne(key);
    }
}