package com.altruista.mp.services;

import com.altruista.mp.model.ValidValue;

import java.util.List;

/**
 * Created by Administrator on 7/3/2014.
 */
public interface ValidValueService {
    String save(ValidValue value, boolean val);

    String save(ValidValue value);

    ValidValue get(String key);

    List<ValidValue> findByName(String name);

    List<ValidValue> findByNameAndRefId(String name, String refId);

    List<ValidValue> findIdByNameAndRefId(String name, String refId);

    List<ValidValue> findByNameAndValue(String name, String value, boolean startsWith);

    List<ValidValue> findByNameAndDescription(String name, String description, boolean startsWith);

    void delete(String id);
}
