package com.altruista.mp.services;

import com.altruista.mp.model.Medication;

import java.util.List;

/**
 * Created by mwixs_000 on 6/22/2014.
 */
public interface MedicationService {
    String save(Medication Medication, boolean value);

    String save(Medication Medication);

    Medication get(String key);

    List<Medication> findByMemberId(String memberId);

    List<Medication> findByRefId(String refId);

    List<Medication> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}

