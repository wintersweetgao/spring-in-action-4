package com.altruista.mp.repositories;

import com.altruista.mp.model.Medication;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MedicationRepository extends CrudRepository<Medication, String> {

    /**
     * Additional custom finder method.
     */
    List<Medication> findByMemberId(String id);

    List<Medication> findByMemberIdAndCreatedOnGreaterThan(String id, DateTime createdOn);

    List<Medication> findByRefId(String id);
}
