package com.altruista.mp.repositories;

import com.altruista.mp.model.Goal;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


/**
 * Created by mwixs_000 on 6/9/2014.
 */
public interface GoalRepository extends CrudRepository<Goal, String> {

    /**
     * Additional custom finder method.
     */
    List<Goal> findByMemberId(String id);

    List<Goal> findByRefId(String id);

    List<Goal> findBySyncedOn(DateTime syncedOn);
}