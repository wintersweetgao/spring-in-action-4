package com.altruista.mp.services;

import com.altruista.mp.model.Lob;

import java.util.List;

/**
 * Created by mwixson on 10/8/15.
 */
public interface LobService {
    String save(Lob program, boolean value);

    String save(Lob program);

    Lob get(String key);

    List<Lob> findByMemberId(String memberId);

    List<Lob> findByRefId(String refId);

    List<Lob> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
