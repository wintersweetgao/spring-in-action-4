package com.altruista.mp.services;

import com.altruista.mp.model.Task;
import com.altruista.mp.repositories.ContactRepository;
import com.altruista.mp.repositories.TaskRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by Administrator on 7/1/2014.
 */
public class TaskServiceImpl extends MPService implements TaskService {
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskServiceImpl.class);

    private TaskRepository repository = null;

    //private MongoOperations mongoOperation;

    @Autowired
    ContactRepository contactRepository;

    @Autowired
    public TaskServiceImpl(TaskRepository repository) {
        this.repository = repository;
    }

    public TaskServiceImpl() {
        // no arg constructor
    }

    public String save(Task task) {
        task = repository.save(task);
        return task.getId();
    }

    public String save(Task task, boolean sync) {

        if (!sync)
            task.setSyncedOn(DateTime.now());
        else
            task.setSyncedOn(getSyncNeededDate());

        task = repository.save(task);
        return task.getId();
    }

    public void delete(String id) {
        repository.delete(id);
    }

    /*
     * This method creates a new event as well as update the existing one
     * For updating document you need to first get document and then update it
     * otherwise data will not be updated
    */
    public void saveTasks(List<Task> tasks) {
        for (Task task : tasks) {
            String id = task.getId();
            Task task2 = repository.findOne(id);

            //find the document, modify and update it with save() method.
            if (task2 != null) {
                task2.setTitle(task.getTitle());
                task2.setDescription(task.getDescription());
                task2.setStart(task.getStart());
                task2.setEnd(task.getEnd());
                repository.save(task2);
            } else
                repository.save(task);
        }
    }

    @Override
    public Task get(String key) {
        Task task = repository.findOne(key);

        // load contact information for appointment
        if (task.getContactId() != null)
            task.setContact(contactRepository.findOne(task.getContactId()));
        return task;
    }

    @Override
    public List<Task> findByMemberId(String memberId) {
        List<Task> tasks = repository.findByMemberId(memberId);

        // load contact information for each appointment
        for (Task task : tasks) {
            if (task.getContactId() != null)
                task.setContact(contactRepository.findOne(task.getContactId()));
        }
        return tasks;
    }

    @Override
    public List<Task> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Task> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void deleteTasks(List<Task> tasks) {
        for (Task task : tasks) {
            repository.delete(task);
        }
    }

    @Override
    public List<Task> findTaskIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

}
