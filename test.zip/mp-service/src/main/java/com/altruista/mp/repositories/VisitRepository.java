package com.altruista.mp.repositories;

import com.altruista.mp.model.Visit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/*
 * Developed by Ashtikar P on 09/09/15
*/
public interface VisitRepository extends PagingAndSortingRepository<Visit, String> {

    /**
     * Additional custom finder method.
     */
    //List<Visit> findByMemberId(String id);
    Page<Visit> findByMemberId(String id, Pageable page);

    List<Visit> findByRefId(String id);
}
