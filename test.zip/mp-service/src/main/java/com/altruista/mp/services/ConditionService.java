package com.altruista.mp.services;

import com.altruista.mp.model.Condition;

import java.util.List;

/**
 * Created by mwixson on 6/20/14.
 */
public interface ConditionService {
    String save(Condition condition, boolean value);

    String save(Condition condition);

    Condition get(String key);

    List<Condition> findByMemberId(String memberId);

    List<Condition> findByRefId(String refId);

    List<Condition> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
