package com.altruista.mp.services;

import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;

import java.util.List;

/**
 * Created by mwixson on 8/3/14.
 */
public interface ContactService {
    String save(Contact contact, boolean value);

    String save(Contact contact);

    Contact get(String key);

    List<Contact> findByRefIdAndContactType(String refId, ContactType contactType);

    List<Contact> findIdByRefIdAndContactType(String refId, ContactType contactType);

    List<Contact> findContactIdsToSync();

    // for SSO to support multiple assertions
    List<Contact> findByContactCode(String contactCode);

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    void delete(String id);

    List<Contact> findByLocation(Double lat, Double lon, Double maxdistance);

    List<Contact> findProviderByLocation(Double lat, Double lon, Double maxdistance); // Double ele

    List<Contact> findProviderByPostalCode(String postalCode);

    List<Contact> findById(String id);
}
