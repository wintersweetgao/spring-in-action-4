package com.altruista.mp.repositories;

import com.altruista.mp.model.AuditLog;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by mahesh on 11/17/14.
 */
public interface AuditLogRepository extends CrudRepository<AuditLog, String> {

}
