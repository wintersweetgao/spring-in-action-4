package com.altruista.mp.repositories;

import com.altruista.mp.model.ProgramEligibility;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 10/2/15.
 */
public interface ProgramEligibilityRepository extends CrudRepository<ProgramEligibility, String> {
    List<ProgramEligibility> findByProgramName(String programName);
}