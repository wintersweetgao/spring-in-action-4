package com.altruista.mp.services;

import com.altruista.mp.model.ProgramEligibility;

/**
 * Created by mwixson on 10/2/15.
 */
public interface ProgramEligibilityService {
    ProgramEligibility findOneByProgramName(String programName);

    String save(ProgramEligibility index, boolean value);

    String save(ProgramEligibility index);

    ProgramEligibility get(String key);
}
