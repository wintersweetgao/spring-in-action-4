package com.altruista.mp.services;

import com.altruista.mp.model.Diagnosis;
import com.altruista.mp.repositories.DiagnosisRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class DiagnosisServiceImpl extends MPService implements DiagnosisService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DiagnosisServiceImpl.class);

    private DiagnosisRepository repository = null;

    @Autowired
    public DiagnosisServiceImpl(DiagnosisRepository repository) {
        this.repository = repository;
    }

    public DiagnosisServiceImpl() {
        // no arg constructor
    }

    public String save(Diagnosis diagnosis, boolean sync) {
        if (diagnosis.getCreatedOn() == null)
            diagnosis.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        diagnosis.setUpdatedOn(DateTime.now());

        if (!sync)
            diagnosis.setSyncedOn(DateTime.now());
        else
            diagnosis.setSyncedOn(getSyncNeededDate());

        diagnosis = repository.save(diagnosis);
        return diagnosis.getId();
    }

    public String save(Diagnosis diagnosis) {
        if (diagnosis.getCreatedOn() == null)
            diagnosis.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        diagnosis.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            diagnosis.setSyncedOn(MPService.getSyncNeededDate());

        diagnosis = repository.save(diagnosis);
        return diagnosis.getId();
    }

    @Override
    public Diagnosis get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Diagnosis> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Diagnosis> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Diagnosis> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}