package com.altruista.mp.services;

import com.altruista.mp.model.ProgramEligibility;
import com.altruista.mp.repositories.ProgramEligibilityRepository;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by mwixson on 10/2/15.
 */
public class ProgramEligibilityServiceImpl extends MPService implements ProgramEligibilityService {
    ProgramEligibilityRepository repository = null;

    @Autowired
    public ProgramEligibilityServiceImpl(ProgramEligibilityRepository repository) {
        this.repository = repository;
    }

    public ProgramEligibilityServiceImpl() {
        // no arg constructor
    }

    @Override
    public String save(ProgramEligibility program, boolean sync) {
        if (program.getCreatedOn() == null)
            program.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        program.setUpdatedOn(DateTime.now());

        if (!sync)
            program.setSyncedOn(DateTime.now());
        else
            program.setSyncedOn(getSyncNeededDate());

        program = repository.save(program);
        return program.getId();
    }

    @Override
    public String save(ProgramEligibility program) {
        return save(program, isSyncEnabled());
    }

    @Override
    public ProgramEligibility get(String key) {
        return repository.findOne(key);
    }

    @Override
    public ProgramEligibility findOneByProgramName(String programName) {
        List<ProgramEligibility> eligibilities = repository.findByProgramName(programName);
        if (!eligibilities.isEmpty())
            return eligibilities.get(0);
        else
            return null;
    }

}
