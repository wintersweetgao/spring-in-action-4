package com.altruista.mp.services;

import com.altruista.mp.model.TrackerRecord;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public interface TrackerRecordService {
    String save(TrackerRecord record, boolean value);

    String save(TrackerRecord record);

    TrackerRecord get(String key);

    List<TrackerRecord> findByRefId(String refId);

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    void delete(String id);

    List<TrackerRecord> getTrackerRecordsByMemberIdAndTrackerIdAndRecordOn(String memberId, String trackerId, String startDate, String endDate);

    List<TrackerRecord> findTrackerIdsToSync();
}
