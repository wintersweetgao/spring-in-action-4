package com.altruista.mp.services;

import com.altruista.mp.model.Visit;
import com.altruista.mp.repositories.VisitRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

/*
 * Developed by Prateek on 06/24/15
*/
public class VisitServiceImpl extends MPService implements VisitService {
    private static final Logger LOGGER = LoggerFactory.getLogger(VisitServiceImpl.class);

    private VisitRepository repository = null;

    @Autowired
    private MongoOperations mongoOperations;

    @Autowired
    public VisitServiceImpl(VisitRepository repository) {
        this.repository = repository;
    }

    public VisitServiceImpl() {
        // no arg constructor
    }

    public String save(Visit visit, boolean sync) {

        if (visit.getCreatedOn() == null)
            visit.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        visit.setUpdatedOn(DateTime.now());

        if (!sync)
            visit.setSyncedOn(DateTime.now());
        else
            visit.setSyncedOn(getSyncNeededDate());

        visit = repository.save(visit);
        return visit.getId();
    }

    public String save(Visit visit) {
        if (visit.getCreatedOn() == null)
            visit.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        visit.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            visit.setSyncedOn(MPService.getSyncNeededDate());

        visit = repository.save(visit);
        return visit.getId();
    }

    public Visit get(String key) {
        return repository.findOne(key);
    }

    public List<Visit> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    public List<Visit> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    public void delete(String id) {
        LOGGER.debug("Visit deleted for : " + id);
        repository.delete(id);
    }

    @Override
    public List<Visit> getLastVisitByMemberIdAndVisitType(String memberId, String visitType) {
        // db.visit.find().sort({visitOn:-1}).limit(1)
        Query query = new Query();
        query.addCriteria(Criteria.where("memberId").is(memberId));
        query.addCriteria(Criteria.where("visitType").is(visitType));
        query.limit(1);
        query.with(new Sort(Sort.Direction.DESC, "visitOn"));

        return mongoOperations.find(query, Visit.class);
    }

    @Override
    public Page<Visit> findByMemberId(String memberId, Pageable pageable) {
        LOGGER.info("MEMBER ID : [" + memberId + "], PAGE INDEX :[" + pageable.getPageNumber() + "], PAGE SIZE : [" + pageable.getPageSize() + "]");
        return repository.findByMemberId(memberId, pageable);
    }
}