package com.altruista.mp.repositories;

import com.altruista.mp.model.MemberContact;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MemberContactRepository extends CrudRepository<MemberContact, String> {

    /**
     * Additional custom finder method.
     */
    List<MemberContact> findByMemberId(String id);

    List<MemberContact> findByMemberIdAndContactType(String id, String contactType);

    List<MemberContact> findByRefIdAndContactType(String id, String contactType);

    List<MemberContact> findByContactId(String id);
}
