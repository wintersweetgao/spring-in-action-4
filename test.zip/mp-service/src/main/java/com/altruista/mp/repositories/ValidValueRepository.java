package com.altruista.mp.repositories;

import com.altruista.mp.model.ValidValue;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ValidValueRepository extends CrudRepository<ValidValue, String> {

    /**
     * Additional custom finder method.
     */
    List<ValidValue> findByName(String name);

    List<ValidValue> findByNameAndRefId(String name, String id);

    List<ValidValue> findByNameAndValue(String name, String value);

    List<ValidValue> findByNameAndValueStartsWith(String name, String value);

    List<ValidValue> findByNameAndDescription(String name, String description);

    List<ValidValue> findByNameAndDescriptionStartsWith(String name, String description);
}
