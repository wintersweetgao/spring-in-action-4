package com.altruista.mp.services;

import com.altruista.mp.model.ActionStep;

import java.util.List;

/**
 * Created by mwixson on 8/11/14.
 */
public interface ActionStepService {
    String save(ActionStep step, boolean value);

    String save(ActionStep step);

    ActionStep get(String key);

    List<ActionStep> findByMemberId(String memberId);

    List<ActionStep> findByGoalId(String goalId);

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    List<ActionStep> findByRefId(String refId);

    List<ActionStep> findIdByRefId(String refId);

    List<ActionStep> findActionStepIdsToSync();

    void delete(String id);
}