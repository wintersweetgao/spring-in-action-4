package com.altruista.mp.services;

import com.altruista.mp.model.ContactType;
import com.altruista.mp.model.MemberContact;
import com.altruista.mp.repositories.MemberContactRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 9/18/14.
 */
public class MemberContactServiceImpl extends MPService implements MemberContactService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberContactServiceImpl.class);

    private MemberContactRepository repository = null;

    @Autowired
    public MemberContactServiceImpl(MemberContactRepository repository) {
        this.repository = repository;
    }

    public MemberContactServiceImpl() {
        // no arg constructor
    }

    public String save(MemberContact relationship, boolean sync) {
        if (relationship.getCreatedOn() == null)
            relationship.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        relationship.setUpdatedOn(DateTime.now());

        if (!sync)
            relationship.setSyncedOn(DateTime.now());
        else
            relationship.setSyncedOn(getSyncNeededDate());

        relationship = repository.save(relationship);
        return relationship.getId();
    }

    public String save(MemberContact relationship) {
        if (relationship.getCreatedOn() == null)
            relationship.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        relationship.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            relationship.setSyncedOn(MPService.getSyncNeededDate());

        relationship = repository.save(relationship);
        return relationship.getId();
    }

    @Override
    public MemberContact get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<MemberContact> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<MemberContact> findByMemberIdAndContactType(String memberId, ContactType contactType) {
        return repository.findByMemberIdAndContactType(memberId, contactType.name());
    }

    @Override
    public List<MemberContact> findByRefIdAndContactType(String refId, ContactType contactType) {
        return repository.findByRefIdAndContactType(refId, contactType.name());
    }

    @Override
    public List<MemberContact> findIdByRefIdAndContactType(String refId, ContactType contactType) {
        return repository.findByRefIdAndContactType(refId, contactType.name());
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    @Override
    public List<String> findByContactId(String contactId) {
        List<MemberContact> memberContacts = repository.findByContactId(contactId);
        List<String> memberIds = new ArrayList<String>();
        for (MemberContact dbMemberContacts : memberContacts) {
            memberIds.add(dbMemberContacts.getMemberId());
        }
        return memberIds;
    }
}
