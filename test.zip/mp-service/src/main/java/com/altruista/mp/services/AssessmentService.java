package com.altruista.mp.services;

import com.altruista.mp.model.Assessment;

import java.util.List;

/**
 * Created by mwixson on 2/17/15.
 */
public interface AssessmentService {
    String save(Assessment assessment, boolean value);

    String save(Assessment assessment);

    Assessment get(String key);

    List<Assessment> findAll();

    List<String> findAllNames();

    List<Assessment> findByRefId(String refId);

    List<String> findIdByRefId(String refId);

    List<Assessment> findByName(String name);

    void delete(Assessment assessment);
}
