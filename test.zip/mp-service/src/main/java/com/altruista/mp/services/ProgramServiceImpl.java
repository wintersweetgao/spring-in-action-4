package com.altruista.mp.services;

import com.altruista.mp.model.Program;
import com.altruista.mp.repositories.ProgramRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ProgramServiceImpl extends MPService implements ProgramService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProgramServiceImpl.class);

    private ProgramRepository repository = null;

    @Autowired
    public ProgramServiceImpl(ProgramRepository repository) {
        this.repository = repository;
    }

    public ProgramServiceImpl() {
        // no arg constructor
    }

    @Override
    public String save(Program program, boolean sync) {
        if (program.getCreatedOn() == null)
            program.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        program.setUpdatedOn(DateTime.now());

        if (!sync)
            program.setSyncedOn(DateTime.now());
        else
            program.setSyncedOn(getSyncNeededDate());

        program = repository.save(program);
        return program.getId();
    }

    @Override
    public String save(Program program) {
        if (program.getCreatedOn() == null)
            program.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        program.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            program.setSyncedOn(MPService.getSyncNeededDate());

        program = repository.save(program);
        return program.getId();
    }

    @Override
    public Program get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Program> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Program> findByRefId(String memberId) {
        return repository.findByRefId(memberId);
    }

    @Override
    public List<Program> findIdByRefId(String memberId) {
        return repository.findByRefId(memberId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}