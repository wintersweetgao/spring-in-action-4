package com.altruista.mp.services;

import com.altruista.mp.model.Sync;

/**
 * Created by mwixson on 10/15/14.
 */
public interface SyncService {
    String save(Sync sync);

    Sync get(String key);
}
