package com.altruista.mp.services;

import com.altruista.mp.model.AssessmentResponse;
import com.altruista.mp.repositories.AssessmentResponseRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

/*
 * created by PRATEEK A on 03/12/15
 */
public class AssessmentResponseServiceImpl extends MPService implements AssessmentResponseService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentResponseServiceImpl.class);

    private AssessmentResponseRepository repository = null;
    @Autowired
    MongoTemplate template;

    // default constructor
    public AssessmentResponseServiceImpl() {
    }

    @Autowired
    public AssessmentResponseServiceImpl(AssessmentResponseRepository repository) {
        this.repository = repository;
    }

    public String save(AssessmentResponse assessmentResponse, boolean sync) {
        /*if(assessmentResponse.getOptionValue() == null || assessmentResponse.getOptionValue().length() == 0)
            assessmentResponse.setOptionValue("New");*/

        // set the created on date if not provided
        if (assessmentResponse.getCreatedOn() == null)
            assessmentResponse.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        assessmentResponse.setUpdatedOn(DateTime.now());

        if (!sync)
            assessmentResponse.setSyncedOn(DateTime.now());
        else
            assessmentResponse.setSyncedOn(getSyncNeededDate());

        assessmentResponse = repository.save(assessmentResponse);
        return assessmentResponse.getId();
    }

    @Override
    public String save(AssessmentResponse assessmentResponse) {
        /*if(assessmentResponse.getOptionValue() == null || assessmentResponse.getOptionValue().length() == 0)
            assessmentResponse.setOptionValue("New");*/

        // set the created on date if not provided
        if (assessmentResponse.getCreatedOn() == null)
            assessmentResponse.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        assessmentResponse.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            assessmentResponse.setSyncedOn(MPService.getSyncNeededDate());

        assessmentResponse = repository.save(assessmentResponse);
        return assessmentResponse.getId();
    }

    @Override
    public AssessmentResponse get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<AssessmentResponse> findByRunId(String runId) {
        return repository.findByRunId(runId);
    }

    @Override
    public List<String> findIdByRunId(String runId) {
        Query q = new Query();
        q.fields().include("id");
        q.addCriteria(Criteria.where("runId").is(runId));

        return template.find(q, String.class, "assessmentResponse");
    }

    @Override
    public AssessmentResponse findOneByRunIdAndQuestionSequence(String runId, int sequence) {
        return repository.findOneByRunIdAndQuestion_Sequence(runId, sequence);
    }

    @Override
    public List<AssessmentResponse> findResponseIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

    @Override
    public List<AssessmentResponse> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(AssessmentResponse response) {
        repository.delete(response);
    }

    @Override
    public void deleteByRunId(String runId) {
        repository.deleteByRunId(runId);
    }

    @Override
    public void saveAssessmentResponses(List<AssessmentResponse> responses) {
        for (AssessmentResponse assessmentResponse : responses) {
            repository.save(assessmentResponse);
        }
    }
}
