package com.altruista.mp.services;

import com.altruista.mp.model.User;
import com.altruista.mp.services.exceptions.ServiceException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserService extends UserDetailsService {
    User get(String key);

    User getUserByUsername(String username) throws ServiceException;

    User getUserByContactCode(String username) throws ServiceException; //Newly Added

    void save(User user) throws ServiceException;

    void save(User user, boolean value) throws ServiceException;

    List<User> getAllUsers(int pageNumber, int pageSize) throws ServiceException;

    User getResetPassword(String username) throws ServiceException;

    List<User> findByRefId(String refId);

    List<User> findIdByRefId(String refId);

    List<User> findByContactId(String contactId);

    User findOneByContactId(String contactId);

    List<User> findByContactCode(String contactCode);

    List<User> findByMemberId(String memberId);

    List<String> getUserSuggestions(String username);
}