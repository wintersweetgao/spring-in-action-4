package com.altruista.mp.services;

import com.altruista.mp.model.User;
import com.altruista.mp.repositories.ClientRepository;
import com.altruista.mp.repositories.ContactRepository;
import com.altruista.mp.repositories.UserRepository;
import com.altruista.mp.services.exceptions.ServiceException;
import com.google.common.collect.FluentIterable;
import org.apache.commons.lang.RandomStringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.List;


public class UserServiceImpl extends MPService implements UserService {
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
    @Autowired
    UserRepository userRepository;
    @Autowired
    ClientRepository clientRepository;
    @Autowired
    ContactRepository contactRepository;

    @Override
    public User get(String key) {
        return userRepository.findOne(key);
    }

    @Override
    public User getUserByUsername(String username)
            throws UsernameNotFoundException {
        log.debug("Loading user by username = " + username);
        List<User> users = userRepository.findByUsername(username);

        if (users != null && users.size() > 0) {
            log.debug("Found user with username = " + users.get(0).getUsername());

            // load contact information
            if (users.get(0).getContactId() != null)
                users.get(0).setContact(contactRepository.findOne(users.get(0).getContactId()));

            return users.get(0);
        } else
            return null;
    }

    @Override
    public User getUserByContactCode(String contactCode) throws ServiceException {
        log.debug("Loading user by contact code = " + contactCode);
        List<User> users = userRepository.findByContactCode(contactCode);

        if (users != null && users.size() > 0) {
            log.debug("Found user with contact code = " + users.get(0).getUsername());

            // load contact information
            if (users.get(0).getContactId() != null)
                users.get(0).setContact(contactRepository.findOne(users.get(0).getContactId()));

            return users.get(0);
        } else
            return null;
    }

    @Override
    public List<String> getUserSuggestions(String username) {
        List<String> users = new ArrayList<String>();

        // if the requested username is unique, return it
        User user = this.getUserByUsername(username);
        if (user == null) {
            users.add(username);
            return users;
        }

        // otherwise search for a unique username
        do {
            StringBuilder suggestedUsername = new StringBuilder();
            suggestedUsername.append(username);
            suggestedUsername.append(RandomStringUtils.random(4, true, true));

            user = this.getUserByUsername(suggestedUsername.toString());
            if (user == null) {
                users.add(suggestedUsername.toString());
            }
        } while (users.size() != 3);
        return users;
    }

    public org.springframework.security.core.userdetails.UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return getUserByUsername(username);
    }

    public List<User> getAllUsers(int pageNumber, int pageSize)
            throws ServiceException {

        return FluentIterable.from(userRepository.findAll()).toList();
    }

    public User getResetPassword(String username) throws ServiceException {
        log.debug("Loading user by username(getResetPassword) = " + username);

        User user = getUserByUsername(username);

        if (user != null) {
            log.debug("Found user with username = " + user.getUsername());
        }

        return user;
    }

    @Override
    public List<User> findByRefId(String refId) {
        return userRepository.findByRefId(refId);
    }

    @Override
    public List<User> findIdByRefId(String refId) {
        return userRepository.findByRefId(refId);
    }

    @Override
    public List<User> findByContactId(String contactId) {
        return userRepository.findByContactId(contactId);
    }

    @Override
    public User findOneByContactId(String contactId) {
        User user = null;

        List<User> users = findByContactId(contactId);
        if (users != null && users.size() > 0)
            user = users.get(0);

        return user;
    }

    @Override
    public List<User> findByMemberId(String memberId) {
        return userRepository.findByMemberAuthoritiesMemberId(memberId);
    }

    @Override
    public List<User> findByContactCode(String contactCode) {
        return userRepository.findByContactCode(contactCode);
    }

    @Override
    public void save(User user) {
        userRepository.save(user);
    }

    @Override
    public void save(User user, boolean sync) {

        if (!sync)
            user.setSyncedOn(DateTime.now());
        else
            user.setSyncedOn(getSyncNeededDate());

        userRepository.save(user);
    }
}