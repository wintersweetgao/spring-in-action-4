package com.altruista.mp.utils;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.util.password.StrongPasswordEncryptor;
import org.springframework.beans.factory.annotation.Value;

/*
 * Developed by Prateek on 09/23/15
*/
public class CryptoHelper {
	
	private static String mpCryptoPassword;

    // @Ref: http://www.jasypt.org/
    public static String encryptString(String value) {
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(mpCryptoPassword);
        return encryptor.encrypt(value);
    }

    public static String decryptString(String value) {
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(mpCryptoPassword);
        return encryptor.decrypt(value);
    }

    public static String hashPassword(String password) {
        StrongPasswordEncryptor encryptor = new StrongPasswordEncryptor();
        return encryptor.encryptPassword(password);
    }

    public static boolean checkPassword(String plainPassword, String hashedPassword) {
        StrongPasswordEncryptor encryptor = new StrongPasswordEncryptor();
        return encryptor.checkPassword(plainPassword, hashedPassword);
    }
    
    @Value("${mp.crypto.password}")
	public void setMpCryptoPassword(String mpCryptoPassword) {
    	CryptoHelper.mpCryptoPassword = mpCryptoPassword;
	}
}