package com.altruista.mp.repositories;

import com.altruista.mp.model.User;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRepository extends CrudRepository<User, String> {

    /**
     * Additional custom finder method.
     */
    List<User> findByUsername(String username);

    List<User> findByRefId(String id);

    List<User> findByContactId(String id);

    List<User> findByContactCode(String contactCode);

    List<User> findByMemberAuthoritiesMemberId(String id);
}
