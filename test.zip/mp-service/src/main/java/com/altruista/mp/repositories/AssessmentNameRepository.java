package com.altruista.mp.repositories;

import com.altruista.mp.model.Assessment;
import org.springframework.data.repository.CrudRepository;

/**
 * created by PRATEEK on 03/04/2015
 */
public interface AssessmentNameRepository extends CrudRepository<Assessment, String> {

}
