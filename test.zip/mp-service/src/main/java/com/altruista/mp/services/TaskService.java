package com.altruista.mp.services;

import com.altruista.mp.model.Task;

import java.util.List;

/**
 * Created by Administrator on 7/1/2014.
 */
public interface TaskService {
    String save(Task Task, boolean value);

    String save(Task Task);

    void saveTasks(List<Task> tasks);

    Task get(String key);

    List<Task> findByMemberId(String memberId);

    List<Task> findByRefId(String refId);

    List<Task> findIdByRefId(String refId);

    List<Task> findTaskIdsToSync();

    void deleteTasks(List<Task> tasks);

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    void delete(String id);
}
