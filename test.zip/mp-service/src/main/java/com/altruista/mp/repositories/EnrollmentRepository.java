package com.altruista.mp.repositories;

import com.altruista.mp.model.Enrollment;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 9/21/15.
 */
public interface EnrollmentRepository extends CrudRepository<Enrollment, String> {
    List<Enrollment> findByMemberId(String id);

    List<Enrollment> findByRefId(String id);

    List<Enrollment> findBySyncedOn(DateTime syncedOn);
}
