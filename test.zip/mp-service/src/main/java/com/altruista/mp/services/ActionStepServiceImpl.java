package com.altruista.mp.services;

import com.altruista.mp.model.ActionStep;
import com.altruista.mp.repositories.ActionStepRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ActionStepServiceImpl extends MPService implements ActionStepService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ActionStepServiceImpl.class);

    private ActionStepRepository repository = null;

    @Autowired
    public ActionStepServiceImpl(ActionStepRepository repository) {
        this.repository = repository;
    }

    public ActionStepServiceImpl() {
        // no arg constructor
    }

    public String save(ActionStep actionStep, boolean sync) {
        if (actionStep.getStatus() == null || actionStep.getStatus().length() == 0)
            actionStep.setStatus("New");

        // set the created on date if not provided
        if (actionStep.getCreatedOn() == null)
            actionStep.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        actionStep.setUpdatedOn(DateTime.now());

        if (!sync)
            actionStep.setSyncedOn(DateTime.now());
        else
            actionStep.setSyncedOn(getSyncNeededDate());

        actionStep = repository.save(actionStep);
        return actionStep.getId();
    }

    public String save(ActionStep actionStep) {
        if (actionStep.getStatus() == null || actionStep.getStatus().length() == 0)
            actionStep.setStatus("New");

        // set the created on date if not provided
        if (actionStep.getCreatedOn() == null)
            actionStep.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        actionStep.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            actionStep.setSyncedOn(MPService.getSyncNeededDate());

        actionStep = repository.save(actionStep);
        return actionStep.getId();
    }

    public ActionStep get(String key) {
        return repository.findOne(key);
    }

    public List<ActionStep> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    public List<ActionStep> findByGoalId(String goalId) {
        return repository.findByGoalId(goalId);
    }

    public List<ActionStep> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    public List<ActionStep> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    public List<ActionStep> findActionStepIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

    public void delete(String id) {
        repository.delete(id);
    }
}