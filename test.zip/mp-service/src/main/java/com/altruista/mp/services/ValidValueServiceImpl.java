package com.altruista.mp.services;

import com.altruista.mp.model.ValidValue;
import com.altruista.mp.repositories.ValidValueRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ValidValueServiceImpl extends MPService implements ValidValueService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ValidValueServiceImpl.class);

    private ValidValueRepository repository = null;

    @Autowired
    public ValidValueServiceImpl(ValidValueRepository repository) {
        this.repository = repository;
    }

    public ValidValueServiceImpl() {
        // no arg constructor
    }

    @Override
    public String save(ValidValue value, boolean sync) {
        value = repository.save(value);
        return value.getId();
    }

    @Override
    public String save(ValidValue value) {
        value = repository.save(value);
        return value.getId();
    }

    @Override
    public ValidValue get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<ValidValue> findByName(String name) {
        return repository.findByName(name);
    }

    @Override
    public List<ValidValue> findByNameAndRefId(String name, String refId) {
        return repository.findByNameAndRefId(name, refId);
    }

    @Override
    public List<ValidValue> findIdByNameAndRefId(String name, String refId) {
        return repository.findByNameAndRefId(name, refId);
    }

    @Override
    public List<ValidValue> findByNameAndValue(String name, String value, boolean startsWith) {
        List<ValidValue> validValues;
        if (startsWith)
            validValues = repository.findByNameAndValueStartsWith(name, value);
        else
            validValues = repository.findByNameAndValue(name, value);
        return validValues;
    }

    @Override
    public List<ValidValue> findByNameAndDescription(String name, String description, boolean startsWith) {
        List<ValidValue> validValues;
        if (startsWith)
            validValues = repository.findByNameAndDescriptionStartsWith(name, description);
        else
            validValues = repository.findByNameAndDescription(name, description);
        return validValues;
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}
