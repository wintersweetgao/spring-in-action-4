package com.altruista.mp.services;

import com.altruista.mp.model.MemberIndex;
import com.altruista.mp.repositories.MemberIndexRepository;
import com.altruista.mp.utils.CryptoHelper;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by mwixson on 9/24/15.
 */
public class MemberIndexServiceImpl extends MPService implements MemberIndexService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberIndexServiceImpl.class);
    private MemberIndexRepository repository = null;
    
    @Value("${guidingCare.member.indexes}")
    private String guidingCareMemberIndexes;

    @Autowired
    public MemberIndexServiceImpl(MemberIndexRepository repository) {
        this.repository = repository;
    }

    public MemberIndexServiceImpl() {
        // no arg constructor
    }

    private List<String> getIndexes() {
        List<String> indexes = new ArrayList<>();

        StringTokenizer st = new StringTokenizer(guidingCareMemberIndexes);
        while (st.hasMoreTokens())
            indexes.add(st.nextToken());

        return indexes;
    }

    public String save(MemberIndex index, boolean sync) {
        if (index.getCreatedOn() == null)
            index.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        index.setUpdatedOn(DateTime.now());

        if (!sync)
            index.setSyncedOn(DateTime.now());
        else
            index.setSyncedOn(getSyncNeededDate());

        // hash any indexes marked as secure or which contain SSN in the name
        if ((index.getIndexType() != null && index.getIndexType().equals("S") ||
                (index.getIndexName() != null && index.getIndexName().contains("SSN")))) {
            String cipherText = CryptoHelper.hashPassword(index.getIndexValue());
            index.setIndexValue(cipherText);
        }

        index = repository.save(index);
        return index.getId();
    }

    @Override
    public String save(MemberIndex index) {
        return save(index, isSyncEnabled());
    }

    @Override
    public MemberIndex get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<MemberIndex> findIdByRefIdAndIndexNameAndIndexValue(String refId, String indexName, String indexValue) {
        return repository.findIdByRefIdAndIndexNameAndIndexValue(refId, indexName, indexValue);
    }

    @Override
    public List<MemberIndex> findByMemberIndexesAndValue(String indexValue) {
        return repository.findByIndexNameInAndIndexValue(getIndexes(), indexValue);
    }

    @Override
    public List<MemberIndex> findByIndexNameInAndValue(List<String> indexNames, String indexValue) {
        return repository.findByIndexNameInAndIndexValue(indexNames, indexValue);
    }

    @Override
    public MemberIndex findOneByMemberIdAndIndexName(String memberId, String indexName) {
        List<MemberIndex> indexes = repository.findByMemberIdAndIndexName(memberId, indexName);
        if (indexes.size() > 0)
            return indexes.get(0);
        else
            return null;
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    @Override
    public List<MemberIndex> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }
}
