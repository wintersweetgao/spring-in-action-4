package com.altruista.mp.services;

import com.altruista.mp.model.CommunicationImpairment;

import java.util.List;

/**
 * Created by mwixson on 10/19/14.
 */
public interface CommunicationImpairmentService {
    String save(CommunicationImpairment allergy, boolean value);

    String save(CommunicationImpairment allergy);

    CommunicationImpairment get(String key);

    List<CommunicationImpairment> findByMemberId(String memberId);

    List<CommunicationImpairment> findByRefId(String refId);

    List<CommunicationImpairment> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
