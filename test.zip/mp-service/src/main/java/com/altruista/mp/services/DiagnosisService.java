package com.altruista.mp.services;

import com.altruista.mp.model.Diagnosis;

import java.util.List;

/**
 * Created by mwixson on 6/20/14.
 */
public interface DiagnosisService {
    String save(Diagnosis diagnosis, boolean value);

    String save(Diagnosis diagnosis);

    Diagnosis get(String key);

    List<Diagnosis> findByMemberId(String memberId);

    List<Diagnosis> findByRefId(String refId);

    List<Diagnosis> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
