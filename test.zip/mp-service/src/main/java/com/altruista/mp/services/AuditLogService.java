package com.altruista.mp.services;

import com.altruista.mp.model.AuditLog;

/**
 * Created by mwixson on 1/18/15.
 */
public interface AuditLogService {
    void save(AuditLog log);
}
