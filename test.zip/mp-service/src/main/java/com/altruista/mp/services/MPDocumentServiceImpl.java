package com.altruista.mp.services;

import com.altruista.mp.model.MPDocument;
import com.altruista.mp.repositories.MPDocumentRepository;
import com.altruista.mp.services.exceptions.ServiceException;
import com.google.common.collect.FluentIterable;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.List;

/**
 * Created by mwixson on 7/29/14.
 */
public class MPDocumentServiceImpl extends MPService implements MPDocumentService {
    static {
        //for localhost testing only
        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
                new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostname,
                                          javax.net.ssl.SSLSession sslSession) {
                        if (hostname.contains("personalcarerecord") || hostname.contains("localhost")) {
                            return true;
                        }
                        return false;
                    }
                });
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(MPDocumentServiceImpl.class);
    private static String[] images = {"png", "gif", "jpg"};

    private MPDocumentRepository repository = null;

    @Autowired
    public MPDocumentServiceImpl(MPDocumentRepository repository) {
        this.repository = repository;
    }

    public MPDocumentServiceImpl() {
        // no arg constructor
    }

    public String save(MPDocument doc, boolean sync) {
        // set the created on date if not provided
        if (doc.getCreatedOn() == null)
            doc.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        doc.setUpdatedOn(DateTime.now());

        if (!sync)
            doc.setSyncedOn(DateTime.now());
        else
            doc.setSyncedOn(getSyncNeededDate());

        doc = repository.save(doc);
        return doc.getId();
    }

    public String save(MPDocument doc) {
        // set the created on date if not provided
        if (doc.getCreatedOn() == null)
            doc.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        doc.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            doc.setSyncedOn(MPService.getSyncNeededDate());

        doc = repository.save(doc);
        return doc.getId();
    }

    public MPDocument get(String key) {
        return repository.findOne(key);
    }

    public List<MPDocument> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    public List<MPDocument> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    public List<MPDocument> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    public List<MPDocument> findAll() {
        return FluentIterable.from(repository.findAll()).toList();
    }

    public String getEncodedImageFile(MPDocument document) throws ServiceException {
        if (document.getDocumentUrl() == null || document.getDocumentType() == null)
            return null;

        if (!Arrays.asList(images).contains(document.getDocumentType()))
            throw new ServiceException("Invalid image type: " + document.getDocumentType());

        try {
            BufferedImage bufferedImage = ImageIO.read(new File(document.getDocumentUrl()));
            return encodeToString(bufferedImage, document.getDocumentType());
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    public String getEncodedImageResource(MPDocument document) throws ServiceException {
        if (document.getDocumentUrl() == null || document.getDocumentType() == null)
            return null;

        if (!Arrays.asList(images).contains(document.getDocumentType()))
            throw new ServiceException("Invalid image type: " + document.getDocumentType());

        try {
            URL url = new URL(document.getDocumentUrl());
            //response.setHeader("Content-Type", "text/csv");
            //response.setHeader("Content-disposition", "attachment;filename="+);
            URLConnection connection = url.openConnection();
            InputStream stream = connection.getInputStream();
            BufferedImage bufferedImage = ImageIO.read(stream);

            return encodeToString(bufferedImage, document.getDocumentType());
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    private static String encodeToString(BufferedImage image, String type) {

        String imageString = null;
        String encodedImage = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();

            encodedImage = org.apache.commons.codec.binary.Base64.encodeBase64String(imageBytes);

            imageString = "data:image/" + type + ";base64," + encodedImage;

            bos.close();
        } catch (IOException e) {
            LOGGER.error("Unable to encode string: " + e);
        }
        return imageString;
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    @Override
    public List<MPDocument> findByTags(List<String> tags) {
        List<MPDocument> docs = repository.findByTagsIn(tags);
        return docs;
    }
}
