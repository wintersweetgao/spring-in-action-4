package com.altruista.mp.services;

import com.altruista.mp.model.SyncLog;
import com.altruista.mp.repositories.SyncLogRepository;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by mwixson on 5/22/15.
 */
public class SyncLogServiceImpl implements SyncLogService {
    @Autowired
    SyncLogRepository repository;

    @Override
    public void save(SyncLog log) {
        log.setCreatedOn(DateTime.now());
        repository.save(log);
    }
}
