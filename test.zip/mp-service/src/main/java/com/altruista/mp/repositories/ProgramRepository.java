package com.altruista.mp.repositories;

import com.altruista.mp.model.Program;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 10/16/14.
 */
public interface ProgramRepository extends CrudRepository<Program, String> {

    /**
     * Additional custom finder method.
     */
    List<Program> findByMemberId(String id);

    List<Program> findByRefId(String id);

    List<Program> findByMemberIdAndLobIn(String memberId, List<String> lobs);
}
