package com.altruista.mp.services;

import com.altruista.mp.model.SyncLog;

/**
 * Created by mwixson on 5/22/15.
 */
public interface SyncLogService {
    void save(SyncLog log);
}
