package com.altruista.mp.services;

import com.altruista.mp.model.AssessmentRun;
import com.altruista.mp.repositories.AssessmentRunRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

public class AssessmentRunServiceImpl extends MPService implements AssessmentRunService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentRunServiceImpl.class);

    private AssessmentRunRepository repository = null;

    // default constructor
    public AssessmentRunServiceImpl() {
    }

    @Autowired
    public AssessmentRunServiceImpl(AssessmentRunRepository repository) {
        this.repository = repository;
    }

    public String save(AssessmentRun assessmentRun, boolean sync) {
        if (assessmentRun.getStatus() == null || assessmentRun.getStatus().length() == 0)
            assessmentRun.setStatus("New");

        // set the created on date if not provided
        if (assessmentRun.getCreatedOn() == null)
            assessmentRun.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        assessmentRun.setUpdatedOn(DateTime.now());

        if (!sync)
            assessmentRun.setSyncedOn(DateTime.now());
        else
            assessmentRun.setSyncedOn(getSyncNeededDate());

        assessmentRun = repository.save(assessmentRun);
        return assessmentRun.getId();
    }

    public String save(AssessmentRun assessmentRun) {
        if (assessmentRun.getStatus() == null || assessmentRun.getStatus().length() == 0)
            assessmentRun.setStatus("New");

        // set the created on date if not provided
        if (assessmentRun.getCreatedOn() == null)
            assessmentRun.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        assessmentRun.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            assessmentRun.setSyncedOn(MPService.getSyncNeededDate());

        assessmentRun = repository.save(assessmentRun);
        return assessmentRun.getId();
    }

    @Override
    public AssessmentRun get(String key) {
        AssessmentRun assessmentRun;
        assessmentRun = repository.findOne(key);
        return assessmentRun;
    }

    @Override
    public List<AssessmentRun> findByMemberId(String memberId) {
        List<AssessmentRun> assessmentRuns = repository.findByMemberId(memberId);
        return assessmentRuns;
    }

    @Override
    public List<AssessmentRun> findRunIdsToSync() {
        List<AssessmentRun> assessmentRuns = repository.findBySyncedOn(MPService.getSyncNeededDate());
        return assessmentRuns;
    }

    @Override
    public List<AssessmentRun> findByRefId(String refId) {
        List<AssessmentRun> assessmentRuns = repository.findByRefId(refId);
        return assessmentRuns;
    }

    @Override
    public List<AssessmentRun> findByMemberIdAndAssessmentId(String memberId, String assessmentId) {
        List<AssessmentRun> assessmentRuns = repository.findByMemberIdAndAssessmentId(memberId, assessmentId);
        return assessmentRuns;
    }

    @Override
    public List<AssessmentRun> findByAssessmentIdAndStatus(String assessmentId, String status) {
        List<AssessmentRun> assessmentRuns = repository.findByAssessmentIdAndStatus(assessmentId, status);
        return assessmentRuns;
    }

    @Override
    public void delete(String id) {
        LOGGER.debug("Assessment Run Deleted : " + id);
        repository.delete(id);
    }

    /*
     *
    */
    @Override
    public void update(String runId, DateTime endTime) {
        AssessmentRun assessmentRuns = repository.findOne(runId);

        // set endTime to be save in mongodb
        assessmentRuns.setEndedOn(endTime);
        repository.save(assessmentRuns);
    }

    @Override
    public List<AssessmentRun> findByFollowupRefId(String followupRefId) {
        return repository.findByFollowupRefId(followupRefId);
    }

    @Override
    public List<AssessmentRun> findByMemberIdAndStatusNotIn(String memberId, Collection<String> status) {
        return repository.findByMemberIdAndStatusNotIn(memberId, status);
    }
}
