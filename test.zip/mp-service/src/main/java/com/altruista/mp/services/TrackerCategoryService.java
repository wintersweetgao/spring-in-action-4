package com.altruista.mp.services;

import com.altruista.mp.model.TrackerCategory;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public interface TrackerCategoryService {
    String save(TrackerCategory category, boolean value);

    String save(TrackerCategory category);

    TrackerCategory get(String key);

    List<TrackerCategory> findByRefId(String refId);

    void delete(String id);

    List<TrackerCategory> getAllCategories();

    List<TrackerCategory> getTrackerCategoriesByMemberCondition(String conditions);
}
