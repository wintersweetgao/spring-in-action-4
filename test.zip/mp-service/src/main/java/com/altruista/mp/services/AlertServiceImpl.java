package com.altruista.mp.services;

import com.altruista.mp.model.*;
import com.altruista.mp.repositories.*;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AlertServiceImpl extends MPService implements AlertService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertServiceImpl.class);

    private MessageRepository messageRepository = null;
    private TaskRepository taskRepository = null;
    private DiagnosisRepository diagnosisRepository = null;
    private MedicationRepository medicationRepository = null;
    private ConditionRepository conditionRepository = null;
    private MPDocumentRepository mpDocumentRepository = null;
    private ActionStepRepository actionStepRepository = null;
    private TrackerRecordRepository trackerRecordRepository = null;
    
    @Value("${mp.mmc.signup.url}")
    private String mpMMCSignupUrl;

    @Autowired
    public EnrollmentService enrollmentService;

    @Autowired
    public AssessmentRunService assessmentRunService;

    @Autowired
    public AlertServiceImpl(MessageRepository messageRepository,
                            TaskRepository taskRepository,
                            DiagnosisRepository diagnosisRepository,
                            MedicationRepository medicationRepository,
                            ConditionRepository conditionRepository,
                            MPDocumentRepository mpDocumentRepository,
                            ActionStepRepository actionStepRepository,
                            TrackerRecordRepository trackerRecordRepository) {
        this.messageRepository = messageRepository;
        this.taskRepository = taskRepository;
        this.diagnosisRepository = diagnosisRepository;
        this.medicationRepository = medicationRepository;
        this.conditionRepository = conditionRepository;
        this.mpDocumentRepository = mpDocumentRepository;
        this.actionStepRepository = actionStepRepository;
        this.trackerRecordRepository = trackerRecordRepository;
    }

    public AlertServiceImpl() {
        // no arg constructor
    }

    @Override
    public List<Alert> findByMemberIdAndCreatedOn(String memberId, Collection<? extends GrantedAuthority> authorities, DateTime accessedOn) {
        List<Alert> alerts = new ArrayList<Alert>();

        // Generate alerts related to MMC
        if (enrollmentService.isEligibleForMMC(memberId, authorities)) {
            Alert alert = new Alert();
            alert.setMemberId(memberId);
            alert.setCount(1);
            alert.setMessageCode("mp.alert.mmc.signup.message");
            alert.setUrlMessageCode("mp.alert.mmc.signup.clickhere");
            alert.setUrl(mpMMCSignupUrl);
            alert.setSource("ENROLLMENT");

            alerts.add(alert);
        }

        Boolean viewed = false;

        // For Assessment Completion
        Collection<String> status = new ArrayList<String>();
        status.add("Completed");
        List<AssessmentRun> assessmentRunStatus = assessmentRunService.findByMemberIdAndStatusNotIn(memberId, status);

        // Generate alerts related to data changes
        List<Message> messages = messageRepository.findByMemberIdAndCreatedOnGreaterThanAndViewed(memberId, accessedOn, viewed);
        List<Task> tasks = taskRepository.findByMemberIdAndCreatedOnGreaterThan(memberId, accessedOn);
        List<Diagnosis> diagnosis = diagnosisRepository.findByMemberIdAndCreatedOnGreaterThan(memberId, accessedOn);
        List<Medication> medications = medicationRepository.findByMemberIdAndCreatedOnGreaterThan(memberId, accessedOn);
        List<Condition> conditions = conditionRepository.findByMemberIdAndCreatedOnGreaterThan(memberId, accessedOn);
        List<MPDocument> mpDocs = mpDocumentRepository.findByMemberIdAndCreatedOnGreaterThan(memberId, accessedOn);
        List<ActionStep> actionStep = actionStepRepository.findByMemberIdAndCreatedOnGreaterThan(memberId, accessedOn);
        List<TrackerRecord> trackerRecord = trackerRecordRepository.findByMemberIdAndCreatedOnGreaterThan(memberId, accessedOn);

        if (!conditions.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.conditions", "CONDITION", conditions.size()));
        if (!medications.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.medications", "MEDICATION", medications.size()));
        if (!diagnosis.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.diagnoses", "DIAGNOSIS", diagnosis.size()));
        if (!messages.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.messages", "MESSAGES", messages.size()));
        if (!tasks.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.appointments", "CALENDAR", tasks.size()));
        if (!assessmentRunStatus.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.assessments", "ASSESSMENT", assessmentRunStatus.size()));
        if (!mpDocs.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.documents", "MPDOCUMENT", mpDocs.size()));
        if (!actionStep.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.actionSteps", "ACTION_STEPS", actionStep.size()));
        if (!trackerRecord.isEmpty())
            alerts.add(new Alert(memberId, "mp.alert.trackerRecords", "TRACKER_RECORDS", trackerRecord.size()));


        return alerts;
    }
}
