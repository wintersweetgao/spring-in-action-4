package com.altruista.mp.repositories;

import com.altruista.mp.model.Lob;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 10/16/14.
 */
public interface LobRepository extends CrudRepository<Lob, String> {

    /**
     * Additional custom finder method.
     */
    List<Lob> findByMemberId(String id);

    List<Lob> findByRefId(String id);

    List<Lob> findByMemberIdAndNameIn(String memberId, List<String> lobs);
}
