package com.altruista.mp.services;

import com.altruista.mp.model.ContactDistance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/*
 * Developed by Prateek on 06/19/15
*/

public interface ContactDistanceService {
    // Developed for Pagination ContactDistance
    Page<ContactDistance> getContactDistanceByPosition(
            List<String> keywords, List<String> tags, Double lat, Double lon, Double radius, Pageable pageable);

    Page<ContactDistance> getContactDistanceByPostalCode(
            List<String> keywords, List<String> tags, String postalCode, Pageable pageable);
}
