package com.altruista.mp.repositories;

import com.altruista.mp.model.SyncLog;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by mahesh on 11/17/14.
 */
public interface SyncLogRepository extends CrudRepository<SyncLog, String> {

}

