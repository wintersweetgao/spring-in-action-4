package com.altruista.mp.services;

import com.altruista.mp.model.Assessment;
import com.altruista.mp.repositories.AssessmentRepository;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 2/17/15.
 */
public class AssessmentServiceImpl extends MPService implements AssessmentService {
    @Autowired
    private AssessmentRepository repository;
    @Autowired
    MongoTemplate template;

    public AssessmentServiceImpl() {
        // no arg constructor
    }

    public String save(Assessment assessment, boolean sync) {
        // set the created on date if not provided
        if (assessment.getCreatedOn() == null)
            assessment.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        assessment.setUpdatedOn(DateTime.now());

        if (!sync)
            assessment.setSyncedOn(DateTime.now());
        else
            assessment.setSyncedOn(getSyncNeededDate());

        assessment = repository.save(assessment);
        return assessment.getId();
    }

    @Override
    public String save(Assessment assessment) {
        // set the created on date if not provided
        if (assessment.getCreatedOn() == null)
            assessment.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        assessment.setUpdatedOn(DateTime.now());

        assessment = repository.save(assessment);
        return assessment.getId();
    }

    @Override
    public Assessment get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Assessment> findAll() {
        return (List<Assessment>) repository.findAll();
    }

    @Override
    public List<String> findAllNames() {
        Query q = new Query();
        q.fields().include("name");

        List<String> names = new ArrayList<>();
        List<Assessment> assessments = template.find(q, Assessment.class);
        for (Assessment assessment : assessments)
            names.add(assessment.getName());
        return names;
    }

    @Override
    public List<Assessment> findByName(String name) {
        return repository.findByName(name);
    }

    @Override
    public List<Assessment> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<String> findIdByRefId(String refId) {
        Query q = new Query();
        q.fields().include("id");
        q.addCriteria(Criteria.where("refId").is(refId));

        return template.find(q, String.class);
    }

    @Override
    public void delete(Assessment assessment) {
        repository.delete(assessment);
    }
}
