package com.altruista.mp.services;

import com.altruista.mp.model.AllergySensitivity;
import com.altruista.mp.repositories.AllergySensitivityRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class AllergySensitivityServiceImpl extends MPService implements AllergySensitivityService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AllergySensitivityServiceImpl.class);

    private AllergySensitivityRepository repository = null;

    @Autowired
    public AllergySensitivityServiceImpl(AllergySensitivityRepository repository) {
        this.repository = repository;
    }

    public AllergySensitivityServiceImpl() {
        // no arg constructor
    }

    public String save(AllergySensitivity allergy, boolean sync) {
        if (allergy.getCreatedOn() == null)
            allergy.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        allergy.setUpdatedOn(DateTime.now());

        if (!sync)
            allergy.setSyncedOn(DateTime.now());
        else
            allergy.setSyncedOn(getSyncNeededDate());

        allergy = repository.save(allergy);
        return allergy.getId();
    }

    public String save(AllergySensitivity allergy) {
        if (allergy.getCreatedOn() == null)
            allergy.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        allergy.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            allergy.setSyncedOn(MPService.getSyncNeededDate());

        allergy = repository.save(allergy);
        return allergy.getId();
    }

    @Override
    public AllergySensitivity get(String key) {
        AllergySensitivity allergy;

        allergy = repository.findOne(key);
        return allergy;
    }

    @Override
    public List<AllergySensitivity> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<AllergySensitivity> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<AllergySensitivity> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}