package com.altruista.mp.repositories;

import com.altruista.mp.model.CommunicationImpairment;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 10/19/14.
 */
public interface CommunicationImpairmentRepository extends CrudRepository<CommunicationImpairment, String> {

    /**
     * Additional custom finder method.
     */
    List<CommunicationImpairment> findByMemberId(String id);

    List<CommunicationImpairment> findByRefId(String id);
}