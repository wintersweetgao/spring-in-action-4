package com.altruista.mp.repositories;

import com.altruista.mp.model.TrackerCategory;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public interface TrackerCategoryRepository extends CrudRepository<TrackerCategory, String> {
    List<TrackerCategory> findByRefId(String id);
}
