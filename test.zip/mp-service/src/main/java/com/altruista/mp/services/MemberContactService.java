package com.altruista.mp.services;

import com.altruista.mp.model.ContactType;
import com.altruista.mp.model.MemberContact;

import java.util.List;

/**
 * Created by mwixson on 9/18/14.
 */
public interface MemberContactService {
    String save(MemberContact relationship, boolean value);

    String save(MemberContact relationship);

    MemberContact get(String key);

    List<MemberContact> findByMemberId(String memberId);

    List<MemberContact> findByMemberIdAndContactType(String memberId, ContactType contactType);

    List<MemberContact> findByRefIdAndContactType(String refId, ContactType contactType);

    List<MemberContact> findIdByRefIdAndContactType(String refId, ContactType contactType);

    List<String> findByContactId(String contactId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
