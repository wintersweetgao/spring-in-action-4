package com.altruista.mp.services;

import com.altruista.mp.model.Tracker;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public interface TrackerService {
    String save(Tracker tracker, boolean value);

    String save(Tracker tracker);

    Tracker get(String key);

    List<Tracker> findByRefId(String refId);

    void delete(String id);

    List<Tracker> getTrackersByCategoryId(String categoryId);

    List<Tracker> getAllTrackers();
}
