package com.altruista.mp.services;

import com.altruista.mp.model.Enrollment;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

/**
 * Created by mwixson on 9/21/15.
 */
@Service
public interface EnrollmentService {
    String save(Enrollment enrollment, boolean value);

    String save(Enrollment enrollment);

    Enrollment get(String key);

    List<Enrollment> findByRefId(String refId);

    List<Enrollment> findByMemberId(String memberId);

    List<Enrollment> findEnrollmentIdsToSync();

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    void delete(String id);

    boolean isEligibleForMMC(String memberId, Collection<? extends GrantedAuthority> collection);
}