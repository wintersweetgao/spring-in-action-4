package com.altruista.mp.services;

import com.altruista.mp.model.Goal;
import com.altruista.mp.repositories.GoalRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class GoalServiceImpl extends MPService implements GoalService {
    private static final Logger LOGGER = LoggerFactory.getLogger(GoalServiceImpl.class);

    private GoalRepository repository = null;

    @Autowired
    public GoalServiceImpl(GoalRepository goalRepository) {
        this.repository = goalRepository;
    }

    public GoalServiceImpl() {
        // no arg constructor
    }

    public String save(Goal goal, boolean sync) {
        // set the created on date if not provided
        if (goal.getCreatedOn() == null)
            goal.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        goal.setUpdatedOn(DateTime.now());

        if (!sync)
            goal.setSyncedOn(DateTime.now());
        else
            goal.setSyncedOn(getSyncNeededDate());

        goal = repository.save(goal);
        return goal.getId();
    }

    public String save(Goal goal) {
        // set the created on date if not provided
        if (goal.getCreatedOn() == null)
            goal.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        goal.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            goal.setSyncedOn(MPService.getSyncNeededDate());

        goal = repository.save(goal);
        return goal.getId();
    }

    @Override
    public Goal get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Goal> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Goal> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Goal> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Goal> findGoalIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}