package com.altruista.mp.repositories;

import com.altruista.mp.model.ActionStep;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 8/11/14.
 */
public interface ActionStepRepository extends CrudRepository<ActionStep, String> {

    /**
     * Additional custom finder method.
     */
    List<ActionStep> findByGoalId(String id);

    List<ActionStep> findByMemberId(String id);

    List<ActionStep> findByRefId(String id);

    List<ActionStep> findBySyncedOn(DateTime time);

    List<ActionStep> findByMemberIdAndCreatedOnGreaterThan(String memberId, DateTime accessedOn);
}
