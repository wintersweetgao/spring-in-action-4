package com.altruista.mp.services;

import com.altruista.mp.model.PushNotificationRegistration;

/*
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by PRATEEK on 10/20/15
 */
public interface PushNotificationRegistrationService {
    String save(PushNotificationRegistration pushNotificationRegistration);

    PushNotificationRegistration findByContactId(String contactId);
}
