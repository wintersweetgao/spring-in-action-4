package com.altruista.mp.repositories;

import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;
import org.joda.time.DateTime;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Point;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/*
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by Prateek on 07/14/15
 */
public interface ContactRepository extends CrudRepository<Contact, String> {
    List<Contact> findByRefIdAndContactType(String id, String contactType);

    List<Contact> findByContactTypeAndAddress_PositionNear(ContactType contactType, Point point, Distance radius);

    List<Contact> findByAddress_PositionNear(Point point, Distance radius);

    List<Contact> findByContactTypeAndAddress_PostalCode(ContactType contactType, String postalCode);

    List<Contact> findBySyncedOn(DateTime syncedOn);

    List<Contact> findByPrimaryEmail(String primaryEmail);

    List<Contact> findByContactCode(String contactCode);

    List<Contact> findById(String id);
}
