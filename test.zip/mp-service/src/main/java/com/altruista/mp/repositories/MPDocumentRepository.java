package com.altruista.mp.repositories;

import com.altruista.mp.model.MPDocument;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 7/29/14.
 */
public interface MPDocumentRepository extends CrudRepository<MPDocument, String> {
    List<MPDocument> findByMemberId(String id);

    List<MPDocument> findByRefId(String id);

    List<MPDocument> findByTagsIn(List<String> tags);

    List<MPDocument> findByMemberIdAndCreatedOnGreaterThan(String memberId, DateTime createdOn);
}
