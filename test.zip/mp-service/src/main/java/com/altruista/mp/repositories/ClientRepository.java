package com.altruista.mp.repositories;

import com.altruista.mp.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientRepository extends CrudRepository<Client, String> {

    /**
     * Additional custom finder method.
     */
}
