package com.altruista.mp.repositories;

import com.altruista.mp.model.Condition;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ConditionRepository extends CrudRepository<Condition, String> {

    /**
     * Additional custom finder method.
     */
    List<Condition> findByMemberId(String id);

    List<Condition> findByMemberIdAndCreatedOnGreaterThan(String id, DateTime createdOn);

    List<Condition> findByRefId(String id);
}
