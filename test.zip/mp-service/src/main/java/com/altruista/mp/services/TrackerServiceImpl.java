package com.altruista.mp.services;

import com.altruista.mp.model.Tracker;
import com.altruista.mp.repositories.TrackerRepository;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerServiceImpl extends MPService implements TrackerService {
    @Autowired
    TrackerRepository repository;

    public String save(Tracker tracker, boolean sync) {
        // set the created on date if not provided
        if (tracker.getCreatedOn() == null)
            tracker.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        tracker.setUpdatedOn(DateTime.now());

        if (!sync)
            tracker.setSyncedOn(DateTime.now());
        else
            tracker.setSyncedOn(getSyncNeededDate());

        tracker = repository.save(tracker);
        return tracker.getId();
    }

    @Override
    public String save(Tracker tracker) {
        // set the created on date if not provided
        if (tracker.getCreatedOn() == null)
            tracker.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        tracker.setUpdatedOn(DateTime.now());

        tracker = repository.save(tracker);
        return tracker.getId();
    }

    @Override
    public Tracker get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Tracker> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    @Override
    public List<Tracker> getTrackersByCategoryId(String categoryId) {
        return repository.findByCategoryId(categoryId);
    }

    @Override
    public List<Tracker> getAllTrackers() {
        return (List<Tracker>) repository.findAll();
    }

}
