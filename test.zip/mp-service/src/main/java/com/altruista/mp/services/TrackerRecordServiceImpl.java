package com.altruista.mp.services;

import com.altruista.mp.model.TrackerRecord;
import com.altruista.mp.repositories.TrackerRecordRepository;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerRecordServiceImpl extends MPService implements TrackerRecordService {
    @Autowired
    TrackerRecordRepository repository;

    @Autowired
    private MongoTemplate template;

    public String save(TrackerRecord record, boolean sync) {
        // set the created on date if not provided
        if (record.getCreatedOn() == null)
            record.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        record.setUpdatedOn(DateTime.now());

        if (!sync)
            record.setSyncedOn(DateTime.now());
        else
            record.setSyncedOn(getSyncNeededDate());

        record = repository.save(record);
        return record.getId();
    }

    @Override
    public String save(TrackerRecord record) {
        // set the created on date if not provided
        if (record.getCreatedOn() == null)
            record.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        record.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            record.setSyncedOn(MPService.getSyncNeededDate());

        record = repository.save(record);
        return record.getId();
    }

    @Override
    public TrackerRecord get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<TrackerRecord> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    /**
     * Show only a documents with a "recordedOn" date between start and end
     */
    @Override
    public List<TrackerRecord> getTrackerRecordsByMemberIdAndTrackerIdAndRecordOn(String memberId, String trackerId, String startDate, String endDate) {

        Query q = new Query();
        q.addCriteria(Criteria.where("memberId").is(memberId));
        q.addCriteria(Criteria.where("trackerId").is(trackerId));

        if (startDate != null && endDate != null) {
            DateTime startDateTime = DateTime.parse(startDate, DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
            DateTime endDateTime = DateTime.parse(endDate, DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

            q.addCriteria(Criteria.where("recordedOn").gte(startDateTime).lte(endDateTime));
        } else {
            if (startDate != null) {
                q.addCriteria(Criteria.where("recordedOn").gte(startDate));
            }

            if (endDate != null) {
                q.addCriteria(Criteria.where("recordedOn").lte(endDate));
            }
        }


        //Find methods that take a Query to express the query and that return a List of objects.
        return template.find(q, TrackerRecord.class);
    }

    @Override
    public List<TrackerRecord> findTrackerIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }
}
