package com.altruista.mp.services.exceptions;

public class ServiceException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = -4604956245800080736L;

    public ServiceException(String description) {
        super(description);
    }

    public ServiceException(Exception exc) {
        super(exc);
    }
}
