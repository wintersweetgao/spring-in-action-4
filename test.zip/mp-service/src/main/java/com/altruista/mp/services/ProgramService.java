package com.altruista.mp.services;

import com.altruista.mp.model.Program;

import java.util.List;

/**
 * Created by mwixson on 10/16/14.
 */
public interface ProgramService {
    String save(Program program, boolean value);

    String save(Program program);

    Program get(String key);

    List<Program> findByMemberId(String memberId);

    List<Program> findByRefId(String refId);

    List<Program> findIdByRefId(String refId);

    void setSyncEnabled(boolean syncEnabled);

    boolean isSyncEnabled();

    void delete(String id);
}
