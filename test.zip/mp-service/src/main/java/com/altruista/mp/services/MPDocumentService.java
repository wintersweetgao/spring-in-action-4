package com.altruista.mp.services;

import com.altruista.mp.model.MPDocument;
import com.altruista.mp.services.exceptions.ServiceException;

import java.util.List;

/**
 * Created by mwixson on 7/29/14.
 */
public interface MPDocumentService {
    String save(MPDocument doc, boolean value);

    String save(MPDocument doc);

    MPDocument get(String key);

    List<MPDocument> findByMemberId(String memberId);

    List<MPDocument> findByRefId(String refId);

    List<MPDocument> findIdByRefId(String refId);

    List<MPDocument> findAll();

    List<MPDocument> findByTags(List<String> tags);

    String getEncodedImageFile(MPDocument document) throws ServiceException;

    String getEncodedImageResource(MPDocument document) throws ServiceException;

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    void delete(String id);
}
