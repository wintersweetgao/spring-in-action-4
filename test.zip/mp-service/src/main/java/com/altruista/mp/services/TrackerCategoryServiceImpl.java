package com.altruista.mp.services;

import com.altruista.mp.model.TrackerCategory;
import com.altruista.mp.repositories.TrackerCategoryRepository;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerCategoryServiceImpl extends MPService implements TrackerCategoryService {
    @Autowired
    TrackerCategoryRepository repository;

    @Autowired
    private MongoTemplate template;

    public String save(TrackerCategory category, boolean sync) {
        // set the created on date if not provided
        if (category.getCreatedOn() == null)
            category.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        category.setUpdatedOn(DateTime.now());

        if (!sync)
            category.setSyncedOn(DateTime.now());
        else
            category.setSyncedOn(getSyncNeededDate());

        category = repository.save(category);
        return category.getId();
    }

    //@Override
    public String save(TrackerCategory category) {
        // set the created on date if not provided
        if (category.getCreatedOn() == null)
            category.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        category.setUpdatedOn(DateTime.now());

        category = repository.save(category);
        return category.getId();
    }

    @Override
    public TrackerCategory get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<TrackerCategory> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    @Override
    public List<TrackerCategory> getAllCategories() {
        return (List<TrackerCategory>) repository.findAll();
    }

    @Override
    public List<TrackerCategory> getTrackerCategoriesByMemberCondition(String conditions) {
        Query q = new Query();
        q.fields().include("conditions");

        return template.find(q, TrackerCategory.class);
    }
}
