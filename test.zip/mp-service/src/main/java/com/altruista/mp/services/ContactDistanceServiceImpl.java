package com.altruista.mp.services;

import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactDistance;
import com.altruista.mp.repositories.ContactRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.geo.Point;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by Prateek on 06/19/15
 */
public class ContactDistanceServiceImpl extends MPService implements ContactDistanceService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContactDistanceServiceImpl.class);
    public static final Double KILOMETER = 111.0d;

    @Autowired
    private ContactRepository repository = null;
    @Autowired
    private MongoOperations operations;

    // default constructor
    public ContactDistanceServiceImpl() {
    }

    @Autowired
    public ContactDistanceServiceImpl(ContactRepository repository) {
        this.repository = repository;
    }

    private Double getInKilometer(Double maxdistance) {
        return maxdistance / KILOMETER;
    }

    @Override
    public Page<ContactDistance> getContactDistanceByPosition(
            List<String> keywords, List<String> tags,
            Double lat, Double lon, Double maxdistance, Pageable pageable) {

        Query query = new Query().with(pageable);
        query.addCriteria(Criteria.where("contactType").in(new String[]{"PROVIDER", "PHYSICIAN"}));
        query.addCriteria(Criteria.where("address.position").nearSphere(new Point(lon, lat)).maxDistance(getInKilometer(maxdistance)));

        // add keyword criteria
        if (keywords != null && !keywords.isEmpty()) {
            List<Criteria> orCriteriaList = new ArrayList<Criteria>();

            for (String keyword : keywords) {
                orCriteriaList.add(Criteria.where("salutation").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("firstName").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("middleName").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("lastName").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("company").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("nameSuffix").regex(keyword, "i"));
            }

            query.addCriteria(new Criteria().orOperator(orCriteriaList.toArray(new Criteria[orCriteriaList.size()])));
        }


        // add tags criteria
        if (tags != null && !tags.isEmpty()) {
            query.addCriteria(Criteria.where("tags").in(tags.toArray()));
        }

        // For Pageable
        /*int offset = pageable.getOffset();
        query.skip(offset);
        query.limit(offset+pageable.getPageSize());*/

        LOGGER.debug("QUERY: " + query.toString());

        List<Contact> contacts = operations.find(query, Contact.class);
        List<ContactDistance> contactDistances = new ArrayList<ContactDistance>();

        for (Contact contact : contacts) {
            // Represents a Geo-spatial point value.
            Point geospatialPoints = new Point(contact.getAddress().getPosition()[0], contact.getAddress().getPosition()[1]);

            ContactDistance contactDistance = new ContactDistance();
            contactDistance.setContactId(contact.getId());
            contactDistance.setSalutation(contact.getSalutation());
            contactDistance.setFirstName(contact.getFirstName());
            contactDistance.setMiddleName(contact.getMiddleName());
            contactDistance.setLastName(contact.getLastName());
            contactDistance.setNameSuffix(contact.getNameSuffix());
            contactDistance.setCompany(contact.getCompany());
            contactDistance.setDistance(getDistanceUsingPoints(lat, lon, geospatialPoints));

            contactDistances.add(contactDistance);
        }
        return new PageImpl<ContactDistance>(contactDistances, pageable, operations.count(query, Contact.class));
    }

    @Override
    public Page<ContactDistance> getContactDistanceByPostalCode(
            List<String> keywords, List<String> tags, String postalCode, Pageable pageable) {

        Query query = new Query().with(pageable);
        query.addCriteria(Criteria.where("contactType").in(new String[]{"PROVIDER", "PHYSICIAN"}));
        query.addCriteria(Criteria.where("address.postalCode").is(postalCode));

        // add keyword criteria
        if (keywords != null && !keywords.isEmpty()) {
            List<Criteria> orCriteriaList = new ArrayList<Criteria>();

            for (String keyword : keywords) {
                orCriteriaList.add(Criteria.where("salutation").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("firstName").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("middleName").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("lastName").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("company").regex(keyword, "i"));
                orCriteriaList.add(Criteria.where("nameSuffix").regex(keyword, "i"));
            }

            query.addCriteria(new Criteria().orOperator(orCriteriaList.toArray(new Criteria[orCriteriaList.size()])));
        }

        // add tags criteria
        if (tags != null && !tags.isEmpty()) {
            query.addCriteria(Criteria.where("tags").in(tags.toArray()));
        }

        // For Pageable
        /*int offset = pageable.getOffset();
        query.skip(offset);
        query.limit(offset+pageable.getPageSize());*/

        LOGGER.debug("QUERY: " + query.toString());

        List<Contact> contacts = operations.find(query, Contact.class);
        List<ContactDistance> contactDistances = new ArrayList<ContactDistance>();

        for (Contact contact : contacts) {

            ContactDistance contactDistance = new ContactDistance();
            contactDistance.setContactId(contact.getId());
            contactDistance.setSalutation(contact.getSalutation());
            contactDistance.setFirstName(contact.getFirstName());
            contactDistance.setMiddleName(contact.getMiddleName());
            contactDistance.setLastName(contact.getLastName());
            contactDistance.setNameSuffix(contact.getNameSuffix());
            contactDistance.setCompany(contact.getCompany());

            contactDistances.add(contactDistance);
        }
        return new PageImpl<ContactDistance>(contactDistances, pageable, operations.count(query, Contact.class));
    }

    /**
     * calculate the distance between two geospatial point value using "Great-circle" distance formula
     *
     * @href: https://en.wikipedia.org/wiki/Great-circle_distance
     */
    public String getDistanceUsingPoints(Double lat, Double lon, Point point) {
        Double x1 = Math.toRadians(lat); // lat
        Double y1 = Math.toRadians(lon); // lon
        LOGGER.debug("Lat1 [" + lat + "], Lon1 [" + lon + "]");

        Double x2 = Math.toRadians(point.getY()); // lat
        Double y2 = Math.toRadians(point.getX()); // lon
        LOGGER.debug("From Mongo Lat2 [" + point.getY() + "], Lon2 [" + point.getX() + "]");

        Double sec1 = Math.sin(x1) * Math.sin(x2);
        Double dl = Math.abs(y1 - y2);
        Double sec2 = Math.cos(x1) * Math.cos(x2);

        Double centralAngle = Math.acos(sec1 + sec2 * Math.cos(dl));

        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(1);

        /** Radius of Earth = 6378.1 kilometers and 1 Km = 0.621371 Miles */
        LOGGER.debug("Distance Between Two Points in Miles : " + df.format(centralAngle * 6378.1 * 0.621371));

        return String.valueOf(df.format(centralAngle * 6378.1 * 0.621371)); // distance in miles
    }
}
