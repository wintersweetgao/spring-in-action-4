package com.altruista.mp.repositories;

import com.altruista.mp.model.Tracker;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
public interface TrackerRepository extends CrudRepository<Tracker, String> {
    List<Tracker> findByRefId(String id);

    List<Tracker> findByCategoryId(String categoryId);
}
