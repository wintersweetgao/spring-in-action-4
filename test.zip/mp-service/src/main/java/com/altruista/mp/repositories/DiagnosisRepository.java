package com.altruista.mp.repositories;

import com.altruista.mp.model.Diagnosis;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DiagnosisRepository extends CrudRepository<Diagnosis, String> {

    /**
     * Additional custom finder method.
     */
    List<Diagnosis> findByMemberId(String id);

    List<Diagnosis> findByMemberIdAndCreatedOnGreaterThan(String id, DateTime createdOn);

    List<Diagnosis> findByRefId(String id);
}
