package com.altruista.mp.repositories;

import com.altruista.mp.model.Assessment;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AssessmentRepository extends CrudRepository<Assessment, String> {
    List<Assessment> findByName(String name);

    List<Assessment> findByRefId(String id);
}
