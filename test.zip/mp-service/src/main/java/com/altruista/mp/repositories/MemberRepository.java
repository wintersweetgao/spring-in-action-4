package com.altruista.mp.repositories;

import com.altruista.mp.model.Member;
import org.joda.time.DateTime;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MemberRepository extends CrudRepository<Member, String> {

    /**
     * Additional custom finder method.
     */
    List<Member> findByRefId(String id);

    List<Member> findByContactCode(String contactCode);

    List<Member> findBySyncedOn(DateTime syncedOn);

    List<Member> findByTest(Boolean test);

    List<Member> findById(String id);
}
