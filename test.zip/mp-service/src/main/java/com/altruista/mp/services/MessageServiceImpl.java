package com.altruista.mp.services;

import com.altruista.mp.model.Message;
import com.altruista.mp.repositories.MessageRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

/**
 * Created by mwixs_000 on 6/24/2014.
 */
public class MessageServiceImpl extends MPService implements MessageService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MessageServiceImpl.class);

    private MessageRepository repository = null;
    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    public MessageServiceImpl(MessageRepository repository) {
        this.repository = repository;
    }

    public MessageServiceImpl() {
        // no arg constructor
    }

    @Override
    public String save(Message message, boolean sync) {
        if (message.getCreatedOn() == null) {
            message.setCreatedOn(DateTime.now());
        }

        if (!sync)
            message.setSyncedOn(DateTime.now());
        else
            message.setSyncedOn(getSyncNeededDate());

        message = repository.save(message);
        return message.getId();
    }

    @Override
    public String save(Message message) {
        if (message.getCreatedOn() == null) {
            message.setCreatedOn(DateTime.now());
        }

        if (isSyncEnabled())
            message.setSyncedOn(MPService.getSyncNeededDate());

        message = repository.save(message);
        return message.getId();
    }

    @Override
    public Message get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Message> findBySenderId(String senderId) {
        return repository.findBySenderId(senderId);
    }

    @Override
    public List<Message> findByRecipientId(String recipientId) {
        return repository.findByRecipientIds(recipientId);
    }

    @Override
    public List<Message> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Message> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Message> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Message> findMessageIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}
