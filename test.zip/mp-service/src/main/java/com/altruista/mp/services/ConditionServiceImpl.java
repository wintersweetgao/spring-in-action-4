package com.altruista.mp.services;

import com.altruista.mp.model.Condition;
import com.altruista.mp.repositories.ConditionRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ConditionServiceImpl extends MPService implements ConditionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConditionServiceImpl.class);

    private ConditionRepository repository = null;

    @Autowired
    public ConditionServiceImpl(ConditionRepository repository) {
        this.repository = repository;
    }

    public ConditionServiceImpl() {
        // no arg constructor
    }

    public String save(Condition condition, boolean sync) {
        if (condition.getCreatedOn() == null)
            condition.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        condition.setUpdatedOn(DateTime.now());

        if (!sync)
            condition.setSyncedOn(DateTime.now());
        else
            condition.setSyncedOn(getSyncNeededDate());

        condition = repository.save(condition);
        return condition.getId();
    }

    public String save(Condition condition) {
        if (condition.getCreatedOn() == null)
            condition.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        condition.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            condition.setSyncedOn(MPService.getSyncNeededDate());

        condition = repository.save(condition);
        return condition.getId();
    }

    @Override
    public Condition get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Condition> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Condition> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Condition> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}