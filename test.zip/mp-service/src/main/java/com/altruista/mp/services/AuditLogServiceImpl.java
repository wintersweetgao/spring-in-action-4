package com.altruista.mp.services;

import com.altruista.mp.model.AuditLog;
import com.altruista.mp.repositories.AuditLogRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by mahesh on 11/17/14.
 */

public class AuditLogServiceImpl implements AuditLogService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuditLogServiceImpl.class);
    @Autowired
    AuditLogRepository repository;

    @Override
    public void save(AuditLog log) {
        log.setCreatedOn(DateTime.now());
        repository.save(log);
    }

}
