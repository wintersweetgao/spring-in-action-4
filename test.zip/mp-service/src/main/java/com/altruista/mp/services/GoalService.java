package com.altruista.mp.services;

import com.altruista.mp.model.Goal;

import java.util.List;

public interface GoalService {
    String save(Goal goal, boolean value);

    String save(Goal goal);

    Goal get(String key);

    List<Goal> findByMemberId(String memberId);

    List<Goal> findByRefId(String refId);

    List<Goal> findIdByRefId(String refId);

    boolean isSyncEnabled();

    void setSyncEnabled(boolean syncEnabled);

    List<Goal> findGoalIdsToSync();

    void delete(String id);
}
