package com.altruista.mp.repositories;

import com.altruista.mp.model.AllergySensitivity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 10/16/14.
 */
public interface AllergySensitivityRepository extends CrudRepository<AllergySensitivity, String> {

    /**
     * Additional custom finder method.
     */
    List<AllergySensitivity> findByMemberId(String id);

    List<AllergySensitivity> findByRefId(String id);
}
