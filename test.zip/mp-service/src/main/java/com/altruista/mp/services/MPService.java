package com.altruista.mp.services;

import org.joda.time.DateTime;

/**
 * Created by mwixson on 7/17/14.
 */
public class MPService {
    private boolean syncEnabled = true;

    public boolean isSyncEnabled() {
        return syncEnabled;
    }

    public void setSyncEnabled(boolean syncEnabled) {
        this.syncEnabled = syncEnabled;
    }

    public static DateTime getSyncNeededDate() {
        return new DateTime(getSyncNeededMillis());
    }

    public static long getSyncNeededMillis() {
        return 2696401854L;
    }
}
