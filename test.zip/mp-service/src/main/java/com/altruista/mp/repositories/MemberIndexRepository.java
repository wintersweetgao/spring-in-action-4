package com.altruista.mp.repositories;

import com.altruista.mp.model.MemberIndex;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by mwixson on 9/24/15.
 */
public interface MemberIndexRepository extends CrudRepository<MemberIndex, String> {

    /**
     * Additional custom finder method.
     */
    List<MemberIndex> findIdByRefIdAndIndexNameAndIndexValue(String refId, String indexName, String indexValue);

    List<MemberIndex> findByIndexNameInAndIndexValue(List<String> indexNames, String indexValue);

    List<MemberIndex> findByMemberIdAndIndexName(String memberId, String indexName);

    List<MemberIndex> findByRefId(String refId);
}
