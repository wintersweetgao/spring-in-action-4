package com.altruista.mp.services;

import com.altruista.mp.model.CommunicationImpairment;
import com.altruista.mp.repositories.CommunicationImpairmentRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CommunicationImpairmentServiceImpl extends MPService implements CommunicationImpairmentService {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommunicationImpairmentServiceImpl.class);

    private CommunicationImpairmentRepository repository = null;

    @Autowired
    public CommunicationImpairmentServiceImpl(CommunicationImpairmentRepository repository) {
        this.repository = repository;
    }

    public CommunicationImpairmentServiceImpl() {
        // no arg constructor
    }

    public String save(CommunicationImpairment impairment, boolean sync) {
        if (impairment.getCreatedOn() == null)
            impairment.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        impairment.setUpdatedOn(DateTime.now());

        if (!sync)
            impairment.setSyncedOn(DateTime.now());
        else
            impairment.setSyncedOn(getSyncNeededDate());

        impairment = repository.save(impairment);
        return impairment.getId();
    }

    public String save(CommunicationImpairment impairment) {
        if (impairment.getCreatedOn() == null)
            impairment.setCreatedOn(DateTime.now());

        // always set the updated on when saving
        impairment.setUpdatedOn(DateTime.now());

        if (isSyncEnabled())
            impairment.setSyncedOn(MPService.getSyncNeededDate());

        impairment = repository.save(impairment);
        return impairment.getId();
    }

    @Override
    public CommunicationImpairment get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<CommunicationImpairment> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<CommunicationImpairment> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<CommunicationImpairment> findIdByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }
}