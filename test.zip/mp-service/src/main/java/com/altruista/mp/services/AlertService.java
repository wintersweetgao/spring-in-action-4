package com.altruista.mp.services;

import com.altruista.mp.model.Alert;
import org.joda.time.DateTime;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.List;

public interface AlertService {
    List<Alert> findByMemberIdAndCreatedOn(String memberId, Collection<? extends GrantedAuthority> authorities, DateTime accessedOn);
}

