package com.altruista.mp.services;

import com.altruista.mp.model.AssessmentRun;
import org.joda.time.DateTime;

import java.util.Collection;
import java.util.List;

public interface AssessmentRunService {
    String save(AssessmentRun assessmentRun, boolean value);

    String save(AssessmentRun assessmentRun);

    List<AssessmentRun> findByMemberId(String memberId);

    boolean isSyncEnabled();

    AssessmentRun get(String key);

    List<AssessmentRun> findRunIdsToSync();

    List<AssessmentRun> findByRefId(String refId);

    List<AssessmentRun> findByMemberIdAndAssessmentId(String memberId, String assessmentId);

    List<AssessmentRun> findByAssessmentIdAndStatus(String assessmentId, String status);

    void delete(String id);

    void update(String runId, DateTime endTime);

    void setSyncEnabled(boolean syncEnabled);

    List<AssessmentRun> findByFollowupRefId(String followupRefId);

    //List<AssessmentRun> findByMemberIdAndStatus(String memberId, String status);
    List<AssessmentRun> findByMemberIdAndStatusNotIn(String memberId, Collection<String> status);
}
