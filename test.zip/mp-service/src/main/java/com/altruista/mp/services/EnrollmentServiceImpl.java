package com.altruista.mp.services;

import com.altruista.mp.model.*;
import com.altruista.mp.repositories.*;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.List;

/**
 * Created by mwixs_000 on 6/24/2014.
 */
public class EnrollmentServiceImpl extends MPService implements EnrollmentService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EnrollmentServiceImpl.class);

    private EnrollmentRepository repository = null;
    private MemberRepository memberRepository = null;
    private ContactRepository contactRepository = null;
    private LobRepository lobRepository = null;
    private UserRepository userRepository = null;

    @Autowired
    ProgramEligibilityService eligibilityService;

    @Autowired
    public EnrollmentServiceImpl(EnrollmentRepository repository,
                                 MemberRepository memberRepository,
                                 ContactRepository contactRepository,
                                 LobRepository lobRepository,
                                 UserRepository userRepository) {
        this.repository = repository;
        this.memberRepository = memberRepository;
        this.contactRepository = contactRepository;
        this.lobRepository = lobRepository;
        this.userRepository = userRepository;
    }

    public EnrollmentServiceImpl() {
        // no arg constructor
    }

    public String save(Enrollment enrollment, boolean sync) {
        if (enrollment.getCreatedOn() == null) {
            enrollment.setCreatedOn(DateTime.now());
        }

        if (!sync)
            enrollment.setSyncedOn(DateTime.now());
        else
            enrollment.setSyncedOn(getSyncNeededDate());

        enrollment = repository.save(enrollment);
        return enrollment.getId();
    }

    public String save(Enrollment enrollment) {
        if (enrollment.getCreatedOn() == null) {
            enrollment.setCreatedOn(DateTime.now());
        }

        if (isSyncEnabled())
            enrollment.setSyncedOn(MPService.getSyncNeededDate());

        enrollment = repository.save(enrollment);

        return enrollment.getId();
    }

    @Override
    public Enrollment get(String key) {
        return repository.findOne(key);
    }

    @Override
    public List<Enrollment> findByMemberId(String memberId) {
        return repository.findByMemberId(memberId);
    }

    @Override
    public List<Enrollment> findByRefId(String refId) {
        return repository.findByRefId(refId);
    }

    @Override
    public List<Enrollment> findEnrollmentIdsToSync() {
        return repository.findBySyncedOn(MPService.getSyncNeededDate());
    }

    @Override
    public void delete(String id) {
        repository.delete(id);
    }

    @Override
    public boolean isEligibleForMMC(String memberId, Collection<? extends GrantedAuthority> authorities) {

        //  user must be a member to enroll in MMC
        if (!authorities.contains(new SimpleGrantedAuthority("MEMBER")))
            return false;

        // member must be in a specified LOB
        ProgramEligibility eligibility = eligibilityService.findOneByProgramName("MyMoneyConnect");
        if (eligibility != null) {
            List<Lob> lob = lobRepository.findByMemberIdAndNameIn(memberId, eligibility.getLobs());
            if (lob.size() == 0)
                return false;
        }

        // member must not already be enrolled
        List<Enrollment> registration = repository.findByMemberId(memberId);
        if (registration.size() > 0)
            return false;

        // member must be 18 or older and in the list of client ids
        Member member = memberRepository.findOne(memberId);
        Contact contact = contactRepository.findOne(member.getContactId());
        if (DateHelper.getAgeInYears(contact.getDob()) >= 18 && eligibility != null && eligibility.getClientRefIds().contains(member.getClientRefId()))
            return true;
        else
            return false;
    }
}