package com.altruista.mp.resources;

import com.altruista.mp.model.Condition;
import com.altruista.mp.rest.ConditionController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class ConditionResourceAssembler extends
        ResourceAssemblerSupport<Condition, ConditionResource> {

    public ConditionResourceAssembler() {
        super(ConditionController.class, ConditionResource.class);
    }

    @Override
    public ConditionResource toResource(Condition condition) {
        return createResourceWithId(condition.getId(), condition);
    }

    @Override
    protected ConditionResource instantiateResource(Condition entity) {
        ConditionResource resource = new ConditionResource();

        resource.setMemberId(entity.getMemberId());
        resource.setCategory(entity.getCategory());
        resource.setName(entity.getName());
        resource.setPrimary(entity.isPrimary());
        resource.setSource(entity.getSource());
        resource.setType(entity.getType());
        resource.setAddedOn(entity.getRefCreatedOn());

        return resource;
    }

}
