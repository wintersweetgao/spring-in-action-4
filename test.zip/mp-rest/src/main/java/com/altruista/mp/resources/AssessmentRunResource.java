package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

/**
 * Created by Prateek on 2/17/15.
 */

public class AssessmentRunResource extends ResourceSupport {

    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentrun.assesssmentId}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentrun.assesssmentId}")
    private String assessmentId;

    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentrun.assessmentName}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentrun.assessmentName}")
    private String assessmentName;

    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentrun.status}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentrun.status}")
    private String status;

    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentrun.careNotes}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentrun.careNotes}")
    private String careNotes;
    private int lastSequence; // newly added fields
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime startedOn;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime endedOn;


    public String getAssessmentId() {
        return assessmentId;
    }

    public void setAssessmentId(String assessmentId) {
        this.assessmentId = assessmentId;
    }

    public String getAssessmentName() {
        return assessmentName;
    }

    public void setAssessmentName(String assessmentName) {
        this.assessmentName = assessmentName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCareNotes() {
        return careNotes;
    }

    public void setCareNotes(String careNotes) {
        this.careNotes = careNotes;
    }

    public DateTime getStartedOn() {
        return startedOn;
    }

    public void setStartedOn(DateTime startedOn) {
        this.startedOn = startedOn;
    }

    public DateTime getEndedOn() {
        return endedOn;
    }

    public void setEndedOn(DateTime endedOn) {
        this.endedOn = endedOn;
    }

    public int getLastSequence() {
        return lastSequence;
    }

    public void setLastSequence(int lastSequence) {
        this.lastSequence = lastSequence;
    }
}
