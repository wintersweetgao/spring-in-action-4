package com.altruista.mp.rest.exceptions;


@SuppressWarnings("serial")
public class InvalidMemberIdException extends RuntimeException {
    private final String errors;

    public InvalidMemberIdException(String message) {
        super(message);
        this.errors = message;
    }

    public String getErrors() {
        return errors;
    }
}
