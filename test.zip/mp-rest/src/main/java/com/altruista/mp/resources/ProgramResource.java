package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 10/16/14.
 */
@XmlRootElement(name = "program")
public class ProgramResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    private boolean primary;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.programname}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.programname}")
    private String name;

    public ProgramResource(String memberId, boolean primary, String name) {
        this.memberId = memberId;
        this.primary = primary;
        this.name = name;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
