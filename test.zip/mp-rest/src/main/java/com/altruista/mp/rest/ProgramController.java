package com.altruista.mp.rest;

import com.altruista.mp.resources.ProgramResource;
import com.altruista.mp.resources.ProgramResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.ProgramService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for alerts
 */
@Controller
@RequestMapping("/api/program")
@Api(value = "Program service", description = "Manage Programs")
public class ProgramController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProgramController.class);

    private final ProgramService programService;
    private ProgramResourceAssembler programAssembler;

    @Autowired
    public ProgramController(ProgramService programService) {
        this.programService = programService;
        programAssembler = new ProgramResourceAssembler();
    }

    @RequestMapping(value = "/{memberId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Programs using member id")
    public HttpEntity<List<ProgramResource>> getProgramsByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<ProgramResource> resourceList = programAssembler.toResources(programService.findByMemberId(memberId));
        return new ResponseEntity<List<ProgramResource>>(resourceList,
                HttpStatus.OK);
    }

}