package com.altruista.mp.resources;


@SuppressWarnings("serial")
public class UserNotFoundException extends RuntimeException {
    private final transient String errorMessage;

    public UserNotFoundException(String message) {
        super(message);
        this.errorMessage = message;
    }

    public String getErrors() {
        return errorMessage;
    }

}
