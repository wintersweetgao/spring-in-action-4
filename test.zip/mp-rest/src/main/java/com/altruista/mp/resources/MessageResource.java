package com.altruista.mp.resources;

import com.altruista.mp.model.HealthSummaryType;
import com.altruista.mp.model.MessagePriorityType;
import com.altruista.mp.model.MessageType;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.joda.time.DateTime;
import org.springframework.data.annotation.Transient;
import org.springframework.hateoas.ResourceSupport;

import javax.validation.Valid;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "Message")
public class MessageResource extends ResourceSupport {
    private MessageType messageType;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.subject}")
    @Length(max = ResourceSize.MAX_ID, message = "{length.validation.subject}")
    private String senderId;
    @Transient
    @Valid
    private ContactNameResource sender;
    private List<String> recipientIds;
    @Transient
    @Valid
    private List<ContactNameResource> recipients;
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.subject}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.subject}")
    private String subject;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.body}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.body}")
    private String body;
    private MessagePriorityType messagePriority;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.location}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.location}")
    private String location;
    private boolean viewed;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime sentOn;
    private HealthSummaryType healthSummary;

    public MessageType getMessageType() {
        return messageType;
    }

    public void setMessageType(MessageType messageType) {
        this.messageType = messageType;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public ContactNameResource getSender() {
        return sender;
    }

    public void setSender(ContactNameResource sender) {
        this.sender = sender;
    }

    public List<String> getRecipientIds() {
        return recipientIds;
    }

    public void setRecipientIds(List<String> recipientIds) {
        this.recipientIds = recipientIds;
    }

    public List<ContactNameResource> getRecipients() {
        if (recipients == null)
            recipients = new ArrayList<ContactNameResource>();
        return recipients;
    }

    public void setRecipients(List<ContactNameResource> recipients) {
        this.recipients = recipients;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public MessagePriorityType getMessagePriority() {
        return messagePriority;
    }

    public void setMessagePriority(MessagePriorityType messagePriority) {
        this.messagePriority = messagePriority;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isViewed() {
        return viewed;
    }

    public void setViewed(boolean viewed) {
        this.viewed = viewed;
    }

    public DateTime getSentOn() {
        return sentOn;
    }

    public void setSentOn(DateTime sentOn) {
        this.sentOn = sentOn;
    }

    public HealthSummaryType getHealthSummary() {
        return healthSummary;
    }

    public void setHealthSummary(HealthSummaryType healthSummary) {
        this.healthSummary = healthSummary;
    }
}
