package com.altruista.mp.rest.exceptions;


@SuppressWarnings("serial")
public class InvalidPasswordException extends RuntimeException {
    private final String errors;

    public InvalidPasswordException(String message) {
        super(message);
        this.errors = message;
    }

    public String getErrors() {
        return errors;
    }
}
