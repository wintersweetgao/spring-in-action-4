package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;

/**
 * Created by mwixson on 11/17/14.
 */
public class AuthorityResource {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_SHORT_STRING)
    private String authority;

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }
}
