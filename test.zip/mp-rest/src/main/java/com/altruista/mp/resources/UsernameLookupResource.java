package com.altruista.mp.resources;

import com.altruista.mp.model.QuestionAnswer;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;

import javax.validation.Valid;

public class UsernameLookupResource {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.membercode}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.membercode}")
    private String memberCode;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.dob}")
    @Length(max = ResourceSize.MAX_DATE, message = "{length.validation.dob}")
    private String dob;
    @Valid
    private QuestionAnswer securityQuestionAnswer;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.password}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.password}")
    private String password;

    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public QuestionAnswer getSecurityQuestionAnswer() {
        return securityQuestionAnswer;
    }

    public void setSecurityQuestionAnswer(QuestionAnswer securityQuestionAnswer) {
        this.securityQuestionAnswer = securityQuestionAnswer;
    }
}