package com.altruista.mp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.config.EnableSpringDataWebSupport;

/**
 * Created by mwixson on 9/14/15.
 */
@Configuration
@EnableSpringDataWebSupport
public class PagingConfig {
}
