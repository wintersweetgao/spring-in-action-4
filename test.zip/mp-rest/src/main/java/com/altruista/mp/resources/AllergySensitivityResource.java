package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 10/16/14.
 */
@XmlRootElement(name = "allergy")
public class AllergySensitivityResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.medicationcode}")
    @Length(max = 50, message = "{length.validation.medicationcode}")
    private String medicationCode;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.allergyname}")
    @Length(max = 500, message = "{length.validation.allergyname}")
    private String name;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMedicationCode() {
        return medicationCode;
    }

    public void setMedicationCode(String medicationCode) {
        this.medicationCode = medicationCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
