package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;

/**
 * Created by mwixson on 11/7/14.
 */
public class AddressResource {
    private boolean primary;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.address}")
    @Length(max = 200, message = "{length.validation.address}")
    private String address;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.address2}")
    @Length(max = 200, message = "{length.validation.address2}")
    private String address2;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.city}")
    @Length(max = 200, message = "{length.validation.city}")
    private String city;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.stateprovince}")
    @Length(max = 200, message = "{length.validation.stateprovince}")
    private String stateProvince;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.postalcode}")
    @Length(max = 200, message = "{length.validation.postalcode}")
    private String postalCode;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.county}")
    @Length(max = 200, message = "{length.validation.county}")
    private String county;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.country}")
    @Length(max = 200, message = "{length.validation.country}")
    private String country;

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
