package com.altruista.mp.rest;

import com.altruista.mp.resources.ValidValueResource;
import com.altruista.mp.resources.ValidValueResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.services.ValidValueService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Handles requests for ValidValues
 */
@Controller
@RequestMapping("/api/validvalue")
@Api(value = "Valid Value service", description = "Manage Valid Values")
public class ValidValueController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ValidValueController.class);

    private final ValidValueService validValueService;
    private ValidValueResourceAssembler validValueAssembler;

    @Autowired
    public ValidValueController(ValidValueService ValidValueService) {
        this.validValueService = ValidValueService;
        validValueAssembler = new ValidValueResourceAssembler();
    }

    @RequestMapping(value = "/{name}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Valid Values using Name")
    public HttpEntity<List<ValidValueResource>> getValidValues(@PathVariable String name) throws ResourceException {
        List<ValidValueResource> resourceList = validValueAssembler.toResources(validValueService.findByName(name));
        return new ResponseEntity<List<ValidValueResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/{name}/{value}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Valid Values using Value & Name")
    public HttpEntity<List<ValidValueResource>> getValidValues(@PathVariable String name, @PathVariable String value, @RequestParam(value = "partial", defaultValue = "false") Boolean partial) throws ResourceException {
        if (partial == null)
            partial = true;

        List<ValidValueResource> resourceList = validValueAssembler.toResources(validValueService.findByNameAndValue(name, value, partial.booleanValue()));
        return new ResponseEntity<List<ValidValueResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/{name}/description/{description}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Valid Description")
    public HttpEntity<List<ValidValueResource>> getValidDescriptions(@PathVariable String name, @PathVariable String description, @RequestParam(value = "partial", defaultValue = "false") Boolean partial) throws ResourceException {
        if (partial == null)
            partial = true;

        List<ValidValueResource> resourceList = validValueAssembler.toResources(validValueService.findByNameAndDescription(name, description, partial.booleanValue()));
        return new ResponseEntity<List<ValidValueResource>>(resourceList,
                HttpStatus.OK);
    }

}