package com.altruista.mp.rest;

import com.altruista.mp.model.Enrollment;
import com.altruista.mp.model.MemberIndex;
import com.altruista.mp.resources.EnrollmentResource;
import com.altruista.mp.resources.EnrollmentResourceAssembler;
import com.altruista.mp.resources.InvalidRequestException;
import com.altruista.mp.rest.exceptions.InvalidCredentialException;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.EnrollmentService;
import com.altruista.mp.services.MemberIndexService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.altruista.mp.utils.CryptoHelper;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.activity.InvalidActivityException;
import javax.validation.Valid;
import java.text.ParseException;
import java.util.List;

/**
 * Created by mwixs_000 on 6/24/2014.
 */
@Controller
@Api(value = "Enrollment service", description = "Manage Program Enrollment")
public class EnrollmentController {
    private static final Logger LOGGER = LoggerFactory.getLogger(EnrollmentController.class);

    @Value("${guidingCare.timezone}")
    private String gcTimezone;
    private MemberIndexService memberIndexService;
    private final EnrollmentService enrollmentService;
    private EnrollmentResourceAssembler enrollmentAssembler;

    @Autowired
    public EnrollmentController(EnrollmentService enrollmentService, MemberIndexService memberIndexService) {
        this.enrollmentService = enrollmentService;
        enrollmentAssembler = new EnrollmentResourceAssembler();
        this.memberIndexService = memberIndexService;
    }

    @RequestMapping(value = "/api/enrollment/{enrollmentId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the enrollment using Enrollment id")
    public HttpEntity<EnrollmentResource> getEnrollment(
            @PathVariable("enrollmentId") String enrollmentId) throws ResourceException {
        Enrollment enrollment = enrollmentService.get(enrollmentId);
        String memberId = enrollment.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        EnrollmentResource resource = enrollmentAssembler.toResource(enrollment);
        return new ResponseEntity<EnrollmentResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/enrollment", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Gets the enrollment using Member id")
    public HttpEntity<List<EnrollmentResource>> getEnrollmentsByMemberId(@PathVariable String memberId) throws ResourceException, InvalidActivityException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<EnrollmentResource> resourceList = enrollmentAssembler.toResources(enrollmentService.findByMemberId(memberId));
        return new ResponseEntity<List<EnrollmentResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/enrollment", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves the enrollment")
    public HttpEntity<EnrollmentResource> saveEnrollment(@Valid @RequestBody EnrollmentResource resource, BindingResult bindingResult) throws ResourceException {
        String memberId = resource.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);

        if (bindingResult.hasErrors()) {
            throw new InvalidRequestException("Invalid resource", bindingResult);
        }
        if (((resource.getSsn() == null || resource.getSsn().isEmpty()) &&
                (resource.getItin() == null || resource.getItin().isEmpty()) &&
                (resource.getRefugeeNumber() == null || resource.getRefugeeNumber().isEmpty()))) {
            throw new ResourceException("Missing SSN, ITIN or RefugeeNumber");
        }

        Enrollment enrollment = enrollmentAssembler.fromResource(resource);

        if (resource.getSsn() != null && !resource.getSsn().isEmpty()) {
            if (!checkHashedSSN(resource.getMemberId(), resource.getSsn().replace("-", "").trim())) {
                throw new InvalidCredentialException("Information entered does not match information on file.");
            }
        }

        // Jasypt encryption for SSN
        if (enrollment.getSsn() != null && !enrollment.getSsn().isEmpty()) {
            String encrypted = CryptoHelper.encryptString(enrollment.getSsn());
            enrollment.setSsn(encrypted);
        } else {
            if (enrollment.getItin() != null && !enrollment.getItin().isEmpty()) {
                String encrypted = CryptoHelper.encryptString(enrollment.getItin());
                enrollment.setItin(encrypted);
            } else if (enrollment.getRefugeeNumber() != null && !enrollment.getRefugeeNumber().isEmpty()) {
                String encrypted = CryptoHelper.encryptString(enrollment.getRefugeeNumber());
                enrollment.setRefugeeNumber(encrypted);
            } else
                throw new ResourceException("Missing SSN, ITIN or Refugee Number.");
        }

        SecurityContext context = SecurityContextHolder.getContext();
        Authentication authentication = context.getAuthentication();
        if (enrollmentService.isEligibleForMMC(memberId, authentication.getAuthorities())) {
            enrollmentService.save(enrollment);
        } else {
            throw new AccessDeniedException("Access Denied");
        }

        // update the enrollment link
        resource = enrollmentAssembler.toResource(enrollment);
        return new ResponseEntity<EnrollmentResource>(resource, HttpStatus.OK);
    }

    // Method to check SSN is hashed or not and send response accordingly
    @ApiOperation(value = "Verifies the SSN")
    @RequestMapping(value = "/api/enrollment/ssn/{memberId}", method = RequestMethod.POST)
    public @ResponseBody ResponseEntity<Boolean> checkSSNIsEncypted(@PathVariable String memberId, @RequestBody EnrollmentResource resource)
            throws ParseException, ServiceException, ResourceException {

        MemberIdValidationUtil.validateMemberClaim(memberId);

        if (checkHashedSSN(resource.getMemberId(), resource.getSsn())) {
            return new ResponseEntity<Boolean>(true, HttpStatus.OK);
        } else {
            return new ResponseEntity<Boolean>(false, HttpStatus.CONFLICT);
        }
    }

    private Boolean checkHashedSSN(String memberId, String plainSSN) {
        MemberIndex memberIndex = memberIndexService.findOneByMemberIdAndIndexName(memberId, "SUBSCRIBER_SSN");
        // check
        if (memberIndex == null || memberIndex.getIndexValue().isEmpty() ||
            CryptoHelper.checkPassword(plainSSN, memberIndex.getIndexValue())) {
            return true;
        }
        else
            return false;
    }

}
