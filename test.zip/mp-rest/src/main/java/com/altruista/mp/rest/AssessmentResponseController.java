package com.altruista.mp.rest;

import com.altruista.mp.model.AssessmentResponse;
import com.altruista.mp.model.AssessmentRun;
import com.altruista.mp.resources.AssessmentResponseResource;
import com.altruista.mp.resources.AssessmentResponseResourceAssembler;
import com.altruista.mp.resources.ResourceNotFoundException;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.AssessmentResponseService;
import com.altruista.mp.services.AssessmentRunService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;

/*
 * Created by Prateek on 03/12/15
 */
@Controller
@Api(value = "Assessment Response service", description = "Manage Assessment Responses")
public class AssessmentResponseController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentResponseController.class);

    private final AssessmentResponseService responseService;
    private final AssessmentRunService runService;
    private final AssessmentResponseResourceAssembler responseAssembler;

    @Autowired
    public AssessmentResponseController(AssessmentResponseService responseService, AssessmentRunService runService) {
        this.responseService = responseService;
        this.runService = runService;
        responseAssembler = new AssessmentResponseResourceAssembler();
    }

    @RequestMapping(value = "/api/assessmentResponse/{responseId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the Assessment Response")
    public HttpEntity<AssessmentResponseResource> getAssessmentResponse(@PathVariable("responseId") String responseId) throws ResourceException {
        AssessmentResponse response = responseService.get(responseId);

        AssessmentRun run = runService.get(response.getRunId());
        MemberIdValidationUtil.validateMemberClaim(run.getMemberId());

        AssessmentResponseResource resource = responseAssembler.toResource(response);

        return new ResponseEntity<AssessmentResponseResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/assessmentResponse/{responseId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Saves the Assessment Response")
    public
    @ResponseBody
    HttpEntity<AssessmentResponseResource> saveAssessmentResponse(@PathVariable("responseId") String responseId, @RequestBody AssessmentResponseResource resource)
            throws ParseException, ServiceException, ResourceException {

        AssessmentResponse original = responseService.get(responseId);
        if (original == null)
            throw new ResourceNotFoundException("Assessment Response not found.");

        // verify user has access to this member's response (run)
        AssessmentRun run = runService.get(original.getRunId());
        MemberIdValidationUtil.validateMemberClaim(run.getMemberId());

        AssessmentResponse response = responseAssembler.fromResource(resource, original);
        responseService.save(response);
        resource = responseAssembler.toResource(response);

        return new ResponseEntity<AssessmentResponseResource>(resource, HttpStatus.OK);
    }
}
