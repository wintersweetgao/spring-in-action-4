package com.altruista.mp.resources;

import com.altruista.mp.model.Medication;
import com.altruista.mp.rest.MedicationController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class MedicationResourceAssembler extends ResourceAssemblerSupport<Medication, MedicationResource> {

    public MedicationResourceAssembler() {
        super(MedicationController.class, MedicationResource.class);
    }

    @Override
    public MedicationResource toResource(Medication medication) {

        MedicationResource resource = createResourceWithId(medication.getId(), medication);

        // copy properties from member to memberResource

        resource.setMemberId(medication.getMemberId());
        resource.setName(medication.getName());
        resource.setDosage(medication.getDosage());
        resource.setQuantity(medication.getQuantity());
        resource.setDays(medication.getDays());
        resource.setStartDate(medication.getStartDate());
        resource.setEndDate(medication.getEndDate());
        resource.setFrequency(medication.getFrequency());
        resource.setAddedOn(medication.getRefCreatedOn());
        resource.setSource(medication.getSource());

        return resource;
    }

}