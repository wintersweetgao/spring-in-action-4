package com.altruista.mp.resources;

import com.altruista.mp.model.ContactType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.validation.Valid;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 8/3/14.
 */
@XmlRootElement(name = "contact")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactResource extends ResourceSupport {
    private ContactType contactType;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.company}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.company}")
    private String company;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.salutation}")
    @Length(max = 50, message = "{length.validation.salutation}")
    private String salutation;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.firstname}")
    @Length(max = 200, message = "{length.validation.firstname}")
    private String firstName;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.middlename}")
    @Length(max = 200, message = "{length.validation.middlename}")
    private String middleName;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.lastname}")
    @Length(max = 200, message = "{length.validation.lastname}")
    private String lastName;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.namesuffix}")
    @Length(max = 50, message = "{length.validation.namesuffix}")
    private String nameSuffix;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.primaryemail}")
    @Length(max = 200, message = "{length.validation.primaryemail}")
    private String primaryEmail;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.alternateemail}")
    @Length(max = 200, message = "{length.validation.alternateemail}")
    private String alternateEmail;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.directemail}")
    @Length(max = 200, message = "{length.validation.directemail}")
    private String directEmail;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.daytimephonenumber}")
    @Length(max = 200, message = "{length.validation.daytimephonenumber}")
    private String daytimePhoneNumber;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.eveningphonenumber}")
    @Length(max = 200, message = "{length.validation.eveningphonenumber}")
    private String eveningPhoneNumber;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.mobilephonenumber}")
    @Length(max = 200, message = "{length.validation.mobilephonenumber}")
    private String mobilePhoneNumber;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.primarylanguage}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.primarylanguage}")
    private String primaryLanguage;
    @NotEmpty()
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.preferredtimeofcontact}")
    @Length(max = 50, message = "{length.validation.preferredtimeofcontact}")
    private String preferredTimeOfContact;
    @Valid
    private AddressResource address;
    @NotEmpty
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.phone}")
    @Length(max = 200, message = "{length.validation.phone}")
    private String phoneNumber;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.fax}")
    @Length(max = 200, message = "{length.validation.fax}")
    private String faxNumber;
    @Valid
    private MPDocumentResource photo;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.ethnicity}")
    @Length(max = ResourceSize.MAX_KEY, message = "{length.validation.ethnicity}")
    private String ethnicity;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.gender}")
    @Length(max = ResourceSize.MAX_KEY, message = "{length.validation.gender}")
    private String gender;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.dob}")
    @Length(max = ResourceSize.MAX_DATE, message = "{length.validation.dob}")
    private String dob;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.maritalstatus}")
    @Length(max = ResourceSize.MAX_KEY, message = "{length.validation.maritalstatus}")
    private String maritalStatus;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.timezone}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.timezone}")
    private String timezone;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.relationshiptomember}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.relationshiptomember}")
    private String relationshipToMember;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.description}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.description}")
    private String description;

    public ContactType getContactType() {
        return contactType;
    }

    public void setContactType(ContactType contactType) {
        this.contactType = contactType;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    public String getPrimaryEmail() {
        return primaryEmail;
    }

    public void setPrimaryEmail(String primaryEmail) {
        this.primaryEmail = primaryEmail;
    }

    public String getAlternateEmail() {
        return alternateEmail;
    }

    public void setAlternateEmail(String alternateEmail) {
        this.alternateEmail = alternateEmail;
    }

    public String getDirectEmail() {
        return directEmail;
    }

    public void setDirectEmail(String directEmail) {
        this.directEmail = directEmail;
    }

    public String getDaytimePhoneNumber() {
        return daytimePhoneNumber;
    }

    public void setDaytimePhoneNumber(String daytimePhoneNumber) {
        this.daytimePhoneNumber = daytimePhoneNumber;
    }

    public String getEveningPhoneNumber() {
        return eveningPhoneNumber;
    }

    public void setEveningPhoneNumber(String eveningPhoneNumber) {
        this.eveningPhoneNumber = eveningPhoneNumber;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public String getPrimaryLanguage() {
        return primaryLanguage;
    }

    public void setPrimaryLanguage(String primaryLanguage) {
        this.primaryLanguage = primaryLanguage;
    }

    public String getPreferredTimeOfContact() {
        return preferredTimeOfContact;
    }

    public void setPreferredTimeOfContact(String preferredTimeOfContact) {
        this.preferredTimeOfContact = preferredTimeOfContact;
    }

    public AddressResource getAddress() {
        return address;
    }

    public void setAddress(AddressResource address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public MPDocumentResource getPhoto() {
        return photo;
    }

    public void setPhoto(MPDocumentResource photo) {
        this.photo = photo;
    }

    public String getEthnicity() {
        return ethnicity;
    }

    public void setEthnicity(String ethnicity) {
        this.ethnicity = ethnicity;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getRelationshipToMember() {
        return relationshipToMember;
    }

    public void setRelationshipToMember(String relationshipToMember) {
        this.relationshipToMember = relationshipToMember;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
