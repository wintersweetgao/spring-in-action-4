package com.altruista.mp.restutils;

import com.altruista.mp.rest.exceptions.InvalidMemberIdException;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

public class MemberIdValidationUtil {
    @SuppressWarnings("unchecked")
    public static void validateMemberClaim(String memberId) throws ResourceException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        List<String> memberIds = (List<String>) auth.getCredentials();
        if (memberId == null || !memberIds.contains(memberId)) {
            throw new InvalidMemberIdException("You are not authorized to access this MemberId");
        }
    }

    public static void validateMemberClaim(List<String> memberIds) throws ResourceException {
        if (memberIds == null)
            throw new InvalidMemberIdException("You are not authorized to access this MemberId");

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        List<String> claims = (List<String>) auth.getCredentials();

        for (String memberId : memberIds) {
            if (claims != null) {
                for (String claim : claims) {
                    if (claim.equalsIgnoreCase(memberId))
                        return;
                }
            }
        }
        throw new InvalidMemberIdException("You are not authorized to access this MemberId");
    }
}