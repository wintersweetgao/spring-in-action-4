package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.joda.time.DateTime;

/**
 * Created by mwixson on 9/11/14.
 */
public class AssessmentRunStatusResource {
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.status}")
    @Length(max = ResourceSize.MAX_STATUS, message = "{length.validation.status}")
    private String status;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.notes}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.notes}")
    private String notes;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{}")
    private int lastSequence; // newly added fields
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime endedOn;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getLastSequence() {
        return lastSequence;
    }

    public void setLastSequence(int lastSequence) {
        this.lastSequence = lastSequence;
    }

    public DateTime getEndedOn() {
        return endedOn;
    }

    public void setEndedOn(DateTime endedOn) {
        this.endedOn = endedOn;
    }
}

