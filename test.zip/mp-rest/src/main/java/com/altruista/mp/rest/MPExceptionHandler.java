package com.altruista.mp.rest;

import com.altruista.mp.resources.*;
import com.altruista.mp.resources.ResourceNotFoundException;
import com.altruista.mp.rest.exceptions.*;
import com.altruista.mp.services.exceptions.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@ControllerAdvice
public class MPExceptionHandler extends ResponseEntityExceptionHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(MPExceptionHandler.class);

    @Autowired
    private ApplicationResourceService resourceService = null;

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
        LOGGER.warn("InvalidHttpMessageException: " + e);

        String message = e.getMessage();
        if (e.getMostSpecificCause() != null) {
            message = e.getMostSpecificCause().getLocalizedMessage();
            if (message.contains("at [")) {
                message = message.substring(0, message.indexOf("at ["));
            }
        }
        ErrorResource error = new ErrorResource("InvalidHttpMessageException", message);

        HttpHeaders responseHeaders = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, responseHeaders, HttpStatus.UNPROCESSABLE_ENTITY, request);
    }

    @ExceptionHandler({InvalidRequestException.class})
    protected ResponseEntity<Object> handleInvalidRequest(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        InvalidRequestException exc = (InvalidRequestException) e;
        LOGGER.warn("InvalidRequestException: " + exc);

        List<FieldErrorResource> fieldErrorResources = new ArrayList<>();

        List<FieldError> fieldErrors = exc.getErrors().getFieldErrors();
        for (FieldError fieldError : fieldErrors) {
            LOGGER.warn(fieldError.toString());
            FieldErrorResource fieldErrorResource = new FieldErrorResource();
            fieldErrorResource.setResource(fieldError.getObjectName());
            fieldErrorResource.setField(fieldError.getField());
            fieldErrorResource.setCode(fieldError.getCode());
            fieldErrorResource.setMessage(fieldError.getDefaultMessage());
            fieldErrorResources.add(fieldErrorResource);
        }

        // ErrorResource error = new ErrorResource("InvalidRequest", exc.getMessage());
        String errors = resourceService.messageResource("mp.exception.invalid.request.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Authentication", errors);
        error.setFieldErrors(fieldErrorResources);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return handleExceptionInternal(e, error, headers, HttpStatus.UNPROCESSABLE_ENTITY, request);
    }

    @ExceptionHandler({BadCredentialsException.class})
    protected ResponseEntity<Object> handleBadCredentials(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        BadCredentialsException be = (BadCredentialsException) e;
        LOGGER.warn("BadCredentialsException: " + be);

        String errors = resourceService.messageResource("mp.exception.bad.credentials.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Authentication", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({AuthenticationServiceException.class})
    protected ResponseEntity<Object> handleAuthServiceException(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        AuthenticationServiceException be = (AuthenticationServiceException) e;
        LOGGER.warn("AuthenticationServiceException: " + be);

        String errors = resourceService.messageResource("mp.exception.bad.authentication.service.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Authentication", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({DisabledException.class})
    protected ResponseEntity<Object> handleDisabledException(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        DisabledException be = (DisabledException) e;
        LOGGER.warn("DisabledException: " + be);

        String errors = resourceService.messageResource("mp.exception.bad.authentication.service.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Disabled", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({LockedUserException.class})
    protected ResponseEntity<Object> handleUserLockedRequest(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        LockedUserException ire = (LockedUserException) e;
        LOGGER.warn("LockedUserException: " + ire);

        String errors = resourceService.messageResource("mp.exception.locked.user.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Locked", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.LOCKED, request);
    }

    @ExceptionHandler({InvalidMemberIdException.class})
    protected ResponseEntity<Object> handleMemberIdRequest(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        InvalidMemberIdException ire = (InvalidMemberIdException) e;
        LOGGER.warn("InvalidMemberIdException: " + ire);

        String errors = resourceService.messageResource("mp.exception.invalid.member.id.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("InvalidMemberId", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({NullPointerException.class})
    protected ResponseEntity<Object> handleNullPointerEx(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        NullPointerException npe = (NullPointerException) e;
        LOGGER.error("NullPointerException: " + npe);

        String errors = resourceService.messageResource("mp.exception.invalid.member.id.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("System", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler({ServiceException.class})
    protected ResponseEntity<Object> handleServiceEx(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        ServiceException se = (ServiceException) e;
        LOGGER.error("ServiceException: " + se);

        String errors = resourceService.messageResource("mp.exception.service.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("System", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNPROCESSABLE_ENTITY, request);
    }

    @ExceptionHandler({IOException.class})
    protected ResponseEntity<Object> handleIOEx(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        IOException ioc = (IOException) e;
        LOGGER.error("IOException: " + ioc);

        String errors = resourceService.messageResource("mp.exception.io.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("System", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler({ServletException.class})
    protected ResponseEntity<Object> handleServletEx(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        ServletException se = (ServletException) e;
        LOGGER.error("ServletException: " + se);

        String errors = resourceService.messageResource("mp.exception.servlet.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("System", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler({TokenException.class})
    protected ResponseEntity<Object> handleTokentEx(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        TokenException te = (TokenException) e;
        LOGGER.warn("TokenException: " + te);

        String errors = resourceService.messageResource("mp.exception.token.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Token", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({Exception.class})
    protected ResponseEntity<Object> handleOtherEx(Exception e, WebRequest request, HttpServletRequest httpRequest) {
        LOGGER.error("GeneralException: " + e);

        String errors = resourceService.messageResource("mp.exception.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("System", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler({UserNotFoundException.class})
    protected ResponseEntity<Object> handleUserNotFoundException(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        UserNotFoundException ire = (UserNotFoundException) e;
        LOGGER.warn("UserNotFoundException: " + ire);

        String errors = resourceService.messageResource("mp.exception.user.not.found.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Registration", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    /**
     * Added for already registered user in Member Portal
     */
    @ExceptionHandler({AlreadyRegisteredException.class})
    protected ResponseEntity<Object> handleAlreadyRegisteredException(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        AlreadyRegisteredException ire = (AlreadyRegisteredException) e;
        LOGGER.warn("AlreadyRegisteredException: " + ire);

        String errors = resourceService.messageResource("mp.exception.already.registered.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("AlreadyRegisteredUser", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.FOUND, request);
    }

    @ExceptionHandler({ResourceNotFoundException.class})
    protected ResponseEntity<Object> handleResourceNotFoundException(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        ResourceNotFoundException ire = (ResourceNotFoundException) e;
        LOGGER.warn("ResourceNotFound: " + ire);

        String errors = resourceService.messageResource("mp.exception.resource.not.found.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Resource", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.NOT_FOUND, request);
    }

    @ExceptionHandler({InvalidPasswordException.class})
    protected ResponseEntity<Object> handlePasswordEx(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        InvalidPasswordException ipe = (InvalidPasswordException) e;
        LOGGER.error("InvalidPasswordException: " + ipe);

        String errors = resourceService.messageResource("mp.exception.invalid.password.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Authentication", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({InvalidCredentialException.class})
    protected ResponseEntity<Object> handleCredentialEx(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        InvalidCredentialException ide = (InvalidCredentialException) e;
        LOGGER.error("InvalidCredentialException: " + ide);

        String errors = resourceService.messageResource("mp.exception.invalid.credential.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Registration", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.UNAUTHORIZED, request);
    }

    @ExceptionHandler({AccessDeniedException.class})
    protected ResponseEntity<Object> handleDisabledEx(RuntimeException e, WebRequest request, HttpServletRequest httpRequest) {
        AccessDeniedException ade = (AccessDeniedException) e;
        LOGGER.error("AccessDeniedException: " + ade);

        String errors = resourceService.messageResource("mp.exception.access.denied.exception", getRequestLocale(httpRequest));
        ErrorResource error = new ErrorResource("Registration", errors);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(e, error, headers, HttpStatus.FORBIDDEN, request);
    }

    private Locale getRequestLocale(HttpServletRequest httpRequest) {
        Locale acceptedLanguage = httpRequest.getLocale();
        LOGGER.debug("Accepted Language : " + acceptedLanguage);
        return acceptedLanguage;
    }

}

