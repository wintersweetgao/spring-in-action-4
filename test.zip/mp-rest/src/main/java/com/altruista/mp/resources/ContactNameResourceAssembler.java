package com.altruista.mp.resources;

import com.altruista.mp.model.Contact;
import com.altruista.mp.rest.ContactController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class ContactNameResourceAssembler extends
        ResourceAssemblerSupport<Contact, ContactNameResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContactNameResourceAssembler.class);

    public ContactNameResourceAssembler() {
        super(ContactController.class, ContactNameResource.class);
    }

    @Override
    public ContactNameResource toResource(Contact contact) {

        ContactNameResource resource = instantiateResource(contact);

        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(ContactController.class).getContact(contact.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }
        // copy properties from contact to contactResource
        resource.setContactType(contact.getContactType());
        resource.setCompany(contact.getCompany());
        resource.setSalutation(contact.getSalutation());
        resource.setFirstName(contact.getFirstName());
        resource.setMiddleName(contact.getMiddleName());
        resource.setLastName(contact.getLastName());
        resource.setNameSuffix(contact.getNameSuffix());

        return resource;
    }

    public Contact fromResource(String id, ContactNameResource resource) {

        Contact contact = new Contact();

        // copy properties from contactResource to contact
        contact.setId(id);
        contact.setContactType(resource.getContactType());
        contact.setCompany(resource.getCompany());
        contact.setSalutation(resource.getSalutation());
        contact.setFirstName(resource.getFirstName());
        contact.setMiddleName(resource.getMiddleName());
        contact.setLastName(resource.getLastName());
        contact.setNameSuffix(resource.getNameSuffix());

        return contact;
    }
}
