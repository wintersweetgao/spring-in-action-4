package com.altruista.mp.restutils;

import com.altruista.mp.resources.ContactResource;

import java.util.Comparator;

/**
 * Created by mwixson on 10/30/14.
 */
public class ContactResourceNameComparer implements Comparator<ContactResource> {
    @Override
    public int compare(ContactResource x, ContactResource y) {
        String xname;
        if (x.getFirstName() != null && x.getLastName() != null)
            xname = String.format("%s %s", x.getFirstName(), x.getLastName());
        else
            xname = x.getCompany();

        String yname;
        if (y.getFirstName() != null && y.getLastName() != null)
            yname = String.format("%s %s", y.getFirstName(), y.getLastName());
        else
            yname = y.getCompany();

        if (xname == null || yname == null)
            return 0;
        else
            return xname.compareTo(yname);
    }
}