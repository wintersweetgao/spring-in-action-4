package com.altruista.mp.resources;

import com.altruista.mp.model.PushNotificationRegistration;
import com.altruista.mp.rest.PushNotificationRegistrationController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;


/*
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by Prateek on 10/19/15
 */
public class PushNotificationRegistrationResourceAssembler extends
        ResourceAssemblerSupport<PushNotificationRegistration, PushNotificationRegistrationResource> {

    public PushNotificationRegistrationResourceAssembler() {
        super(PushNotificationRegistrationController.class, PushNotificationRegistrationResource.class);
    }

    @Override
    public PushNotificationRegistrationResource toResource(PushNotificationRegistration pnRegistration) {
        return createResourceWithId(pnRegistration.getId(), pnRegistration);
    }

    @Override
    protected PushNotificationRegistrationResource instantiateResource(PushNotificationRegistration entity) {
        PushNotificationRegistrationResource resource = new PushNotificationRegistrationResource();
        resource.setContactId(entity.getContactId());
        resource.setDeviceOS(entity.getDeviceOS());
        resource.setDeviceToken(entity.getDeviceToken());
        resource.setRegID(entity.getRegID());

        return resource;
    }

    public PushNotificationRegistration fromResource(PushNotificationRegistrationResource resource) {

        PushNotificationRegistration pnRegistration = new PushNotificationRegistration();

        // copy properties from messageResource to message
        pnRegistration.setContactId(resource.getContactId());
        pnRegistration.setDeviceOS(resource.getDeviceOS());
        pnRegistration.setDeviceToken(resource.getDeviceToken());
        pnRegistration.setRegID(resource.getRegID());

        return pnRegistration;
    }
}
