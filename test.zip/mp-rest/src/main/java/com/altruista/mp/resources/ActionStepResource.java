package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

/**
 * Created by mwixson on 8/11/14.
 */
public class ActionStepResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String goalId;
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.lob}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.lob}")
    private String lob;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.goalgroup}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.goalgroup}")
    private String goalGroup;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.condition}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.condition}")
    private String condition;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.term}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.term}")
    private String term;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.step}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.step}")
    private String step;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.intervention}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.intervention}")
    private String intervention;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.status}")
    @Length(max = ResourceSize.MAX_STATUS, message = "{length.validation.status}")
    private String status;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.memberstatus}")
    @Length(max = ResourceSize.MAX_STATUS, message = "{length.validation.memberstatus}")
    private String memberStatus;
    private Boolean signedOff;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.notes}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.notes}")
    private String notes;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime startOn;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime endOn;

    public String getGoalId() {
        return goalId;
    }

    public void setGoalId(String goalId) {
        this.goalId = goalId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getIntervention() {
        return intervention;
    }

    public void setIntervention(String intervention) {
        this.intervention = intervention;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMemberStatus() {
        return memberStatus;
    }

    public void setMemberStatus(String memberStatus) {
        this.memberStatus = memberStatus;
    }

    public Boolean getSignedOff() {
        return signedOff;
    }

    public void setSignedOff(Boolean signedOff) {
        this.signedOff = signedOff;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public DateTime getStartOn() {
        return startOn;
    }

    public void setStartOn(DateTime startOn) {
        this.startOn = startOn;
    }

    public DateTime getEndOn() {
        return endOn;
    }

    public void setEndOn(DateTime endOn) {
        this.endOn = endOn;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public String getGoalGroup() {
        return goalGroup;
    }

    public void setGoalGroup(String goalGroup) {
        this.goalGroup = goalGroup;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }
}
