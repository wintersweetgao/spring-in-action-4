package com.altruista.mp.rest;

import com.altruista.mp.model.Member;
import com.altruista.mp.resources.MemberResource;
import com.altruista.mp.resources.MemberResourceAssembler;
import com.altruista.mp.resources.ResourceNotFoundException;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.MemberService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/api/member")
@Api(value = "Member service", description = "Manage Members")
public class MemberController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberController.class);

    private final MemberService memberService;
    private MemberResourceAssembler memberAssembler;

    @Autowired
    public MemberController(MemberService memberService) {
        this.memberService = memberService;
        memberAssembler = new MemberResourceAssembler();
    }

    @RequestMapping(value = "/{memberId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the member using Member id")
    public HttpEntity<MemberResource> getMemberByMemberId(
            @PathVariable("memberId") String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        Member member = memberService.get(memberId);
        MemberResource resource = memberAssembler.toResource(member);
        return new ResponseEntity<MemberResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/{memberId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves the member")
    public HttpEntity<MemberResource> saveMember(
            @PathVariable("memberId") String memberId, @RequestBody MemberResource resource) throws ResourceException {
        // verify user has access to this member
        MemberIdValidationUtil.validateMemberClaim(memberId);

        // load existing member information
        Member original = memberService.get(memberId);
        if (original == null)
            throw new ResourceNotFoundException("Member not found.");

        // overwrite member information with updated resource information
        Member updated = memberAssembler.fromResource(resource, original);

        // save the updated member
        memberService.save(updated);

        return new ResponseEntity<MemberResource>(resource, HttpStatus.OK);
    }
}
