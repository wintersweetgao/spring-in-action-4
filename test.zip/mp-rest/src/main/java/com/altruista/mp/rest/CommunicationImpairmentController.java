package com.altruista.mp.rest;

import com.altruista.mp.resources.CommunicationImpairmentResource;
import com.altruista.mp.resources.CommunicationImpairmentResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.CommunicationImpairmentService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for alerts
 */
@Controller
@RequestMapping("/api/impairment")
@Api(value = "Communication Impairment service", description = "Manage Communication Impairments")
public class CommunicationImpairmentController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommunicationImpairmentController.class);

    private final CommunicationImpairmentService impairmentService;
    private CommunicationImpairmentResourceAssembler impairmentAssembler;

    @Autowired
    public CommunicationImpairmentController(CommunicationImpairmentService impairmentService) {
        this.impairmentService = impairmentService;
        impairmentAssembler = new CommunicationImpairmentResourceAssembler();
    }

    @ApiOperation(value = "Gets Communication Impairments using member id")
    @RequestMapping(value = "/{memberId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<CommunicationImpairmentResource>> getCommunicationImpairmentsByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<CommunicationImpairmentResource> resourceList = impairmentAssembler.toResources(impairmentService.findByMemberId(memberId));
        return new ResponseEntity<List<CommunicationImpairmentResource>>(resourceList,
                HttpStatus.OK);
    }

}