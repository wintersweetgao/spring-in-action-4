package com.altruista.mp.resources;

import com.altruista.mp.model.ValidValue;
import com.altruista.mp.rest.ValidValueController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class ValidValueResourceAssembler extends
        ResourceAssemblerSupport<ValidValue, ValidValueResource> {

    public ValidValueResourceAssembler() {
        super(ValidValueController.class, ValidValueResource.class);
    }

    @Override
    public ValidValueResource toResource(ValidValue alert) {
        return createResourceWithId(alert.getId(), alert);
    }

    @Override
    protected ValidValueResource instantiateResource(ValidValue entity) {
        ValidValueResource resource = new ValidValueResource();

        resource.setRefId(entity.getRefId());
        resource.setName(entity.getName());
        resource.setValue(entity.getValue());
        resource.setDescription(entity.getDescription());

        return resource;
    }

}
