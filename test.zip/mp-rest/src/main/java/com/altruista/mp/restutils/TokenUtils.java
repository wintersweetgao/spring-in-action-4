package com.altruista.mp.restutils;

import com.altruista.mp.model.User;
import com.altruista.mp.rest.exceptions.TokenException;
import com.altruista.mp.utils.PropertiesLoaderUtility;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.ReadOnlyJWTClaimsSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;


public class TokenUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(TokenUtils.class);
    private static final String ISSUER = "Altruista Health Member Portal";
    private static RSAPublicKey publicKey;
    private static RSAPrivateKey privateKey;

    static {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");

            // Loading from file (Dynamic code value)
            RSAPublicKeySpec publicKeySpec = new RSAPublicKeySpec(PublicPrivateKeyLoaderUtil.getPublicKeyModulus(), PublicPrivateKeyLoaderUtil.getPublicKeyExponent());
            RSAPrivateKeySpec privateKeySpec = new RSAPrivateKeySpec(PublicPrivateKeyLoaderUtil.getPrivateKeyModulus(), PublicPrivateKeyLoaderUtil.getPrivateKeyExponent());


            publicKey = (RSAPublicKey) keyFactory.generatePublic(publicKeySpec);
            privateKey = (RSAPrivateKey) keyFactory.generatePrivate(privateKeySpec);

        } catch (Exception e) {
            LOGGER.error("Unable to initialize JWT key: " + e);
        }
    }

    public static String createToken(User user, boolean isRegistration) throws TokenException {
        String jwtString = null;
        try {
            JWTClaimsSet jwtClaims = new JWTClaimsSet();
            jwtClaims.setIssuer(ISSUER);
            if (user.getUsername() != null)
                jwtClaims.setSubject(user.getUsername());
            else
                jwtClaims.setSubject(user.getContactCode());
            List<String> aud = new ArrayList<String>();
            // add each memberId as an audience
            for (String id : user.getMemberIds()) {
                aud.add(id);
            }
            jwtClaims.setAudience(aud);
            jwtClaims.setExpirationTime(new Date(new Date().getTime() + 1000 * 60 * Integer.parseInt(PropertiesLoaderUtility.getProperty("user.session.timeout.time.in.minutes"))));   // 1 hour
            jwtClaims.setNotBeforeTime(new Date());
            jwtClaims.setIssueTime(new Date());
            jwtClaims.setJWTID(UUID.randomUUID().toString());
            if (isRegistration)
                jwtClaims.setCustomClaim("MPREG", "1");
            else
                jwtClaims.setCustomClaim("MPREG", "0");

            JWEHeader header = new JWEHeader(
                    JWEAlgorithm.RSA_OAEP,
                    EncryptionMethod.A128GCM
            );

            RSAEncrypter encrypter = new RSAEncrypter(publicKey);

            EncryptedJWT jwt = new EncryptedJWT(header, jwtClaims);
            jwt.encrypt(encrypter);
            jwtString = jwt.serialize();
        } catch (JOSEException exc) {
            LOGGER.error("JWT Exception: " + exc);
            throw new TokenException("JWT Exception: " + exc.getMessage());
        }

        return jwtString;
    }

    public static ReadOnlyJWTClaimsSet extractClaims(String jwtString) throws TokenException {

        try {
            // Parse back
            EncryptedJWT jwt = EncryptedJWT.parse(jwtString);

            // Create an decrypter with the specified private RSA key
            RSADecrypter decrypter = new RSADecrypter(privateKey);

            // Decrypt
            jwt.decrypt(decrypter);

            // Retrieve JWT claims
            return jwt.getJWTClaimsSet();
        } catch (ParseException exc) {
            LOGGER.error("JWT Exception while parsing token: " + exc);
            throw new TokenException("JWT Exception: " + exc.getMessage());
        } catch (JOSEException exc) {
            LOGGER.error("JWT Exception: " + exc);
            throw new TokenException("JWT Exception: " + exc.getMessage());
        }
    }

    public static boolean validateToken(ReadOnlyJWTClaimsSet claims, User user) {
        if (!claims.getIssuer().equals(ISSUER)) {
            LOGGER.error("Validate Token failed-Invalid Issuer for username: " + user.getUsername());
            return false;
        }
        if (!claims.getSubject().equals(user.getUsername())) {
            LOGGER.error("Validate Token failed-Invalid Subject for username: " + user.getUsername());
            return false;
        }

        long expires = claims.getExpirationTime().getTime();
        if (expires < System.currentTimeMillis()) {
            LOGGER.warn("Validate Token failed-token expired for username: " + user.getUsername());
            return false;
        }

        return true;
    }

}
