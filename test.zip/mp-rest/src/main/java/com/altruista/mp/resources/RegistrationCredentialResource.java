package com.altruista.mp.resources;

import com.altruista.mp.model.ContactType;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;

/**
 * Created by mwixson on 11/3/14.
 */
public class RegistrationCredentialResource {
    private ContactType contactType;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.memberCode}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.memberCode}")
    private String memberCode;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.dob}")
    @Length(max = ResourceSize.MAX_DATE, message = "{length.validation.dob}")
    private String dob;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.phone}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.phone}")
    private String phoneNumber;

    public ContactType getContactType() {
        return contactType;
    }

    public void setContactType(ContactType contactType) {
        this.contactType = contactType;
    }

    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
