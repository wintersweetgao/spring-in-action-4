package com.altruista.mp.rest.exceptions;

public class ResourceException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 4315135746501279205L;

    public ResourceException(String message) {
        super(message);
    }
}
