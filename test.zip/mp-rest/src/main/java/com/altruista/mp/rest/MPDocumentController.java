package com.altruista.mp.rest;

import com.altruista.mp.model.Condition;
import com.altruista.mp.model.MPDocument;
import com.altruista.mp.model.XLSDownload;
import com.altruista.mp.resources.MPDocumentResource;
import com.altruista.mp.resources.MPDocumentResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.ConditionService;
import com.altruista.mp.services.MPDocumentService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles requests for MPDocuments
 */
@Controller
@Api(value = "Document service", description = "Manage Documents")
public class MPDocumentController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MPDocumentController.class);

    private final MPDocumentService documentService;
    private MPDocumentResourceAssembler documentAssembler;
    private ConditionService conditionService;

    @Autowired
    public MPDocumentController(MPDocumentService documentService, ConditionService conditionService) {
        this.documentService = documentService;
        this.conditionService = conditionService;
        documentAssembler = new MPDocumentResourceAssembler();
    }

    @RequestMapping(value = "/api/member/{memberId}/document/{bodyRegion}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Documents using member id")
    public HttpEntity<List<MPDocumentResource>> getDocumentsByMemberId(@PathVariable("memberId") String memberId, @PathVariable("bodyRegion") String bodyRegion) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);

        List<String> bodyTags = new ArrayList<String>();
        bodyTags.add(bodyRegion);

        List<MPDocument> docs = documentService.findByTags(bodyTags);
        List<Condition> conditionList = conditionService.findByMemberId(memberId);

        List<MPDocument> resultDocs = new ArrayList<MPDocument>();
        for (MPDocument doc : docs) {
            for (Condition condition : conditionList) {
                List<String> tags = doc.getTags();
                for (int i = 0; i < tags.size(); i++) {
                    if (condition.getName().equalsIgnoreCase(tags.get(i))) {
                        resultDocs.add(doc);
                    }
                }
            }
        }
        List<MPDocumentResource> resourceList = documentAssembler.toResources(resultDocs);
        return new ResponseEntity<List<MPDocumentResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/document", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Gets all Documents")
    public HttpEntity<List<MPDocumentResource>> getAllDocuments() throws ResourceException {
        List<MPDocumentResource> resourceList = documentAssembler.toResources(documentService.findAll());

        return new ResponseEntity<List<MPDocumentResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/document/{documentId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets Document using Document id")
    public HttpEntity<MPDocumentResource> getDocument(
            @PathVariable("documentId") String documentId) throws ResourceException {
        MPDocument doc = documentService.get(documentId);
        String memberId = doc.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        MPDocumentResource resource = documentAssembler.toResource(doc);
        return new ResponseEntity<MPDocumentResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/document/{documentId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves Document using Document id")
    public HttpEntity<MPDocumentResource> saveDocument(
            @PathVariable("documentId") String documentId, @RequestBody MPDocumentResource resource) throws ResourceException {
        String memberId = resource.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        MPDocument doc = documentAssembler.fromResource(documentId, resource);
        documentService.save(doc);
        return new ResponseEntity<MPDocumentResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/document/{documentId}/resource", method = RequestMethod.GET)
    @ApiOperation(value = "Get the Image Resource using Document Id")
    public
    @ResponseBody
    String getImageResource(@PathVariable("documentId") String documentId) throws ResourceException {

        MPDocument doc = documentService.get(documentId);
        String memberId = doc.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        try {
            return documentService.getEncodedImageResource(doc);
        } catch (ServiceException e) {
            throw new RuntimeException(e);
        }
    }

    @RequestMapping(value = "/{documentId}/image", method = RequestMethod.GET)
    @ApiOperation(value = "Get the Image File using Document id")
    public
    @ResponseBody
    String getImageFile(@PathVariable("documentId") String documentId) throws ResourceException {

        MPDocument doc = documentService.get(documentId);
        String memberId = doc.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        try {
            return documentService.getEncodedImageFile(doc);
        } catch (ServiceException e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/api/document", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Export MyHealth Tracker Data to Excel")
    public
    @ResponseBody
    void downloadXLS(@RequestBody XLSDownload payload, HttpServletResponse response) throws IOException {

        response.setHeader("Content-Disposition", "attachment;filename=" + payload.getFileName());
        response.setContentType(payload.getContentType());

        byte[] data = DatatypeConverter.parseBase64Binary(payload.getBase64());
        LOGGER.debug("Data : " + data);
        response.setContentLength(data.length);
        response.getOutputStream().write(data);
        response.flushBuffer();
    }


    /*
     *  @base64: The base-64 encoded file content;
     *  @fileName: the file name as set in the export option;
     *  http://stackoverflow.com/questions/16652760/return-generated-pdf-using-spring-mvc
     */
    /*@RequestMapping(value = "/api/document/{fileName}/{base64}", method = RequestMethod.POST)
    @ApiOperation(value="Export MyHealth Tracker Data to Excel")
    public ResponseEntity<byte[]> ExportToExcel(
            @PathVariable("base64") String base64, @PathVariable("fileName") String fileName) throws ResourceException {

        // Decode the base-64 encoded file contents
        byte[] contents = Base64.decodeBase64(base64);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDispositionFormData(fileName, fileName);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(contents, headers, HttpStatus.OK);
        return response;
    }*/
}