package com.altruista.mp.resources;

import com.altruista.mp.model.Address;
import com.altruista.mp.model.Contact;
import com.altruista.mp.model.MPDocument;
import com.altruista.mp.rest.ContactController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class ContactResourceAssembler extends
        ResourceAssemblerSupport<Contact, ContactResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContactResourceAssembler.class);

    public ContactResourceAssembler() {
        super(ContactController.class, ContactResource.class);
    }

    @Override
    public ContactResource toResource(Contact contact) {

        ContactResource resource = instantiateResource(contact);

        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(ContactController.class).getContact(contact.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }
        // copy properties from contact to contactResource
        resource.setContactType(contact.getContactType());
        resource.setCompany(contact.getCompany());
        resource.setSalutation(contact.getSalutation());
        resource.setFirstName(contact.getFirstName());
        resource.setMiddleName(contact.getMiddleName());
        resource.setLastName(contact.getLastName());
        resource.setNameSuffix(contact.getNameSuffix());
        resource.setPrimaryEmail(contact.getPrimaryEmail());
        resource.setAlternateEmail(contact.getAlternateEmail());
        resource.setDirectEmail(contact.getDirectEmail());
        resource.setDaytimePhoneNumber(contact.getDaytimePhoneNumber());
        resource.setEveningPhoneNumber(contact.getEveningPhoneNumber());
        resource.setMobilePhoneNumber(contact.getMobilePhoneNumber());
        resource.setPrimaryLanguage(contact.getPrimaryLanguage());
        resource.setPreferredTimeOfContact(contact.getPreferredTimeOfContact());
        resource.setAddress(toAddressResource(contact.getAddress()));
        resource.setPhoneNumber(contact.getPhoneNumber());
        resource.setFaxNumber(contact.getFaxNumber());
        resource.setPhoto(toMPDocumentResource(contact.getPhoto()));
        resource.setEthnicity(contact.getEthnicity());
        resource.setGender(contact.getGender());
        resource.setMaritalStatus(contact.getMaritalStatus());
        resource.setDob(contact.getDob());
        resource.setTimezone(contact.getTimezone());
        resource.setRelationshipToMember(contact.getRelationshipToMember());
        resource.setDescription(contact.getDescription());

        return resource;
    }

    public AddressResource toAddressResource(Address address) {

        if (address == null)
            return null;

        AddressResource resource = new AddressResource();
        resource.setPrimary(address.isPrimary());
        resource.setAddress(address.getAddress());
        resource.setAddress2(address.getAddress2());
        resource.setCity(address.getCity());
        resource.setStateProvince(address.getStateProvince());
        resource.setPostalCode(address.getPostalCode());
        resource.setCounty(address.getCounty());
        resource.setCountry(address.getCountry());

        return resource;
    }

    public MPDocumentResource toMPDocumentResource(MPDocument document) {

        if (document == null)
            return null;

        MPDocumentResource mpresource = new MPDocumentResource();
        mpresource.setMemberId(document.getMemberId());
        mpresource.setName(document.getName());
        mpresource.setDescription(document.getDescription());
        mpresource.setHeading(document.getHeading());
        mpresource.setDocumentText(document.getDocumentText());
        mpresource.setDocumentType(document.getDocumentType());
        mpresource.setThumbnail(document.getThumbnail());
        mpresource.setDocumentUrl(document.getDocumentUrl());
        mpresource.setSource(document.getDocumentUrl());
        mpresource.setTags(document.getTags());

        return mpresource;
    }

    public Contact fromResource(ContactResource resource, Contact contact) {

        if (contact == null)
            contact = new Contact();

        // copy properties from contactResource to contact
        contact.setContactType(resource.getContactType());
        contact.setCompany(resource.getCompany());
        contact.setSalutation(resource.getSalutation());
        contact.setFirstName(resource.getFirstName());
        contact.setMiddleName(resource.getMiddleName());
        contact.setLastName(resource.getLastName());
        contact.setNameSuffix(resource.getNameSuffix());
        contact.setPrimaryEmail(resource.getPrimaryEmail());
        contact.setAlternateEmail(resource.getAlternateEmail());
        contact.setDirectEmail(resource.getDirectEmail());
        contact.setDaytimePhoneNumber(resource.getDaytimePhoneNumber());
        contact.setEveningPhoneNumber(resource.getEveningPhoneNumber());
        contact.setMobilePhoneNumber(resource.getMobilePhoneNumber());
        contact.setPrimaryLanguage(resource.getPrimaryLanguage());
        contact.setPreferredTimeOfContact(resource.getPreferredTimeOfContact());
        contact.setAddress(fromAddressResource(resource.getAddress()));
        contact.setPhoneNumber(resource.getPhoneNumber());
        contact.setFaxNumber(resource.getFaxNumber());
        contact.setPhoto(fromMPDocumentResource(resource.getPhoto()));
        contact.setEthnicity(resource.getEthnicity());
        contact.setGender(resource.getGender());
        contact.setMaritalStatus(resource.getMaritalStatus());
        contact.setDob(resource.getDob());
        contact.setTimezone(resource.getTimezone());
        contact.setRelationshipToMember(resource.getRelationshipToMember());

        return contact;
    }

    public Address fromAddressResource(AddressResource resource) {

        if (resource == null)
            return null;

        Address address = new Address();
        address.setPrimary(resource.isPrimary());
        address.setAddress(resource.getAddress());
        address.setAddress2(resource.getAddress2());
        address.setCity(resource.getCity());
        address.setStateProvince(resource.getStateProvince());
        address.setPostalCode(resource.getPostalCode());
        address.setCounty(resource.getCounty());
        address.setCountry(resource.getCountry());

        return address;
    }

    public MPDocument fromMPDocumentResource(MPDocumentResource mpresource) {

        if (mpresource == null)
            return null;

        MPDocument document = new MPDocument();
        document.setMemberId(mpresource.getMemberId());
        document.setName(mpresource.getName());
        document.setDescription(mpresource.getDescription());
        document.setHeading(mpresource.getHeading());
        document.setDocumentText(mpresource.getDocumentText());
        document.setDocumentType(mpresource.getDocumentType());
        document.setThumbnail(mpresource.getThumbnail());
        document.setDocumentUrl(mpresource.getDocumentUrl());
        document.setSource(mpresource.getDocumentUrl());
        document.setTags(mpresource.getTags());

        return document;
    }
}