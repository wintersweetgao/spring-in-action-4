package com.altruista.mp.resources;

import com.altruista.mp.model.Diagnosis;
import com.altruista.mp.rest.DiagnosisController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class DiagnosisResourceAssembler extends
        ResourceAssemblerSupport<Diagnosis, DiagnosisResource> {

    public DiagnosisResourceAssembler() {
        super(DiagnosisController.class, DiagnosisResource.class);
    }

    @Override
    public DiagnosisResource toResource(Diagnosis diagnosis) {
        return createResourceWithId(diagnosis.getId(), diagnosis);
    }

    @Override
    protected DiagnosisResource instantiateResource(Diagnosis entity) {
        DiagnosisResource resource = new DiagnosisResource();
        resource.setMemberId(entity.getMemberId());
        resource.setPrimary(entity.isPrimary());
        resource.setName(entity.getName());
        resource.setCategory(entity.getCategory());
        resource.setSource(entity.getSource());
        resource.setRank(entity.getRank());
        resource.setAddedOn(entity.getRefCreatedOn());
        return resource;
    }

}
