package com.altruista.mp.rest;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberIndexService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.UserService;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.AccessDeniedException;

import java.util.List;

/**
 * Developed by Prateek on 09/25/15
 */
public class SAMLHandlerUHCImpl implements SAMLHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(SAMLHandlerUHCImpl.class);
    
    @Value("#{'${saml.uhc.csp.member.indexes}'.split(',')}")
    private List<String> listOfIndexes;
    
    @Autowired
    private UserService userService;
    @Autowired
    private MemberIndexService memberIndexService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private ContactService contactService;

    public User lookupUser(List<Claim> claims) throws AccessDeniedException {
        LOGGER.debug("~~~ Perform User Lookup ~~~");
        User user;
        String empLastName = null;
        String empFirstName = null;
        String empDateOfBirth = null;
        String empState = null;
        String empDivCode = null;
        String eEID = null;
        String relayState = null;

        // get the claims from Attributes and ChildAttributes
        for (Claim claim : claims) {
            // ClaimType for lastname http://myuhc/claims/EmpLastName
            if (claim.getClaimType().contains("EmpLastName"))
                empLastName = claim.getClaimValue();
                // ClaimType for givenname http://myuhc/claims/EmpFirstName
            else if (claim.getClaimType().contains("EmpFirstName"))
                empFirstName = claim.getClaimValue();
                // ClaimType for EmpDateOfBirth http://myuhc/claims/EmpDateOfBirth
            else if (claim.getClaimType().contains("EmpDateOfBirth"))
                empDateOfBirth = claim.getClaimValue();
                // ClaimType for EmpState http://myuhc/claims/EmpState
            else if (claim.getClaimType().contains("EmpState"))
                empState = claim.getClaimValue();
                // ClaimType for EmpDivCode http://myuhc/claims/EmpDivCode
            else if (claim.getClaimType().contains("EmpDivCode"))
                empDivCode = claim.getClaimValue();
                // ClaimType for EmpAltID http://myuhc/claims/EEID
            else if (claim.getClaimType().contains("EEID")) //EEID (EmpAltID earlier)
                eEID = claim.getClaimValue();
            else if (claim.getClaimType().contains("relayState"))
                relayState = claim.getClaimValue();
        }

        if (empLastName == null)
            throw new AccessDeniedException("ClaimType EmpLastName not found");
        if (empFirstName == null)
            throw new AccessDeniedException("ClaimType EmpFirstName not found");
        if (empDateOfBirth == null)
            throw new AccessDeniedException("ClaimType EmpDateOfBirth not found");
        if (empState == null)
            throw new AccessDeniedException("ClaimType EmpState not found");
        if (eEID == null)
            throw new AccessDeniedException("ClaimType EEID not found");
        else
            eEID = StringUtils.stripStart(eEID, "0");
        if (relayState == null)
            throw new AccessDeniedException("ClaimType RelayState not found");

        if (empDivCode == null || empDivCode.isEmpty()) {
            // CSP Facets Member
            user = lookupUserWithoutUsingDivision(eEID, empFirstName, empLastName, empDateOfBirth, empState);
        } else {
            //COSMOS Member
            user = lookupUserUsingDivision(empDivCode, eEID, empFirstName, empLastName, empDateOfBirth, empState);
        }
        return user;
    }


    // For COSMOS Members
    private User lookupUserUsingDivision(String empDivCode, String eEID, String empFirstName, String empLastName, String empDateOfBirth, String empState) {
        String indexName = String.format("%s%s", eEID, empDivCode);
        User user = null;
        List<Contact> contacts = contactService.findByContactCode(indexName);
        for (Contact contact : contacts) {

            /** check claims matches with field of mongodb documents */
            if (!contact.getFirstName().equals(empFirstName)) {
                LOGGER.info("EmpFirstName " + empFirstName + " does not match with database value " + contact.getFirstName());
            } else if (!contact.getLastName().equals(empLastName)) {
                LOGGER.info("EmpLastName " + empLastName + " does not match with database value " + contact.getLastName());
            } else if (!contact.getDob().equals(getFormattedDOB(empDateOfBirth))) {
                LOGGER.info("EmpDateOfBirth " + getFormattedDOB(empDateOfBirth) + " does not match with database value " + contact.getDob());
            } else if (!contact.getAddress().getStateProvince().equals(empState)) {
                LOGGER.info("EmpState " + empState + " does not match with database value " + contact.getAddress().getStateProvince());
            }
            List<User> userList = userService.findByContactId(contact.getId());
            user = userList.get(0);
            break;
        }

        if (user == null)
            throw new ResourceNotFoundException("Contact Code " + indexName + " not found.");
        else
            return user;
    }

    // For CSP Members
    private User lookupUserWithoutUsingDivision(String eEID, String empFirstName, String empLastName, String empDateOfBirth, String empState) {

        List<MemberIndex> indexes = memberIndexService.findByIndexNameInAndValue(listOfIndexes, eEID);
        User user = null;
        for (MemberIndex memberIndex : indexes) {
            List<Member> members = memberService.findById(memberIndex.getMemberId());
            for (Member member : members) {
                List<Contact> contacts = contactService.findById(member.getContactId());
                for (Contact contact : contacts) {

                    /** check claims matches with our mongodb documents */
                    if (!contact.getFirstName().equals(empFirstName)) {
                        LOGGER.info("EmpFirstName " + empFirstName + " does not match with database value " + contact.getFirstName());
                    } else if (!contact.getLastName().equals(empLastName)) {
                        LOGGER.info("EmpLastName " + empLastName + " does not match with database value " + contact.getLastName());
                    } else if (!contact.getDob().equals(getFormattedDOB(empDateOfBirth))) {
                        LOGGER.info("EmpDateOfBirth " + getFormattedDOB(empDateOfBirth) + " does not match with database value " + contact.getDob());
                    } else if (!contact.getAddress().getStateProvince().equals(empState)) {
                        LOGGER.info("EmpState " + empState + " does not match with database value " + contact.getAddress().getStateProvince());
                    }
                    List<User> userList = userService.findByContactId(contact.getId());
                    user = userList.get(0);
                    break;
                }
            }
        }
        if (user == null)
            throw new ResourceNotFoundException("Subscriber ID " + eEID + " not found.");
        else
            return user;
    }

    private String getFormattedDOB(String empDateOfBirth) {
        DateTime empDOB = DateTime.parse(empDateOfBirth, DateTimeFormat.forPattern("MM/dd/yyyy"));
        DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd");
        return fmt.print(empDOB);
    }

    @Override
    public String lookupWidgetName(List<Claim> claims, String relayState) {
        String widgetName = null;
        for (Claim claim : claims) {
            if (claim.getClaimType().contains("relayState"))
                widgetName = getLastBitFromUrl(claim.getClaimValue());
        }
        return widgetName;
    }

    // This will get data after last slash (/)
    private static String getLastBitFromUrl(final String url) {
        return url.replaceFirst(".*/([^/?]+).*", "$1");
    }


	@Override
	public String lookupMode(List<Claim> claims) {
		String mode = null;
		for (Claim claim : claims) {
            if (claim.getClaimType().contains("Mode"))
            	mode = getLastBitFromUrl(claim.getClaimValue());
        }
		return mode;
	}
}

