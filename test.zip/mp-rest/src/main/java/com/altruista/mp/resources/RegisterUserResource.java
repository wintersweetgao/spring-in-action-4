package com.altruista.mp.resources;

import com.altruista.mp.model.QuestionAnswer;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;

import javax.validation.Valid;

/**
 * Created by mwixson on 11/3/14.
 */
public class RegisterUserResource {
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.username}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.username}")
    private String username;
    @Valid
    private QuestionAnswer securityQuestionAnswer;

    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.regpassword}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.regpassword}")
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public QuestionAnswer getSecurityQuestionAnswer() {
        return securityQuestionAnswer;
    }

    public void setSecurityQuestionAnswer(QuestionAnswer securityQuestionAnswer) {
        this.securityQuestionAnswer = securityQuestionAnswer;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
