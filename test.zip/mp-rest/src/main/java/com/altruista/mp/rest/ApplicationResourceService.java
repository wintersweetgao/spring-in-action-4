package com.altruista.mp.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Created by Prateek on 02/16/15
 */

public class ApplicationResourceService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationResourceService.class);

    public String messageResource(String propertyKey, Locale locale) {
        String errors = "";

        //To resolve text messages from properties file
        ResourceBundle bundle = ResourceBundle.getBundle("i18n-resources/message", locale);
        if (bundle != null) {
            errors = bundle.getString(propertyKey);
        }
        return errors;
    }
}
