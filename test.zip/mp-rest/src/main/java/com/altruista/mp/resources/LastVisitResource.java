package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

/*
 * Created by Prateek on 06/24/15
*/
public class LastVisitResource extends ResourceSupport {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.providerName}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.providerName}")
    private String providerName;

    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.visitOn}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.visitOn}")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime visitOn;

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public DateTime getVisitOn() {
        return visitOn;
    }

    public void setVisitOn(DateTime visitOn) {
        this.visitOn = visitOn;
    }
}
