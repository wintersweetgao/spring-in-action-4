package com.altruista.mp.rest;

import com.altruista.mp.model.Task;
import com.altruista.mp.resources.TaskResource;
import com.altruista.mp.resources.TaskResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.TaskService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.apache.commons.httpclient.HttpException;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles requests for Tasks
 */
@Controller
@Api(value = "Task service", description = "Manage Tasks")
public class TaskController {
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskController.class);

    private final TaskService taskService;
    private TaskResourceAssembler taskAssembler;

    @Autowired
    public TaskController(TaskService TaskService) {
        this.taskService = TaskService;
        taskAssembler = new TaskResourceAssembler();
    }

    @RequestMapping(value = "/api/task/{taskId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets Task using task id")
    public HttpEntity<TaskResource> getTask(@PathVariable("taskId") String taskId) throws ResourceException {
        Task task = taskService.get(taskId);
        MemberIdValidationUtil.validateMemberClaim(task.getMemberId());

        TaskResource resource = taskAssembler.toResource(task);

        return new ResponseEntity<TaskResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/task", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Tasks using member id")
    public HttpEntity<List<TaskResource>> getTasksByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);

        List<Task> tasks = taskService.findByMemberId(memberId);
        List<Task> authTasks = new ArrayList<Task>();

        for (Task task : tasks) {
            if (task.getStatus() != null && (task.getStatus().equalsIgnoreCase("Confirmed") || task.getStatus().equalsIgnoreCase("Scheduled"))) {
                authTasks.add(task);
            }
        }

        List<TaskResource> resourceList = taskAssembler.toResources(authTasks);
        return new ResponseEntity<List<TaskResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/task", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Save the Task")
    public HttpEntity<TaskResource> saveTask(@RequestBody TaskResource resource, Principal principal) throws ResourceException, ServiceException {
        MemberIdValidationUtil.validateMemberClaim(resource.getMemberId());

        Task task = taskAssembler.fromResource(resource, null);

        // assign current user as the owner
        if (principal != null)
            task.setOwnerId(principal.getName());

        // member portal services can only create MEMBER tasks
        task.setOwnerType("MEMBER");

        task = save(task, principal);

        return new ResponseEntity<TaskResource>(taskAssembler.toResource(task), HttpStatus.OK);
    }

    @RequestMapping(value = "/api/task/{taskId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Update the Task")
    public HttpEntity<TaskResource> updateTask(@PathVariable String taskId, @RequestBody TaskResource resource, Principal principal) throws ResourceException, ServiceException {
        Task original = taskService.get(taskId);
        MemberIdValidationUtil.validateMemberClaim(original.getMemberId());

        Task task = taskAssembler.fromResource(resource, original);

        if (task.getOwnerId() == null && principal != null)
            task.setOwnerId(principal.getName());

        if (principal.getName().equalsIgnoreCase(task.getOwnerId())) {
            task = save(task, principal);
            return new ResponseEntity<TaskResource>(taskAssembler.toResource(task), HttpStatus.OK);
        } else {
            throw new AccessDeniedException("Access Denied");
        }
    }

    private Task save(Task task, Principal principal) throws ServiceException {

        if (task.getStart() == null) {
            throw new ServiceException("Start date is required");
        } else {
            DateTime local = task.getStart();
            task.setStart(local.toDateTime(DateTimeZone.UTC));
        }

        if (task.getStatus() == null)
            task.setStatus("Scheduled");

        taskService.save(task);

        return task;
    }

    @RequestMapping(value = "/api/task/{taskId}", method = RequestMethod.DELETE)
    @ResponseBody
    @ApiOperation(value = "Remove the Task")
    public HttpStatus deleteTask(@PathVariable String taskId, Principal principal) throws ResourceException, ServiceException, HttpException {
        Task task = taskService.get(taskId);
        MemberIdValidationUtil.validateMemberClaim(task.getMemberId());

        if (principal.getName().equalsIgnoreCase(task.getOwnerId())) {
            taskService.delete(taskId);
            return HttpStatus.OK;
        } else {
            throw new AccessDeniedException("Access Denied");
        }
    }
}