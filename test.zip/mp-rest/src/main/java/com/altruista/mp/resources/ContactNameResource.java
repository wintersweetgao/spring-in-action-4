package com.altruista.mp.resources;

import com.altruista.mp.model.ContactType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 8/3/14.
 */
@XmlRootElement(name = "contactName")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactNameResource extends ResourceSupport {
    private ContactType contactType;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.company}")
    @Length(max = ResourceSize.MAX_ID, message = "{length.validation.company}")
    private String company;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.salutation}")
    @Length(max = 50, message = "{length.validation.salutation}")
    private String salutation;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.firstname}")
    @Length(max = 200, message = "{length.validation.firstname}")
    private String firstName;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.middlename}")
    @Length(max = 200, message = "{length.validation.middlename}")
    private String middleName;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.lastname}")
    @Length(max = 200, message = "{length.validation.lastname}")
    private String lastName;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.namesuffix}")
    @Length(max = 50, message = "{length.validation.namesuffix}")
    private String nameSuffix;

    public ContactType getContactType() {
        return contactType;
    }

    public void setContactType(ContactType contactType) {
        this.contactType = contactType;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }
}
