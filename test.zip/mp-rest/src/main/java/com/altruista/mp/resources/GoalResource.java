package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.validation.Valid;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "goal")
public class GoalResource extends ResourceSupport {

    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.goal}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.goal}")
    private String goal;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.status}")
    @Length(max = ResourceSize.MAX_STATUS, message = "{length.validation.status}")
    private String status;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.notes}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.notes}")
    private String notes;
    @Valid
    private List<ActionStepResource> actionSteps;

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public List<ActionStepResource> getActionSteps() {
        return actionSteps;
    }

    public void setActionSteps(List<ActionStepResource> actionSteps) {
        this.actionSteps = actionSteps;
    }
}
