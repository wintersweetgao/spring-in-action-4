package com.altruista.mp.rest;

import com.altruista.mp.resources.ConditionResource;
import com.altruista.mp.resources.ConditionResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.ConditionService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for alerts
 */
@Controller
@RequestMapping("/api/condition")
@Api(value = "Condition service", description = "Manage Conditions")
public class ConditionController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConditionController.class);

    private final ConditionService conditionService;
    private ConditionResourceAssembler conditionAssembler;

    @Autowired
    public ConditionController(ConditionService conditionService) {
        this.conditionService = conditionService;
        conditionAssembler = new ConditionResourceAssembler();
    }

    @ApiOperation(value = "Gets Conditions using member id")
    @RequestMapping(value = "/{memberId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<ConditionResource>> getConditionsByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<ConditionResource> resourceList = conditionAssembler.toResources(conditionService.findByMemberId(memberId));
        return new ResponseEntity<List<ConditionResource>>(resourceList,
                HttpStatus.OK);
    }

}