package com.altruista.mp.resources;


@SuppressWarnings("serial")
public class ResourceNotFoundException extends RuntimeException {
    private final transient String errorMessage;

    public ResourceNotFoundException(String message) {
        super(message);
        this.errorMessage = message;
    }

    public String getErrors() {
        return errorMessage;
    }
}
