package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.SafeHtml;
import org.springframework.hateoas.ResourceSupport;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

/**
 * Created by mwixson on 9/21/15.
 */
public class EnrollmentResource extends ResourceSupport {
    private String memberId;

    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.ssn}")
    @Length(max = 11, message = "{length.validation.ssn}")
    @Pattern(regexp = "^\\d{3}-?\\d{2}-?\\d{4}$|^\\s*$")
    private String ssn;

    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.refugeeNumber}")
    @Length(max = 50, message = "{length.validation.refugeeNumber}")
    private String refugeeNumber;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.itin}")
    @Length(max = 9, message = "{length.validation.itin}")
    private String itin;
    @Valid
    private AddressResource address;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.programname}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.programname}")
    @NotEmpty
    private String programName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.firstname}")
    @Length(max = 200, message = "{length.validation.firstname}")
    private String firstName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.middlename}")
    @Length(max = 200, message = "{length.validation.middlename}")
    private String middleName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.lastname}")
    @Length(max = 200, message = "{length.validation.lastname}")
    private String lastName;

    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.primaryemail}")
    @Length(max = 200, message = "{length.validation.primaryemail}")
    //@Pattern(regexp="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
    @Pattern(regexp = "^(.+)@(.+)$")
    @NotEmpty
    private String primaryEmail;

    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.mobilephonenumber}")
    @Length(max = 200, message = "{length.validation.mobilephonenumber}")
    @Pattern(regexp = "^(\\([0-9]{3}\\)) ?[0-9]{3}-[0-9]{4}$")
    @NotEmpty
    private String mobilePhoneNumber;

    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.relationshiptomember}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.relationshiptomember}")
    private String relationshipToMember;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getRefugeeNumber() {
        return refugeeNumber;
    }

    public void setRefugeeNumber(String refugeeNumber) {
        this.refugeeNumber = refugeeNumber;
    }

    public String getItin() {
        return itin;
    }

    public void setItin(String itin) {
        this.itin = itin;
    }

    public AddressResource getAddress() {
        return address;
    }

    public void setAddress(AddressResource address) {
        this.address = address;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPrimaryEmail() {
        return primaryEmail;
    }

    public void setPrimaryEmail(String primaryEmail) {
        this.primaryEmail = primaryEmail;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public String getRelationshipToMember() {
        return relationshipToMember;
    }

    public void setRelationshipToMember(String relationshipToMember) {
        this.relationshipToMember = relationshipToMember;
    }
}
