package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

/**
 * created by PRATEEK on 03/04/2015
 */
public class AssessmentNameResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentname.assesssmentId}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentname.assesssmentId}")
    private String assessmentId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentname.name}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentname.name}")
    private String name;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentname.status}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentname.status}")
    private String status;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.assessmentname.lastRunId}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessmentname.lastRunId}")
    private String lastRunId;
    private int lastSequence;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAssessmentId() {
        return assessmentId;
    }

    public void setAssessmentId(String assessmentId) {
        this.assessmentId = assessmentId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastRunId() {
        return lastRunId;
    }

    public void setLastRunId(String lastRunId) {
        this.lastRunId = lastRunId;
    }

    public int getLastSequence() {
        return lastSequence;
    }

    public void setLastSequence(int lastSequence) {
        this.lastSequence = lastSequence;
    }
}
