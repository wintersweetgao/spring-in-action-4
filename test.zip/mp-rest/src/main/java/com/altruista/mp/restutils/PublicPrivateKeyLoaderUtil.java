package com.altruista.mp.restutils;

import com.altruista.mp.utils.PropertiesLoaderUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class PublicPrivateKeyLoaderUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(PublicPrivateKeyLoaderUtil.class);

    private static BigInteger publicKeyModulus;
    private static BigInteger privateKeyModulus;
    private static BigInteger privateKeyExponent;
    private static BigInteger publicKeyExponent;
    private static File privateKeyFile;
    private static File publicKeyFile;

    static {
        String certificateLocation = System.getProperty("user.home") + "/" + PropertiesLoaderUtility.getProperty("mp.keys.folder").trim();
        File folderCreation = new File(certificateLocation);
        if (!folderCreation.exists() && !folderCreation.isDirectory()) {
            folderCreation.mkdirs();
        }
        privateKeyFile = new File(certificateLocation + "/" + PropertiesLoaderUtility.getProperty("private.key.file.name").trim());
        publicKeyFile = new File(certificateLocation + "/" + PropertiesLoaderUtility.getProperty("public.key.file.name").trim());
        try {
            loadPublicAndPrivateKey();
        } catch (IOException | GeneralSecurityException e) {
            LOGGER.error("Unable to load public and private key from " + certificateLocation + ", exception: " + e);
        }
    }

    private static void loadPublicAndPrivateKey() throws IOException, GeneralSecurityException {
        /* Public Key */
        byte[] publicKeyBytes = new byte[(int) publicKeyFile.length()];
        FileInputStream publicFis = null;
        try {
            publicFis = new FileInputStream(publicKeyFile);
            if (publicFis.read(publicKeyBytes) > 0) {
                X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
                KeyFactory factory = KeyFactory.getInstance("RSA");
                RSAPublicKey pubKey = (RSAPublicKey) factory.generatePublic(publicKeySpec);
                publicKeyModulus = pubKey.getModulus();
                publicKeyExponent = pubKey.getPublicExponent();
            }
        } finally {
            if (publicFis != null) {
                publicFis.close();
            }
        }

        /*Private Key*/
        byte[] privateKeyBytes = new byte[(int) privateKeyFile.length()];
        FileInputStream privateFis = null;
        try {
            privateFis = new FileInputStream(privateKeyFile);
            if (privateFis.read(privateKeyBytes) > 0) {
                PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(privateKeyBytes);
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                RSAPrivateKey privKey = (RSAPrivateKey) keyFactory.generatePrivate(spec);
                privateKeyModulus = privKey.getModulus();
                privateKeyExponent = privKey.getPrivateExponent();
            }
        } finally {
            if (privateFis != null) {
                privateFis.close();
            }
        }
    }

    public static BigInteger getPublicKeyModulus() {
        return publicKeyModulus;
    }

    public static BigInteger getPublicKeyExponent() {
        return publicKeyExponent;
    }

    public static BigInteger getPrivateKeyModulus() {
        return privateKeyModulus;
    }

    public static BigInteger getPrivateKeyExponent() {
        return privateKeyExponent;
    }
}