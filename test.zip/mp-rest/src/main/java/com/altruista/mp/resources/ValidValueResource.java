package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.springframework.hateoas.ResourceSupport;

/**
 * Created by Administrator on 7/3/2014.
 */
public class ValidValueResource extends ResourceSupport {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_SHORT_STRING)
    private String refId;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.validname}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.validname}")
    private String name;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.validvalue}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.validvalue}")
    private String value;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.validdescription}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.validdescription}")
    private String description;

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
