package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;

/**
 * Created by mwixson on 9/11/14.
 */
public class ActionStepStatusResource {
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.status}")
    @Length(max = ResourceSize.MAX_STATUS, message = "{length.validation.status}")
    private String status;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.notes}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.notes}")
    private String notes;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
