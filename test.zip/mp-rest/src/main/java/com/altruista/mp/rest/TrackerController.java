package com.altruista.mp.rest;

import com.altruista.mp.resources.TrackerAssembler;
import com.altruista.mp.resources.TrackerResource;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.services.TrackerService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for  Health Trackers
 */
@Controller
@RequestMapping("/api/tracker")
@Api(value = "Tracker service", description = "Manage Health Trackers")
public class TrackerController {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrackerController.class);

    private final TrackerService trackerService;
    private TrackerAssembler healthTrackerAssembler;

    @Autowired
    public TrackerController(TrackerService trackerService) {
        this.trackerService = trackerService;
        healthTrackerAssembler = new TrackerAssembler();
    }

    @ApiOperation(value = "Gets the Tracker using Tracker id")
    @RequestMapping(value = "/{trackerId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<TrackerResource> getTrackerByTrackerId(@PathVariable String trackerId) throws ResourceException {
        TrackerResource resourceList = healthTrackerAssembler.toResource(trackerService.get(trackerId));
        return new ResponseEntity<TrackerResource>(resourceList,
                HttpStatus.OK);
    }

    @ApiOperation(value = "Gets the Trackers for a given CategoryId")
    @RequestMapping(value = "/{categoryId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<TrackerResource>> getTrackersByCategoryId(@PathVariable String categoryId) throws ResourceException {
        List<TrackerResource> resourceList = healthTrackerAssembler.toResources(trackerService.getTrackersByCategoryId(categoryId));
        return new ResponseEntity<List<TrackerResource>>(resourceList,
                HttpStatus.OK);
    }

    @ApiOperation(value = "Gets all the Trackers")
    @RequestMapping(method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<TrackerResource>> getAllTrackers() throws ResourceException {
        List<TrackerResource> resourceList = healthTrackerAssembler.toResources(trackerService.getAllTrackers());
        return new ResponseEntity<List<TrackerResource>>(resourceList,
                HttpStatus.OK);
    }

}