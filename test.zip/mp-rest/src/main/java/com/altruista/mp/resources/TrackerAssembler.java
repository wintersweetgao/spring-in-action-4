package com.altruista.mp.resources;

import com.altruista.mp.model.Tracker;
import com.altruista.mp.rest.TrackerController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class TrackerAssembler extends
        ResourceAssemblerSupport<Tracker, TrackerResource> {

    public TrackerAssembler() {
        super(TrackerController.class, TrackerResource.class);
    }

    @Override
    public TrackerResource toResource(Tracker tracker) {
        return createResourceWithId(tracker.getId(), tracker);
    }

    @Override
    protected TrackerResource instantiateResource(Tracker entity) {
        TrackerResource resource = new TrackerResource();
        resource.setName(entity.getName());
        resource.setCategoryId(entity.getCategoryId());
        resource.setParameters(entity.getParameters());
        return resource;
    }

}
