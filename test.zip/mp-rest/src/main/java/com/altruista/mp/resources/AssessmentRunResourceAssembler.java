package com.altruista.mp.resources;

import com.altruista.mp.model.AssessmentRun;
import com.altruista.mp.rest.AssessmentRunController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

/**
 * Developed by Prateek on 03/18/15
 */

public class AssessmentRunResourceAssembler extends
        ResourceAssemblerSupport<AssessmentRun, AssessmentRunResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentRunResourceAssembler.class);

    // default constructor
    public AssessmentRunResourceAssembler() {
        super(AssessmentRunController.class, AssessmentRunResource.class);
    }

    @Override
    public AssessmentRunResource toResource(AssessmentRun run) {
        AssessmentRunResource resource = instantiateResource(run);

        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(AssessmentRunController.class).getAssessmentRun(run.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }
        return resource;
    }


    @Override
    protected AssessmentRunResource instantiateResource(AssessmentRun entity) {

        AssessmentRunResource resource = new AssessmentRunResource();
        resource.setAssessmentId(entity.getAssessmentId());
        resource.setAssessmentName(entity.getAssessmentName());
        resource.setStatus(entity.getStatus());
        resource.setCareNotes(entity.getCareNotes());
        resource.setLastSequence(entity.getLastSequence()); // newly added fields
        resource.setStartedOn(entity.getStartedOn());
        resource.setEndedOn(entity.getEndedOn());

        return resource;
    }

    public AssessmentRun fromResource(AssessmentRunResource resource, AssessmentRun run) {
        if (run == null)
            run = new AssessmentRun();

        run.setAssessmentId(resource.getAssessmentId());
        run.setAssessmentName(resource.getAssessmentName());
        run.setStatus(resource.getStatus());
        run.setCareNotes(resource.getCareNotes());
        run.setLastSequence(resource.getLastSequence()); // newly added fields
        run.setStartedOn(resource.getStartedOn());
        run.setEndedOn(resource.getEndedOn());

        return run;
    }

    public AssessmentRun fromResource(AssessmentRunResource resource) {
        return fromResource(resource, null);
    }
}