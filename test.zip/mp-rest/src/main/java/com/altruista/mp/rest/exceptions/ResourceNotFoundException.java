package com.altruista.mp.rest.exceptions;

public class ResourceNotFoundException extends ResourceException {
    /**
     *
     */
    private static final long serialVersionUID = -8775042635363093336L;

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
