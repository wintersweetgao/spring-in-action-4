package com.altruista.mp.resources;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

import com.altruista.mp.model.User;
import com.altruista.mp.rest.UserController;
import org.springframework.security.core.GrantedAuthority;

import java.util.HashMap;
import java.util.Map;

public class UserResourceAssembler extends
        ResourceAssemblerSupport<User, UserResource> {

    public UserResourceAssembler() {
        super(UserController.class, UserResource.class);
    }

    @Override
    public UserResource toResource(User user) {
        return instantiateResource(user);
    }

    @Override
    protected UserResource instantiateResource(User entity) {
        UserResource resource = new UserResource();

        resource.setUsername(entity.getUsername());
        resource.setRoles(createRoleMap(entity));
        resource.setContactType(entity.getContact().getContactType());
        resource.setContactId(entity.getContactId());
        resource.setSalutation(entity.getContact().getSalutation());
        resource.setFirstName(entity.getContact().getFirstName());
        resource.setMiddleName(entity.getContact().getMiddleName());
        resource.setLastName(entity.getContact().getLastName());
        resource.setSelectedMemberId(entity.getSelectedMemberId());
        resource.setAccessedOn(entity.getAccessedOn());
        resource.setPriorAccessedOn(entity.getPriorAccessedOn());
        resource.setTimezone(entity.getTimezone());
        resource.setTiles(entity.getTiles());
        resource.setSsoEnabled(entity.isSsoEnabled());

        return resource;
    }

    private Map<String, Boolean> createRoleMap(User user) {
        Map<String, Boolean> roles = new HashMap<String, Boolean>();
        for (GrantedAuthority authority : user.getAuthorities()) {
            roles.put(authority.getAuthority(), Boolean.TRUE);
        }

        return roles;
    }

}
