package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "member")
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String contactId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.primarymedicalprovider}")
    @Length(max = 400, message = "{length.validation.primarymedicalprovider}")
    private String primaryMedicalProvider;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.primarymedicalcondition}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.primarymedicalcondition}")
    private String primaryMedicalCondition;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.primarybehavioralprovider}")
    @Length(max = 400, message = "{length.validation.primarybehavioralprovider}")
    private String primaryBehavioralProvider;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.primarybehavioralcondition}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.primarybehavioralcondition}")
    private String primaryBehavioralCondition;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.caremanager}")
    @Length(max = 400, message = "{length.validation.caremanager}")
    private String careManager;
    @Length(max = 4, message = "{length.validation.riskscore}")
    private Float riskScore;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.risklevel}")
    @Length(max = 50, message = "{length.validation.risklevel}")
    private String riskLevel;
    @Length(max = 50, message = "{length.validation.height}")
    private float height;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.heightunits}")
    @Length(max = 50, message = "{length.validation.heightunits}")
    private String heightUnits;
    @Length(max = 50, message = "{length.validation.weight}")
    private float weight;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.weightunits}")
    @Length(max = 50, message = "{length.validation.weightunits}")
    private String weightUnits;

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getPrimaryMedicalProvider() {
        return primaryMedicalProvider;
    }

    public void setPrimaryMedicalProvider(String primaryMedicalProvider) {
        this.primaryMedicalProvider = primaryMedicalProvider;
    }

    public String getPrimaryMedicalCondition() {
        return primaryMedicalCondition;
    }

    public void setPrimaryMedicalCondition(String primaryMedicalCondition) {
        this.primaryMedicalCondition = primaryMedicalCondition;
    }

    public String getPrimaryBehavioralProvider() {
        return primaryBehavioralProvider;
    }

    public void setPrimaryBehavioralProvider(String primaryBehavioralProvider) {
        this.primaryBehavioralProvider = primaryBehavioralProvider;
    }

    public String getPrimaryBehavioralCondition() {
        return primaryBehavioralCondition;
    }

    public void setPrimaryBehavioralCondition(String primaryBehavioralCondition) {
        this.primaryBehavioralCondition = primaryBehavioralCondition;
    }

    public String getCareManager() {
        return careManager;
    }

    public void setCareManager(String careManager) {
        this.careManager = careManager;
    }

    public Float getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(Float riskScore) {
        this.riskScore = riskScore;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public String getHeightUnits() {
        return heightUnits;
    }

    public void setHeightUnits(String heightUnits) {
        this.heightUnits = heightUnits;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public String getWeightUnits() {
        return weightUnits;
    }

    public void setWeightUnits(String weightUnits) {
        this.weightUnits = weightUnits;
    }
}
