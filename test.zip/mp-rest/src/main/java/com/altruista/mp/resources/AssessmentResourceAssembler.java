package com.altruista.mp.resources;

import com.altruista.mp.model.Assessment;
import com.altruista.mp.rest.AssessmentController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class AssessmentResourceAssembler extends
        ResourceAssemblerSupport<Assessment, AssessmentResource> {

    public AssessmentResourceAssembler() {
        super(AssessmentController.class, AssessmentResource.class);
    }

    @Override
    public AssessmentResource toResource(Assessment assessment) {
        return createResourceWithId(assessment.getId(), assessment);
    }

    @Override
    protected AssessmentResource instantiateResource(Assessment entity) {
        AssessmentResource resource = new AssessmentResource();
        resource.setName(entity.getName());
        resource.setCareActivityTypeName(entity.getCareActivityTypeName());
        resource.setRunTypeName(entity.getRunTypeName());
        resource.setDuration(entity.getDuration());
        resource.setScore(entity.getScore());
        resource.setNumOfQuestions(entity.getNumOfQuestions());
        resource.setActive(entity.isActive());
        resource.setQuestions(entity.getQuestions());
        return resource;
    }

}
