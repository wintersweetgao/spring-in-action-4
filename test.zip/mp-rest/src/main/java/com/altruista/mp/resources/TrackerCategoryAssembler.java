package com.altruista.mp.resources;

import com.altruista.mp.model.TrackerCategory;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class TrackerCategoryAssembler extends
        ResourceAssemblerSupport<TrackerCategory, TrackerCategoryResource> {

    public TrackerCategoryAssembler() {
        super(TrackerCategory.class, TrackerCategoryResource.class);
    }

    @Override
    public TrackerCategoryResource toResource(TrackerCategory trackerCategory) {
        return createResourceWithId(trackerCategory.getId(), trackerCategory);
    }

    @Override
    protected TrackerCategoryResource instantiateResource(TrackerCategory entity) {
        TrackerCategoryResource resource = new TrackerCategoryResource();
        resource.setCategoryId(entity.getId());
        resource.setName(entity.getName());
        resource.setReadOnly(entity.getReadOnly());
        resource.setConditions(entity.getConditions());

        return resource;
    }

}
