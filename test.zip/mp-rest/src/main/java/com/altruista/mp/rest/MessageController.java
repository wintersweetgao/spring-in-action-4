package com.altruista.mp.rest;

import com.altruista.mp.model.Message;
import com.altruista.mp.resources.*;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MessageService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.activity.InvalidActivityException;
import java.util.List;

/**
 * Created by mwixs_000 on 6/24/2014.
 */
@Controller
@Api(value = "Message service", description = "Manage Messages")
public class MessageController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MessageController.class);

    @Value("${guidingCare.timezone}")
    private String gcTimezone;

    private final MessageService messageService;
    private MessageResourceAssembler messageAssembler;
    private final ContactService contactService;
    private ContactNameResourceAssembler contactNameAssembler;

    @Autowired
    public MessageController(MessageService messageService, ContactService contactService) {
        this.messageService = messageService;
        messageAssembler = new MessageResourceAssembler();

        this.contactService = contactService;
        contactNameAssembler = new ContactNameResourceAssembler();
    }

    @RequestMapping(value = "/api/message/{messageId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the message using Message id")
    public HttpEntity<MessageResource> getMessage(
            @PathVariable("messageId") String messageId) throws ResourceException {
        Message message = messageService.get(messageId);
        String memberId = message.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        MessageResource resource = messageAssembler.toResource(message);
        return new ResponseEntity<MessageResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/message", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Gets the message using Member id")
    public HttpEntity<List<MessageResource>> getMessagesByMemberId(@PathVariable String memberId) throws ResourceException, InvalidActivityException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<MessageResource> resourceList = messageAssembler.toResources(messageService.findByMemberId(memberId));
        addContacts(resourceList);
        return new ResponseEntity<List<MessageResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/message/sender/{senderId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Gets the message using Sender id")
    public HttpEntity<List<MessageResource>> getMessagesBySenderId(@PathVariable String senderId) throws ResourceException, InvalidActivityException {
        List<MessageResource> resourceList = messageAssembler.toResources(messageService.findBySenderId(senderId));
        for (MessageResource message : resourceList) {
            String memberId = message.getMemberId();
            MemberIdValidationUtil.validateMemberClaim(memberId);
        }
        addContacts(resourceList);
        return new ResponseEntity<List<MessageResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/message/recipient/{recipientId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Gets the message using Recipient id")
    public HttpEntity<List<MessageResource>> getMessagesByRecipientId(@PathVariable String recipientId) throws ResourceException, InvalidActivityException {
        List<MessageResource> resourceList = messageAssembler.toResources(messageService.findByRecipientId(recipientId));
        for (MessageResource message : resourceList) {
            String memberId = message.getMemberId();
            MemberIdValidationUtil.validateMemberClaim(memberId);
        }
        addContacts(resourceList);
        return new ResponseEntity<List<MessageResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/message", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves the message")
    public HttpEntity<MessageResource> saveMessage(@RequestBody MessageResource resource) throws ResourceException {
        String memberId = resource.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        Message message = messageAssembler.fromResource(resource);
        if (message.getSentOn() == null) {
            DateTime local = new DateTime(DateTime.now(), DateTimeZone.forID(gcTimezone));
            DateTime sentOn = local.toDateTime(DateTimeZone.UTC);
            message.setSentOn(sentOn);
        }

        validateMessageContacts(resource);
        messageService.save(message);

        // update the message link
        resource = messageAssembler.toResource(message);
        return new ResponseEntity<MessageResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/message/{messageId}/location", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Sets the message location")
    public HttpEntity<MessageResource> setMessageLocation(
            @PathVariable("messageId") String messageId, @RequestBody LocationResource location) throws ResourceException {
        LOGGER.debug("set the message location");

        Message message = messageService.get(messageId);
        String memberId = message.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        message.setLocation(location.getLocation());
        if (message.getSentOn() == null) {
            DateTime local = new DateTime(DateTime.now(), DateTimeZone.forID(gcTimezone));
            DateTime sentOn = local.toDateTime(DateTimeZone.UTC);
            message.setSentOn(sentOn);
        }
        messageService.save(message);

        MessageResource resource = messageAssembler.toResource(message);
        return new ResponseEntity<MessageResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/message/{messageId}/viewed", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Update the message flag")
    public HttpEntity<MessageResource> setMessageFlag(
            @PathVariable("messageId") String messageId) throws ResourceException {
        LOGGER.debug("Update the message flag");

        Message message = messageService.get(messageId);
        String memberId = message.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);

        if (message.getViewedOn() == null) {
            DateTime local = new DateTime(DateTime.now(), DateTimeZone.forID(gcTimezone));
            DateTime viewedOn = local.toDateTime(DateTimeZone.UTC);
            message.setViewedOn(viewedOn);
            message.setViewed(true);
        }
        messageService.save(message);

        MessageResource resource = messageAssembler.toResource(message);
        return new ResponseEntity<MessageResource>(resource, HttpStatus.OK);
    }

    private void addContacts(List<MessageResource> resourceList) throws ResourceException, InvalidActivityException {
        for (MessageResource message : resourceList) {
            String memberId = message.getMemberId();
            MemberIdValidationUtil.validateMemberClaim(memberId);
            // add sender

            if (contactService.get(message.getSenderId()) == null) {
                throw new IllegalArgumentException("SenderId is not correct");
            } else {
                message.setSender(contactNameAssembler.toResource(contactService.get(message.getSenderId())));
            }

            // add recipients
            List<ContactNameResource> resources = message.getRecipients();
            for (String contactId : message.getRecipientIds()) {
                if (contactService.get(contactId) == null) {
                    throw new IllegalArgumentException("ContactId is not correct");
                } else {
                    ContactNameResource resource = contactNameAssembler.toResource(contactService.get(contactId));
                    resources.add(resource);
                }
            }
        }
    }

    void validateMessageContacts(MessageResource messageResource) throws IllegalArgumentException {
        if (contactService.get(messageResource.getSenderId()) == null) {
            throw new IllegalArgumentException("SenderId is not correct");
        }

        for (String contactId : messageResource.getRecipientIds()) {
            if (contactService.get(contactId) == null) {
                throw new IllegalArgumentException("RecipientId is not correct");
            }
        }
    }
}
