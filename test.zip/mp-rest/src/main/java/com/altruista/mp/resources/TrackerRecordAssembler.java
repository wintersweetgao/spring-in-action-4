package com.altruista.mp.resources;

import com.altruista.mp.model.TrackerRecord;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class TrackerRecordAssembler extends
        ResourceAssemblerSupport<TrackerRecord, TrackerRecordResource> {

    public TrackerRecordAssembler() {
        super(TrackerRecord.class, TrackerRecordResource.class);
    }

    @Override
    public TrackerRecordResource toResource(TrackerRecord trackerRecord) {
        return createResourceWithId(trackerRecord.getId(), trackerRecord);
    }

    @Override
    protected TrackerRecordResource instantiateResource(TrackerRecord entity) {
        TrackerRecordResource resource = new TrackerRecordResource();
        resource.setComments(entity.getComments());
        resource.setParameterId(entity.getParameterId());
        resource.setMemberId(entity.getMemberId());
        resource.setParameterName(entity.getParameterName());
        resource.setParameterType(entity.getParameterType());
        resource.setRecordedOn(entity.getRecordedOn());
        resource.setTrackerId(entity.getTrackerId());
        resource.setUom(entity.getUom());
        resource.setValue(entity.getValue());

        return resource;
    }

    public TrackerRecord fromResource(TrackerRecordResource resource) {

        TrackerRecord entity = new TrackerRecord();

        // copy properties from resource to entity
        entity.setComments(resource.getComments());
        entity.setParameterId(resource.getParameterId());
        entity.setMemberId(resource.getMemberId());
        entity.setParameterName(resource.getParameterName());
        entity.setParameterType(resource.getParameterType());
        entity.setRecordedOn(resource.getRecordedOn());
        entity.setTrackerId(resource.getTrackerId());
        entity.setUom(resource.getUom());
        entity.setValue(resource.getValue());

        return entity;
    }

}
