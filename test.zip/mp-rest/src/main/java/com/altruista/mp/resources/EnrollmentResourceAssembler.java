package com.altruista.mp.resources;

import com.altruista.mp.model.Address;
import com.altruista.mp.model.Enrollment;
import com.altruista.mp.rest.EnrollmentController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class EnrollmentResourceAssembler extends
        ResourceAssemblerSupport<Enrollment, EnrollmentResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(EnrollmentResourceAssembler.class);

    public EnrollmentResourceAssembler() {
        super(EnrollmentController.class, EnrollmentResource.class);
    }

    @Override
    public EnrollmentResource toResource(Enrollment enrollment) {

        EnrollmentResource resource = instantiateResource(enrollment);

        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(EnrollmentController.class).getEnrollment(enrollment.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }
        // copy properties from enrollment to enrollmentResource
        resource.setFirstName(enrollment.getFirstName());
        resource.setMiddleName(enrollment.getMiddleName());
        resource.setLastName(enrollment.getLastName());
        resource.setPrimaryEmail(enrollment.getPrimaryEmail());
        resource.setMobilePhoneNumber(enrollment.getMobilePhoneNumber());
        resource.setAddress(toAddressResource(enrollment.getAddress()));
        resource.setRelationshipToMember(enrollment.getRelationshipToMember());

        resource.setMemberId(enrollment.getMemberId());
        resource.setSsn(enrollment.getSsn());
        resource.setRefugeeNumber(enrollment.getRefugeeNumber());
        resource.setItin(enrollment.getItin());
        resource.setAddress(toAddressResource(enrollment.getAddress()));
        resource.setProgramName(enrollment.getProgramName());

        return resource;
    }

    public AddressResource toAddressResource(Address address) {

        if (address == null)
            return null;

        AddressResource resource = new AddressResource();
        resource.setPrimary(address.isPrimary());
        resource.setAddress(address.getAddress());
        resource.setAddress2(address.getAddress2());
        resource.setCity(address.getCity());
        resource.setStateProvince(address.getStateProvince());
        resource.setPostalCode(address.getPostalCode());
        resource.setCounty(address.getCounty());
        resource.setCountry(address.getCountry());

        return resource;
    }

    public Enrollment fromResource(EnrollmentResource resource) {

        Enrollment enrollment = new Enrollment();

        // copy properties from enrollmentResource to enrollment
        enrollment.setFirstName(resource.getFirstName());
        enrollment.setMiddleName(resource.getMiddleName());
        enrollment.setLastName(resource.getLastName());
        enrollment.setPrimaryEmail(resource.getPrimaryEmail());
        enrollment.setMobilePhoneNumber(resource.getMobilePhoneNumber());
        enrollment.setAddress(fromAddressResource(resource.getAddress()));
        enrollment.setRelationshipToMember(resource.getRelationshipToMember());

        enrollment.setMemberId(resource.getMemberId());
        enrollment.setSsn(resource.getSsn());
        enrollment.setRefugeeNumber(resource.getRefugeeNumber());
        enrollment.setItin(resource.getItin());
        enrollment.setAddress(fromAddressResource(resource.getAddress()));
        enrollment.setProgramName(resource.getProgramName());

        return enrollment;
    }

    public Address fromAddressResource(AddressResource resource) {

        if (resource == null)
            return null;

        Address address = new Address();
        address.setPrimary(resource.isPrimary());
        address.setAddress(resource.getAddress());
        address.setAddress2(resource.getAddress2());
        address.setCity(resource.getCity());
        address.setStateProvince(resource.getStateProvince());
        address.setPostalCode(resource.getPostalCode());
        address.setCounty(resource.getCounty());
        address.setCountry(resource.getCountry());

        return address;
    }

}