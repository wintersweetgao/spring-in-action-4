package com.altruista.mp.resources;

import com.altruista.mp.model.AllergySensitivity;
import com.altruista.mp.rest.AllergySensitivityController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class AllergySensitivityResourceAssembler extends
        ResourceAssemblerSupport<AllergySensitivity, AllergySensitivityResource> {

    public AllergySensitivityResourceAssembler() {
        super(AllergySensitivityController.class, AllergySensitivityResource.class);
    }

    @Override
    public AllergySensitivityResource toResource(AllergySensitivity program) {
        return createResourceWithId(program.getId(), program);
    }

    @Override
    protected AllergySensitivityResource instantiateResource(AllergySensitivity entity) {
        AllergySensitivityResource resource = new AllergySensitivityResource();
        resource.setMemberId(entity.getMemberId());
        resource.setMedicationCode(entity.getMedicationCode());
        resource.setName(entity.getName());
        return resource;
    }

}
