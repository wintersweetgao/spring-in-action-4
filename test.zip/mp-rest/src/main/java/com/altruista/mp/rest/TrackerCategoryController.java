package com.altruista.mp.rest;

import com.altruista.mp.model.Tracker;
import com.altruista.mp.resources.TrackerAssembler;
import com.altruista.mp.resources.TrackerCategoryAssembler;
import com.altruista.mp.resources.TrackerCategoryResource;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.services.TrackerCategoryService;
import com.altruista.mp.services.TrackerService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for  Health Trackers categories
 */
@Controller
@RequestMapping("/api/trackerCategory")
@Api(value = "Tracker Category service", description = "Manage Health Tracker Categories")
public class TrackerCategoryController {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrackerCategoryController.class);

    private final TrackerCategoryService trackerCategoryService;
    private TrackerCategoryAssembler trackerCategoryAssembler;
    private final TrackerService trackerService;
    private TrackerAssembler trackerAssembler;

    @Autowired
    public TrackerCategoryController(TrackerCategoryService trackerCategoryService, TrackerService trackerService) {
        this.trackerCategoryService = trackerCategoryService;
        trackerCategoryAssembler = new TrackerCategoryAssembler();
        this.trackerService = trackerService;
        trackerAssembler = new TrackerAssembler();
    }

    @ApiOperation(value = "Gets the Tracker categories using id")
    @RequestMapping(value = "/{trackerCategoryId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<TrackerCategoryResource> getTrackerByTrackerId(@PathVariable String trackerCategoryId) throws ResourceException {
        TrackerCategoryResource resourceList = trackerCategoryAssembler.toResource(trackerCategoryService.get(trackerCategoryId));
        return new ResponseEntity<TrackerCategoryResource>(resourceList,
                HttpStatus.OK);
    }

    @ApiOperation(value = "Gets all the Trackers categories")
    @RequestMapping(method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<TrackerCategoryResource>> getAllTrackers() throws ResourceException {
        List<TrackerCategoryResource> resourceList = trackerCategoryAssembler.toResources(trackerCategoryService.getAllCategories());
        for (TrackerCategoryResource category : resourceList) {
            List<Tracker> trackerList = trackerService.getTrackersByCategoryId(category.getCategoryId());
            category.setTrackers(trackerAssembler.toResources(trackerList));
        }
        return new ResponseEntity<List<TrackerCategoryResource>>(resourceList,
                HttpStatus.OK);
    }


    /*
     *
    */
    @ApiOperation(value = "Gets the Tracker categories using conditions")
    @RequestMapping(value = "/{conditions}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<TrackerCategoryResource> getTrackerCategoryByCondition(@PathVariable String condition) throws ResourceException {

        //TrackerCategoryResource resourceList = trackerCategoryAssembler.toResource(trackerCategoryService.getTrackerCategoriesByMemberCondition(condition));
        TrackerCategoryResource resourceList = trackerCategoryAssembler.toResource(trackerCategoryService.get(condition));
        return new ResponseEntity<TrackerCategoryResource>(resourceList,
                HttpStatus.OK);
    }
}