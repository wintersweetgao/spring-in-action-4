package com.altruista.mp.resources;

import com.altruista.mp.model.Task;
import com.altruista.mp.rest.TaskController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class TaskResourceAssembler extends
        ResourceAssemblerSupport<Task, TaskResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskResourceAssembler.class);

    public TaskResourceAssembler() {
        super(TaskController.class, TaskResource.class);
    }

    @Override
    public TaskResource toResource(Task task) {
        TaskResource resource = instantiateResource(task);

        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(TaskController.class).getTask(task.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }

        resource.setMemberId(task.getMemberId());
        resource.setContactId(task.getContactId());
        resource.setTaskType(task.getTaskType());
        resource.setDescription(task.getDescription());
        resource.setReason(task.getReason());
        resource.setStatus(task.getStatus());
        resource.setPriority(task.getPriority());
        resource.setTitle(task.getTitle());
        resource.setStart(task.getStart());
        resource.setEnd(task.getEnd());
        resource.setStartTimezone(task.getStartTimezone());
        resource.setEndTimezone(task.getEndTimezone());
        resource.setDescription(task.getDescription());
        resource.setRecurrenceId(task.getRecurrenceId());
        resource.setRecurrenceRule(task.getRecurrenceRule());
        resource.setRecurrenceException(task.getRecurrenceException());
        resource.setOwnerId(task.getOwnerId());
        resource.setOwnerType(task.getOwnerType());
        resource.setAllDay(task.getAllDay());

        return resource;
    }


    public Task fromResource(TaskResource resource, Task entity) {

        if (entity == null) {
            entity = new Task();
        }

        // copy properties from taskResource to task
        entity.setMemberId(resource.getMemberId());
        entity.setContactId(resource.getContactId());
        entity.setTaskType(resource.getTaskType());
        entity.setReason(resource.getReason());
        entity.setDescription(resource.getDescription());
        entity.setStatus(resource.getStatus());
        entity.setPriority(resource.getPriority());
        entity.setTitle(resource.getTitle());
        entity.setStart(resource.getStart());
        entity.setEnd(resource.getEnd());
        entity.setStartTimezone(resource.getStartTimezone());
        entity.setEndTimezone(resource.getEndTimezone());
        entity.setDescription(resource.getDescription());
        entity.setRecurrenceId(resource.getRecurrenceId());
        entity.setRecurrenceRule(resource.getRecurrenceRule());
        entity.setRecurrenceException(resource.getRecurrenceException());
        entity.setOwnerId(resource.getOwnerId());
        entity.setOwnerType(resource.getOwnerType());
        entity.setAllDay(resource.getAllDay());

        return entity;
    }

}