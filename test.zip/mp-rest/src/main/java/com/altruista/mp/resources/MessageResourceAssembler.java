package com.altruista.mp.resources;

import com.altruista.mp.model.Message;
import com.altruista.mp.rest.MessageController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;


/**
 * Created by mwixs_000 on 6/24/2014.
 */
public class MessageResourceAssembler extends
        ResourceAssemblerSupport<Message, MessageResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MessageResourceAssembler.class);

    public MessageResourceAssembler() {
        super(MessageController.class, MessageResource.class);
    }

    @Override
    public MessageResource toResource(Message message) {

        MessageResource resource = instantiateResource(message);

        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(MessageController.class).getMessage(message.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }

        return resource;
    }

    @Override
    protected MessageResource instantiateResource(Message entity) {

        MessageResource resource = new MessageResource();

        resource.setMessageType(entity.getMessageType());
        resource.setSenderId(entity.getSenderId());
        resource.setRecipientIds(entity.getRecipientIds());
        resource.setMemberId(entity.getMemberId());
        resource.setSubject(entity.getSubject());
        resource.setBody(entity.getBody());
        resource.setMessagePriority(entity.getMessagePriority());
        resource.setLocation(entity.getLocation());
        resource.setViewed(entity.isViewed());
        resource.setSentOn(entity.getSentOn());
        resource.setHealthSummary(entity.getHealthSummary());

        return resource;
    }

    public Message fromResource(MessageResource resource) {

        Message message = new Message();

        // copy properties from messageResource to message
        message.setMessageType(resource.getMessageType());
        message.setSenderId(resource.getSenderId());
        message.setRecipientIds(resource.getRecipientIds());
        message.setMemberId(resource.getMemberId());
        message.setSubject(resource.getSubject());
        message.setBody(resource.getBody());
        message.setMessagePriority(resource.getMessagePriority());
        message.setLocation(resource.getLocation());
        message.setViewed(resource.isViewed());
        message.setSentOn(resource.getSentOn());
        message.setHealthSummary(resource.getHealthSummary());

        return message;
    }
}