package com.altruista.mp.resources;

import com.altruista.mp.model.Assessment;
import com.altruista.mp.rest.AssessmentController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;


/**
 * created by PRATEEK on 03/04/2015
 */
public class AssessmentNameResourceAssembler extends
        ResourceAssemblerSupport<Assessment, AssessmentNameResource> {

    public AssessmentNameResourceAssembler() {
        super(AssessmentController.class, AssessmentNameResource.class);
    }

    @Override
    public AssessmentNameResource toResource(Assessment assessment) {
        return createResourceWithId(assessment.getId(), assessment);
    }

    @Override
    protected AssessmentNameResource instantiateResource(Assessment entity) {
        AssessmentNameResource resource = new AssessmentNameResource();
        resource.setName(entity.getName());
        resource.setAssessmentId(entity.getId());
        return resource;
    }
}
