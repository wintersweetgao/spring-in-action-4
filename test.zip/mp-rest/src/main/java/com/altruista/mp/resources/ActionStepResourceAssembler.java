package com.altruista.mp.resources;

import com.altruista.mp.model.ActionStep;
import com.altruista.mp.rest.ActionStepController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

public class ActionStepResourceAssembler extends
        ResourceAssemblerSupport<ActionStep, ActionStepResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ActionStepResourceAssembler.class);

    public ActionStepResourceAssembler() {
        super(ActionStepController.class, ActionStepResource.class);
    }

    @Override
    public ActionStepResource toResource(ActionStep item) {
        ActionStepResource resource = instantiateResource(item);
        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(ActionStepController.class).getActionStep(item.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }

        return resource;
    }

    @Override
    protected ActionStepResource instantiateResource(ActionStep entity) {
        ActionStepResource resource = new ActionStepResource();

        resource.setGoalId(entity.getGoalId());
        resource.setMemberId(entity.getMemberId());
        resource.setLob(entity.getLob());
        resource.setGoalGroup(entity.getGoalGroup());
        resource.setCondition(entity.getCondition());
        resource.setTerm(entity.getTerm());
        resource.setStep(entity.getStep());
        resource.setIntervention(entity.getIntervention());
        resource.setStatus(entity.getStatus());
        resource.setMemberStatus(entity.getMemberStatus());
        resource.setSignedOff(entity.getSignedOff());
        resource.setNotes(entity.getNotes());
        resource.setStartOn(entity.getStartOn());
        resource.setEndOn(entity.getEndOn());

        return resource;
    }

    public ActionStep fromResource(ActionStepResource resource, ActionStep step) {

        if (step == null)
            step = new ActionStep();

        // copy properties from memberResource to member (skip GoalId and MemberId)
        step.setLob(resource.getLob());
        step.setGoalGroup(resource.getGoalGroup());
        step.setCondition(resource.getCondition());
        step.setTerm(resource.getTerm());
        step.setStep(resource.getStep());
        step.setIntervention(resource.getIntervention());
        step.setStatus(resource.getStatus());
        step.setMemberStatus(resource.getMemberStatus());
        step.setSignedOff(resource.getSignedOff());
        step.setNotes(resource.getNotes());
        step.setStartOn(resource.getStartOn());
        step.setEndOn(resource.getEndOn());
        return step;

    }

    public List<ActionStepResource> toResources(List<ActionStep> entities) {

        Assert.notNull(entities);
        List<ActionStepResource> result = new ArrayList<ActionStepResource>();

        for (ActionStep entity : entities) {
            if ((entity.getStartOn() == null || entity.getStartOn().isBeforeNow()) &&
                    (entity.getEndOn() == null || entity.getEndOn().isAfterNow())) {
                result.add(toResource(entity));
            }
        }

        return result;
    }
}
