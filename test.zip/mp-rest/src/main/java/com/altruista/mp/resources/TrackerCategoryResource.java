package com.altruista.mp.resources;

import org.springframework.data.annotation.Transient;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "trackercategory")
public class TrackerCategoryResource extends ResourceSupport {
    private String categoryId;
    private String name;
    private Boolean readOnly;
    private List<String> conditions;
    @Transient
    private List<TrackerResource> trackers;

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getReadOnly() {
        return readOnly;
    }

    public void setReadOnly(Boolean readOnly) {
        this.readOnly = readOnly;
    }

    public List<String> getConditions() {
        return conditions;
    }

    public void setConditions(List<String> conditions) {
        this.conditions = conditions;
    }

    public List<TrackerResource> getTrackers() {
        return trackers;
    }

    public void setTrackers(List<TrackerResource> trackers) {
        this.trackers = trackers;
    }
}
