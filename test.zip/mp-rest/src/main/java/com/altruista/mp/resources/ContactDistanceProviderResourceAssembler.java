package com.altruista.mp.resources;

import com.altruista.mp.model.ContactDistance;
import com.altruista.mp.rest.ContactController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

/**
 * Developed by Prateek on 09/07/15
 */
public class ContactDistanceProviderResourceAssembler extends ResourceAssemblerSupport<ContactDistance, ContactDistanceResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContactDistanceProviderResourceAssembler.class);

    public ContactDistanceProviderResourceAssembler() {
        super(ContactController.class, ContactDistanceResource.class);
    }

    @Override
    public ContactDistanceResource toResource(ContactDistance contactDistance) {
        ContactDistanceResource resource = instantiateResource(contactDistance);

        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(ContactController.class).getContactWithoutValidation(contactDistance.getContactId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }
        resource.setSalutation(contactDistance.getSalutation());
        resource.setFirstName(contactDistance.getFirstName());
        resource.setMiddleName(contactDistance.getMiddleName());
        resource.setLastName(contactDistance.getLastName());
        resource.setNameSuffix(contactDistance.getNameSuffix());
        resource.setCompany(contactDistance.getCompany());
        resource.setDistance(contactDistance.getDistance());
        return resource;
    }

    @Override
    protected ContactDistanceResource instantiateResource(ContactDistance entity) {
        ContactDistanceResource resource = new ContactDistanceResource();
        resource.setSalutation(entity.getSalutation());
        resource.setFirstName(entity.getFirstName());
        resource.setMiddleName(entity.getMiddleName());
        resource.setLastName(entity.getLastName());
        resource.setNameSuffix(entity.getNameSuffix());
        resource.setCompany(entity.getCompany());
        resource.setDistance(entity.getDistance());

        return resource;
    }

}
