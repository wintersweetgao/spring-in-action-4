package com.altruista.mp.rest;

import com.altruista.mp.model.*;
import com.altruista.mp.resources.*;
import com.altruista.mp.rest.exceptions.*;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.restutils.TokenUtils;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MPDocumentService;
import com.altruista.mp.services.MemberIndexService;
import com.altruista.mp.services.UserService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.altruista.mp.utils.PropertiesLoaderUtility;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.apache.commons.lang.RandomStringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Copyright 2015 Altruista Health. All Rights Reserved
 *
 * @author: Refactored by Prateek on 10/05/15
 */

@Controller
@Api(value = "User service", description = "Manage Users")
public class UserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    private final String USER_IS_LOCKED = "User is locked.";
    @Value("${mp.sso.enabled}")
    private String ssoEnabled;
    @Autowired
    private UserService userService;
    @Autowired
    private ContactService contactService;
    @Autowired
    private MemberIndexService indexService;
    @Autowired
    private MPDocumentService docService;
    @Autowired
    private BCryptPasswordEncoder encoder;

    @Autowired
    @Qualifier("authenticationManager")
    private AuthenticationManager authManager;

    private UserResourceAssembler userAssembler;

    public UserController() {
        userAssembler = new UserResourceAssembler();
    }

    /**
     * Retrieves the currently logged in user.
     *
     * @return A resource containing the username, name information and the roles.
     */
    @RequestMapping(value = "/api/user", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Get the User profile")
    public HttpEntity<UserResource> getUserProfile(Principal principal) {
        //User authUser = (User) ((Authentication) principal).getPrincipal();
        if (principal == null || principal.getName().length() == 0 || principal.getName().equals("anonymousUser")) {
            throw new AccessDeniedException("Anonymous access is not permitted.");
        }

        try {
            User user = userService.getUserByUsername(principal.getName());
            UserResource resource = userAssembler.toResource(user);

            if (user.getContact() != null &&
                    user.getContact().getPhoto() != null &&
                    user.getContact().getPhoto().getDocumentUrl() != null) {
                resource.setPhotoData(docService.getEncodedImageResource(user.getContact().getPhoto()));
            }

            return new ResponseEntity<UserResource>(resource, HttpStatus.OK);
        } catch (ServiceException exc) {
            LOGGER.warn("Unable to retrieve user profile: " + principal.getName() + ", exception: " + exc);
            return new ResponseEntity<UserResource>(new UserResource(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @RequestMapping(value = "/api/contact/{contactId}/member/{memberId}/grant", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Get the User Authority")
    public HttpEntity<List<String>> getUserAuthority(
            @PathVariable("contactId") String contactId, @PathVariable("memberId") String memberId) throws ResourceException, ServiceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        User user = userService.findOneByContactId(contactId);
        List<String> grants;
        if (user == null) {
            grants = new ArrayList<String>();
        } else
            grants = user.getAuthorityList(memberId);

        return new ResponseEntity<List<String>>(grants, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/contact/{contactId}/member/{memberId}/grant", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Get the User Authority")
    public HttpEntity<AuthorityResource> grantUserAuthority(
            @PathVariable("contactId") String contactId, @PathVariable("memberId") String memberId, @RequestBody AuthorityResource authority) throws ResourceException, ServiceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        User user = userService.findOneByContactId(contactId);

        // add the grant as an authority if it doesn't exist
        if (!user.getAuthorityList(memberId).contains(authority.getAuthority())) {
            user.getAuthorityList(memberId).add(authority.getAuthority());
            userService.save(user);
        }

        return new ResponseEntity<AuthorityResource>(authority, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/contact/{contactId}/member/{memberId}/revoke", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Revoke the User Authority")
    public HttpEntity<AuthorityResource> revokeUserAuthority(
            @PathVariable("contactId") String contactId, @PathVariable("memberId") String memberId, @RequestBody AuthorityResource authority) throws ResourceException, ServiceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        User user = userService.findOneByContactId(contactId);

        // remove the authority if it exists
        if (user.getAuthorityList(memberId).contains(authority.getAuthority())) {
            user.getAuthorityList(memberId).remove(authority.getAuthority());
            userService.save(user);
        }

        return new ResponseEntity<AuthorityResource>(authority, HttpStatus.OK);
    }

    /**
     * Authenticates a user and creates an authentication token.
     *
     * @param credential The name and password of the user.
     * @return A transfer containing the authentication token.
     * @throws ServiceException
     */
    @RequestMapping(value = "/api/user/authenticate", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Authenticate the user")
    public TokenTransfer authenticate(@RequestBody UsernameCredentialResource credential) throws ServiceException {
        /*
         * Reload user as password of authentication principal will be null after authorization and
         * password is needed for token generation
         */
        int lockdownTime = Integer.parseInt(PropertiesLoaderUtility.getProperty("user.lock.down.time.in.minutes"));
        int maxFailedAllowedAttempt = Integer.parseInt(PropertiesLoaderUtility.getProperty("user.allowed.failed.login.attempts"));

        DateTime now = DateTime.now();
        DateTime currentDate = DateTime.now();
        User user;
        try {
            user = userService.getUserByUsername(credential.getUsername());
        } catch (ServiceException exc) {
            LOGGER.error("Unable to authenticate user: " + credential.getUsername() + ", exception: " + exc);
            return null;
        }

        // check if user is SSO enabled
        /*if(ssoEnabled.equals("1") && user.getContact().getContactType() == ContactType.MEMBER)
            throw new InvalidCredentialException("Member must authenticate using SSO.");*/

        try {

            if (user != null && user.getLastFailedAccessOn() != null) {
                DateTime lastFailedAccess = user.getLastFailedAccessOn();

                // calculate minutes from lastAttempt and SystemDate
                long minuteDiff = (currentDate.getMillis() - lastFailedAccess.getMillis()) / (1000 * 60);
                LOGGER.debug("Minutes Difference : " + minuteDiff);

                // Throw error if user is locked and minutes difference is less than equals to Lock Down time
                if (minuteDiff <= lockdownTime && user.isUserLocked()) {
                    throw new LockedUserException(USER_IS_LOCKED);
                }
                // this will reset Failure Attempts counter if time cross on user threshold limit
                else if (minuteDiff > lockdownTime) {
                    user.setUserLocked(false);
                    user.setFailedAccessAttempts(0);
                    userService.save(user);
                }
                // Check if User is Locked
                if (user != null && user.isUserLocked() && user.getFailedAccessAttempts() >= maxFailedAllowedAttempt)
                    throw new LockedUserException(USER_IS_LOCKED);
            }

            UsernamePasswordAuthenticationToken authenticationToken =
                    new UsernamePasswordAuthenticationToken(credential.getUsername(), credential.getPassword());
            Authentication authentication = this.authManager.authenticate(authenticationToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            if (user != null) {
                user.setUserLocked(false);
                user.setFailedAccessAttempts(0);
                if (user.getAccessedOn() != null)
                    user.setPriorAccessedOn(user.getAccessedOn());
                else
                    user.setPriorAccessedOn(now);
                user.setAccessedOn(now);
                user.setSsoEnabled(false);
                userService.save(user);
            }

            return new TokenTransfer(TokenUtils.createToken(user, false));
        } catch (BadCredentialsException exc) {
            if (user != null) {
                // For Failure Attempts, add/update FailedAttempts
                int failedAccessAttemptsCounter = user.getFailedAccessAttempts();
                int tempCounter = failedAccessAttemptsCounter + 1;
                if (tempCounter >= maxFailedAllowedAttempt)
                    user.setUserLocked(true);
                user.setLastFailedAccessOn(DateTime.now());
                user.setFailedAccessAttempts(tempCounter);

                try {
                    userService.save(user);
                } catch (Exception ignore) {
                    LOGGER.error("Unable to updated failed attempts counter: " + ignore);
                }
            }

            throw exc;  // rethrow
        } catch (ServiceException exc) {
            LOGGER.error("Unable to authenticate user: " + credential.getUsername() + ", exception: " + exc);
        } catch (TokenException exc) {
            LOGGER.error("Unable to authenticate user: " + credential.getUsername() + ", exception: " + exc);
        }

        return null;
    }

    /**
     * Verify a registration request.
     *
     * @param credential The registration code issued to the user and the user's birth date
     * @return A transfer containing the authentication token.
     */
    @RequestMapping(value = "/api/user/authenticateRegistration", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Authenticate the Registration")
    public TokenTransfer authenticateRegistration(@RequestBody RegistrationCredentialResource credential) {
        try {
            // Lookup the memberId given the Member Code
            List<MemberIndex> members = indexService.findByMemberIndexesAndValue(credential.getMemberCode());
            for (MemberIndex index : members) {
                LOGGER.debug("Found member with registration code = " + index.getMemberId());

                List<User> users = userService.findByMemberId(index.getMemberId());

                for (User user : users) {
                    LOGGER.debug("Found user with contact code = " + user.getContactCode());

                    // check if user is SSO enabled
                    /*if(ssoEnabled.equals("1") && user.getContact().getContactType() == ContactType.MEMBER)
                        throw new InvalidCredentialException("Member must authenticate using SSO.");*/

                    // load contact information
                    Contact contact = null;
                    if (user.getContactId() != null)
                        contact = contactService.get(user.getContactId());


                    // skip invalid data, if user does not have a contact
                    if (contact == null) {
                        LOGGER.warn("Unable to locate contact: " + user.getContactId() + ", for user: " + user.getId());
                        continue;
                    }

                    /** check if user is already registered in Member Portal */
                    if (contact.getRegistrationStatus().equalsIgnoreCase("Registered"))
                        throw new AlreadyRegisteredException("This User has been already registered. You're not allowed to registered.");

                    // multiple contacts may share the same registration code
                    // only check the credentials for contacts of the proper type, skip others
                    if (contact.getContactType() != credential.getContactType())
                        continue;

                    if (credential.getContactType() == ContactType.MEMBER) {
                        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");
                        DateTime inDOB = DateTime.parse(credential.getDob(), formatter);
                        DateTime dbDOB = new DateTime(contact.getDob());
                        if (!inDOB.isEqual(dbDOB)) {
                            LOGGER.debug("Invalid DOB, checking next matching contact: " + credential.getMemberCode());
                            continue;   // registration code may not be unique, search for other matches
                        }
                    } else {
                        if (credential.getPhoneNumber() == null || !credential.getPhoneNumber().equalsIgnoreCase(contact.getPhoneNumber())) {
                            LOGGER.debug("Invalid phone number, checking next matching contact: " + credential.getMemberCode());
                            continue;   // registration code may not be unique, search for other matches
                        }
                    }

                    DateTime now = DateTime.now();
                    DateTime currentDate = DateTime.now();
                    int lockdownTime = Integer.parseInt(PropertiesLoaderUtility.getProperty("user.lock.down.time.in.minutes"));

                    if (user != null && user.getLastFailedAccessOn() != null) {
                        DateTime lastFailedAccess = user.getLastFailedAccessOn();
                        long minuteDiff = (currentDate.getMillis() - lastFailedAccess.getMillis()) / (1000 * 60);    // number of minutes
                        if (minuteDiff <= lockdownTime && user.isUserLocked()) {
                            throw new LockedUserException(USER_IS_LOCKED);
                        }
                    }

                    // only grant REGISTER authority
                    List<GrantedAuthority> auths = new ArrayList<>();
                    auths.add(new SimpleGrantedAuthority("REGISTER"));

                    UsernamePasswordAuthenticationToken authenticationToken =
                            new UsernamePasswordAuthenticationToken(user.getUsername(), user.getContactCode(), auths);
                    Authentication authentication = this.authManager.authenticate(authenticationToken);
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    if (user != null) {
                        user.setUserLocked(false);
                        user.setFailedAccessAttempts(0);
                        if (user.getAccessedOn() != null)
                            user.setPriorAccessedOn(user.getAccessedOn());
                        else
                            user.setPriorAccessedOn(now);
                        user.setAccessedOn(now);
                        user.setSsoEnabled(false);
                        userService.save(user);
                    }

                    return new TokenTransfer(TokenUtils.createToken(user, true));
                }   // for each user matching the memberId
            } // for each member matching the registrationCode

        } catch (ServiceException exc) {
            LOGGER.error("Unable to authenticate for registration: " + credential.getMemberCode() + ", exception: " + exc);
        } catch (TokenException exc) {
            LOGGER.error("Unable to authenticate for registration: " + credential.getMemberCode() + ", exception: " + exc);
        }

        throw new InvalidCredentialException("Information entered does not match information on file.");
    }

    private Map<String, Boolean> createRoleMap(UserDetails userDetails) {
        Map<String, Boolean> roles = new HashMap<String, Boolean>();
        for (GrantedAuthority authority : userDetails.getAuthorities()) {
            roles.put(authority.getAuthority(), Boolean.TRUE);
        }

        return roles;
    }

    @RequestMapping(value = "/api/user/username", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Recover the User name")
    public HttpEntity<UsernameResource> userNameRecovery(@RequestBody UsernameLookupResource usernameLookupResource) throws ServiceException {
        QuestionAnswer questionAnswerClass = usernameLookupResource.getSecurityQuestionAnswer();
        String securityQuestion = questionAnswerClass.getQuestion();
        String securityAnswer = questionAnswerClass.getAnswer();

        boolean isUserFound = false;
        String retrievedUserId = "";

        // Lookup the memberId given the Member Code
        List<MemberIndex> members = indexService.findByMemberIndexesAndValue(usernameLookupResource.getMemberCode());
        for (MemberIndex index : members) {

            List<User> users = userService.findByMemberId(index.getMemberId());
            for (User user : users) {
                boolean isPasswordMatch = false;
                boolean isQuestionMatch = false;
                boolean isAnswerMatch = false;

                // check if user is SSO enabled
                /*if(ssoEnabled.equals("1") && user.getContact().getContactType() == ContactType.MEMBER)
                    throw new InvalidCredentialException("Member must authenticate using SSO.");*/

                Contact userContact = contactService.get(user.getContactId());

                // skip invalid data, if user does not have a contact
                if (userContact == null) {
                    LOGGER.warn("Unable to locate contact: " + user.getContactId() + ", for user: " + user.getId());
                    continue;
                }

                DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");
                DateTime inDOB = DateTime.parse(usernameLookupResource.getDob(), formatter);
                DateTime dbDOB = new DateTime(userContact.getDob());
                if (!inDOB.isEqual(dbDOB)) {
                    LOGGER.info("Invalid DOB or non-unique member code: " + usernameLookupResource.getMemberCode());
                    continue;   // registration code may not be unique, search for other matches
                }

                if (encoder.matches(usernameLookupResource.getPassword(), user.getPassword()))
                    isPasswordMatch = true;

                for (QuestionAnswer dbQA : user.getSecurityQuestionAnswers()) {
                    isQuestionMatch = false;
                    isAnswerMatch = false;

                    if (dbQA.getQuestion() != null && dbQA.getQuestion().equalsIgnoreCase(securityQuestion))
                        isQuestionMatch = true;
                    if (dbQA.getAnswer() != null && dbQA.getAnswer().equalsIgnoreCase(securityAnswer))
                        isAnswerMatch = true;
                    if (isAnswerMatch && isQuestionMatch)
                        break;
                }

                // if user found, stop searching through users assigned to this memberId
                if (isPasswordMatch && isQuestionMatch && isAnswerMatch) {
                    isUserFound = true;
                    retrievedUserId = user.getUsername();
                    break;
                }
            }

            // if user found, stop searching through members with matching memberCode
            if (isUserFound)
                break;
        }

        if (isUserFound)
            return new ResponseEntity<UsernameResource>(new UsernameResource(retrievedUserId), HttpStatus.OK);
        else
            throw new UserNotFoundException("Information entered does not match information on file.");
    }

    @RequestMapping(value = "/api/user/authenticatePasswordReset", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Authenticate the password reset")
    public TokenTransfer authenticatePasswordReset(@RequestBody PasswordResetCredentialResource credential) throws ServiceException {

        User user = userService.getUserByUsername(credential.getUsername());
        if (user == null)
            throw new InvalidCredentialException("Information entered does not match information on file.");

        // check if user is SSO enabled
        /*if(ssoEnabled.equals("1") && user.getContact().getContactType() == ContactType.MEMBER)
            throw new InvalidCredentialException("Member must authenticate using SSO.");*/

        Contact userContact = contactService.get(user.getContactId());

        // skip invalid data, if user does not have a contact
        if (userContact == null) {
            LOGGER.warn("Unable to locate contact: " + user.getContactId() + ", for user: " + user.getId());
            throw new InvalidCredentialException("Information entered does not match information on file.");
        }

        boolean isQuestionMatch = false;
        boolean isAnswerMatch = false;

        String secQuestion = credential.getSecurityQuestionAnswer().getQuestion();
        String secAnswer = credential.getSecurityQuestionAnswer().getAnswer();

        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");
        DateTime inDOB = DateTime.parse(credential.getDob(), formatter);
        DateTime dbDOB = new DateTime(userContact.getDob());
        if (!inDOB.isEqual(dbDOB)) {
            LOGGER.warn("Invalid DOB for username: " + credential.getUsername());
            throw new InvalidCredentialException("Information entered does not match information on file.");
        }

        for (QuestionAnswer dbQA : user.getSecurityQuestionAnswers()) {
            isQuestionMatch = false;
            isAnswerMatch = false;

            if (dbQA.getQuestion() != null && dbQA.getQuestion().equalsIgnoreCase(secQuestion))
                isQuestionMatch = true;
            if (dbQA.getAnswer() != null && dbQA.getAnswer().equalsIgnoreCase(secAnswer))
                isAnswerMatch = true;
            if (isAnswerMatch && isQuestionMatch)
                break;
        }

        if (isQuestionMatch && isAnswerMatch) {
            DateTime now = DateTime.now();
            DateTime currentDate = DateTime.now();
            int lockdownTime = Integer.parseInt(PropertiesLoaderUtility.getProperty("user.lock.down.time.in.minutes"));

            if (user != null && user.getLastFailedAccessOn() != null) {
                DateTime lastFailedAccess = user.getLastFailedAccessOn();
                long minuteDiff = (currentDate.getMillis() - lastFailedAccess.getMillis()) / (1000 * 60);    // number of minutes
                if (minuteDiff <= lockdownTime && user.isUserLocked()) {
                    throw new LockedUserException(USER_IS_LOCKED);
                }
            }

            // temporarily reset password to a random string
            String password = RandomStringUtils.random(8, true, true);
            user.setPassword(encoder.encode(password));
            userService.save(user);

            // only grant REGISTER authority
            List<GrantedAuthority> auths = new ArrayList<>();
            auths.add(new SimpleGrantedAuthority("REGISTER"));

            UsernamePasswordAuthenticationToken authenticationToken =
                    new UsernamePasswordAuthenticationToken(user.getUsername(), password, auths);
            Authentication authentication = this.authManager.authenticate(authenticationToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            if (user != null) {
                user.setUserLocked(false);
                user.setFailedAccessAttempts(0);
                if (user.getAccessedOn() != null)
                    user.setPriorAccessedOn(user.getAccessedOn());
                else
                    user.setPriorAccessedOn(now);
                user.setAccessedOn(now);
                user.setSsoEnabled(false);
                userService.save(user);
            }

            try {
                return new TokenTransfer(TokenUtils.createToken(user, true));
            } catch (TokenException exc) {
                LOGGER.error("Unable to authenticate for password reset: " + credential.getUsername() + ", exception: " + exc);
            }

            return null;

        } else {
            throw new InvalidCredentialException("Information entered does not match information on file.");
        }
    }

    @RequestMapping(value = "/api/user/registerUser", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Register the user")
    public HttpEntity<String> registerUser(@RequestBody RegisterUserResource registerResource, Principal principal) throws ServiceException {

        //BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(8);
        User user = userService.getUserByUsername(principal.getName());

        // check if user is SSO enabled
        /*if(ssoEnabled.equals("1") && user.getContact().getContactType() == ContactType.MEMBER)
            throw new InvalidCredentialException("Member must authenticate using SSO.");*/

        user.setUsername(registerResource.getUsername());
        user.setPassword(encoder.encode(registerResource.getPassword()));
        List<QuestionAnswer> qas = user.getSecurityQuestionAnswers();
        qas.add(registerResource.getSecurityQuestionAnswer());
        userService.save(user);

        if (user.getContactId() != null) {
            Contact contact = contactService.get(user.getContactId());
            contact.setRegistrationStatus("Registered");
            contactService.save(contact);
        }

        return new ResponseEntity<String>(user.getUsername(), HttpStatus.OK);
    }

    @RequestMapping(value = "/api/user/resetPassword", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Reset the password")
    public HttpEntity<String> resetPassword(@RequestBody PasswordResource passwordResource, Principal principal) throws ServiceException {

        //BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(8);
        User user = userService.getUserByUsername(principal.getName());

        // check if user is SSO enabled
        /*if(ssoEnabled.equals("1") && user.getContact().getContactType() == ContactType.MEMBER)
            throw new InvalidCredentialException("Member must authenticate using SSO.");*/

        String newPassword = passwordResource.getPassword();
        String reTypeNewPassword = passwordResource.getVerifyPassword();

        if (newPassword != null && newPassword.equals(reTypeNewPassword)) {
            user.setPassword(encoder.encode(newPassword));
            userService.save(user);
        } else {
            throw new InvalidPasswordException("New and re-entered passwords do not match.");
        }

        return new ResponseEntity<String>(newPassword, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/user/checkUsername/{userName}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Checks the user name")
    public HttpEntity<List<String>> checkUsername(@PathVariable("userName") String userName) throws ServiceException {
        List<String> suggestedUser = userService.getUserSuggestions(userName);

        return new ResponseEntity<List<String>>(suggestedUser, HttpStatus.OK);
    }


    @RequestMapping(value = "/api/user/tiles", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Updates current user's tiles")
    public HttpEntity<List<Tile>> updateTiles(Principal principal, @RequestBody List<Tile> tiles) throws ResourceException, ServiceException {
        if (principal == null || principal.getName().length() == 0 || principal.getName().equals("anonymousUser")) {
            throw new AccessDeniedException("Anonymous access is not permitted.");
        }

        try {
            User user = userService.getUserByUsername(principal.getName());
            user.setTiles(tiles);

            userService.save(user);
        } catch (ServiceException exc) {
            LOGGER.warn("Unable to retrieve user tiles : " + principal.getName() + ", exception: " + exc);
            return new ResponseEntity<List<Tile>>(new ArrayList<Tile>(), HttpStatus.INTERNAL_SERVER_ERROR);
        }


        return new ResponseEntity<List<Tile>>(tiles, HttpStatus.OK);
    }
}
