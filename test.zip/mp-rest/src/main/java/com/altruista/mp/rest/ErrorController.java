package com.altruista.mp.rest;

import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/api/error")
@Api(value = "Error service", description = "Manage Errors")
public class ErrorController {
    @RequestMapping(value = "/404", method = RequestMethod.GET)
    @ApiOperation(value = "Returns error message for 404")
    public String print404Error(ModelMap model) {
        model.addAttribute("message", "The requested page is not available. Please check the URL and try again");
        return "error";
    }

}