package com.altruista.mp.rest;

import com.altruista.mp.model.Goal;
import com.altruista.mp.resources.*;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.ActionStepService;
import com.altruista.mp.services.GoalService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles requests for the care plan
 */
@Controller
@Api(value = "Goal service", description = "Manage Goals")
public class GoalController {
    private static final Logger LOGGER = LoggerFactory.getLogger(GoalController.class);

    private final GoalService goalService;
    private final GoalResourceAssembler goalAssembler;
    private final ActionStepService stepService;
    private final ActionStepResourceAssembler stepAssembler;

    @Autowired
    public GoalController(GoalService cpService, ActionStepService stepService) {
        this.goalService = cpService;
        this.stepService = stepService;
        goalAssembler = new GoalResourceAssembler();
        stepAssembler = new ActionStepResourceAssembler();
    }

    @ApiOperation(value = "Gets the goals using Member id")
    @RequestMapping(value = "/api/member/{memberId}/goal", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<GoalResource>> getGoalsByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<Goal> goals = goalService.findByMemberId(memberId);
        List<GoalResource> resourceList = new ArrayList<GoalResource>();
        for (Goal goal : goals) {
            if ((goal.getStartOn() == null || goal.getStartOn().isBeforeNow()) &&
                    (goal.getEndOn() == null || goal.getEndOn().isAfterNow()) &&
                    (goal.getStatus() == null || !goal.getStatus().equalsIgnoreCase("Deleted"))) {
                GoalResource resource = goalAssembler.toResource(goal);
                resource.setActionSteps(stepAssembler.toResources(stepService.findByGoalId(goal.getId())));
                resourceList.add(resource);
            }
        }
        return new ResponseEntity<List<GoalResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/goal/{goalId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the goals using Goal id")
    public HttpEntity<GoalResource> getGoal(
            @PathVariable("goalId") String goalId) throws ResourceException {
        Goal goal = goalService.get(goalId);
        GoalResource resource = goalAssembler.toResource(goal);
        List<ActionStepResource> actionStepResource = resource.getActionSteps();
        for (ActionStepResource actionStepResource2 : actionStepResource) {
            String memberId = actionStepResource2.getMemberId();
            MemberIdValidationUtil.validateMemberClaim(memberId);
        }

        return new ResponseEntity<GoalResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/goal/{goalId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves the goal")
    public HttpEntity<GoalResource> saveGoal(
            @PathVariable("goalId") String goalId, @RequestBody GoalResource resource) throws ResourceException {
        // verify user has access to this goal
        for (ActionStepResource actionStepResource : resource.getActionSteps()) {
            String memberId = actionStepResource.getMemberId();
            MemberIdValidationUtil.validateMemberClaim(memberId);
        }

        // load existing action step information
        Goal original = goalService.get(goalId);
        if (original == null)
            throw new ResourceNotFoundException("Goal not found.");

        // overwrite action step information with updated resource information
        Goal updated = goalAssembler.fromResource(goalId, resource);

        // save the updated action step
        goalService.save(updated);
        return new ResponseEntity<GoalResource>(resource, HttpStatus.OK);
    }

}