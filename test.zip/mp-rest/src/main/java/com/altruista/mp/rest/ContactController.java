package com.altruista.mp.rest;

import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactDistance;
import com.altruista.mp.model.ContactType;
import com.altruista.mp.model.MemberContact;
import com.altruista.mp.resources.*;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.ContactResourceNameComparer;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.ContactDistanceService;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberContactService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Handles requests for contacts
 * Developed by Prateek A on 06/26/15
 */
@Controller
@Api(value = "Contact service", description = "Manage Contacts")
public class ContactController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContactController.class);
    @Autowired
    private PagedResourcesAssembler<ContactDistance> pagedAssembler;

    private final ContactService contactService;
    private final MemberContactService memberContactService;
    private final ContactDistanceService contactDistanceService;

    private ContactResourceAssembler contactAssembler;
    private ContactDistanceResourceAssembler contactDistanceResourceAssembler;
    private ContactDistanceProviderResourceAssembler contactDistanceProviderResourceAssembler;

    @Autowired
    public ContactController(ContactService contactService,
                             MemberContactService memberContactService,
                             ContactDistanceService contactDistanceService) {

        this.contactService = contactService;
        this.memberContactService = memberContactService;
        this.contactAssembler = new ContactResourceAssembler();
        this.contactDistanceService = contactDistanceService;
        contactDistanceResourceAssembler = new ContactDistanceResourceAssembler();
        contactDistanceProviderResourceAssembler = new ContactDistanceProviderResourceAssembler();
    }

    @RequestMapping(value = "/api/contact/{contactId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets Contact using contact id")
    public HttpEntity<ContactResource> getContact(
            @PathVariable("contactId") String contactId) throws ResourceException {
        List<String> memberIds = memberContactService.findByContactId(contactId);
        MemberIdValidationUtil.validateMemberClaim(memberIds);

        Contact contact = contactService.get(contactId);
        ContactResource resource = contactAssembler.toResource(contact);

        return new ResponseEntity<ContactResource>(resource, HttpStatus.OK);
    }

    // Newly added for Contact Provider
    @RequestMapping(value = "/api/contact/provider/{contactId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets Contact using contact id")
    public HttpEntity<ContactResource> getContactWithoutValidation(
            @PathVariable("contactId") String contactId) throws ResourceException {

        Contact contact = contactService.get(contactId);
        ContactResource resource = contactAssembler.toResource(contact);

        return new ResponseEntity<ContactResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/{contactType}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets Member Contact using member id")
    public HttpEntity<ContactResource> getMemberContactByMemberId(
            @PathVariable("memberId") String memberId, @PathVariable("contactType") String contactTypeStr) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        ContactType contactType = ContactType.MEMBER;
        if (contactTypeStr.equalsIgnoreCase("CAREGIVER"))
            contactType = ContactType.CAREGIVER;
        else if (contactTypeStr.equalsIgnoreCase("PHYSICIAN"))
            contactType = ContactType.PHYSICIAN;
        else if (contactTypeStr.equalsIgnoreCase("CARECOACH"))
            contactType = ContactType.CARECOACH;


        List<MemberContact> contacts = memberContactService.findByMemberIdAndContactType(memberId, contactType);

        Contact contact = contactService.get(contacts.get(0).getContactId());
        ContactResource resource = contactAssembler.toResource(contact);
        return new ResponseEntity<ContactResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/contact/{contactId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"}, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @ApiOperation(value = "Saves the Contact")
    public HttpEntity<ContactResource> saveContact(
            @PathVariable("contactId") String contactId, @Valid @RequestBody ContactResource resource, BindingResult bindingResult) throws ResourceException {
        // verify user has access to this contact
        List<String> memberIds = memberContactService.findByContactId(contactId);
        MemberIdValidationUtil.validateMemberClaim(memberIds);

        if (bindingResult.hasErrors()) {
            throw new InvalidRequestException("Invalid resource", bindingResult);
        }

        // load existing contact information
        Contact original = contactService.get(contactId);
        if (original == null)
            throw new ResourceNotFoundException("Contact not found.");

        // overwrite contact information with updated resource information
        Contact updated = contactAssembler.fromResource(resource, original);

        // save the updated contact
        contactService.save(updated);

        return new ResponseEntity<ContactResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/careteam", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Retrieves the care team")
    public HttpEntity<List<ContactResource>> getCareTeamByMemberId(
            @PathVariable("memberId") String memberId, @RequestParam(value = "isDirect", required = false) Boolean isDirect) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<MemberContact> contacts = memberContactService.findByMemberId(memberId);
        List<ContactResource> resourceList = getContactResources(contacts, isDirect);

        return new ResponseEntity<List<ContactResource>>(resourceList, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/coaches", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the Coaches using member id")
    public HttpEntity<List<ContactResource>> getCoachesByMemberId(
            @PathVariable("memberId") String memberId, @RequestParam(value = "isDirect", required = false) Boolean isDirect) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<MemberContact> contacts = memberContactService.findByMemberIdAndContactType(memberId, ContactType.CARECOACH);
        List<ContactResource> resourceList = getContactResources(contacts, isDirect);

        return new ResponseEntity<List<ContactResource>>(resourceList, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/physicians", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the Physician using member id")
    public HttpEntity<List<ContactResource>> getPhysiciansByMemberId(
            @PathVariable("memberId") String memberId, @RequestParam(value = "isDirect", required = false) Boolean isDirect) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<MemberContact> contacts = memberContactService.findByMemberIdAndContactType(memberId, ContactType.PHYSICIAN);
        List<ContactResource> resourceList = getContactResources(contacts, isDirect);

        return new ResponseEntity<List<ContactResource>>(resourceList, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/member/{memberId}/caregivers", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Retrieve CareGivers using member id")
    public HttpEntity<List<ContactResource>> getCareGiversByMemberId(
            @PathVariable("memberId") String memberId, @RequestParam(value = "isDirect", required = false) Boolean isDirect) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<MemberContact> contacts = memberContactService.findByMemberIdAndContactType(memberId, ContactType.CAREGIVER);
        List<ContactResource> resourceList = getContactResources(contacts, isDirect);

        return new ResponseEntity<List<ContactResource>>(resourceList, HttpStatus.OK);
    }

    private List<ContactResource> getContactResources(List<MemberContact> contacts, Boolean isDirect) {
        List<ContactResource> resourceList = new ArrayList<ContactResource>();

        for (MemberContact teamMember : contacts) {
            if ((teamMember.getStartOn() == null || teamMember.getStartOn().isBeforeNow()) &&
                    (teamMember.getEndOn() == null || teamMember.getEndOn().isAfterNow()) &&
                    teamMember.isActive()) {

                Contact contact = contactService.get(teamMember.getContactId());

                // do not add the contact if this is a request for Direct contacts
                // and the contact does not have a direct email address
                if ((isDirect != null && isDirect.booleanValue()) &&
                        (contact.getDirectEmail() == null || contact.getDirectEmail().length() == 0))
                    continue;

                resourceList.add(contactAssembler.toResource(contact));
            }
        }
        Collections.sort(resourceList, new ContactResourceNameComparer());

        return resourceList;
    }

    @RequestMapping(value = "/api/contact/contactDistance",
            method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Contact Distances By Points")
    public HttpEntity<PagedResources<ContactDistanceResource>> getContactDistanceByPositions(
            @RequestParam(value = "keywords", required = false) List<String> keywords,
            @RequestParam(value = "tags", required = false) List<String> tags,
            @RequestParam(value = "lat", required = false) Double lat,
            @RequestParam(value = "lon", required = false) Double lon,
            @RequestParam(value = "radius", required = false) Double radius,
            @RequestParam(value = "postalCode", required = false) String postalCode,
            Pageable pageable) throws ServiceException, ResourceException {

        Page<ContactDistance> pagedResourcesContact;

        if (lat != null && lon != null) {
            pagedResourcesContact = contactDistanceService.getContactDistanceByPosition(
                    keywords, tags, lat, lon, radius, pageable);
        } else if (postalCode != null) {
            pagedResourcesContact = contactDistanceService.getContactDistanceByPostalCode(
                    keywords, tags, postalCode, pageable);
        } else {
            throw new ServiceException("Missing postalCode or lat/lon/radius/PostalCode/PageIndex parameters.");
        }

        return new ResponseEntity<>(pagedAssembler.toResource(pagedResourcesContact, contactDistanceProviderResourceAssembler), HttpStatus.OK);
    }
}
