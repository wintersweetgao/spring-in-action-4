package com.altruista.mp.rest;

import com.altruista.mp.model.ActionStep;
import com.altruista.mp.resources.ActionStepResource;
import com.altruista.mp.resources.ActionStepResourceAssembler;
import com.altruista.mp.resources.ActionStepStatusResource;
import com.altruista.mp.resources.ResourceNotFoundException;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.ActionStepService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Handles requests for the care plan's action steps
 */
@Controller
@Api(value = "Action step service", description = "Manage Action Steps")
public class ActionStepController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ActionStepController.class);

    private final ActionStepService stepService;
    private final ActionStepResourceAssembler stepAssembler;

    @Autowired
    public ActionStepController(ActionStepService cpService) {
        this.stepService = cpService;
        stepAssembler = new ActionStepResourceAssembler();
    }

    @ApiOperation(value = "Gets the Action steps by member id")
    @RequestMapping(value = "/api/member/{memberId}/step", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<ActionStepResource>> getActionStepsByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<ActionStepResource> resourceList = stepAssembler.toResources(stepService.findByMemberId(memberId));
        return new ResponseEntity<List<ActionStepResource>>(resourceList,
                HttpStatus.OK);
    }

    @ApiOperation(value = "Gets the Action steps by Goals")
    @RequestMapping(value = "/api/goal/{goalId}/step", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<ActionStepResource>> getActionStepsByGoal(@PathVariable String goalId) throws ResourceException {
        List<ActionStepResource> resourceList = stepAssembler.toResources(stepService.findByGoalId(goalId));
        for (ActionStepResource actionStep : resourceList) {
            String memberId = actionStep.getMemberId();
            MemberIdValidationUtil.validateMemberClaim(memberId);
        }
        return new ResponseEntity<List<ActionStepResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/step/{stepId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the Action steps by Step id")
    public HttpEntity<ActionStepResource> getActionStep(
            @PathVariable("stepId") String stepId) throws ResourceException {
        ActionStep step = stepService.get(stepId);
        ActionStepResource resource = stepAssembler.toResource(step);
        String memberId = resource.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);

        return new ResponseEntity<ActionStepResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/step/{stepId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves action step")
    public HttpEntity<ActionStepResource> saveActionStep(
            @PathVariable("stepId") String stepId, @RequestBody ActionStepResource resource) throws ResourceException {
        // verify user has access to this action step
        String memberId = resource.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);

        // load existing action step information
        ActionStep original = stepService.get(stepId);
        if (original == null)
            throw new ResourceNotFoundException("ActionStep not found.");

        // overwrite action step information with updated resource information
        ActionStep updated = stepAssembler.fromResource(resource, original);

        // save the updated action step
        stepService.save(updated);

        return new ResponseEntity<ActionStepResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/step/{stepId}/status", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves action step status")
    public HttpEntity<ActionStepResource> saveActionStepStatus(
            @PathVariable("stepId") String stepId, @RequestBody ActionStepStatusResource status) throws ResourceException {
        ActionStep step = stepService.get(stepId);
        String memberId = step.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        step.setMemberStatus(status.getStatus());
        step.setNotes(status.getNotes());
        stepService.save(step);

        ActionStepResource resource = stepAssembler.toResource(step);
        return new ResponseEntity<ActionStepResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/step/{stepId}/signoff", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves action step's sign off")
    public HttpEntity<ActionStepResource> saveActionStepSignOff(
            @PathVariable("stepId") String stepId, @RequestBody Boolean signoff) throws ResourceException {
        ActionStep step = stepService.get(stepId);
        String memberId = step.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        step.setSignedOff(signoff);
        stepService.save(step);

        ActionStepResource resource = stepAssembler.toResource(step);
        return new ResponseEntity<ActionStepResource>(resource, HttpStatus.OK);
    }
}