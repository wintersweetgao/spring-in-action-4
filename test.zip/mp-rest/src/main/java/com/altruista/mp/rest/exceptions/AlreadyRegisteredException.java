package com.altruista.mp.rest.exceptions;

public class AlreadyRegisteredException extends RuntimeException {
    private static final long serialVersionUID = 7428251272165618698L;
    private final String errors;

    public AlreadyRegisteredException(String message) {
        super(message);
        this.errors = message;
    }

    public String getErrors() {
        return errors;
    }
}
