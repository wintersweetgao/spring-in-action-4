package com.altruista.mp.resources;

import com.altruista.mp.model.QuestionAnswer;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;

import javax.validation.Valid;

/**
 * Created by mahesh on 10/28/14.
 */
public class PasswordResetCredentialResource {
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.username}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.username}")
    private String username;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.dob}")
    @Length(max = ResourceSize.MAX_DATE, message = "{length.validation.dob}")
    private String dob;
    @Valid
    private QuestionAnswer securityQuestionAnswer;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public QuestionAnswer getSecurityQuestionAnswer() {
        return securityQuestionAnswer;
    }

    public void setSecurityQuestionAnswer(QuestionAnswer securityQuestionAnswer) {
        this.securityQuestionAnswer = securityQuestionAnswer;
    }
}