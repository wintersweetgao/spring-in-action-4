package com.altruista.mp.aspects;

import com.altruista.mp.model.AuditLog;
import com.altruista.mp.services.AuditLogService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Component;

/**
 * Created by mwixson on 1/16/15.
 */
@Aspect
@Component
public class AuditAspect {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuditAspect.class);
    private static final String UNKNOWN = "UNKNOWN";
    @Autowired
    AuditLogService auditLogService;

    @Pointcut("execution(* com.altruista.mp.rest.*.*(..))")
    public void myPointCut() {
    }

    @Around("myPointCut()")
    public Object logSuccesses(ProceedingJoinPoint jp) throws Throwable {
        String status = null;
        final long start, end;

        start = System.nanoTime();
        Object result = jp.proceed();
        end = System.nanoTime();

        // obtain HTTP response
        if (result instanceof ResponseEntity) {
            status = ((ResponseEntity<Object>) result).getStatusCode().toString();
        }

        // obtain username and ipAddress
        String userName = UNKNOWN;
        String ipAddress = UNKNOWN;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            userName = authentication.getName();
            if (authentication.getDetails() instanceof WebAuthenticationDetails) {
                WebAuthenticationDetails details = (WebAuthenticationDetails) authentication.getDetails();
                if (details != null)
                    ipAddress = details.getRemoteAddress();
            }
        }

        // log them
        if (jp.getSignature() != null) {
            // Append arguments
            StringBuilder args = new StringBuilder();
            for (Object arg : jp.getArgs()) {
                if (arg instanceof String) {
                    args.append(arg);
                    args.append(",");
                }
            }
            if (args.length() > 0)
                args.setLength(args.length() - 1);

            String methodName = jp.getSignature().getName();
            String memberId = null;
            if (methodName.contains("ByMemberId") &&
                    jp.getArgs().length > 0 && jp.getArgs()[0] instanceof String) {
                memberId = (String) jp.getArgs()[0];
            }

            String action = String.format("%s(%s)", methodName, args.toString());
            LOGGER.debug("AUDIT SUCCESS [" + ipAddress + "]:" + userName + " called the method: " + action);

            AuditLog log = new AuditLog();
            log.setAction(action);
            log.setUserName(userName);
            log.setUserIpAddress(ipAddress);
            log.setMemberId(memberId);
            log.setRuntimeMillis(Math.round((end - start) / 1000 / 1000));
            log.setStatus(status);

            auditLogService.save(log);
        } else
            LOGGER.debug("AUDIT SUCCESS [" + ipAddress + "]:" + userName + " called an UNKNOWN method");

        return result;
    }

    @AfterThrowing(pointcut = "myPointCut()", throwing = "e")
    public void logExceptions(JoinPoint jp, Throwable e) {
        // obtain username and ipAddress
        String userName = "UNKNOWN";
        String ipAddress = "UNKNOWN";

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            userName = authentication.getName();
            if (authentication.getDetails() instanceof WebAuthenticationDetails) {
                WebAuthenticationDetails details = (WebAuthenticationDetails) authentication.getDetails();
                if (details != null)
                    ipAddress = details.getRemoteAddress();
            }
        }

        // log them
        if (jp.getSignature() != null) {
            // Append arguments
            StringBuilder args = new StringBuilder();
            for (Object arg : jp.getArgs()) {
                if (arg instanceof String) {
                    args.append(arg);
                    args.append(",");
                }
            }
            if (args.length() > 0)
                args.setLength(args.length() - 1);

            String methodName = jp.getSignature().getName();
            String memberId = null;
            if (methodName.contains("ByMemberId") &&
                    jp.getArgs().length > 0 && jp.getArgs()[0] instanceof String) {
                memberId = (String) jp.getArgs()[0];
            }

            String action = String.format("%s(%s)", methodName, args.toString());
            LOGGER.debug("AUDIT EXCEPTION [" + ipAddress + "]:" + userName + " called the method: " + action);

            AuditLog log = new AuditLog();
            log.setAction(action);
            log.setUserName(userName);
            log.setUserIpAddress(ipAddress);
            log.setMemberId(memberId);
            log.setRuntimeMillis(0);
            log.setStatus(e.getClass().getSimpleName());
            log.setDescription(e.getMessage());

            auditLogService.save(log);
        } else
            LOGGER.debug("AUDIT EXCEPTION [" + ipAddress + "]:" + userName + " called an UNKNOWN method");

    }

}
