package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;

/**
 * Created by mwixson on 11/3/14.
 */
public class UsernameCredentialResource {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.username}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.tasktype}")
    private String username;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.password}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.password}")
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
