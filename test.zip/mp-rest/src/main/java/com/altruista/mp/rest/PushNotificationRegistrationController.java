package com.altruista.mp.rest;

import com.altruista.mp.model.PushNotificationRegistration;
import com.altruista.mp.resources.PushNotificationRegistrationResource;
import com.altruista.mp.resources.PushNotificationRegistrationResourceAssembler;
import com.altruista.mp.resources.ResourceNotFoundException;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.MemberContactService;
import com.altruista.mp.services.PushNotificationRegistrationService;
import com.altruista.mp.utils.PropertiesLoaderUtility;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
 * Developed by Prateek on 10/27/15
 */
@Controller
@RequestMapping("/api/pushNotification")
@Api(value = "Push Notification Registration service", description = "Manage Push Notification Registration")
public class PushNotificationRegistrationController {
    private static final Logger LOGGER = LoggerFactory.getLogger(PushNotificationRegistrationController.class);

    private final PushNotificationRegistrationService pNRegistrationService;
    private PushNotificationRegistrationResourceAssembler pNRegistrationAssembler;
    private final MemberContactService memberContactService;

    @Autowired
    public PushNotificationRegistrationController(PushNotificationRegistrationService pNRegistrationService, MemberContactService memberContactService) {
        this.pNRegistrationService = pNRegistrationService;
        this.memberContactService = memberContactService;
        pNRegistrationAssembler = new PushNotificationRegistrationResourceAssembler();
    }

    @RequestMapping(value = "/device/registration", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Save the Push Notification Registration")
    public @ResponseBody HttpEntity<PushNotificationRegistrationResource> savePNRegistration(
            String memberId, @RequestBody PushNotificationRegistrationResource resource) throws ResourceException {

        // verify user has access to this member
        MemberIdValidationUtil.validateMemberClaim(memberId);

        PushNotificationRegistration pnRegistration = pNRegistrationAssembler.fromResource(resource);
        // save Push Notification Registration
        pNRegistrationService.save(pnRegistration);

        resource = pNRegistrationAssembler.toResource(pnRegistration);
        return new ResponseEntity<PushNotificationRegistrationResource>(resource, HttpStatus.OK);
    }


    @RequestMapping(value = "/apns/send", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Send Apple Push Notifications")
    public HttpEntity<PushNotificationRegistrationResource> sendAPNS(@PathVariable("contactId") String contactId) throws ResourceException {
        List<String> memberIds = memberContactService.findByContactId(contactId);
        MemberIdValidationUtil.validateMemberClaim(memberIds);

        PushNotificationRegistration pnRegistraton = pNRegistrationService.findByContactId(contactId);

        // send APNS to iOS devices
        LOGGER.debug("Send Apple Push Notifications to iOS devices");
        String userHome = System.getProperty("user.home");
        ApnsService pushService = APNS.newService()
                .withCert(userHome + "/" + PropertiesLoaderUtility.getProperty("apns.push.notification.cert.path"), PropertiesLoaderUtility.getProperty("apns.push.notification.cert.password"))
                .withSandboxDestination()
                .build();

        String payload = APNS.newPayload().alertBody(pnRegistraton.getMessageText()).badge(pnRegistraton.getBadge()).sound("default").build();
        pushService.push(pnRegistraton.getDeviceToken(), payload);

        PushNotificationRegistrationResource resource = pNRegistrationAssembler.toResource(pnRegistraton);

        return new ResponseEntity<PushNotificationRegistrationResource>(resource, HttpStatus.OK);
    }


    @RequestMapping(value = "/gcm/send", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Send Apple Push Notifications")
    public HttpEntity<PushNotificationRegistrationResource> sendGCM(
            @RequestBody PushNotificationRegistrationResource registrationResource) throws ResourceException, IOException {
        List<String> memberIds = memberContactService.findByContactId(registrationResource.getContactId());
        MemberIdValidationUtil.validateMemberClaim(memberIds);

        PushNotificationRegistration pnRegistraton = pNRegistrationService.findByContactId(registrationResource.getContactId());
        if (!pnRegistraton.getDeviceOS().equalsIgnoreCase("android"))
            throw new ResourceNotFoundException("You're not allowed to send messages through this device. Must be send from Andriod Device.");

        if (!sendGCMPushNotification(pnRegistraton))
            throw new ResourceNotFoundException("Message sending has failed. Your GCM registration found invalid");

        PushNotificationRegistrationResource resource = pNRegistrationAssembler.toResource(pnRegistraton);

        return new ResponseEntity<PushNotificationRegistrationResource>(resource, HttpStatus.OK);
    }


    /**
     * Method sends actual Push Notifications on Android Physical Device using "Google Cloud Messaging (GCM)"
     *
     * @throws IOException
     * @throws NumberFormatException
     * @ref http://javapapers.com/android/google-cloud-messaging-gcm-for-android-and-push-notifications/
     * @Ref http://myandroidpoint.blogspot.in/2013/03/android-google-cloud-messaging-server.html
     * @ref https://developers.google.com/cloud-messaging/
     */
    private Boolean sendGCMPushNotification(PushNotificationRegistration pnRegistraton) throws NumberFormatException, IOException {
        Boolean isGCMSuccess = false;

        /** Helper class to send messages to the GCM service using an API Key. */
        Sender sender = new Sender(PropertiesLoaderUtility.getProperty("gcm.push.notification.api.key"));

        /** Add devices into list */
        ArrayList<String> devicesList = new ArrayList<String>();
        devicesList.add(pnRegistraton.getRegID());

        /** Message with optional attributes and payload data Time in seconds to keep message queued if device offline.
         * 	Wait for device to become active before sending. */
        Message message = new Message.Builder().timeToLive(30).delayWhileIdle(true).addData("message", pnRegistraton.getMessageText()).build();

        /** Result of a GCM multi-cast message request */
        MulticastResult result = sender.send(message, devicesList, Integer.parseInt(PropertiesLoaderUtility.getProperty("gcm.push.notification.no.of.retries")));
        sender.send(message, devicesList, Integer.parseInt(PropertiesLoaderUtility.getProperty("gcm.push.notification.no.of.retries")));
        LOGGER.debug("GCM Response : " + result);

        /** Check if message sent successfully */
        List<Result> finalResult = result.getResults();
        for (Result actualResult : finalResult) {
            if (actualResult.getErrorCodeName() != null) {
                LOGGER.error("GCM Push Notification Failed " + actualResult.getErrorCodeName());
                isGCMSuccess = false;
            } else {
                LOGGER.debug("GCM Push Notification Sent successfully...");
                isGCMSuccess = true;
            }
        }
        return isGCMSuccess;
    }

}
