package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;


/**
 * Created by mahesh on 10/28/14.
 */

public class PasswordResource {

    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.password}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.password}")
    private String password;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.verifypassword}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.verifypassword}")
    private String verifyPassword;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVerifyPassword() {
        return verifyPassword;
    }

    public void setVerifyPassword(String verifyPassword) {
        this.verifyPassword = verifyPassword;
    }
}
