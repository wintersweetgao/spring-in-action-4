package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "medication")
public class MedicationResource extends ResourceSupport {
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime addedOn;
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.medname}")
    @Length(max = 255, message = "{length.validation.medname}")
    private String name;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.dosage}")
    @Length(max = 500, message = "{length.validation.dosage}")
    private String dosage;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.quantity}")
    @Length(max = 500, message = "{length.validation.quantity}")
    private String quantity;
    private Integer days;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.source}")
    @Length(max = 50, message = "{length.validation.source}")
    private String source;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime startDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime endDate;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.frequency}")
    @Length(max = 150, message = "{length.validation.frequency}")
    private String frequency;

    public DateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(DateTime addedOn) {
        this.addedOn = addedOn;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }


    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public Integer getDays() {
        return days;
    }

    public void setDays(Integer days) {
        this.days = days;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public DateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(DateTime endDate) {
        this.endDate = endDate;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}