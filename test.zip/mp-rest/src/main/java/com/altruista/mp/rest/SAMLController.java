package com.altruista.mp.rest;

import com.altruista.mp.model.Claim;
import com.altruista.mp.model.User;
import com.altruista.mp.rest.exceptions.TokenException;
import com.altruista.mp.restutils.TokenUtils;
import com.altruista.mp.services.UserService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.wordnik.swagger.annotations.ApiOperation;
import org.apache.commons.codec.binary.Base64;
import org.joda.time.DateTime;
import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.*;
import org.opensaml.saml2.encryption.Decrypter;
import org.opensaml.security.SAMLSignatureProfileValidator;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallerFactory;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.security.SecurityHelper;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.keyinfo.KeyInfoCredentialResolver;
import org.opensaml.xml.security.keyinfo.StaticKeyInfoCredentialResolver;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.SignatureValidator;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import javax.crypto.SecretKey;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.DataFormatException;


/**
 * Created by mwixson and Prateek on 6/15/15.
 */
@Controller
public class SAMLController {
    private static final Logger LOGGER = LoggerFactory.getLogger(SAMLController.class);
    @Autowired
    private UserService userService;
    @Autowired
    private SAMLHandler samlHandler;
    @Value("${saml.callback.url}")
	private String samlCallbackUrl;
    @Value("${error.callback.url}")
	private String samlErrorUrl;
    @Value("${jks.file.location}")
    private String jksFile;
    @Value("${jks.password}")
    private String jksPassword;
    @Value("${decryption.alias.name}")
    private String decryptionAliasName;
    @Value("${signing.alias.name}")
    private String signingAliasName;


    @RequestMapping(value = "/sso", method = RequestMethod.POST)
    @ApiOperation(value = "Handle IDP Initiated SAML 2.0 POST")
    public ModelAndView handleSAMLPost(@RequestParam("SAMLResponse") String assertion, @RequestParam("RelayState") String relayState)
            throws ServiceException, ConfigurationException, ParserConfigurationException, SAXException, IOException,
            UnmarshallingException, DataFormatException, TokenException, ValidationException {
        LOGGER.debug("SAML RESPONSE: " + assertion);

        /** read the <SAMLResponse> 2.0 using OpenSAML library */
        Response response = buildResponseFromString(assertion);

        //		List<Assertion> samlAssertions = new ArrayList<Assertion>();

        Assertion samlAssertion = null;
        for (EncryptedAssertion encrypted : response.getEncryptedAssertions()) {
            if (encrypted != null) {
                /** reading the encrypted Assertion. This Response has only one Assertion */
                Credential credential = getCredential(decryptionAliasName, true);

                EncryptedAssertion encryptedAssertion = response.getEncryptedAssertions().get(0);
                try {
                    samlAssertion = decrypt(encryptedAssertion, credential);
                } catch (DecryptionException e) {
                    LOGGER.error("Unable to decrypt assertion: " + e);
                    throw new ServiceException("Unable to decrypt assertion.");
                }
            } else {
                /** reading the Assertion. This Response has only one Assertion */
                samlAssertion = response.getAssertions().get(0);
            }
        }

        //check if assertion is expired
        checkIfAssertionExpired(samlAssertion);

        // add clear assertions
        //		for (Assertion clearAssertion : response.getAssertions()) {
        //			samlAssertions.add(clearAssertion);
        //		}


        /** Reading the issuer (Issuer is the IDP who issued the Response object) */
        String issuer = samlAssertion.getIssuer().getValue();

        /** Reading the audience (To whom the Response was issued)*/
        String audience = samlAssertion.getConditions().getAudienceRestrictions().get(0).getAudiences().get(0).getAudienceURI();

        /** You can read other parts of the Response message other than the Assertion. Reading the status */
        String statusCode = response.getStatus().getStatusCode().getValue();
        LOGGER.debug("ISSUER :  [" + issuer + "]");
        LOGGER.debug("AUDIENCE : [" + audience + "]");
        LOGGER.debug("STATUS_CODE [: " + statusCode + "]");

        String prefix = response.getElementQName().getPrefix();
        String namespaceURI = response.getElementQName().getNamespaceURI();
        LOGGER.debug("SAML Prefix : [" + prefix + "], NamespaceURI : [" + namespaceURI + "]");

        /** Reading the Subject name (Subject is what was authenticated at the IDP) */
        String nameId = samlAssertion.getSubject().getNameID().getValue();
        LOGGER.debug("NAME_ID  : " + nameId);

        /** validate the credentials here */
        Credential credential = getCredential(signingAliasName, false);

        /** validating the signature only if signature has values coming
         * validate() is void method does not return anything */
        if (response.getSignature() != null) {
            SAMLSignatureProfileValidator profileValidator = new SAMLSignatureProfileValidator();
            try {
                profileValidator.validate(response.getSignature());
                SignatureValidator sigValidator = new SignatureValidator(credential);
                sigValidator.validate(response.getSignature());
                LOGGER.debug("Signature validated with key from supplied credential");
            } catch (ValidationException e) {
                LOGGER.error("Unable to validate signature: " + e);
            }
        }

        // Read the claims from the Attributes and ChildAttributes
        List<Claim> claims = getClaims(samlAssertion);
        // Lookup user details
        User user = samlHandler.lookupUser(claims);
        // Lookup widget name
        String widgetName = samlHandler.lookupWidgetName(claims, relayState);
        // Lookup Mode
        String mode = samlHandler.lookupMode(claims);

        String token = null;
        DateTime now = DateTime.now();

        if (user != null) {
            user.setUserLocked(false);
            user.setFailedAccessAttempts(0);
            if (user.getAccessedOn() != null)
                user.setPriorAccessedOn(user.getAccessedOn());
            else
                user.setPriorAccessedOn(now);
            user.setAccessedOn(now);
            user.setSsoEnabled(true);
            userService.save(user);

            /** return the token in a redirect */
            token = TokenUtils.createToken(user, false);
        } else {
            return new ModelAndView("redirect:" + samlErrorUrl + token);
        }

        StringBuilder sb = new StringBuilder();
        sb.append(token);
        
        if(widgetName != null && !widgetName.equals("null") && widgetName.length() > 0)
        	sb.append("&").append(widgetName);
        
        if(mode != null && !mode.equals("null") && mode.length() > 0)
        	sb.append("&").append(mode);

        return new ModelAndView("redirect:" +samlCallbackUrl+ getEncodedTokenString(sb.toString()));
    }

    public String getEncodedTokenRelayString(String token, String widgetName) {
        String hash = String.format("%s&%s", token, widgetName);
        byte[] base64hash = Base64.encodeBase64(hash.getBytes());
        return new String(base64hash);
    }

    public String getEncodedTokenString(String token) {
        String hash = String.format("%s", token);
        byte[] base64hash = Base64.encodeBase64(hash.getBytes());
        return new String(base64hash);
    }


    /**
     * Get the date/time before which the assertion is invalid.
     * Gets the date/time on, or after, which the assertion is invalid.
     *
     * @param assertion
     * @throws ValidationException
     */
    private void checkIfAssertionExpired(Assertion assertion) throws ValidationException {
        if (assertion.getConditions().getNotBefore() != null && assertion.getConditions().getNotBefore().isAfterNow()) {
            LOGGER.warn("Condition states that assertion is not yet valid");
            throw new ValidationException("Condition states that assertion is not yet valid");
        }

        if (assertion.getConditions().getNotOnOrAfter() != null
                && (assertion.getConditions().getNotOnOrAfter().isBeforeNow() || assertion.getConditions().getNotOnOrAfter().isEqualNow())) {
            LOGGER.warn("Condition states that assertion is no longer valid");
            throw new ValidationException("Condition states that assertion is no longer valid");
        }
    }


    /**
     * Decrypt the specified EncryptedAssertion.
     *
     * @param assertion the EncryptedAssertion to decrypt
     * @return an Assertion
     * @throws DecryptionException thrown when decryption generates an error
     *                             Ref:  http://braindump.dk/tech/2008/05/14/opensaml-and-xml-encryption/
     */
    public Assertion decrypt(EncryptedAssertion assertion, Credential credential) throws DecryptionException {
        KeyInfoCredentialResolver keyResolver = new StaticKeyInfoCredentialResolver(credential);

        /** XMLObject representing XML Encryption,EncryptedKey element. */
        org.opensaml.xml.encryption.EncryptedKey key = assertion.getEncryptedData().getKeyInfo().getEncryptedKeys().get(0);

        /** Class which implements SAML2-specific options for EncryptedElementType objects. */
        Decrypter decrypter = new Decrypter(null, keyResolver, null);
        try {
            SecretKey dkey = (SecretKey) decrypter.decryptKey(key, assertion.getEncryptedData().getEncryptionMethod().getAlgorithm());
            Credential shared = SecurityHelper.getSimpleCredential(dkey);
            decrypter = new Decrypter(new StaticKeyInfoCredentialResolver(shared), null, null);
        } catch (DecryptionException e) {
            LOGGER.error("Unable to decrypt assertion: " + e);
        }
        return decrypter.decrypt(assertion);
    }


    /**
     * Read A SAML 2.0 Response With OpenSAML library
     * Ref: http://sureshatt.blogspot.in/2012/11/how-to-read-saml-20-response-with.html
     */
    private Response buildResponseFromString(String assertion) throws ConfigurationException, ParserConfigurationException,
            SAXException, IOException, UnmarshallingException {

        /** Base64 Decode the response */
        Base64 decoder = new Base64();
        byte[] base64DecodedResponse = decoder.decode(assertion);
        ByteArrayInputStream is = new ByteArrayInputStream(base64DecodedResponse);

        /** This class can be used to bootstrap the OpenSAML library with the default configurations
         that ship with the library. */
        DefaultBootstrap.bootstrap();

        /** Unmarshalling the response, First we need to create a DOM Element object out of the response string.*/
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        documentBuilderFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = documentBuilderFactory.newDocumentBuilder();

        Document document = docBuilder.parse(is);
        Element element = document.getDocumentElement();

        /** Now lets unmarshall the element. */
        UnmarshallerFactory unmarshallerFactory = Configuration.getUnmarshallerFactory();
        Unmarshaller unmarshaller = unmarshallerFactory.getUnmarshaller(element);
        XMLObject responseXmlObj = unmarshaller.unmarshall(element);

        /** Casting the response to the SAML 2.0 Response message. */
        Response response = (Response) responseXmlObj;
        return response;
    }


    /*
     * Validate the Credentials from the .jks file
     */
    private Credential getCredential(String alias, boolean hasPrivateKey) {
        BasicX509Credential credential = new BasicX509Credential();
        try {
            String userHome = System.getProperty("user.home");

            String jksFileLocation;
            if (jksFile.charAt(0) == '/') {
                jksFileLocation = jksFile;
            } else {
                jksFileLocation = new StringBuffer(userHome).append("/").append(jksFile).toString();
            }
            char[] password = jksPassword.toCharArray();

            /** read the signing cert file */
            FileInputStream fileInputStream = new FileInputStream(jksFileLocation);
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType()); //JKS
            keyStore.load(fileInputStream, password);

            fileInputStream.close();

            X509Certificate certificate = (X509Certificate) keyStore.getCertificate(alias);
            credential.setEntityCertificate(certificate);
            PublicKey publicKey = certificate.getPublicKey();
            credential.setPublicKey(publicKey);

            if (hasPrivateKey) {
                /** A KeyStore entry that holds a PrivateKey and corresponding certificate chain.
                 * Ref: http://codereview.stackexchange.com/questions/59169/single-sign-on-saml-response-generation*/
                KeyStore.PrivateKeyEntry pkEntry =
                        (KeyStore.PrivateKeyEntry) keyStore.getEntry(alias, new KeyStore.PasswordProtection(password));
                PrivateKey privKey = pkEntry.getPrivateKey();

                /** A basic implementation of X509Credential. */
                BasicX509Credential signingCredential = new BasicX509Credential();
                signingCredential.setPrivateKey(privKey);
                credential.setPrivateKey(privKey);
            }

        } catch (KeyStoreException kse) {
            LOGGER.error("Exception while loading credential: " + kse);
        } catch (FileNotFoundException fnfe) {
            LOGGER.error("Exception while loading credential: " + fnfe);
        } catch (CertificateException ce) {
            LOGGER.error("Exception while loading credential: " + ce);
        } catch (NoSuchAlgorithmException nsae) {
            LOGGER.error("Exception while loading credential: " + nsae);
        } catch (IOException ioe) {
            LOGGER.error("Exception while loading credential: " + ioe);
        } catch (UnrecoverableEntryException e) {
            LOGGER.error("Exception while loading credential: " + e);
        }
        return credential;
    }


    private static String getValueFrom(List<XMLObject> attributeValues) {
        StringBuffer buffer = new StringBuffer();
        for (XMLObject value : attributeValues) {
            if (buffer.length() > 0)
                buffer.append(',');
            buffer.append(value.getDOM().getTextContent());
        }
        return buffer.toString();
    }

    /**
     * Read the claims from the Attributes and ChildAttributes
     */
    private static List<Claim> getClaims(Assertion samlAssertion) {
        List<Claim> claimList = new ArrayList<Claim>();

        List<AttributeStatement> attributeStmts = samlAssertion.getAttributeStatements();

        for (AttributeStatement attributeStmt : attributeStmts) {
            List<Attribute> attributes = attributeStmt.getAttributes();
            for (Attribute attribute : attributes) {
                String claimType = attribute.getName();
                String claimValue = getValueFrom(attribute.getAttributeValues());

                LOGGER.debug("=== Claim Type: [" + claimType + "], Claim Value : [" + claimValue + "]====");
                claimList.add(new Claim(claimType, claimValue));
            }
        }
        return claimList;
    }
}