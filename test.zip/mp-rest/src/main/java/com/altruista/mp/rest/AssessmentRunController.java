package com.altruista.mp.rest;

import com.altruista.mp.model.AssessmentResponse;
import com.altruista.mp.model.AssessmentRun;
import com.altruista.mp.resources.*;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.AssessmentResponseService;
import com.altruista.mp.services.AssessmentRunService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

/*
 * Developed by Prateek on 03/18/15
 */
@Controller
@Api(value = "Assessment Run service", description = "Manage Assessment Runs")
public class AssessmentRunController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentRunController.class);

    private final AssessmentRunService runService;
    private final AssessmentRunResourceAssembler runAssembler;
    private final AssessmentResponseResourceAssembler responseAssembler;
    private final AssessmentResponseService responseService;


    @Autowired
    public AssessmentRunController(AssessmentRunService runService, AssessmentResponseService responseService) {
        this.runService = runService;
        this.responseService = responseService;
        runAssembler = new AssessmentRunResourceAssembler();
        responseAssembler = new AssessmentResponseResourceAssembler();
    }

    @ApiOperation(value = "Gets the Assessment Run by member id")
    @RequestMapping(value = "/api/member/{memberId}/assessmentRun", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<AssessmentRunResource>> getAssessmentRunByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<AssessmentRunResource> resourceList = runAssembler.toResources(runService.findByMemberId(memberId));
        return new ResponseEntity<List<AssessmentRunResource>>(resourceList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/api/assessmentRun/{runId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the Assessment Run using run id")
    public HttpEntity<AssessmentRunResource> getAssessmentRun(@PathVariable("runId") String runId) throws ResourceException {
        AssessmentRun run = runService.get(runId);
        if (run == null)
            throw new ResourceNotFoundException("Assessment Run not found.");

        MemberIdValidationUtil.validateMemberClaim(run.getMemberId());

        AssessmentRunResource resource = runAssembler.toResource(run);

        return new ResponseEntity<AssessmentRunResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/assessmentRun/{runId}", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves Assessment Run")
    public HttpEntity<AssessmentRunResource> saveAssessmentRun(@PathVariable("runId") String runId, @RequestBody AssessmentRunResource resource)
            throws ResourceException {

        AssessmentRun original = runService.get(runId);
        if (original == null)
            throw new ResourceNotFoundException("Assessment Run not found.");

        // verify user has access to this run
        MemberIdValidationUtil.validateMemberClaim(original.getMemberId());

        // overwrite run information with updated resource information
        AssessmentRun updated = runAssembler.fromResource(resource, original);

        // save the updated run
        updated.setMemberId(original.getMemberId());
        runService.save(updated);

        return new ResponseEntity<AssessmentRunResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(value = "/api/assessmentRun/{runId}/status", method = RequestMethod.PUT, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Saves Assessment Run status")
    public HttpEntity<AssessmentRunResource> saveAssessmentRunStatus(@PathVariable("runId") String runId, @RequestBody AssessmentRunStatusResource status)
            throws ResourceException {

        // verify user has access to this run
        AssessmentRun run = runService.get(runId);
        if (run == null)
            throw new ResourceNotFoundException("Assessment Run not found.");

        MemberIdValidationUtil.validateMemberClaim(run.getMemberId());

        // update run status information
        run.setLastSequence(status.getLastSequence());
        run.setEndedOn(status.getEndedOn());
        run.setStatus(status.getStatus());
        run.setCareNotes(status.getNotes());
        runService.save(run);

        AssessmentRunResource resource = runAssembler.toResource(run);
        return new ResponseEntity<AssessmentRunResource>(resource, HttpStatus.OK);
    }

    @ApiOperation(value = "Creates an Assessment Run")
    @RequestMapping(value = "/api/assessmentRun/{memberId}", method = RequestMethod.POST)
    public
    @ResponseBody
    HttpEntity<AssessmentRunResource> createAssessmentRun(@PathVariable String memberId, @RequestBody AssessmentRunResource resource)
            throws ParseException, ServiceException, ResourceException {

        // verify user has access to this member
        MemberIdValidationUtil.validateMemberClaim(memberId);

        // create a new assessment run and save it
        AssessmentRun run = runAssembler.fromResource(resource);
        run.setMemberId(memberId);
        runService.save(run);
        resource = runAssembler.toResource(run);
        return new ResponseEntity<AssessmentRunResource>(resource, HttpStatus.OK);
    }

    @ApiOperation(value = "Gets the Assessment Responses for an Assessment Run")
    @RequestMapping(value = "/api/assessmentRun/{runId}/assessmentResponse", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<AssessmentResponseResource>> getAssessmentResponseByRunId(@PathVariable String runId) throws ResourceException {

        // verify user has access to this run
        AssessmentRun run = runService.get(runId);
        MemberIdValidationUtil.validateMemberClaim(run.getMemberId());

        List<AssessmentResponseResource> resourceList = responseAssembler.toResources(responseService.findByRunId(runId));
        return new ResponseEntity<List<AssessmentResponseResource>>(resourceList,
                HttpStatus.OK);
    }

    @ApiOperation(value = "Gets the specified Assessment Response for an Assessment Run")
    @RequestMapping(value = "/api/assessmentRun/{runId}/assessmentResponse/{sequenceId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<AssessmentResponseResource> getAssessmentResponseByRunIdAndSequence(@PathVariable("runId") String runId, @PathVariable("sequenceId") String sequence) throws ResourceException {

        AssessmentRun run = runService.get(runId);
        if (run == null)
            throw new ResourceNotFoundException("Assessment Run not found.");

        AssessmentResponse response = responseService.findOneByRunIdAndQuestionSequence(runId, Integer.parseInt(sequence));
        if (response == null)
            return new ResponseEntity(HttpStatus.NO_CONTENT);

        // verify user has access to this run
        MemberIdValidationUtil.validateMemberClaim(run.getMemberId());

        AssessmentResponseResource resourceList = responseAssembler.toResource(response);
        return new ResponseEntity<AssessmentResponseResource>(resourceList, HttpStatus.OK);
    }

    @ApiOperation(value = "Creates an Assessment Response")
    @RequestMapping(value = "/api/assessmentRun/{runId}/assessmentResponse", method = RequestMethod.POST)
    public
    @ResponseBody
    HttpEntity<AssessmentResponseResource> createAssessmentResponse(@PathVariable String runId, @RequestBody AssessmentResponseResource resource)
            throws ParseException, ServiceException, ResourceException {

        // verify user has access to this member's assessmentRun
        AssessmentRun original = runService.get(runId);
        MemberIdValidationUtil.validateMemberClaim(original.getMemberId());

        AssessmentResponse response = responseAssembler.fromResource(resource);
        response.setRunId(runId);
        responseService.save(response);
        resource = responseAssembler.toResource(response);

        return new ResponseEntity<AssessmentResponseResource>(resource, HttpStatus.OK);
    }
}