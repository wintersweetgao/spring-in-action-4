package com.altruista.mp.resources;

import com.altruista.mp.model.AssessmentQuestion;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

/**
 * Created by mwixson on 2/17/15.
 */
public class AssessmentResource extends ResourceSupport {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.assessment.name}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessment.name}")
    private String name;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.assessment.careActivityTypeName}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessment.careActivityTypeName}")
    private String careActivityTypeName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.assessment.runTypeName}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.assessment.runTypeName}")
    private String runTypeName;
    private Long duration;
    private Float score;
    private Integer numOfQuestions;
    private boolean isActive;
    private List<AssessmentQuestion> questions;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCareActivityTypeName() {
        return careActivityTypeName;
    }

    public void setCareActivityTypeName(String careActivityTypeName) {
        this.careActivityTypeName = careActivityTypeName;
    }

    public String getRunTypeName() {
        return runTypeName;
    }

    public void setRunTypeName(String runTypeName) {
        this.runTypeName = runTypeName;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public Float getScore() {
        return score;
    }

    public void setScore(Float score) {
        this.score = score;
    }

    public Integer getNumOfQuestions() {
        return numOfQuestions;
    }

    public void setNumOfQuestions(Integer numOfQuestions) {
        this.numOfQuestions = numOfQuestions;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public List<AssessmentQuestion> getQuestions() {
        return questions;
    }

    public void setQuestions(List<AssessmentQuestion> questions) {
        this.questions = questions;
    }
}
