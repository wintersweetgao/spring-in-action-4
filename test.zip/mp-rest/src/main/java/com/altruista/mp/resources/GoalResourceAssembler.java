package com.altruista.mp.resources;

import com.altruista.mp.model.Goal;
import com.altruista.mp.rest.GoalController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class GoalResourceAssembler extends
        ResourceAssemblerSupport<Goal, GoalResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(GoalResourceAssembler.class);

    public GoalResourceAssembler() {
        super(GoalController.class, GoalResource.class);
    }

    @Override
    public GoalResource toResource(Goal item) {
        GoalResource resource = instantiateResource(item);
        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(GoalController.class).getGoal(item.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }

        return resource;
    }

    @Override
    protected GoalResource instantiateResource(Goal entity) {
        GoalResource resource = new GoalResource();

        resource.setGoal(entity.getGoal());
        resource.setStatus(entity.getStatus());
        resource.setNotes(entity.getNotes());

        return resource;
    }

    public Goal fromResource(String id, GoalResource resource) {

        Goal goal = new Goal();

        // copy properties from memberResource to member
        goal.setId(id);
        goal.setGoal(resource.getGoal());
        goal.setStatus(resource.getStatus());
        goal.setNotes(resource.getNotes());

        return goal;
    }
}
