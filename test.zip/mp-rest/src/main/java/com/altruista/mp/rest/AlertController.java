package com.altruista.mp.rest;

import com.altruista.mp.model.Alert;
import com.altruista.mp.model.User;
import com.altruista.mp.resources.AlertResource;
import com.altruista.mp.resources.AlertResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.AlertService;
import com.altruista.mp.services.EnrollmentService;
import com.altruista.mp.services.UserService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.Principal;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

/**
 * Handles requests for alerts
 */
@Controller
@Api(value = "Alert service", description = "Manage Alerts")
public class AlertController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertController.class);

    private final AlertService alertService;
    private AlertResourceAssembler alertAssembler;
    @Autowired
    public EnrollmentService enrollmentService;
    @Autowired
    private ApplicationResourceService appResourceService;

    @Autowired
    public AlertController(AlertService alertService, UserService userService) {
        this.alertService = alertService;
        this.alertAssembler = new AlertResourceAssembler();
    }

    @ApiOperation(value = "Gets the Alerts")
    @RequestMapping(value = "/api/member/{memberId}/alert", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<AlertResource>> getAlertsByMemberId(@PathVariable String memberId, Principal principal) throws ResourceException, ServiceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);

        SecurityContext context = SecurityContextHolder.getContext();
        Authentication authentication = context.getAuthentication();
        //User user = (User) authentication.getPrincipal();
        User user = (User) ((Authentication) principal).getPrincipal();
        List<AlertResource> resourceList = alertAssembler.toResources(findByMemberIdAndCreatedOn(memberId, authentication.getAuthorities(), user.getPriorAccessedOn()));
        return new ResponseEntity<>(resourceList, HttpStatus.OK);
    }

    public List<Alert> findByMemberIdAndCreatedOn(String memberId, Collection<? extends GrantedAuthority> authorities, DateTime priorAccessedOn) throws ServiceException {

        // Add alerts related to data changes
        // NOTE: Used to use user.getPriorAccessedOn()
        //DateTime startOfToday = new DateTime().withTimeAtStartOfDay();
        List<Alert> alerts = alertService.findByMemberIdAndCreatedOn(memberId, authorities, priorAccessedOn);

        // Translate alerts to local
        Locale locale = LocaleContextHolder.getLocale();
        for (Alert alert : alerts) {
            if (alert.getMessageCode() != null && !alert.getMessageCode().isEmpty())
                alert.setMessage(appResourceService.messageResource(alert.getMessageCode(), locale));

            if (alert.getUrlMessageCode() != null && !alert.getUrlMessageCode().isEmpty())
                alert.setUrlMessage(appResourceService.messageResource(alert.getUrlMessageCode(), locale));

            // add URL to the description if provided
            if (alert.getUrl() != null && !alert.getUrl().isEmpty()) {
                try {
                    String encodedUrl = URLEncoder.encode(alert.getUrl(), "UTF-8");
                    alert.setUrl(encodedUrl);
                } catch (UnsupportedEncodingException e) {
                    LOGGER.error("Unable to encode alert URL: " + e);
                }
            }
        }

        return alerts;
    }
}