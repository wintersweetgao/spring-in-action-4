package com.altruista.mp.resources;

import com.altruista.mp.model.ContactType;
import com.altruista.mp.model.Tile;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.SafeHtml;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Map;

/**
 * Created by mwixson on 7/29/14.
 */
@XmlRootElement(name = "user")
public class UserResource extends ResourceSupport {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.username}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.username}")
    private String username;
    @NotBlank
    private ContactType contactType;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String contactId;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.usersalutation}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.usersalutation}")
    private String salutation;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.userfirstname}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.userfirstname}")
    private String firstName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.usermiddlename}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.usermiddlename}")
    private String middleName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.userlastname}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.userlastname}")
    private String lastName;
    private Map<String, Boolean> roles;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String selectedMemberId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime accessedOn;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime priorAccessedOn;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.userphotodata}")
    @Length(max = ResourceSize.MAX_PHOTO, message = "{length.validation.userphotodata}")
    private String photoData;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.usertimezone}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.usertimezone}")
    private String timezone;
    private List<Tile> tiles;
    private boolean ssoEnabled;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public ContactType getContactType() {
        return contactType;
    }

    public void setContactType(ContactType contactType) {
        this.contactType = contactType;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public Map<String, Boolean> getRoles() {
        return roles;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setRoles(Map<String, Boolean> roles) {
        this.roles = roles;
    }

    public String getSelectedMemberId() {
        return selectedMemberId;
    }

    public void setSelectedMemberId(String selectedMemberId) {
        this.selectedMemberId = selectedMemberId;
    }

    public DateTime getAccessedOn() {
        return accessedOn;
    }

    public void setAccessedOn(DateTime accessedOn) {
        this.accessedOn = accessedOn;
    }

    public DateTime getPriorAccessedOn() {
        return priorAccessedOn;
    }

    public void setPriorAccessedOn(DateTime priorAccessedOn) {
        this.priorAccessedOn = priorAccessedOn;
    }

    public String getPhotoData() {
        return photoData;
    }

    public void setPhotoData(String photoData) {
        this.photoData = photoData;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public List<Tile> getTiles() {
        return tiles;
    }

    public void setTiles(List<Tile> tiles) {
        this.tiles = tiles;
    }

    public boolean isSsoEnabled() {
        return ssoEnabled;
    }

    public void setSsoEnabled(boolean ssoEnabled) {
        this.ssoEnabled = ssoEnabled;
    }
}