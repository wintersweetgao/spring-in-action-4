package com.altruista.mp.resources;


@SuppressWarnings("serial")
public class LockedUserException extends RuntimeException {
    private final transient String errorMessage;

    public LockedUserException(String message) {
        super(message);
        this.errorMessage = message;
    }

    public String getErrors() {
        return errorMessage;
    }

}
