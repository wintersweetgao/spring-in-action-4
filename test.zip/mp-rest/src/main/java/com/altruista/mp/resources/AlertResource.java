package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "alert")
public class AlertResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.description}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.description}")
    private String message;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.description}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.description}")
    private String urlMessage;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.description}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.description}")
    private String url;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.source}")
    @Length(max = ResourceSize.MAX_SOURCE, message = "{length.validation.source}")
    private String source;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.count}")
    private Integer count;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUrlMessage() {
        return urlMessage;
    }

    public void setUrlMessage(String urlMessage) {
        this.urlMessage = urlMessage;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
