package com.altruista.mp.resources;

import com.altruista.mp.model.TrackerParameter;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "tracker")
public class TrackerResource extends ResourceSupport {
    private String name;
    private String trackerId;
    private String categoryId;
    private List<TrackerParameter> parameters;

    public String getTrackerId() {
        return trackerId;
    }

    public void setTrackerId(String trackerId) {
        this.trackerId = trackerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public List<TrackerParameter> getParameters() {
        return parameters;
    }

    public void setParameters(List<TrackerParameter> parameters) {
        this.parameters = parameters;
    }


}
