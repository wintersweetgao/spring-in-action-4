package com.altruista.mp.rest.exceptions;

/**
 * Created by mwixson on 10/2/14.
 */
public class TokenException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 4315135746501279205L;

    public TokenException(String message) {
        super(message);
    }
}

