package com.altruista.mp.rest;

import com.altruista.mp.model.User;
import com.altruista.mp.resources.ErrorResource;
import com.altruista.mp.services.UserService;
import com.altruista.mp.services.exceptions.ServiceException;
import com.altruista.mp.utils.PropertiesLoaderUtility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * {@link org.springframework.security.web.AuthenticationEntryPoint} that rejects all requests with an unauthorized error message.
 *
 * @author Philip W. Sorst <philip@sorst.net>
 */
public class UnauthorizedEntryPoint implements AuthenticationEntryPoint {
    private static final Logger LOGGER = LoggerFactory.getLogger(UnauthorizedEntryPoint.class);

    @Autowired
    private UserService userService;

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
            throws IOException, ServletException {
        String username = request.getParameter("username");
        String maxFailedAllowedAttempt = PropertiesLoaderUtility.getProperty("user.allowed.failed.login.attempts");
        try {
            User user = userService.getUserByUsername(username);
            if (user != null) {
                int failedAccessAttemptsCounter = user.getFailedAccessAttempts();
                int tempCounter = failedAccessAttemptsCounter + 1;
                if (tempCounter >= Integer.parseInt(maxFailedAllowedAttempt))
                    user.setUserLocked(true);
                user.setLastFailedAccessOn(DateTime.now());
                user.setFailedAccessAttempts(tempCounter);
                /*user.setUserLocked(false);
                user.setFailedAccessAttempts(0);*/
                userService.save(user);
            }
        } catch (ServiceException e) {
            LOGGER.warn("Exception during authentication: " + e);
        }

        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON.getType());

        ErrorResource error = new ErrorResource("InvalidToken", "Your session has expired.  Please login again.");
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL); // no more null-valued properties
        mapper.writeValue(response.getWriter(), error);
    }
}