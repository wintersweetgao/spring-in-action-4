package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 10/16/14.
 */
@XmlRootElement(name = "communicationImpairment")
public class CommunicationImpairmentResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.name}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.name}")
    private String name;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
