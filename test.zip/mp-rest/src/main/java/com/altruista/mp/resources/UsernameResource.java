package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;

/**
 * Created by mwixson on 11/4/14.
 */
public class UsernameResource {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.username}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.username}")
    private String username;

    public UsernameResource(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
