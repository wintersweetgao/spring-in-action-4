package com.altruista.mp.rest;

import com.altruista.mp.model.Claim;
import com.altruista.mp.model.User;

import java.util.List;

public interface SAMLHandler {
    User lookupUser(List<Claim> claims);

    String lookupWidgetName(List<Claim> claims, String relayState);
    String lookupMode(List<Claim> claims);
}
