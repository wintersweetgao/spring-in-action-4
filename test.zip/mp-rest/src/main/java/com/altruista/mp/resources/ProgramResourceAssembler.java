package com.altruista.mp.resources;

import com.altruista.mp.model.Program;
import com.altruista.mp.rest.ProgramController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class ProgramResourceAssembler extends
        ResourceAssemblerSupport<Program, ProgramResource> {

    public ProgramResourceAssembler() {
        super(ProgramController.class, ProgramResource.class);
    }

    @Override
    public ProgramResource toResource(Program program) {
        return createResourceWithId(program.getId(), program);
    }

    @Override
    protected ProgramResource instantiateResource(Program entity) {
        return new ProgramResource(
                entity.getMemberId(),
                entity.isPrimary(),
                entity.getName());
    }

}
