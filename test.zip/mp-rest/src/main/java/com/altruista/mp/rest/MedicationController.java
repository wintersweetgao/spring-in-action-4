package com.altruista.mp.rest;

import com.altruista.mp.resources.MedicationResource;
import com.altruista.mp.resources.MedicationResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.MedicationService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for alerts
 */
@Controller
@RequestMapping("/api/medication")
@Api(value = "Medication service", description = "Manage Medications")
public class MedicationController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MedicationController.class);

    private final MedicationService medicationService;
    private MedicationResourceAssembler medicationAssembler;

    @Autowired
    public MedicationController(MedicationService medicationService) {
        this.medicationService = medicationService;
        medicationAssembler = new MedicationResourceAssembler();
    }

    @ApiOperation(value = "Gets medications using Member id")
    @RequestMapping(value = "/{memberId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<MedicationResource>> getMedicationsByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<MedicationResource> resourceList = medicationAssembler.toResources(medicationService.findByMemberId(memberId));
        return new ResponseEntity<List<MedicationResource>>(resourceList,
                HttpStatus.OK);
    }

}