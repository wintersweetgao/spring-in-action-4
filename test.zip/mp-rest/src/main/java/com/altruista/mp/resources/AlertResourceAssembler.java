package com.altruista.mp.resources;

import com.altruista.mp.model.Alert;
import com.altruista.mp.rest.AlertController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class AlertResourceAssembler extends
        ResourceAssemblerSupport<Alert, AlertResource> {

    public AlertResourceAssembler() {
        super(AlertController.class, AlertResource.class);
    }

    @Override
    public AlertResource toResource(Alert alert) {
        return instantiateResource(alert);
    }

    @Override
    protected AlertResource instantiateResource(Alert entity) {
        AlertResource resource = new AlertResource();
        resource.setMemberId(entity.getMemberId());
        resource.setSource(entity.getSource());
        resource.setMessage(entity.getMessage());
        resource.setUrlMessage(entity.getUrlMessage());
        resource.setUrl(entity.getUrl());
        resource.setCount(entity.getCount());

        return resource;
    }

}
