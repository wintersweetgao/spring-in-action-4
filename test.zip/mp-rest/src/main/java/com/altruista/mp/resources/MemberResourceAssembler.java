package com.altruista.mp.resources;

import com.altruista.mp.model.Member;
import com.altruista.mp.rest.MemberController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class MemberResourceAssembler extends ResourceAssemblerSupport<Member, MemberResource> {

    public MemberResourceAssembler() {
        super(MemberController.class, MemberResource.class);
    }

    @Override
    public MemberResource toResource(Member member) {

        MemberResource resource = createResourceWithId(member.getId(), member);

        // copy properties from member to memberResource
        resource.setContactId(member.getContactId());
        resource.setPrimaryMedicalProvider(member.getPrimaryMedicalProvider());
        resource.setPrimaryMedicalCondition(member.getPrimaryMedicalCondition());
        resource.setPrimaryBehavioralProvider(member.getPrimaryBehavioralProvider());
        resource.setPrimaryBehavioralCondition(member.getPrimaryBehavioralCondition());
        resource.setCareManager(member.getCareManager());
        resource.setRiskScore(member.getRiskScore());
        resource.setRiskLevel(member.getRiskLevel());
        resource.setWeight(member.getWeight());
        resource.setWeightUnits(member.getWeightUnits());
        resource.setHeight(member.getHeight());
        resource.setHeightUnits(member.getHeightUnits());

        return resource;
    }

    public Member fromResource(MemberResource resource, Member member) {

        if (member == null)
            member = new Member();

        // copy properties from memberResource to member
        //member.setContactId(resource.getContactId());
        member.setPrimaryMedicalProvider(resource.getPrimaryMedicalProvider());
        member.setPrimaryBehavioralProvider(resource.getPrimaryBehavioralProvider());
        member.setCareManager(resource.getCareManager());
        member.setRiskScore(resource.getRiskScore());
        member.setRiskLevel(resource.getRiskLevel());
        member.setWeight(resource.getWeight());
        member.setWeightUnits(resource.getWeightUnits());
        member.setHeight(resource.getHeight());
        member.setHeightUnits(resource.getHeightUnits());

        return member;
    }
}