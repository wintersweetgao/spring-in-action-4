package com.altruista.mp.resources;

/**
 * Created by mwixson on 11/8/14.
 */
public final class ResourceSize {
    public static final int MAX_ID = 100;
    public static final int MAX_STATUS = 500;
    public static final int MAX_STRING = 4000;
    public static final int MAX_SHORT_STRING = 100;
    public static final int MAX_SOURCE = 100;
    public static final int MAX_DATE = 10;      // YYYY-MM-DD
    public static final int MAX_KEY = 10;
    public static final int MAX_PHOTO = 4000;
}
