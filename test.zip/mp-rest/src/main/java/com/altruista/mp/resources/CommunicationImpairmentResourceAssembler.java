package com.altruista.mp.resources;

import com.altruista.mp.model.CommunicationImpairment;
import com.altruista.mp.rest.CommunicationImpairmentController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class CommunicationImpairmentResourceAssembler extends
        ResourceAssemblerSupport<CommunicationImpairment, CommunicationImpairmentResource> {

    public CommunicationImpairmentResourceAssembler() {
        super(CommunicationImpairmentController.class, CommunicationImpairmentResource.class);
    }

    @Override
    public CommunicationImpairmentResource toResource(CommunicationImpairment program) {
        return createResourceWithId(program.getId(), program);
    }

    @Override
    protected CommunicationImpairmentResource instantiateResource(CommunicationImpairment entity) {
        CommunicationImpairmentResource resource = new CommunicationImpairmentResource();

        resource.setMemberId(entity.getMemberId());
        resource.setName(entity.getName());

        return resource;
    }

}
