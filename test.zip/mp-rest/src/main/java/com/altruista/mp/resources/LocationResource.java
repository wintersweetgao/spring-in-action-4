package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;

/**
 * Created by mwixson on 11/12/14.
 */
public class LocationResource {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.location}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.location}")
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
