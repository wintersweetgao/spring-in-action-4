package com.altruista.mp.resources;

import com.altruista.mp.model.Address;
import com.altruista.mp.model.Visit;
import com.altruista.mp.rest.VisitController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class VisitResourceAssembler extends ResourceAssemblerSupport<Visit, VisitResource> {

    public VisitResourceAssembler() {
        super(VisitController.class, VisitResource.class);
    }

    @Override
    public VisitResource toResource(Visit visit) {

        VisitResource resource = createResourceWithId(visit.getId(), visit);

        // copy properties from member to memberResource

        resource.setMemberId(visit.getMemberId());
        resource.setReason(visit.getReason());
        resource.setProviderName(visit.getProviderName());
        resource.setProviderAddress(toAddressResource(visit.getProviderAddress()));
        resource.setStatus(visit.getStatus());
        resource.setVisitType(visit.getVisitType());
        resource.setVisitOn(visit.getVisitOn());
        resource.setPaidAmount(visit.getPaidAmount());
        resource.setSource(visit.getSource());
        resource.setAddedOn(visit.getRefCreatedOn());

        return resource;
    }

    public AddressResource toAddressResource(Address address) {

        if (address == null)
            return null;

        AddressResource resource = new AddressResource();
        resource.setPrimary(address.isPrimary());
        resource.setAddress(address.getAddress());
        resource.setAddress2(address.getAddress2());
        resource.setCity(address.getCity());
        resource.setStateProvince(address.getStateProvince());
        resource.setPostalCode(address.getPostalCode());
        resource.setCounty(address.getCounty());
        resource.setCountry(address.getCountry());

        return resource;
    }

}