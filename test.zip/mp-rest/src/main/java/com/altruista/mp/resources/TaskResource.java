package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "task")
public class TaskResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String contactId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.tasktype}")
    @Length(max = 4, message = "{length.validation.tasktype}")
    private String taskType;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.reason}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.reason}")
    private String reason;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.taskstatus}")
    @Length(max = ResourceSize.MAX_STATUS, message = "{length.validation.taskstatus}")
    private String status;
    private Integer priority;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.title}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.title}")
    private String title;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime start;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime end;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.starttimezone}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.starttimezone}")
    private String startTimezone;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.endtimezone}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.endtimezone}")
    private String endTimezone;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.taskdescription}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.taskdescription}")
    private String description;
    @Length(max = ResourceSize.MAX_ID, message = "{length.validation.recurrenceid}")
    private Integer recurrenceId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.recurrencerule}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.recurrencerule}")
    private String recurrenceRule;
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_STRING)
    private String recurrenceException;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.ownerid}")
    @Length(max = ResourceSize.MAX_ID, message = "{length.validation.ownerid}")
    private String ownerId;
    private String ownerType;
    private Boolean allDay;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public Boolean getAllDay() {
        return allDay;
    }

    public void setAllDay(Boolean allDay) {
        this.allDay = allDay;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public DateTime getStart() {
        return start;
    }

    public void setStart(DateTime start) {
        this.start = start;
    }

    public DateTime getEnd() {
        return end;
    }

    public void setEnd(DateTime end) {
        this.end = end;
    }

    public String getStartTimezone() {
        return startTimezone;
    }

    public void setStartTimezone(String startTimezone) {
        this.startTimezone = startTimezone;
    }

    public String getEndTimezone() {
        return endTimezone;
    }

    public void setEndTimezone(String endTimezone) {
        this.endTimezone = endTimezone;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getRecurrenceId() {
        return recurrenceId;
    }

    public void setRecurrenceId(Integer recurrenceID) {
        this.recurrenceId = recurrenceID;
    }

    public String getRecurrenceRule() {
        return recurrenceRule;
    }

    public void setRecurrenceRule(String recurrenceRule) {
        this.recurrenceRule = recurrenceRule;
    }

    public String getRecurrenceException() {
        return recurrenceException;
    }

    public void setRecurrenceException(String recurrenceException) {
        this.recurrenceException = recurrenceException;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getOwnerType() {
        return ownerType;
    }

    public void setOwnerType(String ownerType) {
        this.ownerType = ownerType;
    }

}
