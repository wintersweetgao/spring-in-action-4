package com.altruista.mp.rest;

import com.altruista.mp.model.Assessment;
import com.altruista.mp.model.AssessmentRun;
import com.altruista.mp.resources.AssessmentNameResource;
import com.altruista.mp.resources.AssessmentNameResourceAssembler;
import com.altruista.mp.resources.AssessmentResource;
import com.altruista.mp.resources.AssessmentResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.AssessmentNameService;
import com.altruista.mp.services.AssessmentRunService;
import com.altruista.mp.services.AssessmentService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles requests for Assessments
 */
@Controller
@RequestMapping("/api/assessment")
@Api(value = "Assessment service", description = "Manage Assessments")
public class AssessmentController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentController.class);

    private final AssessmentService assessmentService;
    private AssessmentResourceAssembler assessmentAssembler;
    private final AssessmentRunService assessmentRunService;

    @Autowired
    public AssessmentController(AssessmentService assessmentService, AssessmentNameService assessmentNameService, AssessmentRunService assessmentRunService) {
        this.assessmentService = assessmentService;
        assessmentAssembler = new AssessmentResourceAssembler();
        this.assessmentRunService = assessmentRunService;
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Gets the Assessment using id")
    public HttpEntity<AssessmentResource> getAssessment(@PathVariable("id") String id) throws ResourceException {
        Assessment run = assessmentService.get(id);
        AssessmentResource resource = assessmentAssembler.toResource(run);

        return new ResponseEntity<AssessmentResource>(resource, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get all Assessments")
    public HttpEntity<List<AssessmentResource>> getAllAssessments() throws ResourceException {
        List<AssessmentResource> resourceList = assessmentAssembler.toResources(assessmentService.findAll());
        return new ResponseEntity<List<AssessmentResource>>(resourceList,
                HttpStatus.OK);
    }

    /*
     *
     */
    @RequestMapping(value = "/{memberId}/names", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get all Assessment Names")
    public HttpEntity<List<AssessmentNameResource>> getAllAssessmentNamesByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);

        List<AssessmentNameResource> newList = new ArrayList<AssessmentNameResource>();
        List<AssessmentRun> runs = assessmentRunService.findByMemberId(memberId);

        // add status to resource and remove completed assessments
        for (AssessmentRun run : runs) {
            // only add if not completed
            if (!"Completed".equalsIgnoreCase(run.getStatus())) {
                AssessmentNameResource name = new AssessmentNameResource();

                name.setAssessmentId(run.getAssessmentId());
                name.setName(run.getAssessmentName());
                name.setStatus(run.getStatus());
                name.setLastRunId(run.getId());
                name.setLastSequence(run.getLastSequence());
                newList.add(name);
            }
        }

        return new ResponseEntity<List<AssessmentNameResource>>(newList,
                HttpStatus.OK);
    }

    @RequestMapping(value = "/name/{name}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Assessments by Name")
    public HttpEntity<List<AssessmentResource>> getAssessmentsByName(@PathVariable String name) throws ResourceException {
        List<AssessmentResource> resourceList = assessmentAssembler.toResources(assessmentService.findByName(name));
        return new ResponseEntity<List<AssessmentResource>>(resourceList,
                HttpStatus.OK);
    }

}