package com.altruista.mp.rest;

import com.altruista.mp.model.TrackerRecord;
import com.altruista.mp.resources.TrackerRecordAssembler;
import com.altruista.mp.resources.TrackerRecordResource;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.TrackerRecordService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Handles requests for  Health Trackers
 */
@Controller
@Api(value = "Tracker Record service", description = "Manage Tracker Records")
public class TrackerRecordController {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrackerRecordController.class);

    @Value("${guidingCare.timezone}")
    private String gcTimezone;

    private final TrackerRecordService trackerRecordService;
    private TrackerRecordAssembler trackerRecordAssembler;

    @Autowired
    public TrackerRecordController(TrackerRecordService trackerRecordService) {
        this.trackerRecordService = trackerRecordService;
        trackerRecordAssembler = new TrackerRecordAssembler();
    }

    @ApiOperation(value = "Gets the Tracker records using Tracker record id")
    @RequestMapping(value = "/api/trackerRecord/{id}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<TrackerRecordResource> getTrackerRecordId(@PathVariable String id) throws ResourceException {
        TrackerRecordResource resourceList = trackerRecordAssembler.toResource(trackerRecordService.get(id));
        return new ResponseEntity<TrackerRecordResource>(resourceList,
                HttpStatus.OK);
    }


    @RequestMapping(value = "/api/trackerRecord", method = RequestMethod.POST, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ResponseBody
    @ApiOperation(value = "Creates a Tracker Record")
    public HttpEntity<TrackerRecordResource> saveRecord(@RequestBody TrackerRecordResource resource) throws ResourceException {
        String memberId = resource.getMemberId();
        MemberIdValidationUtil.validateMemberClaim(memberId);
        TrackerRecord record = trackerRecordAssembler.fromResource(resource);
        if (record.getRecordedOn() == null) {
            DateTime local = new DateTime(DateTime.now(), DateTimeZone.forID(gcTimezone));
            DateTime recordedOn = local.toDateTime(DateTimeZone.UTC);
            record.setRecordedOn(recordedOn);
        }
        trackerRecordService.save(record);
        resource = trackerRecordAssembler.toResource(record);
        return new ResponseEntity<TrackerRecordResource>(resource, HttpStatus.OK);
    }


    /*
     *
     */
    @RequestMapping(value = "/api/member/{memberId}/{trackerId}/trackerRecord", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get All Tracker Records By RecordedOn")
    public HttpEntity<List<TrackerRecordResource>> getTrackers(
            @PathVariable String memberId, @PathVariable String trackerId,
            @RequestParam(value = "startDate", required = false) String startDate,
            @RequestParam(value = "endDate", required = false) String endDate) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);

        List<TrackerRecordResource> resourceList = trackerRecordAssembler.toResources(trackerRecordService.getTrackerRecordsByMemberIdAndTrackerIdAndRecordOn(memberId, trackerId, startDate, endDate));
        return new ResponseEntity<List<TrackerRecordResource>>(resourceList,
                HttpStatus.OK);
    }
}