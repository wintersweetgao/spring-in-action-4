package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

import javax.validation.Valid;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "visit")
public class VisitResource extends ResourceSupport {
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime addedOn;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.visitreason}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.visitreason}")
    private String reason;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.providername}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.providername}")
    private String providerName;
    @Valid
    private AddressResource providerAddress;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.visitstatus}")
    @Length(max = ResourceSize.MAX_STATUS, message = "{length.validation.visitstatus}")
    private String status;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.visittype}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.visittype}")
    private String visitType;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime visitOn;
    private float paidAmount;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.visitsource}")
    @Length(max = ResourceSize.MAX_STRING, message = "{length.validation.visitsource}")
    private String source;

    public DateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(DateTime addedOn) {
        this.addedOn = addedOn;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public AddressResource getProviderAddress() {
        return providerAddress;
    }

    public void setProviderAddress(AddressResource providerAddress) {
        this.providerAddress = providerAddress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVisitType() {
        return visitType;
    }

    public void setVisitType(String visitType) {
        this.visitType = visitType;
    }

    public DateTime getVisitOn() {
        return visitOn;
    }

    public void setVisitOn(DateTime visitOn) {
        this.visitOn = visitOn;
    }

    public float getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(float paidAmount) {
        this.paidAmount = paidAmount;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

}