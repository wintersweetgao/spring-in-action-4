package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;


/*
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by Prateek on 10/19/15
 */
@XmlRootElement(name = "PushNotificationRegistration")
public class PushNotificationRegistrationResource extends ResourceSupport {
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.deviceOS}")
    @Length(max = 2000, message = "{length.validation.deviceOS}")
    private String deviceOS;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.deviceToken}")
    @Length(max = 2000, message = "{length.validation.deviceToken}")
    private String deviceToken;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.regID}")
    @Length(max = 2000, message = "{length.validation.regID}")
    private String regID;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.contactId}")
    @Length(max = 2000, message = "{length.validation.contactId}")
    private String contactId;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.messageText}")
    @Length(max = 4000, message = "{length.validation.messageText}")
    private String messageText;
    private int badge;

    public String getDeviceOS() {
        return deviceOS;
    }

    public void setDeviceOS(String deviceOS) {
        this.deviceOS = deviceOS;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public String getRegID() {
        return regID;
    }

    public void setRegID(String regID) {
        this.regID = regID;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public int getBadge() {
        return badge;
    }

    public void setBadge(int badge) {
        this.badge = badge;
    }
}
