package com.altruista.mp.rest;

import com.altruista.mp.resources.AllergySensitivityResource;
import com.altruista.mp.resources.AllergySensitivityResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.AllergySensitivityService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for alerts
 */
@Controller
@RequestMapping("/api/allergy")
@Api(value = "Allergy Sensitivity service", description = "Manage Allergy Sensitivies")
public class AllergySensitivityController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AllergySensitivityController.class);

    private final AllergySensitivityService allergyService;
    private AllergySensitivityResourceAssembler allergyAssembler;

    @Autowired
    public AllergySensitivityController(AllergySensitivityService allergyService) {
        this.allergyService = allergyService;
        allergyAssembler = new AllergySensitivityResourceAssembler();
    }

    @ApiOperation(value = "Gets Allergy Sensitivities")
    @RequestMapping(value = "/{memberId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    public HttpEntity<List<AllergySensitivityResource>> getAllergySensitivitiesByMemberId(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);
        List<AllergySensitivityResource> resourceList = allergyAssembler.toResources(allergyService.findByMemberId(memberId));
        return new ResponseEntity<List<AllergySensitivityResource>>(resourceList,
                HttpStatus.OK);
    }

}