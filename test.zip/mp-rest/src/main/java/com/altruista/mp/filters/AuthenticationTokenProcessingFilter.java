package com.altruista.mp.filters;

import com.altruista.mp.model.User;
import com.altruista.mp.rest.exceptions.TokenException;
import com.altruista.mp.restutils.TokenUtils;
import com.altruista.mp.services.UserService;
import com.nimbusds.jwt.ReadOnlyJWTClaimsSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;


public class AuthenticationTokenProcessingFilter extends GenericFilterBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationTokenProcessingFilter.class);

    private final UserService userService;


    public AuthenticationTokenProcessingFilter(UserService userService) {
        this.userService = userService;
    }


    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {

        HttpServletRequest httpRequest = this.getAsHttpRequest(request);
        String encryptedToken = this.extractAuthTokenFromRequest(httpRequest);

        if (encryptedToken != null) {
            try {
                ReadOnlyJWTClaimsSet claims = TokenUtils.extractClaims(encryptedToken);
                String userName = claims.getSubject();

                if (userName != null) {

                    User user = null;
                    try {
                        user = this.userService.getUserByUsername(userName);

                        // consider updating accessedOn here if we need a timeout relative to inactivity
                    } catch (Exception exc) {
                        LOGGER.error("Unable to retrieve user: " + userName + ", exception: " + exc);
                    }

                    if (TokenUtils.validateToken(claims, user)) {
                        Collection<GrantedAuthority> auths = new ArrayList<>();

                        if ((claims.getCustomClaim("MPREG")).equals("1"))
                            auths.add(new SimpleGrantedAuthority("REGISTER"));
                        else
                            auths = user.getAuthorities();

                        UsernamePasswordAuthenticationToken authentication =
                                new UsernamePasswordAuthenticationToken(user, claims.getAudience(), auths);
                        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(httpRequest));
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                    }
                }
            } catch (TokenException exc) {
                LOGGER.error("Unable to authenticate request using token." + ", exception: " + exc);
            }
        }

        chain.doFilter(request, response);
    }


    private HttpServletRequest getAsHttpRequest(ServletRequest request) {
        if (!(request instanceof HttpServletRequest)) {
            throw new RuntimeException("Expecting an HTTP request");
        }

        return (HttpServletRequest) request;
    }


    private String extractAuthTokenFromRequest(HttpServletRequest httpRequest) {
        /* Get token from header */
        String authToken = httpRequest.getHeader("X-Auth-Token");

        /* If token not found get it from request parameter */
        if (authToken == null) {
            authToken = httpRequest.getParameter("token");
        }

        return authToken;
    }
}