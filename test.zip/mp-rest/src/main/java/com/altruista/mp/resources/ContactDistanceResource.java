package com.altruista.mp.resources;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.springframework.hateoas.ResourceSupport;

/*
 * Developed by Prateek A on 06/22/15
 */
public class ContactDistanceResource extends ResourceSupport {
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.salutation}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.salutation}")
    private String salutation;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.firstName}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.firstName}")
    private String firstName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.middleName}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.middleName}")
    private String middleName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.lastName}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.lastName}")
    private String lastName;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.distance}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.distance}")
    private String distance;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.nameSuffix}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.nameSuffix}")
    private String nameSuffix;
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE, message = "{html.validation.company}")
    @Length(max = ResourceSize.MAX_SHORT_STRING, message = "{length.validation.company}")
    private String company;

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }
}
