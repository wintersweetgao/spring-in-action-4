package com.altruista.mp.resources;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;
import org.hibernate.validator.constraints.SafeHtml.WhiteListType;
import org.joda.time.DateTime;
import org.springframework.hateoas.ResourceSupport;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "diagnosis")
public class DiagnosisResource extends ResourceSupport {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime addedOn;
    @SafeHtml(whitelistType = WhiteListType.NONE)
    @Length(max = ResourceSize.MAX_ID)
    private String memberId;
    private boolean primary;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.diagname}")
    @Length(max = 2000, message = "{length.validation.diagname}")
    private String name;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.diagcategory}")
    @Length(max = 10, message = "{length.validation.diagcategory}")
    private String category;
    private Integer rank;
    @SafeHtml(whitelistType = WhiteListType.NONE, message = "{html.validation.source}")
    @Length(max = ResourceSize.MAX_SOURCE, message = "{length.validation.source}")
    private String source;

    public DateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(DateTime addedOn) {
        this.addedOn = addedOn;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

}
