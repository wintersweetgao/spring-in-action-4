package com.altruista.mp.rest;

import com.altruista.mp.model.Visit;
import com.altruista.mp.resources.LastVisitResource;
import com.altruista.mp.resources.VisitResource;
import com.altruista.mp.resources.VisitResourceAssembler;
import com.altruista.mp.rest.exceptions.ResourceException;
import com.altruista.mp.restutils.MemberIdValidationUtil;
import com.altruista.mp.services.VisitService;
import com.altruista.mp.utils.PropertiesLoaderUtility;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Handles requests for alerts
 */
@Controller
@RequestMapping("/api/visit")
@Api(value = "Visit service", description = "Manage Visits")
public class VisitController {
    private static final Logger LOGGER = LoggerFactory.getLogger(VisitController.class);

    private final VisitService visitService;
    private VisitResourceAssembler visitAssembler;
    @Autowired
    private PagedResourcesAssembler<Visit> pagedAssembler;

    @Autowired
    public VisitController(VisitService visitService) {
        this.visitService = visitService;
        this.visitAssembler = new VisitResourceAssembler();
    }

    @RequestMapping(value = "/{memberId}", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Visits using Member Id")
    public HttpEntity<PagedResources<VisitResource>> getVisitsByMemberId(@PathVariable String memberId,
                                                                         Pageable pageable) throws ResourceException {
        Page<Visit> visits = visitService.findByMemberId(memberId, pageable);
        return new ResponseEntity<>(pagedAssembler.toResource(visits, visitAssembler), HttpStatus.OK);
    }

    @RequestMapping(value = "/{memberId}/lastVisit", method = RequestMethod.GET, produces = {"application/json"}, headers = {"Accept=application/json"})
    @ApiOperation(value = "Get Last Visits using Member Id and Visit Type")
    public HttpEntity<LastVisitResource> getLastVisitByMemberIdAndVisitType(@PathVariable String memberId) throws ResourceException {
        MemberIdValidationUtil.validateMemberClaim(memberId);

        String visitType = PropertiesLoaderUtility.getProperty("medical.claim.visittype");
        List<Visit> visits = visitService.getLastVisitByMemberIdAndVisitType(memberId, visitType);
        if (visits.isEmpty())
            return new ResponseEntity(HttpStatus.NO_CONTENT);

        LastVisitResource lastVisitResources = new LastVisitResource();
        for (Visit visit : visits) {
            lastVisitResources.setProviderName(visit.getProviderName());
            lastVisitResources.setVisitOn(visit.getVisitOn());
        }
        return new ResponseEntity<LastVisitResource>(lastVisitResources, HttpStatus.OK);
    }
}