package com.altruista.mp.resources;

import com.altruista.mp.model.AssessmentResponse;
import com.altruista.mp.rest.AssessmentResponseController;
import com.altruista.mp.rest.exceptions.ResourceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

/*
 * Created by Prateek on 03/12/15
 */
public class AssessmentResponseResourceAssembler extends
        ResourceAssemblerSupport<AssessmentResponse, AssessmentResponseResource> {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentResponseResourceAssembler.class);

    // default constructor
    public AssessmentResponseResourceAssembler() {
        super(AssessmentResponseController.class, AssessmentResponseResource.class);
    }

    @Override
    public AssessmentResponseResource toResource(AssessmentResponse response) {
        AssessmentResponseResource resource = instantiateResource(response);
        try {
            resource.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(AssessmentResponseController.class).getAssessmentResponse(response.getId())).withSelfRel());
        } catch (ResourceException exc) {
            LOGGER.warn("Unable to add HATEOAS link to resource: " + exc);
        }
        return resource;
    }

    @Override
    protected AssessmentResponseResource instantiateResource(AssessmentResponse entity) {
        AssessmentResponseResource resource = new AssessmentResponseResource();
        
        resource.setQuestion(entity.getQuestion());
        resource.setCreatedOn(entity.getCreatedOn());
        resource.setUpdatedOn(entity.getUpdatedOn());

        return resource;
    }

    public AssessmentResponse fromResource(AssessmentResponseResource resource, AssessmentResponse response) {
        if (response == null)
            response = new AssessmentResponse();

        response.setQuestion(resource.getQuestion());
        response.setCreatedOn(resource.getCreatedOn());
        response.setUpdatedOn(resource.getUpdatedOn());
        return response;
    }

    public AssessmentResponse fromResource(AssessmentResponseResource resource) {
        return fromResource(resource, null);
    }
}
