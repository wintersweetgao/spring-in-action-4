package com.altruista.mp.resources;

import com.altruista.mp.model.MPDocument;
import com.altruista.mp.rest.MPDocumentController;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;

public class MPDocumentResourceAssembler extends
        ResourceAssemblerSupport<MPDocument, MPDocumentResource> {

    public MPDocumentResourceAssembler() {
        super(MPDocumentController.class, MPDocumentResource.class);
    }

    @Override
    public MPDocumentResource toResource(MPDocument MPDocument) {
        return createResourceWithId(MPDocument.getId(), MPDocument);
    }

    @Override
    protected MPDocumentResource instantiateResource(MPDocument entity) {
        MPDocumentResource resource = new MPDocumentResource();

        resource.setMemberId(entity.getMemberId());
        resource.setName(entity.getName());
        resource.setDescription(entity.getDescription());
        resource.setHeading(entity.getHeading());
        resource.setDocumentText(entity.getDocumentText());
        resource.setDocumentType(entity.getDocumentType());
        resource.setThumbnail(entity.getThumbnail());
        resource.setDocumentUrl(entity.getDocumentUrl());
        resource.setSource(entity.getSource());
        resource.setTags(entity.getTags());

        return resource;
    }

    public MPDocument fromResource(String id, MPDocumentResource resource) {

        MPDocument doc = new MPDocument();

        // copy properties from memberResource to member
        doc.setId(id);
        doc.setMemberId(resource.getMemberId());
        doc.setName(resource.getName());
        doc.setDescription(resource.getDescription());
        doc.setHeading(resource.getHeading());
        doc.setDocumentText(resource.getDocumentText());
        doc.setDocumentType(resource.getDocumentType());
        doc.setThumbnail(resource.getThumbnail());
        doc.setDocumentUrl(resource.getDocumentUrl());
        doc.setSource(resource.getSource());
        doc.setTags(resource.getTags());

        return doc;
    }

}