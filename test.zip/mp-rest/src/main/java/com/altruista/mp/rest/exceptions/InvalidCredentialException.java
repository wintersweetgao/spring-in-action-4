package com.altruista.mp.rest.exceptions;


@SuppressWarnings("serial")
public class InvalidCredentialException extends RuntimeException {
    private final String errors;

    public InvalidCredentialException(String message) {
        super(message);
        this.errors = message;
    }

    public String getErrors() {
        return errors;
    }
}
