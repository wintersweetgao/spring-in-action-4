package com.altruista.mp.rest.MyHealthRecord;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;


/*
 * Developed by Prateek on 09/22/15
 */

public class CareGiverMedicalInfoTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareGiverMedicalInfoTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";
    private String CONTACT_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "susan");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
        setMemberId();
    }


    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();
        CONTACT_ID = jo.get("contactId").getAsString();
        LOGGER.debug("MemberId : " + MEMBER_ID);
        LOGGER.debug("ContactId : " + CONTACT_ID);
    }

    //https://demo.personalcarerecord.com:9443/DEVL-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7
    // Member Diagnosis
    @Test
    public void testMemberDiagnosis() {
        LOGGER.info("**** testMemberDiagnosis() *****");
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/member/" + MEMBER_ID;

        getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        Assert.assertEquals("200", removeDoubleQuotes(getResponse.getStatusCode().toString()));
        Assert.assertEquals("OK", removeDoubleQuotes(getResponse.getStatusCode().getReasonPhrase()));
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    // Member Condition
    @Test
    public void testMemberCondition() {
        LOGGER.debug("--- testMemberCondition  ----");
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/condition/" + MEMBER_ID;

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            LOGGER.error("Response : [" + getResponse + "]");
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    //https://demo.personalcarerecord.com:9443/DEVL-rest/api/allergy/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7
    // Allergy
    @Test
    public void testAllergy() {
        LOGGER.info("**** testAllergy() *****");
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/allergy/" + MEMBER_ID;

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            LOGGER.error("Response : [" + getResponse + "]");
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    //https://demo.personalcarerecord.com:9443/DEVL-rest/api/program/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7
    // Program
    @Test
    public void testProgram() {
        LOGGER.info("**** testProgram() *****");
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/program/" + MEMBER_ID;

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            LOGGER.error("Response : [" + getResponse + "]");
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    //impairment
    //https://demo.personalcarerecord.com:9443/DEVL-rest/api/impairment/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7
    @Test
    public void testImpairment() {
        LOGGER.info("**** testImpairment() *****");
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/impairment/" + MEMBER_ID;

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            LOGGER.error("Response : [" + getResponse + "]");
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    //https://demo.personalcarerecord.com:9443/DEVL-rest/api/contact/6def8512-4a6e-44c6-8d15-7a0a330ddf53
    @Test
    public void testContact() {
        LOGGER.info("**** testImpairment() *****");
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/" + CONTACT_ID;

        getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        Assert.assertEquals("200", removeDoubleQuotes(getResponse.getStatusCode().toString()));
        Assert.assertEquals("OK", removeDoubleQuotes(getResponse.getStatusCode().getReasonPhrase()));
    }
}
