package com.altruista.mp.rest.pushNotification;

import java.io.IOException;
import java.util.Properties;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsDelegate;
import com.notnoop.apns.ApnsNotification;
import com.notnoop.apns.ApnsService;
import com.notnoop.apns.DeliveryError;

public class APNSTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(APNSTest.class);
    Properties prop = null;

    @org.junit.Before
    public void beforeTest() throws IOException {
        prop = new Properties();
        prop.load(APNSTest.class.getClassLoader().getResourceAsStream("DEVL.mp-rest.properties"));
    }

    @Test
    public void testAPNSForIOSDevice() throws IOException {
        LOGGER.debug("Test APNS for iOS");
        String userHome = System.getProperty("user.home");

        ApnsService pushService = APNS.newService()
                .withCert(userHome + "/" + prop.getProperty("apns.push.notification.cert.path"), prop.getProperty("apns.push.notification.cert.password"))
                .withSandboxDestination()
                .withDelegate(new ApnsDelegate() {
                    @Override
                    public void notificationsResent(int resendCount) {
                        LOGGER.debug("A number of notifications has been queued for resending due to a error-response packet being received." + resendCount);
                    }

                    @Override
                    public void messageSent(ApnsNotification message, boolean resent) {
                        LOGGER.debug("Message sent successfully" + message + ",Resent :" + resent);
                    }

                    @Override
                    public void messageSendFailed(ApnsNotification message, Throwable e) {
                        LOGGER.debug("A delivery of the message failed for any reason" + message);
                    }

                    @Override
                    public void connectionClosed(DeliveryError e, int messageIdentifier) {
                        LOGGER.debug("The connection was closed and/or an error packet was received while monitoring was turned on." + e);
                    }

                    @Override
                    public void cacheLengthExceeded(int newCacheLength) {
                        LOGGER.debug("The resend cache needed a bigger size (while resending messages)" + newCacheLength);
                    }
                })
                .build();

        String payload = APNS.newPayload().alertBody("Testing APNS from India !!").badge(45).sound("default").build();
        String token = "c61de3c4 8847579d 9c5588ab f50b6654 d43767db cc19ba86 c2130b14 54ca289a";
        pushService.push(token, payload);
        LOGGER.debug("Response : " + pushService);
    }

}
