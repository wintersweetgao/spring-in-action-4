package com.altruista.mp.rest.test;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class MapQuestTest {
    private static HttpHeaders headers = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void getData() throws UnsupportedEncodingException {
        String location = "1707 BOULEVARD SQ STE A";
        String address = URLEncoder.encode(location, "UTF-8");
        System.out.println("Address : " + address + "WAYCROSS GA 31501");
        String url = "http://open.mapquestapi.com/nominatim/v1/search.php?format=json&q=" + location;

        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(url, String.class);
        System.out.println("Result : " + result);
    }


    //
    @Test
    public void testgetLatAndLon1() throws UnsupportedEncodingException {
        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<String> entity = new HttpEntity<String>(headers);

        // lat: 38.95291, lon: -77.346809
        String location = "11480 Sunset Hills Road, Reston, VA 20190";

        //String location = "1946 Isaac Newton Square Reston, VA, 20190";

		/*String url = "http://open.mapquestapi.com/nominatim/v1/search.php?format=json&json_callback=renderExampleBasicResults&q="+ 
				encode+"&addressdetails=1&limit=3&viewbox="+viewBox+"&exclude_place_ids=41697";*/

        String url = "http://open.mapquestapi.com/nominatim/v1/search.php?format=json&q=" + location;
        System.out.println("URL :" + url);


        String result = restTemplate.getForObject(url, String.class);
        System.out.println("Result : " + result);
		
		/*ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		System.out.println("Response : " + response);*/

        JsonElement jelement = new JsonParser().parse(result);
        JsonArray jsonArray = jelement.getAsJsonArray();
        JsonObject jo = jsonArray.get(0).getAsJsonObject();

        String lat = removeDoubleQuotes(jo.get("lat").toString());
        String lon = removeDoubleQuotes(jo.get("lon").toString());

        System.out.println("Lat : " + lat);
        System.out.println("Lon : " + lon);
		
		/*Assert.assertEquals("38.95296", lat);
		Assert.assertEquals("-77.346809", lon);*/
    }


    @Test
    public void testgetLatAndLon2() throws UnsupportedEncodingException {
        RestTemplate restTemplate = new RestTemplate();

        // 18.5499129° N, 73.809553° E ==> Pune
        String location = "Pune, MH";

        String url = "http://open.mapquestapi.com/nominatim/v1/search.php?format=json&q=" + location;
        String result = restTemplate.getForObject(url, String.class);
        System.out.println("Result : " + result);

        JsonElement jelement = new JsonParser().parse(result);
        JsonArray jsonArray = jelement.getAsJsonArray();
        JsonObject jo = jsonArray.get(0).getAsJsonObject();

        String lat = removeDoubleQuotes(jo.get("lat").toString());
        String lon = removeDoubleQuotes(jo.get("lon").toString());

        Assert.assertEquals("18.64395815", lat);
        Assert.assertEquals("73.9325681901252", lon);
    }


    @Test
    public void testgetLatAndLon3() throws UnsupportedEncodingException {
        RestTemplate restTemplate = new RestTemplate();

        // 18.5499129° N, 73.809553° E ==> Pune
        String location = "Balewadi, Baner"; //street

        String url = "http://open.mapquestapi.com/nominatim/v1/search.php?format=json&q=" + location;
        String result = restTemplate.getForObject(url, String.class);
        System.out.println("Result : " + result);

        JsonElement jelement = new JsonParser().parse(result);
        JsonArray jsonArray = jelement.getAsJsonArray();
        JsonObject jo = jsonArray.get(0).getAsJsonObject();

        Assert.assertEquals("18.563542", removeDoubleQuotes(jo.get("lat").toString()));
        Assert.assertEquals("73.7829187", removeDoubleQuotes(jo.get("lon").toString()));
    }
}
