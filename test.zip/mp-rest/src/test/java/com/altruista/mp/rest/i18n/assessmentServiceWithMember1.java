package com.altruista.mp.rest.i18n;

import com.altruista.mp.services.exceptions.ServiceException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Properties;

/*
 * 
 */
public class assessmentServiceWithMember1 {
    private static final Logger LOGGER = LoggerFactory.getLogger(assessmentServiceWithMember1.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private Properties prop = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        prop = new Properties();
        prop.load(assessmentServiceWithMember1.class.getClassLoader().getResourceAsStream("member.properties"));

        // create request body
        JSONObject request = new JSONObject();
        request.put("username", prop.getProperty("mp.username"));
        request.put("password", prop.getProperty("mp.password"));


        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------------  Load the User from the mongodb -------------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("victoria", username);
        Assert.assertEquals("Jefferson", removeDoubleQuotes(jo.get("lastName").toString()));
    }

    @Test
    public void getAssessment() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessment/71efc277-5939-4df2-8301-a8adefffccae";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void API_POSTAssessmentRun_Test() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7";


        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
        Assert.assertEquals("New", jo.get("status").toString().replaceAll("\"", "").trim());

    }


    @Test
    public void getAllAssessmentNamesByMemberId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessment/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/names/";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void saveAssessmentRun() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/5f75adfb-e34f-4d51-aae2-37c5f96cb76b";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

    }

    @Test
    public void getAssessmentResponseByRunId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/5f75adfb-e34f-4d51-aae2-37c5f96cb76b/assessmentResponse";


        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

        Assert.assertNotNull(getResponse);

        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

    }

    @Test
    public void createAssessmentResponse() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"question\":{\"refId\":\"7\",\"question\":"
                + "\"Does the call result in a successful contact with the member or care giver?\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":1,\"isRequired\":false,"
                + "\"options\":[{\"refId\":\"9\",\"optionText\":\"Successful contact\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":1,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[{\"refId\":\"1\",\"optionText\":\"Select the person\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":0}]},{\"refId\":\"10\",\"optionText\":\"Unsuccessful contact-Left message\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":2,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},{\"refId\":\"11\",\"optionText\":\"Unsuccessful contact- Number disconnected\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":3,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},{\"refId\":\"12\",\"optionText\":\"Unsuccessful contact-Wrong Number\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":4,\"nextQuestionRefId\":\"8\","
                + "\"nextQuestionSequence\":2,\"subOptions\":[]},{\"refId\":\"13\","
                + "\"optionText\":\"\\nUnsuccessful contact- Member wants to reschedule\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":5,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,\"subOptions\":[]}],"
                + "\"active\":true,\"optionModelRadio\":\"9\"},\"option\":{\"refId\":\"9\","
                + "\"optionText\":\"Successful contact\",\"optionType\":\"RadioButtonList\",\"sequence\":1,"
                + "\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,\"subOptions\":[{\"refId\":\"1\","
                + "\"optionText\":\"Select the person\",\"optionType\":\"RadioButtonList\",\"sequence\":0}]},"
                + "\"optionValue\":\"9\",\"subOption\":null,\"subOptionValue\":null}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/5f75adfb-e34f-4d51-aae2-37c5f96cb76b/assessmentResponse/";


        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        Assert.assertNotNull(getResponse);

        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

    }

    @Test
    public void saveAssessmentRunStatus() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

		/*String json="{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
				+ "\"assessmentName\":\"Wheelchair Assessment AHS\","
				+ "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";*/
        String json = "{\"status\":\"Pending\",\"lastSequence\":1}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/0034a5b3-4f51-45b1-b186-ee16373a9fe7/status/";


        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        Assert.assertNotNull(getResponse);

        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

    }

    @Test
    public void saveAssessmentResponse() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"question\":{\"refId\":\"7\",\"question\":\"Does the call result in a successful contact with the member or care giver?\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":1,\"isRequired\":false,\"options\":"
                + "[{\"refId\":\"9\",\"optionText\":\"Successful contact\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":1,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,\"subOptions\":"
                + "[{\"refId\":\"1\",\"optionText\":\"Select the person\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":0}]},{\"refId\":\"10\",\"optionText\":\"Unsuccessful contact-Left message\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":2,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},{\"refId\":\"11\",\"optionText\":\"Unsuccessful contact- Number disconnected\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":3,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},{\"refId\":\"12\",\"optionText\":\"Unsuccessful contact-Wrong Number\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":4,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},{\"refId\":\"13\",\"optionText\":\"\\nUnsuccessful contact- Member wants to "
                + "reschedule\",\"optionType\":\"RadioButtonList\",\"sequence\":5,\"nextQuestionRefId\":\"8\","
                + "\"nextQuestionSequence\":2,\"subOptions\":[]}],\"active\":false,\"optionModelRadio\":\"10\"},"
                + "\"option\":{\"refId\":\"10\",\"optionText\":\"Unsuccessful contact-Left message\",\"optionType\":"
                + "\"RadioButtonList\",\"sequence\":2,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},\"optionValue\":\"10\",\"subOption\":null,\"subOptionValue\":null}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentResponse/2fa1c5a9-5714-4fdd-a953-f85d8338f8be";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        Assert.assertNotNull(getResponse);

        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

    }

}
