package com.altruista.mp.rest.i18n;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

public class AssessmentResponseAPI {
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "susan");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    @Test
    public void PUT_Assessment_Response_Test() {
        System.out.println("\n------  Update Contact Info ---------");

        String json = "{\"question\":{\"refId\":\"40411\",\"question\":\"Member's current location\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":3,\"isRequired\":false,\"options\":[{\"refId\":\"40998\",\"optionText\":\"Fairview\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":1,\"nextQuestionRefId\":\"40412\",\"nextQuestionSequence\":4,"
                + "\"subOptions\":[]},{\"refId\":\"40999\",\"optionText\":\"Home\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":2,\"nextQuestionRefId\":\"40412\",\"nextQuestionSequence\":4,\"subOptions\":[]},"
                + "{\"refId\":\"41000\",\"optionText\":\"Long Term Care Facility\",\"optionType\":\"RadioButtonList\",\"sequence\":3,"
                + "\"nextQuestionRefId\":\"40412\",\"nextQuestionSequence\":4,\"subOptions\":[]},{\"refId\":\"41001\","
                + "\"optionText\":\"Regional Center of Orange County (RCOC)\",\"optionType\":\"RadioButtonList\",\"sequence\":4,"
                + "\"nextQuestionRefId\":\"40412\",\"nextQuestionSequence\":4,\"subOptions\":[]},{\"refId\":\"41002\","
                + "\"optionText\":\"Skilled Nursing Facility\",\"optionType\":\"RadioButtonList\",\"sequence\":5,"
                + "\"nextQuestionRefId\":\"40412\",\"nextQuestionSequence\":4,\"subOptions\":[]},"
                + "{\"refId\":\"41003\",\"optionText\":\"Boarding Care Facility\",\"optionType\":\"RadioButtonList\",\"sequence\":6,"
                + "\"nextQuestionRefId\":\"40412\",\"nextQuestionSequence\":4,\"subOptions\":[]}],\"active\":false,"
                + "\"optionModelRadio\":\"40998\"},\"option\":{\"refId\":\"40998\",\"optionText\":\"Fairview\",\"optionType\":"
                + "\"RadioButtonList\",\"sequence\":1,\"nextQuestionRefId\":\"40412\",\"nextQuestionSequence\":4,\"subOptions\":[]},"
                + "\"optionValue\":\"40998\",\"subOption\":null,\"subOptionValue\":null}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            Assert.assertEquals("403 Prohibido", e.getMessage());
        }
    }


    @Test
    public void GET_Assessment_Response_Test() {
        System.out.println("\n------  Update Contact Info ---------");

        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/18c661f3-a893-4541-8117-91acf1646fcb/assessmentResponse";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (RestClientException e) {
            Assert.assertEquals("403 Prohibido", e.getMessage());
        }
    }
}
