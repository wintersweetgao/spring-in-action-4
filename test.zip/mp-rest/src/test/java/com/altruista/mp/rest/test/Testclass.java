package com.altruista.mp.rest.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class Testclass {

    public static void main(String[] args) {
        String path = "/home/shripad/atbarhkeys/key.der";
        File publicKeyFile = new File("/home/shripad/ShripadDaware");
        if (!publicKeyFile.exists() && !publicKeyFile.isDirectory()) {
            publicKeyFile.mkdir();
        }

			/*RSAPublicKey publicKey = Testclass.getPublicKey(publicKeyFile);
			RSAPrivateKey privateKey = Testclass.getPrivateKey(publicKeyFile);*/
    }

    public static RSAPublicKey getPublicKey(File publicKeyFile) throws IOException, GeneralSecurityException {
        byte[] keyBytes = new byte[(int) publicKeyFile.length()];
        System.out.println("Shripad Daware");
        FileInputStream fis = new FileInputStream(publicKeyFile);
        fis.read(keyBytes);
        X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        RSAPublicKey pubKey = (RSAPublicKey) factory.generatePublic(publicKeySpec);
        return pubKey;
    }

    public static RSAPrivateKey getPrivateKey(File privateKeyFile) throws IOException, GeneralSecurityException {
        byte[] keyBytes = new byte[(int) privateKeyFile.length()];
        System.out.println("Shripad daware");
        FileInputStream fis = new FileInputStream(privateKeyFile);
        fis.read(keyBytes);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        RSAPrivateKey privKey = (RSAPrivateKey) keyFactory.generatePrivate(spec);
        return privKey;
    }


}
