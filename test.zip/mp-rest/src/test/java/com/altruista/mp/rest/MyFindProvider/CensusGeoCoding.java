package com.altruista.mp.rest.MyFindProvider;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/*
 * Developed by Prateek on 09/22/15
*/
public class CensusGeoCoding {
    private static final Logger LOGGER = LoggerFactory.getLogger(CensusGeoCoding.class);

    public static final String ADDRESS = "http://geocoding.geo.census.gov/geocoder/locations/onelineaddress?address=";
    public static final String BENCHMARK = "&benchmark=Public_AR_Current&format=jsonp";

    @Test
    public void testLatAndLon() throws UnsupportedEncodingException {

        String[] locationArray = {
                "202 S PERSHING ST ENERGY IL 629333602",
                "1707 BOULEVARD SQ STE A	WAYCROSS GA 315018030",
                "6 OFFICE PARK CIR STE 100 MOUNTAIN BRK AL 352232664",
                "115 THREE CROSS DR ROSWELL NM 882017825",
                "47 MAPLE ST STE 104 SUMMIT NJ 79012571",
                "2003 LINCOLN WAY COEUR D ALENE ID 838142611",
                "555 MIDDLEFIELD RD # 207 PALO ALTO CA 943012124",
                "7011 SOUTHWEST FWY HOUSTON TX 770742007",
                "1003 BROAD ST STE 300 JOHNSTOWN PA 159062445",
                "RR 1 RIPLEY WV 252719801",
                "214 S PETERS RD STE 101 KNOXVILLE TN 379235229",
                "801 N ZANG BLVD STE 101 DALLAS TX 752084858",
                "PO BOX 814 ADDISON IL 601010814",
                "200 HENRY CLAY AVE NEW ORLEANS LA 70118",
                "300 FRANK H OGAWA PLZ STE 450 OAKLAND CA 946122047",
                "575 N SIOUX POINT RD NORTH SIOUX CITY SD 570495312",
                "900 N SHORE DR STE 120 LAKE BLUFF IL 600442225",
                "555 MIDDLEFIELD RD # 207 PALO ALTO CA 943012124",
                "333 EAST ST PITTSFIELD MA 12015312",
                "1 WASHINGTON ST TAUNTON MA 27803960",
                "4585 SW 185TH AVE ALOHA OR 970071557",
                "16216 WINDSOR CREEK DR MONUMENT CO 801328985",
                "199 COON RAPIDS BLVD NW STE 31 COON RAPIDS MN 554335861",
                "4033 E MADISON ST STE 101 SEATTLE WA 981123104",
                "1020 2ND ST SANTA ROSA CA 954046607",
                "7227 N 16TH ST STE 213 PHOENIX AZ 850205257",
                "801 W BAY DR LARGO FL 337703269",
                "15502 S TELEGRAPH RD MONROE MI 481615520",
                "PO BOX 3360 PORTLAND OR 972083360",
                "2800 N SHERIDAN RD STE 502 CHICAGO IL 606576183",
                "5931 S HIGHWAY 94 WELDON SPRING MO 633045611",
                "15421 CLAYTON RD STE G1 BALLWIN MO 630113161",
                "PO BOX 25608 SALT LAKE CITY UT 841250608",
                "10012 W CAPITOL DR STE 101 MILWAUKEE WI 532221300",
                "PO BOX 641130 OMAHA NE 681647130",
                "288 BEDFORD ST WHITMAN MA 23821820",
                "41 MALL RD BURLINGTON MA 18050002",
                "10117 SE SUNNYSIDE RD STE F121 CLACKAMAS OR 970157708",
                "600 COFFEE RD MODESTO CA 953554201",
                "27 COLLEGE ST SOUTH HADLEY MA 10756461",
                "2006 BROOKWOOD MED CTR DR #508 BIRMINGHAM AL 352096850",
                "MCLEAN HOSPITALPO BOX 415578 BOSTON MA 22410001",
                "PO BOX 671244 DALLAS TX 752671244",
                "9200 WALL ST AUSTIN TX 787544534",
                "87 WASHINGTON ST CONWAY NH 38186044",
                "325 33RD AVE N STE 103 SAINT CLOUD MN 563031929",
                "11845 SW GREENBURG RD STE 120 TIGARD OR 972236464",
                "1821 LENDEW ST GREENSBORO NC 274087035",
                "1265 UNION AVE RM135 MEMPHIS TN 381043415",
                "12 QUEEN ST STE 2 WORCESTER MA 16102411"
        };

        for (int i = 0; i < locationArray.length; i++) {
            LOGGER.info("--------------------- " + i + " addresses");
            String location = URLEncoder.encode(locationArray[i], "UTF-8").replace("+", "%20");
            LOGGER.info("Location : " + location);

            RestTemplate restTemplate = new RestTemplate();
            String result = restTemplate.getForObject(ADDRESS + location + BENCHMARK, String.class);
            LOGGER.info("Result : " + result);

            JsonElement jelement = new JsonParser().parse(result);
            if (jelement.toString().equals("[]")) {

            } else {
                JsonObject jobject = jelement.getAsJsonObject();

                if (jobject.get("result") != null) {
                    JsonElement jelement1 = jobject.get("result");
                    JsonObject jobject1 = jelement1.getAsJsonObject();

                    JsonElement jelement2 = jobject1.get("addressMatches");
                    JsonArray jarray = jelement2.getAsJsonArray();
                    if (!jarray.toString().equals("[]")) {
                        JsonObject jobject2 = jarray.get(0).getAsJsonObject();

                        JsonElement jelement3 = jobject2.get("coordinates");
                        JsonObject jo = jelement3.getAsJsonObject();

                        LOGGER.info("Latitude : [" + jo.get("x") + "],  longitude :[" + jo.get("y") + "]");
                        LOGGER.info("-----------------------" + " end");
                    }
                }
            }
        }
    }
}
