package com.altruista.mp.rest.MyFindProvider;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Iterator;

public class MemberFindProviderPaginationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberFindProviderPaginationTest.class);
    private RestTemplate restTemplate = null;
    private String JWT_TOKEN = "";

    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    // Get the access token - JWT for Successful Authentication
    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        JWT_TOKEN = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(JWT_TOKEN);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", JWT_TOKEN);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }


    // Total 77 document for PostalCode=12345, PageSize=18, Total Pages will be 5

    @Test
    public void testGetPaginationIndexZeroforPostalCode() {
        LOGGER.info("******** GetPagination() **********");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        // For 0th Page Index
        LOGGER.info("------------------- For 1st Page Index ------------------------ ");
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=Dr., Provider&postalCode=12345&page=1&size=18";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        int elements = numberOfElements(getResponse.getBody());
        LOGGER.info("(1) Expected Total 77 items, found = " + elements, elements == 77);
        //Assert.assertTrue("(1) Expected Total 77 items, found = " + elements, elements == 77);

        int count = numberOfProviders(getResponse.getBody());
        Assert.assertTrue("(1) Expected 18 items in this page, found = " + count, count == 18);

        // For 2nd Page Index
        LOGGER.info("------------------ For 2nd Page Index ------------------------ ");
        String BASE_URL2 = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&page=2&size=18";
        ResponseEntity<String> getResponse2 = restTemplate.exchange(BASE_URL2, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse2.getBody());

        Assert.assertNotNull(getResponse2.getBody());
        Assert.assertEquals("OK", getResponse2.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse2.getStatusCode().toString().trim());

        int elements1 = numberOfElements(getResponse.getBody());
        //Assert.assertTrue("(2) Expected 77 items in this page, found = " + elements1, elements1 == 77);
        LOGGER.info("(2) Expected 77 items in this page, found = " + elements1, elements1 == 77);

        // For 3rd Page Index
        LOGGER.info("------------------ Back to 0th Page Index ------------------------ ");
        String BASE_URL3 = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&page=3&size=18";

        ResponseEntity<String> getResponse3 = restTemplate.exchange(BASE_URL3, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse3.getBody());
        Assert.assertNotNull(getResponse3.getBody());
        Assert.assertEquals("OK", getResponse3.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse3.getStatusCode().toString().trim());

        int elements2 = numberOfElements(getResponse.getBody());
        //Assert.assertTrue("(3) Expected 77 items in this page, found = " + elements2, elements2 == 77);
        LOGGER.info("(3) Expected 77 items in this page, found = " + elements2, elements2 == 77);

        // For 4th Page Index
        LOGGER.info("------------------ Back to 0th Page Index ------------------------ ");
        String BASE_URL4 = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&page=4&size=18";

        ResponseEntity<String> getResponse4 = restTemplate.exchange(BASE_URL4, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse4.getBody());
        Assert.assertNotNull(getResponse4.getBody());
        Assert.assertEquals("OK", getResponse4.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse4.getStatusCode().toString().trim());

        int elements3 = numberOfElements(getResponse.getBody());
        //Assert.assertTrue("(3) Expected 77 items in this page, found = " + elements3, elements3 == 77);
        LOGGER.info("(4) Expected 77 items in this page, found = " + elements3, elements3 == 77);


        // For 5th Page Index
        LOGGER.info("------------------ Back to 0th Page Index ------------------------ ");
        String BASE_URL5 = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&page=4&size=18";

        ResponseEntity<String> getResponse5 = restTemplate.exchange(BASE_URL5, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse5.getBody());
        Assert.assertNotNull(getResponse5.getBody());
        Assert.assertEquals("OK", getResponse5.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse5.getStatusCode().toString().trim());

        int elements4 = numberOfElements(getResponse.getBody());
        //Assert.assertTrue("(3) Expected 77 items in this page, found = " + elements4, elements4 == 77);
        LOGGER.info("(4) Expected 77 items in this page, found = " + elements4, elements4 == 77);
    }


    // This is XOR condition between keywords and PostalCode (finding both) - May not get data (Dr. Flinto) on 1st or
    // 2nd page, it could not any page
    @Test
    public void testGetPaginationIndexWiseforPostalCode() {
        LOGGER.info("******** GetPagination() **********");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        // For 1st Page Index
        LOGGER.info("------------------- For 0th Page Index ------------------------ ");
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=Dr, Flinto&postalCode=12345&page=1&size=10";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        int elements = numberOfElements(getResponse.getBody());
        //	Assert.assertTrue("(1) Expected 77 items in this page, found = " + elements, elements == 77);
        LOGGER.info("(1) Expected 77 items in this page, found = " + elements, elements == 77);
    }


    /**
     * PostalCode Test cases
     */

    // with keywords
    @Test
    public void testContactsByPostalCodeAndLatAndLong() {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        // For 1st Page Index
        LOGGER.info("------------------- For 1st Page Index ------------------------ ");
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?lat=38.9526439&lon=-77.3415925&keywords=Dr.,Maria&postalCode=22204&page=1&size=10";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        int elements = numberOfElements(getResponse.getBody());
        Assert.assertTrue("(1) Expected 1 item in this page, found = " + elements, elements == 1);
    }


    // without keywords
    @Test
    public void testContactsByPostalCodeAndLatAndLongWithTags() {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        // For 1st Page Index
        LOGGER.info("------------------- For 1st Page Index ------------------------ ");
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?lat=38.9526439&lon=-77.3415925&keywords=&postalCode=22204&page=1&size=10";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        int elements = numberOfElements(getResponse.getBody());
        Assert.assertTrue("(1) Expected 1 item in this page, found = " + elements, elements == 1);
    }


    @Test
    public void testContactsByPostalCodeAndLatAndLongWithTags1() {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        // For 1st Page Index
        LOGGER.info("------------------- For 1st Page Index ------------------------ ");
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?lat=38.9526439&lon=-77.3415925&keywords=&postalCode=12345&page=1&size=3";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        int elements = numberOfElements(getResponse.getBody());
        //Assert.assertTrue("(1) Expected 1 item in this page, found = " + elements, elements == 6);
    }


    // For PageIndex 1-2-1
    @Test
    public void testGetPaginationIndexWiseforPostalCodeAndTags() {
        LOGGER.info("******** GetPaginationIndexWiseforPostalCodeAndTags() **********");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);


        // For 0th Page Index
        LOGGER.info("------------------- For 1ST Page Index ------------------------ ");
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&tags=General Practice&page=1&size=10";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        int elements = numberOfElements(getResponse.getBody());
        LOGGER.info("(1) Expected Total 13 items, found = " + elements, elements == 13);
        //Assert.assertTrue("(1) Expected Total 13 items, found = " + elements, elements == 13);

        int count = numberOfProviders(getResponse.getBody());
        //Assert.assertTrue("(1) Expected 10 items in this page, found = " + count, count == 10);

        // For 1st Page Index
        LOGGER.info("------------------ For 2ND Page Index ------------------------ ");
        String BASE_URL2 = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&tags=General Practice&page=2&size=10";
        ResponseEntity<String> getResponse2 = restTemplate.exchange(BASE_URL2, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse2.getBody());
        Assert.assertNotNull(getResponse2.getBody());
        Assert.assertEquals("OK", getResponse2.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse2.getStatusCode().toString().trim());

        int elements1 = numberOfElements(getResponse.getBody());
        LOGGER.info("(1) Expected Total 13 items, found = " + elements1, elements1 == 13);
        //Assert.assertTrue("(2) Expected Total 13 items, found = " + elements1, elements1 == 13);

        int count1 = numberOfProviders(getResponse.getBody());
        //Assert.assertTrue("(2) Expected 18 items in this page, found = " + count1, count1 == 10);

        // For 0th Page Index
        LOGGER.info("------------------ Back to 1st Page Index ------------------------ ");
        String BASE_URL3 = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&tags=General Practice&page=1&size=10";

        ResponseEntity<String> getResponse3 = restTemplate.exchange(BASE_URL3, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse3.getBody());
        Assert.assertNotNull(getResponse3.getBody());
        Assert.assertEquals("OK", getResponse3.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse3.getStatusCode().toString().trim());

        int elements2 = numberOfElements(getResponse.getBody());
        LOGGER.info("(1) Expected Total 13 items, found = " + elements2, elements2 == 13);
        //	Assert.assertTrue("(2) Expected Total 13 items, found = " + elements2, elements2 == 13);

        int count2 = numberOfProviders(getResponse.getBody());
        //	Assert.assertTrue("(2) Expected 10 items in this page, found = " + count2, count2 == 10);
    }


    int numberOfElements(String json) {
        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(json);

        LOGGER.debug("Page : " + jo.get("page").toString());

        JsonObject po = jo.get("page").getAsJsonObject();
        LOGGER.debug("Page Size: " + po.get("size").getAsInt());
        LOGGER.debug("Total Elements: " + po.get("totalElements").getAsInt());
        LOGGER.debug("Total Pages: " + po.get("totalPages").getAsInt());

        return po.get("totalElements").getAsInt();
    }


    int numberOfProviders(String json) {
        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(json);

        LOGGER.debug("Content : " + jo.get("content").toString());

        JsonArray visitArray = jo.get("content").getAsJsonArray();
        Iterator<JsonElement> visitIter = visitArray.iterator();

        while (visitIter.hasNext()) {
            JsonObject vo = visitIter.next().getAsJsonObject();

            LOGGER.debug("Visit : " + vo.toString());
            if (vo.get("providerName") != null)
                LOGGER.debug("Provider: " + vo.get("providerName").getAsString());
        }

        return visitArray.size();
    }
}
