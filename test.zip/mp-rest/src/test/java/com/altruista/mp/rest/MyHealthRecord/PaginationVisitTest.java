package com.altruista.mp.rest.MyHealthRecord;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Iterator;

public class PaginationVisitTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(PaginationVisitTest.class);
    private RestTemplate restTemplate = null;
    private String JWT_TOKEN = "";
    private String MEMBER_ID = "";

    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    // Get the access token - JWT for Successful Authentication
    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "astar"); //MEMBER
        request.put("password", "Rest@n123");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        JWT_TOKEN = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(JWT_TOKEN);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", JWT_TOKEN);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);

        setMemberId();
    }

    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }

    @Test
    public void testPagination() throws IOException {
        LOGGER.info("****** Pagination() ******");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        LOGGER.info("------ For 1th Page Index ------- ");
        String BASE_URL = String.format("http://localhost:8080/mp-rest/api/visit/%s?page=1&size=3", MEMBER_ID);

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        int elements = numberOfElements(getResponse.getBody());
        Assert.assertTrue("(1) Expected 11 items in this page, found = " + elements, elements == 11);

        int count = numberOfVisits(getResponse.getBody());
        Assert.assertTrue("(1) Expected 3 items in this page, found = " + count, count == 3);

        LOGGER.info("------------------ For 2nd Page Index ------------------------ ");
        String BASE_URL2 = String.format("http://localhost:8080/mp-rest/api/visit/%s?page=2&size=3", MEMBER_ID);
        ResponseEntity<String> getResponse2 = restTemplate.exchange(BASE_URL2, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse2.getBody());

        Assert.assertNotNull(getResponse2.getBody());
        Assert.assertEquals("OK", getResponse2.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse2.getStatusCode().toString().trim());

        int count2 = numberOfVisits(getResponse2.getBody());
        Assert.assertTrue("(2) Expected 3 items in this page, found = " + count2, count2 == 3);

        LOGGER.info("------------------  For 3rd Page Index ------------------------ ");
        String BASE_URL3 = String.format("http://localhost:8080/mp-rest/api/visit/%s?page=3&size=3", MEMBER_ID);

        ResponseEntity<String> getResponse3 = restTemplate.exchange(BASE_URL3, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse3.getBody());
        Assert.assertNotNull(getResponse3.getBody());
        Assert.assertEquals("OK", getResponse3.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse3.getStatusCode().toString().trim());

        int count3 = numberOfVisits(getResponse3.getBody());
        Assert.assertTrue("(3) Expected 3 items in this page, found = " + count3, count3 == 3);

        LOGGER.info("------------------  For 3rd Page Index ------------------------ ");
        String BASE_URL4 = String.format("http://localhost:8080/mp-rest/api/visit/%s?page=4&size=3", MEMBER_ID);

        ResponseEntity<String> getResponse4 = restTemplate.exchange(BASE_URL4, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse4.getBody());
        Assert.assertNotNull(getResponse4.getBody());
        Assert.assertEquals("OK", getResponse4.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse4.getStatusCode().toString().trim());

        int count4 = numberOfVisits(getResponse4.getBody());
        Assert.assertTrue("(4) Expected 2 items in this page, found = " + count4, count4 == 2);

    }

    @Test
    public void testPaginationWithoutPageIndexAndSize() {
        LOGGER.info("****** PaginationWithoutPageIndexAndSize() ******");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        // For 0th Page Index
        LOGGER.info("------ For 0th Page Index ------- ");
        String BASE_URL = "http://localhost:8080/mp-rest/api/visit/bd1aa955-c96e-41f2-af78-00590a38074a";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());
    }

    int numberOfVisits(String json) {
        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(json);

        LOGGER.debug("Content : " + jo.get("content").toString());

        JsonArray visitArray = jo.get("content").getAsJsonArray();
        Iterator<JsonElement> visitIter = visitArray.iterator();

        while (visitIter.hasNext()) {
            JsonObject vo = visitIter.next().getAsJsonObject();

            LOGGER.debug("Visit : " + vo.toString());
            if (vo.get("providerName") != null)
                LOGGER.debug("Provider: " + vo.get("providerName").getAsString());
        }

        return visitArray.size();
    }

    int numberOfElements(String json) {
        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(json);

        LOGGER.debug("Page : " + jo.get("page").toString());

        JsonObject po = jo.get("page").getAsJsonObject();
        LOGGER.debug("Page Size: " + po.get("size").getAsInt());
        LOGGER.debug("Total Elements: " + po.get("totalElements").getAsInt());
        LOGGER.debug("Total Pages: " + po.get("totalPages").getAsInt());

        return po.get("totalElements").getAsInt();
    }

}
