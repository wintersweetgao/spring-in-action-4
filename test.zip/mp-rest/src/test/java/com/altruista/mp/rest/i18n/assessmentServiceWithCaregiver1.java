package com.altruista.mp.rest.i18n;

import com.altruista.mp.services.exceptions.ServiceException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Properties;

/*
 * 
*/
public class assessmentServiceWithCaregiver1 {
    private static final Logger LOGGER = LoggerFactory.getLogger(assessmentServiceWithCaregiver1.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private Properties prop = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        prop = new Properties();
        prop.load(assessmentServiceWithCaregiver1.class.getClassLoader().getResourceAsStream("caregiver.properties"));

        // create request body
        JSONObject request = new JSONObject();
        request.put("username", prop.getProperty("mp.username"));
        request.put("password", prop.getProperty("mp.password"));


        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------------  Load the User from the mongodb -------------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("susan", username);
        //Assert.assertEquals("victoria", username);
        Assert.assertEquals("Jefferson", removeDoubleQuotes(jo.get("lastName").toString()));
    }

    /**
     * resulted in 403 (Prohibido)
     */
    @Test
    public void API_ACCESS_AssessmentRun_Test() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }


    @Test
    public void getAssessment() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessment/71efc277-5939-4df2-8301-a8adefffccae";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    @Test
    public void getAllAssessmentNamesByMemberId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessment/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/names/";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    @Test
    public void saveAssessmentRun() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/6ba90596-38c0-4375-b29e-b50cd156cb43";


        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }

    }

    @Test
    public void getAssessmentResponseByRunId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"question\":{\"refId\":\"7\",\"question\":"
                + "\"Does the call result in a successful contact with the member or care giver?\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":1,\"isRequired\":false,"
                + "\"options\":[{\"refId\":\"9\",\"optionText\":\"Successful contact\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":1,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[{\"refId\":\"1\",\"optionText\":\"Select the person\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":0}]},{\"refId\":\"10\",\"optionText\":\"Unsuccessful contact-Left message\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":2,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},{\"refId\":\"11\",\"optionText\":\"Unsuccessful contact- Number disconnected\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":3,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,"
                + "\"subOptions\":[]},{\"refId\":\"12\",\"optionText\":\"Unsuccessful contact-Wrong Number\","
                + "\"optionType\":\"RadioButtonList\",\"sequence\":4,\"nextQuestionRefId\":\"8\","
                + "\"nextQuestionSequence\":2,\"subOptions\":[]},{\"refId\":\"13\","
                + "\"optionText\":\"\\nUnsuccessful contact- Member wants to reschedule\",\"optionType\":\"RadioButtonList\","
                + "\"sequence\":5,\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,\"subOptions\":[]}],"
                + "\"active\":true,\"optionModelRadio\":\"9\"},\"option\":{\"refId\":\"9\","
                + "\"optionText\":\"Successful contact\",\"optionType\":\"RadioButtonList\",\"sequence\":1,"
                + "\"nextQuestionRefId\":\"8\",\"nextQuestionSequence\":2,\"subOptions\":[{\"refId\":\"1\","
                + "\"optionText\":\"Select the person\",\"optionType\":\"RadioButtonList\",\"sequence\":0}]},"
                + "\"optionValue\":\"9\",\"subOption\":null,\"subOptionValue\":null}";

        //getRequest.put("json", json);
        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        //String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/ae1294b8-f99e-4841-aada-4fd6d5123579/assessmentResponse/";
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/d33f9671-c34e-4151-ada8-04dd5204b9ad/assessmentResponse";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    @Test
    public void createAssessmentResponse() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
                + "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/0034a5b3-4f51-45b1-b186-ee16373a9fe7/assessmentResponse/";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }

    }

    @Test
    public void saveAssessmentRunStatus() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

		/*String json="{\"assessmentId\":\"71efc277-5939-4df2-8301-a8adefffccae\","
                + "\"assessmentName\":\"Wheelchair Assessment AHS\","
				+ "\"startedOn\":\"2015-04-27T08:47:22.635Z\"}";*/
        String json = "{\"status\":\"Pending\",\"lastSequence\":10}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/0034a5b3-4f51-45b1-b186-ee16373a9fe7/status/";


        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }

    }

    @Test
    public void saveAssessmentResponse() {
        LOGGER.debug("\n------------  Get the Contact API ---------");


        String json = "{\"status\":\"Pending\",\"lastSequence\":10}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentResponse/b9f74653-752a-4ec7-ac57-6dff14ccb12e";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }

    }

}

