package com.altruista.mp.rest.MMC;

import com.altruista.mp.model.Address;
import com.altruista.mp.model.Enrollment;
import com.altruista.mp.resources.AddressResource;
import com.altruista.mp.resources.EnrollmentResource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.text.SimpleDateFormat;

public class MMCModelvalidationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MMCModelvalidationTest.class);

    private RestTemplate restTemplate = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = removeDoubleQuotes(jo.get("token").toString());

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);

        RestTemplate rt = new RestTemplate();
        String URL = "http://localhost:8080/mp-rest/api/user";

        setMemberId();

        HttpEntity<String> _entity_ = new HttpEntity<String>(getRequest.toString(), headers);
        @SuppressWarnings("unused")
        ResponseEntity<String> resp = rt.exchange(URL, HttpMethod.GET, _entity_, String.class);
    }


    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }

    // Added Test cases for testing QAUHG issue
    @Test
    public void saveEnrollmentforRefugeeNumberForRavi() throws JsonProcessingException {
        LOGGER.debug("******  saveEnrollment() *******");
        EnrollmentResource enrollment = new EnrollmentResource();
        enrollment.setMemberId(MEMBER_ID);
        enrollment.setFirstName("AADE");
        //enrollment.setMiddleName("");
        enrollment.setLastName("NOURI");
        enrollment.setRefugeeNumber("123");
        enrollment.setMobilePhoneNumber("");
        enrollment.setPrimaryEmail("test@test.com");
        enrollment.setProgramName("MyMoneyConnect");

        AddressResource address = new AddressResource();
        address.setPrimary(true);
        address.setAddress("memb add");
        address.setAddress2("411 N BINGHAM AVE");
        address.setCity("SOMERTON");
        address.setStateProvince("AZ");
        address.setPostalCode("88350");
        enrollment.setAddress(address);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(enrollment);

        System.out.println("JSON: " + json);

        String BASE_URL = "http://localhost:8080/mp-rest/api/enrollment";
        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, deleteEntity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    // Only one test case will need to execute at a time
    @Test
    public void saveEnrollmentforITIN() throws JsonProcessingException {
        LOGGER.debug("******  saveEnrollment() *******");
        EnrollmentResource enrollment = new EnrollmentResource();
        enrollment.setMemberId(MEMBER_ID);
        enrollment.setFirstName("Victoria");
        enrollment.setMiddleName("M.");
        enrollment.setLastName("Jefferson");
        enrollment.setItin("123");
        enrollment.setMobilePhoneNumber("(619) 555-1212");
        enrollment.setPrimaryEmail("test@test.com");
        enrollment.setProgramName("MyMoneyConnect");

        AddressResource address = new AddressResource();
        address.setPrimary(true);
        address.setAddress("4414 Bluejay Court");
        address.setAddress2("Courtyard Terrace");
        address.setCity("Oakland");
        address.setStateProvince("CA");
        address.setPostalCode("92345");
        enrollment.setAddress(address);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(enrollment);

        System.out.println("JSON: " + json);

        String BASE_URL = "http://localhost:8080/mp-rest/api/enrollment";
        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, deleteEntity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }


    @Test
    public void saveEnrollmentforRefugeeNumber() throws JsonProcessingException {
        LOGGER.debug("******  saveEnrollment() *******");
        EnrollmentResource enrollment = new EnrollmentResource();
        enrollment.setMemberId(MEMBER_ID);
        enrollment.setFirstName("Victoria");
        enrollment.setMiddleName("M.");
        enrollment.setLastName("Jefferson");
        enrollment.setRefugeeNumber("123");
        enrollment.setMobilePhoneNumber("(619) 555-1212");
        enrollment.setPrimaryEmail("test@test.com");
        enrollment.setProgramName("MyMoneyConnect");

        AddressResource address = new AddressResource();
        address.setPrimary(true);
        address.setAddress("4414 Bluejay Court");
        address.setAddress2("Courtyard Terrace");
        address.setCity("Oakland");
        address.setStateProvince("CA");
        address.setPostalCode("92345");
        enrollment.setAddress(address);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(enrollment);

        System.out.println("JSON: " + json);

        String BASE_URL = "http://localhost:8080/mp-rest/api/enrollment";
        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, deleteEntity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    //@Test
    public void saveEnrollmentforSSN() throws JsonProcessingException {
        LOGGER.debug("******  saveEnrollment() *******");
        EnrollmentResource enrollment = new EnrollmentResource();
        enrollment.setMemberId(MEMBER_ID);
        enrollment.setFirstName("Victoria");
        enrollment.setMiddleName("M.");
        enrollment.setLastName("Jefferson");
        enrollment.setSsn("123-45-6789");
        enrollment.setMobilePhoneNumber("(619) 555-1212");
        enrollment.setPrimaryEmail("test@test.com");
        enrollment.setProgramName("MyMoneyConnect");

        AddressResource address = new AddressResource();
        address.setPrimary(true);
        address.setAddress("4414 Bluejay Court");
        address.setAddress2("Courtyard Terrace");
        address.setCity("Oakland");
        address.setStateProvince("CA");
        address.setPostalCode("92345");
        enrollment.setAddress(address);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(enrollment);

        System.out.println("JSON: " + json);

        String url = "http://localhost:8080/mp-rest/api/enrollment/ssn/" + MEMBER_ID;
        HttpEntity<String> checkEntity = new HttpEntity<String>(json, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, checkEntity, String.class);

        String BASE_URL = "http://localhost:8080/mp-rest/api/enrollment";
        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, deleteEntity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }


    ///////////////////////////

    @Test
    public void testSubmitEnrollmentForWrongFormat() throws JsonProcessingException {
        LOGGER.debug("******  testSubmitEnrollment() *******");

        Enrollment enrollment = new Enrollment();
        enrollment.setMemberId(MEMBER_ID);
        enrollment.setFirstName("Victoria");
        enrollment.setMiddleName("M.");
        enrollment.setLastName("Jefferson");
        enrollment.setSsn("123456789"); // wrong format
        enrollment.setMobilePhoneNumber("619-555-1212"); //Wrong Format
        enrollment.setPrimaryEmail("test.test.com");  //Wrong Format

        Address address = new Address();
        address.setPrimary(true);
        address.setAddress("4414 Bluejay Court");
        address.setAddress2("Courtyard Terrace");
        address.setCity("Oakland");
        address.setStateProvince("CA");
        address.setPostalCode("92345");
        enrollment.setAddress(address);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        String json = mapper.writeValueAsString(enrollment);

        System.out.println("JSON: " + json);


        String BASE_URL = "http://localhost:8080/mp-rest/api/enrollment";
        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, deleteEntity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response Error : [" + e.getMessage() + "]");
            Assert.assertEquals("422 Unprocessable Entity", e.getMessage());
        }
    }


    @Test
    public void testSubmitEnrollmentForHTML() throws JsonProcessingException {
        LOGGER.debug("******  testSubmitEnrollment() *******");

        Enrollment enrollment = new Enrollment();
        enrollment.setMemberId(MEMBER_ID);
        enrollment.setFirstName("Victoria");
        enrollment.setMiddleName("M.");
        enrollment.setLastName("Jefferson");
        enrollment.setSsn("123-45-6789"); // wrong format
        enrollment.setMobilePhoneNumber("<a>619-555-1212</a>"); //Wrong Format
        enrollment.setPrimaryEmail("<a>test@test.com</a>");  //Wrong Format

        Address address = new Address();
        address.setPrimary(true);
        address.setAddress("4414 Bluejay Court");
        address.setAddress2("Courtyard Terrace");
        address.setCity("Oakland");
        address.setStateProvince("CA");
        address.setPostalCode("92345");
        enrollment.setAddress(address);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        String json = mapper.writeValueAsString(enrollment);

        System.out.println("JSON: " + json);


        String BASE_URL = "http://localhost:8080/mp-rest/api/enrollment";
        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, deleteEntity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response Error : [" + e.getMessage() + "]");
            Assert.assertEquals("422 Unprocessable Entity", e.getMessage());
        }
    }
}
