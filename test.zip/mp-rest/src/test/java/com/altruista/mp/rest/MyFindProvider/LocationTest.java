package com.altruista.mp.rest.MyFindProvider;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;

/**
 * Created by mwixson on 5/26/15.
 */
public class LocationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(LocationTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private Properties prop = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        prop = new Properties();
        prop.load(LocationTest.class.getClassLoader().getResourceAsStream("member.properties"));

        // create request body
        JSONObject request = new JSONObject();
        request.put("username", prop.getProperty("mp.username"));
        request.put("password", prop.getProperty("mp.password"));


        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void getProvidersNearLocation() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location ---------");

        //-77.34952, 38.95451
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.8567437&lat=18.520430299999997&radius=20";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

		/*JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/
        LOGGER.debug("Providers near me: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertTrue(response.getBody().contains("Kumar"));
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void getProvidersNearLocationAndKeyword() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location ---------");

        //-77.34952, 38.95451
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.8567437&lat=18.520430299999997&radius=20&keywords=Vinod";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/
        LOGGER.debug("Providers near me: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
        Assert.assertTrue(response.getBody().contains("Kumar"));
    }

    @Test
    public void getProvidersNearLocationAndKeywords() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location ---------");

        //-77.34952, 38.95451
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.8567437&lat=18.520430299999997&radius=20&keywords=Kumar,Dr.";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/
        LOGGER.debug("Providers near me: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
        Assert.assertTrue(response.getBody().contains("Kumar"));
    }


    /**
     * Find Contact using Point, Radius, keywords, Size=1
     */
    @Test
    public void getProvidersNearLocationAndKeywordsForUser() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location, 1st Page ---------");

        //-77.34952, 38.95451
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.776640&lat=18.574730&radius=20&keywords=Vinod&page=1&size=1";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 1st Page: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        int elements = numberOfElements(response.getBody());
        LOGGER.info("(1) Expected items, found = " + elements, elements == 1);

        LOGGER.debug("---- 2nd Page ----");
        String url2 = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.776640&lat=18.574730&radius=20&keywords=Vinod&page=2&size=1";
        ResponseEntity<String> response2 = restTemplate.exchange(url2, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 2nd Page: " + response2.getBody());
        Assert.assertNotNull(response2);
        Assert.assertEquals("OK", response2.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response2.getStatusCode().toString().trim());

        int elements2 = numberOfElements(response2.getBody());
        LOGGER.info("(1) Expected items, found = " + elements2, elements2 == 1);


        LOGGER.debug("---- 3rd Page ----");
        String url3 = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.776640&lat=18.574730&radius=20&keywords=Vinod&page=3&size=1";
        ResponseEntity<String> response3 = restTemplate.exchange(url3, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 3rd Page: " + response3.getBody());
        Assert.assertNotNull(response3);
        Assert.assertEquals("OK", response3.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response3.getStatusCode().toString().trim());

        int elements3 = numberOfElements(response3.getBody());
        LOGGER.info("(3) Expected items, found = " + elements3, elements3 == 1);
    }


    /**
     * Find Contact using Point, Radius, keywords, Size=1 and Tags
     */
    @Test
    public void getProvidersNearLocationAndKeywordsAndTagsForUser() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location, 1st Page ---------");

        //-77.34952, 38.95451
        LOGGER.debug("---- 1st Page ----");
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.776640&lat=18.574730&radius=20&keywords=Vinod&tags=General Practice&page=1&size=1";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 1st Page: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        int elements = numberOfElements(response.getBody());
        LOGGER.info("(1) Expected items, found = " + elements, elements == 1);

        LOGGER.debug("---- 2nd Page ----");
        String url2 = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.776640&lat=18.574730&radius=20&keywords=Vinod&tags=General Practice&page=2&size=1";
        ResponseEntity<String> response2 = restTemplate.exchange(url2, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 2nd Page: " + response2.getBody());
        Assert.assertNotNull(response2);
        Assert.assertEquals("OK", response2.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response2.getStatusCode().toString().trim());

        int elements2 = numberOfElements(response2.getBody());
        LOGGER.info("(1) Expected items, found = " + elements2, elements2 == 1);
        
        
        /*LOGGER.debug("---- 3rd Page ----");
        String url3 = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.776640&lat=18.574730&radius=20&keywords=Vinod&tags=General Practice&page=3&size=1";
        ResponseEntity<String> response3 = restTemplate.exchange(url3, HttpMethod.GET, entity, String.class);
        
        LOGGER.debug("Providers near me on 3rd Page: "+response3.getBody());
        Assert.assertNotNull(response3);
        Assert.assertEquals("OK", response3.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response3.getStatusCode().toString().trim());
        
        int elements3 = numberOfElements(response3.getBody());
        LOGGER.info("(3) Expected items, found = " + elements3, elements3 == 1);*/
    }


    /**
     * Find Contact using PostalCode
     */
    @Test
    public void getProvidersUsingPostalCodes() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location, 1st Page ---------");

        //-77.34952, 38.95451
        LOGGER.debug("---- 1st Page ----");
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?postalCode=12345&page=1&size=1";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 1st Page: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        int elements = numberOfElements(response.getBody());
        LOGGER.info("(1) Expected items, found = " + elements, elements == 1);

        LOGGER.debug("---- 2nd Page ----");
        String url2 = "http://localhost:8080/mp-rest/api/contact/contactDistance?postalCode=12345&page=2&size=1";
        ResponseEntity<String> response2 = restTemplate.exchange(url2, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 2nd Page: " + response2.getBody());
        Assert.assertNotNull(response2);
        Assert.assertEquals("OK", response2.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response2.getStatusCode().toString().trim());

        int elements2 = numberOfElements(response2.getBody());
        LOGGER.info("(1) Expected items, found = " + elements2, elements2 == 1);


        LOGGER.debug("---- 3rd Page ----");
        String url3 = "http://localhost:8080/mp-rest/api/contact/contactDistance?postalCode=12345&page=3&size=1";
        ResponseEntity<String> response3 = restTemplate.exchange(url3, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 3rd Page: " + response3.getBody());
        Assert.assertNotNull(response3);
        Assert.assertEquals("OK", response3.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response3.getStatusCode().toString().trim());

        int elements3 = numberOfElements(response3.getBody());
        LOGGER.info("(3) Expected items, found = " + elements3, elements3 == 1);


        LOGGER.debug("---- 4th Page ----");
        String url4 = "http://localhost:8080/mp-rest/api/contact/contactDistance?postalCode=12345&page=4&size=1";
        ResponseEntity<String> response4 = restTemplate.exchange(url4, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 4th Page: " + response4.getBody());
        Assert.assertNotNull(response4);
        Assert.assertEquals("OK", response4.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response4.getStatusCode().toString().trim());

        int elements4 = numberOfElements(response4.getBody());
        LOGGER.info("(4) Expected items, found = " + elements4, elements4 == 1);
    }


    /**
     * Find Contact using PostalCode
     */
    @Test
    public void getProvidersUsingPostalCodesSelect() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location, 1st Page ---------");

        //-77.34952, 38.95451
        LOGGER.debug("---- 1st Page ----");
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?postalCode=12345&page=1&size=10";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 1st Page: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        int elements = numberOfElements(response.getBody());
        LOGGER.info("(1) Expected items, found = " + elements, elements == 1);

        LOGGER.debug("---- 2nd Page ----");
        String url2 = "http://localhost:8080/mp-rest/api/contact/contactDistance?postalCode=12345&page=2&size=10";
        ResponseEntity<String> response2 = restTemplate.exchange(url2, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 2nd Page: " + response2.getBody());
        Assert.assertNotNull(response2);
        Assert.assertEquals("OK", response2.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response2.getStatusCode().toString().trim());

        int elements2 = numberOfElements(response2.getBody());
        LOGGER.info("(1) Expected items, found = " + elements2, elements2 == 1);


        LOGGER.debug("---- 3rd Page ----");
        String url3 = "http://localhost:8080/mp-rest/api/contact/contactDistance?postalCode=12345&page=1&size=10";
        ResponseEntity<String> response3 = restTemplate.exchange(url3, HttpMethod.GET, entity, String.class);

        LOGGER.debug("Providers near me on 3rd Page: " + response3.getBody());
        Assert.assertNotNull(response3);
        Assert.assertEquals("OK", response3.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response3.getStatusCode().toString().trim());

        int elements3 = numberOfElements(response3.getBody());
        LOGGER.info("(3) Expected items, found = " + elements3, elements3 == 1);
    }


    @Test
    public void getProvidersNearLocationAndTagAndKeyword() {
        // NOTE: db.contact.ensureIndex( { "address.position" : "2dsphere" } )
        LOGGER.debug("\n------------  Get Providers Near Location ---------");

        //-77.34952, 38.95451
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String url = "http://localhost:8080/mp-rest/api/contact/contactDistance?lon=73.8567437&lat=18.520430299999997&radius=20&keywords=Kumar";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/
        LOGGER.debug("Providers near me: " + response.getBody());

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
        Assert.assertTrue(response.getBody().contains("Kumar"));
    }


    int numberOfElements(String json) {
        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(json);

        LOGGER.debug("Page : " + jo.get("page").toString());

        JsonObject po = jo.get("page").getAsJsonObject();
        LOGGER.debug("Page Size: " + po.get("size").getAsInt());
        LOGGER.debug("Total Elements: " + po.get("totalElements").getAsInt());
        LOGGER.debug("Total Pages: " + po.get("totalPages").getAsInt());

        return po.get("totalElements").getAsInt();
    }


    int numberOfProviders(String json) {
        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(json);

        LOGGER.debug("Content : " + jo.get("content").toString());

        JsonArray providerArray = jo.get("content").getAsJsonArray();
        Iterator<JsonElement> visitIter = providerArray.iterator();

        while (visitIter.hasNext()) {
            JsonObject vo = visitIter.next().getAsJsonObject();

            LOGGER.debug("Visit : " + vo.toString());
            if (vo.get("providerName") != null)
                LOGGER.debug("Provider: " + vo.get("providerName").getAsString());
        }

        return providerArray.size();
    }
}
