package com.altruista.mp.rest.MyFindProvider;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

/**
 * Developed by Prateek on 09/22/15
 */

public class CareGiverFindProviderTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareGiverFindProviderTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    // Get the access token - JWT for Successful Authentication
    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "susan");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }


    // Get Distance between two lat & lon with tag
    @Test
    public void getDistanceforLatAndLon() {
        LOGGER.debug("----- Get Distance for Lat and long with tags -----");
        ResponseEntity<String> getResponse = null;
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=&postalCode=12345&page=1&size=18";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (Exception e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // Get Distance between two lat & lon without tag
    @Test
    public void getDistanceforLatAndLonWithoutTags() {
        LOGGER.debug("----- Get Distance for Lat and long without tags -----");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        ResponseEntity<String> getResponse = null;

        // 12001 Sunrise Valley Dr Reston, VA, United States (38.9456827,-77.360861)
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=dr.,maria&lat=38.9526439&lon=-77.3415925&radius=20&page=1&size=10";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (Exception e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }


    // Get Distance for Lat and long with tags and without keywords
    @Test
    public void getDistanceforLatAndLonWithTagsWithoutKeyword() {
        LOGGER.debug("----- Get Distance for Lat and long with tags and without keywords -----");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        ResponseEntity<String> getResponse = null;

        // 12001 Sunrise Valley Dr Reston, VA, United States (38.9456827,-77.360861)
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?lat=38.9526439&lon=-77.3415925&radius=20&tags=Cardiology&page=1&size=5";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (Exception e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }


    // Get the Contacts using PostalCode with tags
    @Test
    public void getContactsforPostalCode() {
        LOGGER.debug("----- Get Contacts for PostalCode -----");
        ResponseEntity<String> getResponse = null;

        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=Dr.,Maria&postalCode=22204&tags=General Practice&page=1&size=5";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (Exception e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }


    // Get Contacts using keyword and PostalCode
    @Test
    public void getContactsforPostalCodeWithoutTags() {
        LOGGER.debug("----- Get Contacts for PostalCode without Tags -----");
        ResponseEntity<String> getResponse = null;

        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?keywords=Dr.,Maria&postalCode=22204&page=1&size=5";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (Exception e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }


    // Get Contacts using PostalCode and Lat And lon and Keywords
    @Test
    public void getContactsByPostalCodeAndLatAndLong() {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/contactDistance?lat=38.9526439&lon=-77.3415925&keywords=Dr.,Maria&postalCode=22204&page=1&size=5";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (Exception e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }
}
