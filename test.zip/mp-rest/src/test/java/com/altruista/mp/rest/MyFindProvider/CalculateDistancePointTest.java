package com.altruista.mp.rest.MyFindProvider;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Distance is calculated using Great Distance Formula
*/
public class CalculateDistancePointTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CalculateDistancePointTest.class);

    @Test
    public void testGetDistanceUsingMathAlgorith() {
        //1946 Isaac Newton Square Reston, VA, 20190
        Double lat1 = 38.95296;
        Double lon1 = -77.346809;
        double x1 = Math.toRadians(lat1);
        double y1 = Math.toRadians(lon1);

        //11480 Sunset Hills Road, Reston, VA, 20190
        Double lat2 = 38.9522717781168;
        Double lon2 = -77.3397555318337;
        double x2 = Math.toRadians(lat2);
        double y2 = Math.toRadians(lon2);

        double sec1 = Math.sin(x1) * Math.sin(x2);
        double dl = Math.abs(y1 - y2);
        double sec2 = Math.cos(x1) * Math.cos(x2);

        double centralAngle = Math.acos(sec1 + sec2 * Math.cos(dl));
        //Radius of Earth: 6378.1 kilometers
        //1 KM  = 0.621371 Miles
        double distance = centralAngle * 6378.1 * 0.621371;
        LOGGER.info("Distance in Miles : " + distance);

        Assert.assertEquals("0.38239070130324276", String.valueOf(distance));
    }

    @Test
    public void testGetDistanceUsingMathAlgorith1() {
        // 12001 Sunrise Valley Dr Reston, VA, United States
        Double lat1 = 38.9456827;
        Double lon1 = -77.360861;
        double x1 = Math.toRadians(lat1);
        double y1 = Math.toRadians(lon1);

        //11480 Sunset Hills Road, Reston, VA, 20190
        Double lat2 = 38.9526439;
        Double lon2 = -77.3415925;
        double x2 = Math.toRadians(lat2);
        double y2 = Math.toRadians(lon2);

        double sec1 = Math.sin(x1) * Math.sin(x2);
        double dl = Math.abs(y1 - y2);
        double sec2 = Math.cos(x1) * Math.cos(x2);

        double centralAngle = Math.acos(sec1 + sec2 * Math.cos(dl));
        //Radius of Earth: 6378.1 kilometers
        //1 KM  = 0.621371 Miles
        double distance = centralAngle * 6378.1;
        LOGGER.info("Distance in Miles : " + distance);
        Assert.assertEquals("1.8393371036638735", String.valueOf(distance));
    }
}
