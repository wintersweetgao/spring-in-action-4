package com.altruista.mp.rest.MyHealthTrackers;

import com.altruista.mp.resources.TrackerRecordResource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

public class CareGiverMyHealthRecordTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareGiverMyHealthRecordTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "susan");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);

        setMemberId();
    }

    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }

    // /api/trackerCategory
    @Test
    public void testTrackerCategory() {
        LOGGER.debug("--- testTrackerCategory ---");
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest//api/trackerCategory";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            LOGGER.error("Response : [" + getResponse + "]");
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }

    }

    @Test
    public void testTrackerRecord() throws JsonProcessingException {
        LOGGER.debug("\n------  Update Contact Info ---------");

        TrackerRecordResource trackerRecord = new TrackerRecordResource();
        trackerRecord.setParameterId("3");
        trackerRecord.setParameterName("Height");
        trackerRecord.setRecordedOn(formatter.parseDateTime("2015-10-07T18:30:00.000Z"));
        trackerRecord.setUom("Cms");
        trackerRecord.setValue("174");
        trackerRecord.setMemberId(MEMBER_ID);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(trackerRecord);

        ResponseEntity<String> getResponse = null;

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : " + getResponse);
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }
}
