package com.altruista.mp.rest.MyHealthTrackers;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

/*
 * Refactored by Prateek on 09/22/15
 */
public class CareGiverMyHealthTrackersTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareGiverMyHealthTrackersTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "susan");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);

        setMemberId();
    }

    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }

    // /api/trackerCategory
    // https://demo.personalcarerecord.com:9443/DEVL-rest/api/trackerCategory
    @Test
    public void testTrackerCategory() {
        LOGGER.info("**** testMyHealthTracker() *****");
        HttpEntity<String> getentity = new HttpEntity<String>(getRequest.toString(), headers);

        String url = "http://localhost:8080/mp-rest/api/trackerCategory";
        ResponseEntity<String> getResponse = null;
        try {
            getResponse = restTemplate.exchange(url, HttpMethod.GET, getentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // /api/member/{memberId}/{trackerId}/trackerRecord
    @Test
    public void testListofMyHealthTracker() {
        LOGGER.info("**** testMyHealthTracker() *****");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        ResponseEntity<String> getResponse = null;
        String BASE_URL = "http://localhost:8080/mp-rest/api/member/" + MEMBER_ID + "/8a0e2953-026b-4258-9ad5-80f94fc979d3/"
                + "trackerRecord?endDate=2015-09-21T19:08:57.706Z&startDate=2015-01-01T18:29:59.000Z";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // /api/trackerRecord
    @Test
    public void testAddNewValue() {
        System.out.println("\n----testAddNewValue() -------");

        ResponseEntity<String> getResponse = null;

        String json = "{\"parameterId\":\"4\",\"parameterName\":\"Weight\",\"recordedOn\":\"2015-09-21T18:30:00.000Z\",\"uom\":\"Pounds\",\"value\":\"111\","
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"trackerId\":\"8a0e2953-026b-4258-9ad5-80f94fc979d3\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/trackerRecord/";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }
}
