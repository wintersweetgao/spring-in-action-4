package com.altruista.mp.rest.i18n;

import com.altruista.mp.services.exceptions.ServiceException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Properties;

/*
 * Developed by Prateek on 04/25/15
*/
public class LanguageValidationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(LanguageValidationTest.class);

    private static Properties prop = null;
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private JSONObject getRequest = null;
    private static HttpHeaders headers = null;


    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");

        prop = new Properties();
        try {
            prop.load(LanguageValidationTest.class.getClassLoader().getResourceAsStream("credentials.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Before
    public void beforeTest() {
        /** create request body */
        JsonObject request = new JsonObject();
        request.addProperty("username", prop.getProperty("mp.username"));
        request.addProperty("password", prop.getProperty("mp.password"));

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        restTemplate = new RestTemplate();
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        /** parse the JSON Response */
        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = removeDoubleQuotes(jo.get("token").toString());

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        /** set JWT token to header to use it for another web service */
        headers.add("X-Auth-Token", jwtToken);


        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }


    @Test
    public void BadCredentialsTest() throws RestClientException {
        System.out.println("----  BadCredentaisl Test case  -------");
        /** create request body with wrong userId and Password */
        JsonObject request = new JsonObject();
        request.addProperty("username", "victoria");
        request.addProperty("password", "agilenova");

        /** set headers */
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        // send request and parse result
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException rce) {
            Assert.assertEquals("401 Unauthorized", rce.getMessage());
        }
    }


    @Test
    public void API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------ Load the login User from the mongodb --------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/user";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        System.out.println("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("victoria", username);
        Assert.assertEquals("Jefferson", removeDoubleQuotes(jo.get("lastName").toString()));
    }


    @Test
    public void API_CONTACT_Test() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String primaryEmail = removeDoubleQuotes(jo.get("primaryEmail").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
        Assert.assertEquals("mwixson@altruistahealth.com", primaryEmail);
        Assert.assertEquals("619-555-1212", removeDoubleQuotes(jo.get("phoneNumber").toString()));
        Assert.assertEquals("619-555-1333", removeDoubleQuotes(jo.get("faxNumber").toString()));

        JsonObject jsonObject = jo.getAsJsonObject("address");
        Assert.assertEquals("CA", removeDoubleQuotes(jsonObject.get("stateProvince").toString()));
        Assert.assertEquals("Oakland", removeDoubleQuotes(jsonObject.get("city").toString()));
    }


    // Valid Request ==>Positive Testing
    @Test
    public void CONTACT_PUT_Test() {
        System.out.println("----  API Contact PUT -----");

        String validJson = "{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"Victoria\",\"middleName\":\"M.\","
                + "\"lastName\":\"Jefferson\",\"primaryEmail\":\"mwixson@altruistahealth.com\",\"primaryLanguage\":\"ENGL\","
                + "\"preferredTimeOfContact\":\"Monday:Morning\",\"address\":{\"primary\":true,\"address\":\"USA\","
                + "\"address2\":\"Courtyard Terrace\",\"city\":\"Oakland\",\"stateProvince\":\"CA\",\"postalCode\":\"92345\"},"
                + "\"phoneNumber\":\"619-555-1212\",\"faxNumber\":\"619-555-1333\",\"ethnicity\":\"5\",\"gender\":\"F\","
                + "\"dob\":\"1988-2-24\",\"maritalStatus\":\"M\",\"timezone\":\"America/New_York\","
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8080/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]}";


		/*HttpEntity<String> entity = new HttpEntity<String>(jobj.toString(),headers);
        restTemplate.put("http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d",entity);*/

        HttpEntity<String> putentity = new HttpEntity<String>(validJson, headers);
        ResponseEntity<String> getResponse = restTemplate.exchange("http://localhost:8080/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d",
                HttpMethod.PUT, putentity, String.class);

        System.out.println(getResponse);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());
    }


    @Test
    public void Negative_CONTACT_PUT_Test() {
        System.out.println("------------- Invalid Contact Data Test Case   --------------");

        String invalidJson = "{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"VictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoriaVictoria\",\"middleName\":\"M.\","
                + "\"lastName\":\"Jefferson\",\"primaryEmail\":\"mwixsonaltruistahealth.com\",\"primaryLanguage\":\"ENGL\","
                + "\"preferredTimeOfContact\":\"Monday:Morning\",\"address\":{\"primary\":true,\"address\":\"USA\","
                + "\"address2\":\"Courtyard Terrace\",\"city\":\"Oakland\",\"stateProvince\":\"CA\",\"postalCode\":\"92345\"},"
                + "\"phoneNumber\":\"\",\"faxNumber\":\"619-555-1333\",\"ethnicity\":\"5\",\"gender\":\"11\","
                + "\"dob\":\"1988-2-241\",\"maritalStatus\":\"M\",\"timezone\":\"America/New_York\","
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8080/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]}";


        HttpEntity<String> putentity = new HttpEntity<String>(invalidJson, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d";
        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            System.out.println(e.getMessage());
            Assert.assertEquals("422 Unprocessable Entity", e.getMessage());
        }
    }
}
