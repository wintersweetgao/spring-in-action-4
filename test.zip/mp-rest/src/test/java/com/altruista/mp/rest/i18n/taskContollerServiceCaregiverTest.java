package com.altruista.mp.rest.i18n;

import com.altruista.mp.services.exceptions.ServiceException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Properties;

/*
 * 
 */
public class taskContollerServiceCaregiverTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(taskContollerServiceCaregiverTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private Properties prop = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("deleteTaskAccept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        prop = new Properties();
        prop.load(taskContollerServiceCaregiverTest.class.getClassLoader().getResourceAsStream("caregiver.properties"));

        // create request body
        JSONObject request = new JSONObject();
        request.put("username", prop.getProperty("mp.username"));
        request.put("password", prop.getProperty("mp.password"));


        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------------  Load the User from the mongodb -------------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("victoria", username);
        Assert.assertEquals("Jefferson", removeDoubleQuotes(jo.get("lastName").toString()));
    }

    @Test
    public void getTasksByMemberId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "[{\"id\":\"\",\"title\":\"Assessment Call\",\"start\":\"2015-04-29T14:30:00.000Z\","
                + "\"startTimezone\":\"America/New_York\",\"end\":\"2015-04-29T15:00:00.000Z\",\"endTimezone\":\"America/New_York\","
                + "\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"isAllDay\":false,\"description\":\"\","
                + "\"reason\":\"Schedule for today\",\"ownerId\":\"victoria\",\"ownerType\":\"MEMBER\","
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"status\":null}]";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080//mp-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/task";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void saveTask() {
        LOGGER.debug("\n------------  Get the Contact API ---------");
        String json = "{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"Test\","
                + "\"status\":\"Scheduled\",\"title\":\"Test\",\"start\":\"2015-05-07T15:00:00.000+0000\","
                + "\"end\":\"2015-05-07T15:30:00.000+0000\",\"startTimezone\":\"America/New_York\",\"endTimezone\":\"America/New_York\","
                + "\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"ownerType\":\"MEMBER\",\"allDay\":false,"
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8080/mp-rest/api/task/4d51b1cb-b64f-4519-844a-697ebc632ec8\"}]},"
                + "{Pragma=[No-cache], Cache-Control=[no-cache], Server=[generic], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], "
                + "Content-Type=[application/json], Transfer-Encoding=[chunked], Date=[Fri, 08 May 2015 07:31:27 GMT]}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void updateTask() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"Test\","
                + "\"status\":\"Scheduled\",\"title\":\"Test\",\"start\":\"2015-05-07T15:00:00.000+0000\","
                + "\"end\":\"2015-05-07T15:30:00.000+0000\",\"startTimezone\":\"America/New_York\",\"endTimezone\":\"America/New_York\","
                + "\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"ownerType\":\"MEMBER\",\"allDay\":false,"
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8080/mp-rest/api/task/4d51b1cb-b64f-4519-844a-697ebc632ec8\"}]},"
                + "{Pragma=[No-cache], Cache-Control=[no-cache], Server=[generic], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], "
                + "Content-Type=[application/json], Transfer-Encoding=[chunked], Date=[Fri, 08 May 2015 07:31:27 GMT]}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task/3c5a7fed-8de6-443b-97bd-c12afbf31596";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void deleteTask_of_Member() {
        LOGGER.debug("\n------------  Get the Contact API ---------");
		
		

		/*String json="{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"Test\","
				+ "\"status\":\"Scheduled\",\"title\":\"Test\",\"start\":\"2015-05-07T15:00:00.000+0000\","
				+ "\"end\":\"2015-05-07T15:30:00.000+0000\",\"startTimezone\":\"America/New_York\",\"endTimezone\":\"America/New_York\","
				+ "\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"ownerType\":\"MEMBER\",\"allDay\":false,"
				+ "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8080/mp-rest/api/task/4d51b1cb-b64f-4519-844a-697ebc632ec8\"}]},"
				+ "{Pragma=[No-cache], Cache-Control=[no-cache], Server=[generic], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], "
				+ "Content-Type=[application/json], Transfer-Encoding=[chunked], Date=[Fri, 08 May 2015 07:31:27 GMT]}";*/
        String json = "[{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"testV1\",\"status\":\"Scheduled\",\"title\":\"testV1\","
                + "\"start\":\"2015-05-13T06:00:00.000+0000\",\"end\":\"2015-05-13T06:30:00.000+0000\",\"startTimezone\":\"America/New_York\","
                + "\"endTimezone\":\"America/New_York\",\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"ownerId\":\"victoria\","
                + "\"ownerType\":\"MEMBER\",\"allDay\":false,\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8080/mp-rest/api/task/4f56b5ca-c15b-4c1f-96ba-4325fa070b34\"}]}],"
                + "{Pragma=[No-cache], Cache-Control=[no-cache], Server=[generic], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], "
                + "Content-Type=[application/json], Transfer-Encoding=[chunked], Date=[Wed, 13 May 2015 07:35:26 GMT]}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task/4f56b5ca-c15b-4c1f-96ba-4325fa070b34";
        //String BASE_URL = "http://localhost:8080/mp-rest/api/task/7ed5c24a-34ac-4ce8-b53d-c63fa0b4dfa4";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.DELETE, putentity, String.class);

        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    @Test
    public void getTask() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"Test\","
                + "\"status\":\"Scheduled\",\"title\":\"Test\",\"start\":\"2015-05-07T15:00:00.000+0000\","
                + "\"end\":\"2015-05-07T15:30:00.000+0000\",\"startTimezone\":\"America/New_York\",\"endTimezone\":\"America/New_York\","
                + "\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"ownerType\":\"MEMBER\",\"allDay\":false,"
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8080/mp-rest/api/task/4d51b1cb-b64f-4519-844a-697ebc632ec8\"}]},"
                + "{Pragma=[No-cache], Cache-Control=[no-cache], Server=[generic], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], "
                + "Content-Type=[application/json], Transfer-Encoding=[chunked], Date=[Fri, 08 May 2015 07:31:27 GMT]}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        //Member Task Id
        String BASE_URL = "http://localhost:8080//mp-rest/api/task/7ed5c24a-34ac-4ce8-b53d-c63fa0b4dfa4";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void deleteTask_of_Caregiver() {
        LOGGER.debug("\n------------  Get the Contact API ---------");
		
		

		/*String json="{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"Test\","
				+ "\"status\":\"Scheduled\",\"title\":\"Test\",\"start\":\"2015-05-07T15:00:00.000+0000\","
				+ "\"end\":\"2015-05-07T15:30:00.000+0000\",\"startTimezone\":\"America/New_York\",\"endTimezone\":\"America/New_York\","
				+ "\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"ownerType\":\"MEMBER\",\"allDay\":false,"
				+ "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8080/mp-rest/api/task/4d51b1cb-b64f-4519-844a-697ebc632ec8\"}]},"
				+ "{Pragma=[No-cache], Cache-Control=[no-cache], Server=[generic], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], "
				+ "Content-Type=[application/json], Transfer-Encoding=[chunked], Date=[Fri, 08 May 2015 07:31:27 GMT]}";*/
        String json = "[{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"testV1\",\"status\":\"Scheduled\",\"title\":\"testV1\","
                + "\"start\":\"2015-05-13T06:00:00.000+0000\",\"end\":\"2015-05-13T06:30:00.000+0000\",\"startTimezone\":\"America/New_York\","
                + "\"endTimezone\":\"America/New_York\",\"recurrenceRule\":\"\",\"recurrenceException\":\"\",\"ownerId\":\"victoria\","
                + "\"ownerType\":\"MEMBER\",\"allDay\":false,\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8080/mp-rest/api/task/4f56b5ca-c15b-4c1f-96ba-4325fa070b34\"}]}],"
                + "{Pragma=[No-cache], Cache-Control=[no-cache], Server=[generic], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], "
                + "Content-Type=[application/json], Transfer-Encoding=[chunked], Date=[Wed, 13 May 2015 07:35:26 GMT]}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task/2b63c373-b0f3-42a9-b40d-9330b41dc6d8";
        //String BASE_URL = "http://localhost:8080/mp-rest/api/task/7ed5c24a-34ac-4ce8-b53d-c63fa0b4dfa4";


        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.DELETE, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void updateTask_of_Member() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"reason\":\"vic_task\","
                + "\"status\":\"Scheduled\",\"title\":\"vic_task\",\"start\":\"2015-05-13T14:30:00.000+0000\","
                + "\"end\":\"2015-05-13T15:00:00.000+0000\",\"startTimezone\":\"America/New_York\","
                + "\"endTimezone\":\"America/New_York\",\"recurrenceRule\":\"\",\"recurrenceException\":\"\","
                + "\"ownerId\":\"victoria\",\"ownerType\":\"MEMBER\",\"allDay\":false,\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/task/8d4dcf1c-4824-434d-bc2a-7b37a00b3189\"}]}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task/8d4dcf1c-4824-434d-bc2a-7b37a00b3189";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

}
