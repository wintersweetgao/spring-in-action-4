package com.altruista.mp.rest.assessment;

import com.altruista.mp.resources.AssessmentRunResource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Properties;

/*
 * 
 */
public class AssessmentServiceWithPhysician {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentServiceWithPhysician.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private Properties prop = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }


    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        prop = new Properties();
        prop.load(AssessmentServiceWithPhysician.class.getClassLoader().getResourceAsStream("physician.properties"));

        // create request body
        JSONObject request = new JSONObject();
        request.put("username", prop.getProperty("mp.username"));
        request.put("password", prop.getProperty("mp.password"));


        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
        setMemberId();
    }

    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }


    /**
     * resulted in 403 (Prohibido)
     *
     * @throws JsonProcessingException
     */

    @Test
    public void API_ACCESS_AssessmentRun_Test() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");
        ResponseEntity<String> getResponse = null;

        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("71efc277-5939-4df2-8301-a8adefffccae");
        assessmentRun.setAssessmentName("Wheelchair Assessment AHS");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-04-27T08:47:22.635Z"));

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);
        System.out.println(json);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // It looks like Amanda can access AssessmentNames, but she can't take Assessment
    @Test
    public void testTakeAssessmentByAmanda() throws JsonProcessingException {
        LOGGER.debug("\n----------- testTakeAssessmentByAmanda() ---------");

        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("5b7b1cf7-0956-428a-b60f-addf0fb561d6");
        assessmentRun.setAssessmentName("PHQ9-Depression Assessment");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-10-09T13:23:21.698Z"));
        assessmentRun.setLastSequence(3);
        assessmentRun.setStatus("InProgress");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/bdb88a9a-42c9-4db0-8c9f-2f3a23a26660";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    @Test
    public void getAllAssessmentNamesByMemberId() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("71efc277-5939-4df2-8301-a8adefffccae");
        assessmentRun.setAssessmentName("PHQ9-Depression Assessment");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-10-09T13:23:21.698Z"));
        assessmentRun.setLastSequence(5);
        assessmentRun.setStatus("InProgress");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/098e299f-fdb1-4619-b121-1637790e98af";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    @Test
    public void createAssessmentResponse() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("71efc277-5939-4df2-8301-a8adefffccae");
        assessmentRun.setAssessmentName("PHQ9-Depression Assessment");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-10-09T13:23:21.698Z"));
        assessmentRun.setLastSequence(10);
        assessmentRun.setStatus("Pending");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/0034a5b3-4f51-45b1-b186-ee16373a9fe7/assessmentResponse/";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }

    }

    @Test
    public void saveAssessmentRunStatus() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("71efc277-5939-4df2-8301-a8adefffccae");
        assessmentRun.setAssessmentName("PHQ9-Depression Assessment");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-10-09T13:23:21.698Z"));
        assessmentRun.setLastSequence(10);
        assessmentRun.setStatus("Pending");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/0034a5b3-4f51-45b1-b186-ee16373a9fe7/status/";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }

    }

    @Test
    public void saveAssessmentResponse() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("71efc277-5939-4df2-8301-a8adefffccae");
        assessmentRun.setAssessmentName("PHQ9-Depression Assessment");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-10-09T13:23:21.698Z"));
        assessmentRun.setLastSequence(10);
        assessmentRun.setStatus("Pending");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentResponse/b9f74653-752a-4ec7-ac57-6dff14ccb12e";

        try {
            ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }
}
