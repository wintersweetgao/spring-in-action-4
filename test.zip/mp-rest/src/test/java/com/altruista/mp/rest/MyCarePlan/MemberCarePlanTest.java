package com.altruista.mp.rest.MyCarePlan;

import com.altruista.mp.resources.ActionStepResource;
import com.altruista.mp.services.exceptions.ServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

/*
 *  Copyright 2015 Altruista Health.  All Rights Reserved
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MemberCarePlanTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberCarePlanTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void test1API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------------  Load the User from the mongodb -------------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("victoria", username);
        Assert.assertEquals("Jefferson", removeDoubleQuotes(jo.get("lastName").toString()));
    }

    // Get All Goals
    @Test
    public void test2getMyCarePlanDashBorad() {
        LOGGER.debug("--- getMyCarePlanDashBorad ---");
        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/goal";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    // SignOff
    @Test
    public void test3SignOff() {
        LOGGER.debug("--- testSignOff ---");
        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/step/9d92f179-0d37-44c8-9bc2-724c40892372/signoff";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, newentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    //get all goals after signoff
    @Test
    public void test4GetAllGoalsAfterSignOff() {
        LOGGER.debug("--- testGetAllGoalsAfterSignOff ---");
        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/goal";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    //save action step
    @Test
    public void test5saveActionStepStatus() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        ActionStepResource step = new ActionStepResource();
        step.setStatus("Completed");
        step.setNotes("Hello");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(step);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/step/9d92f179-0d37-44c8-9bc2-724c40892372/status";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    // Get
    @Test
    public void test6getActionStepsByMEMBER() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        ActionStepResource step = new ActionStepResource();
        step.setStatus("Completed");
        step.setNotes("Hello");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(step);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/goal";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    //get Get Goal from ActionStep
    @Test
    public void test7GoalFromViewCareTeamPlan() {
        LOGGER.debug("\n------------  testGoalFromViewCareTeamPlan() ---------");
        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/goal";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }
}
