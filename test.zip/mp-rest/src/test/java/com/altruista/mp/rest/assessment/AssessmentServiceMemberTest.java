package com.altruista.mp.rest.assessment;

import com.altruista.mp.resources.AssessmentRunResource;
import com.altruista.mp.services.exceptions.ServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

/*
 * 
 */
public class AssessmentServiceMemberTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(AssessmentServiceMemberTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        // create request body
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
        setMemberId();
    }

    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------------  Load the User from the mongodb -------------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("victoria", username);
        Assert.assertEquals("Jefferson", removeDoubleQuotes(jo.get("lastName").toString()));
    }


    @Test
    public void testGetAssessmentByNames() {
        LOGGER.debug("--- testGetAssessmentByNames --- ");

        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessment/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/names";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        JsonElement jelement = new JsonParser().parse(getResponse.getBody());
        JsonArray jarray = jelement.getAsJsonArray();
        for (int i = 0; i < jarray.size(); i++) {
            JsonObject jsonObject = jarray.get(i).getAsJsonObject();
            LOGGER.debug("------------------------");
            LOGGER.debug("AssessmentID : " + jsonObject.get("assessmentId"));
            LOGGER.debug("Name : " + jsonObject.get("name"));
            LOGGER.debug("Status : " + jsonObject.get("status"));
            LOGGER.debug("Last RunId : " + jsonObject.get("lastRunId"));
            LOGGER.debug("Last Sequence : " + jsonObject.get("lastSequence"));
        }
    }

    @Test
    public void getAssessment() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("71efc277-5939-4df2-8301-a8adefffccae");
        assessmentRun.setAssessmentName("Wheelchair Assessment AHS");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-10-09T11:31:30.736Z"));
        assessmentRun.setLastSequence(0);
        assessmentRun.setStatus("InProgress");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);
        System.out.println(json);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/8d92f06a-fd57-4c8f-b61e-c3a61093619d";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void testGetAssessmentResponse() {
        LOGGER.debug("----- testGetAssessmentResponse --- ");

        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentRun/bdb88a9a-42c9-4db0-8c9f-2f3a23a26660/assessmentResponse";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void testAnswerAssessmentResponse() throws JsonProcessingException {
        LOGGER.debug("----- testAnswerAssessmentResponse --- ");
        AssessmentRunResource assessmentRun = new AssessmentRunResource();
        assessmentRun.setAssessmentId("71efc277-5939-4df2-8301-a8adefffccae");
        assessmentRun.setAssessmentName("Wheelchair Assessment AHS");
        assessmentRun.setStartedOn(formatter.parseDateTime("2015-10-09T11:31:30.736Z"));
        assessmentRun.setLastSequence(0);
        assessmentRun.setStatus("InProgress");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(assessmentRun);
        System.out.println(json);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/assessmentResponse/a452156e-1b57-49d9-b012-59cb92f60ed2";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }
}
