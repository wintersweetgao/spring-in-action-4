package com.altruista.mp.rest.security;

import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

public class DatabaseTimeOutTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(DatabaseTimeOutTest.class);
    private RestTemplate restTemplate = null;
    private static HttpHeaders headers = null;

    static {
        /** set headers */
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    //  Timed out after 10000 ms while waiting for a server that matches AnyServerSelector{}.
    @Test
    public void testDatabaseTimeOut() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";

        try {
            ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
            LOGGER.debug("Response : " + response);
        } catch (RestClientException restCE) {
            LOGGER.error(restCE.getMessage());
            Assert.assertEquals("500 Internal Server Error", restCE.getMessage());
        }
    }
}
