package com.altruista.mp.rest.userlockout;

import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Copyright 2015 Altruista Health. All Rights Reserved
 *
 * @author: Prateek Ashtikar on 10/05/15
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserLockOutTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserLockOutTest.class);
    private static String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
    private static HttpHeaders headers = null;
    private HttpEntity<String> entity = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void testBefore() {
        JSONObject request = new JSONObject();
        request.put("username", "nitin");
        request.put("password", "Rest@n1234"); // Correct Password: Rest@n123
        entity = new HttpEntity<String>(request.toString(), headers);
    }

    // Make user locked for 3 successive failed attempts
    @Test
    public void test1UserLockOut() {
        LOGGER.info("*****  User Lock Out Test *****");
        ResponseEntity<String> response = null;
        int failedAttemptCount = 0;
        String lockoutmessage = "";
        /** send request and parse result */
        RestTemplate restTemplate = new RestTemplate();

        LOGGER.info("*****  1st Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        LOGGER.info("*****  2nd Failure Attempt*****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        LOGGER.info("*****  3rd Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        LOGGER.info("*****  4th Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            lockoutmessage = e.getMessage();
            failedAttemptCount++;
        }

        Assert.assertTrue(failedAttemptCount >= 3);
        Assert.assertEquals("423 Locked", lockoutmessage);
    }


    // Give user another 3 attempts post threshold time although user is locked out for
    // his/her first time 3 failed attempts
    @Test
    public void test2UserLockOutForThreshold() throws InterruptedException {
        LOGGER.info("\n*****  User Lock Out Test for Threshold, still can get 3 attempts for failure *****");
        ResponseEntity<String> response = null;
        int failedAttemptCount = 0;
        String lockoutmessage = "";
        /** send request and parse result */
        RestTemplate restTemplate = new RestTemplate();


        LOGGER.info("*****  1st Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
        }
        LOGGER.info("*****  2nd Failure Attempt*****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
        }
        LOGGER.info("*****  3rd Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
        }
        LOGGER.info("*****  4th Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
        }

        LOGGER.info("Wait for 4 mins for Next Login ..., And get 3 fresh attempts:");
        Thread.sleep(240000);  // 1 min = 60 sec = 60000 ms

        LOGGER.info("*****  1st Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        LOGGER.info("*****  2nd Failure Attempt*****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        LOGGER.info("*****  3rd Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        LOGGER.info("*****  4th Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            lockoutmessage = e.getMessage();
            failedAttemptCount++;
        }
        Assert.assertTrue(failedAttemptCount >= 3);
        Assert.assertEquals("423 Locked", lockoutmessage);
    }

    // Make successful login after two failure failure attempts
    @Test
    public void test3UserLockOutForThreshold() throws InterruptedException {
        LOGGER.info("\n*****  User Lock Out Test for Threshold *****");
        ResponseEntity<String> response = null;
        int failedAttemptCount = 0;
        String lockoutmessage = "";
        /** send request and parse result */
        RestTemplate restTemplate = new RestTemplate();


        LOGGER.info("*****  1st Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        LOGGER.info("*****  2nd Failure Attempt*****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }

        LOGGER.info("Wait for 4 mins for Next Login ..., then enter correct login credentials:");
        Thread.sleep(240000);  // 10 min = 600 sec = 600000 ms


        JSONObject request = new JSONObject();
        request.put("username", "nitin");
        request.put("password", "Rest@n123"); // Correct Password: Prateek@123
        entity = new HttpEntity<String>(request.toString(), headers);

        LOGGER.info("*****  3rd Failure Attempt *****");
        try {
            response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Error Message : " + e.getMessage());
            failedAttemptCount++;
        }
        Assert.assertNotNull(response.getBody());
        ;
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }
}
