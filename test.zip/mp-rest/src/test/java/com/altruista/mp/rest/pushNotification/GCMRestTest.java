package com.altruista.mp.rest.pushNotification;

import com.altruista.mp.resources.PushNotificationRegistrationResource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Sender;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

/**
 * Developed by Prateek A on 07/09/15
 */
public class GCMRestTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(GCMRestTest.class);
    public static final String RegID = "dHS9a7Ph7E4:APA91bGLslQ97Es-0S27os5SKKGEoGuO0sJs-vrhabItwhX1Jro3F8Y19F-zJxId8iUjpHJmyALXiUAukhT68BgEystjdc8w3JUCdD2so-3zqrGrKzCibjBN1tIVghJuoYZQA-3rE9li";
    public static final String MESSAGE = "Hello, Good Morning from AgileNova";

    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;


    Properties prop = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @org.junit.Before
    public void beforeTest() throws IOException {
        prop = new Properties();
        prop.load(APNSTest.class.getClassLoader().getResourceAsStream("DEVL.mp-rest.properties"));


        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    /**
     * Send Notifications using GCM jar
     */
    @Test
    public void testSendNotificationUsingGCM() throws IOException {
        LOGGER.debug(" Send Notifications using GCM Jar");
        Sender sender = new Sender(prop.getProperty("gcm.push.notification.api.key"));

        ArrayList<String> devicesList = new ArrayList<String>();
        devicesList.add(RegID);
        Message message = new Message.Builder().timeToLive(30).delayWhileIdle(true).addData("message", "Hello world from AgileNova!").build();

        MulticastResult multicastResult = sender.send(message, devicesList, Integer.parseInt(prop.getProperty("gcm.push.notification.no.of.retries")));
        sender.send(message, devicesList, Integer.parseInt(prop.getProperty("gcm.push.notification.no.of.retries")));

        LOGGER.debug(multicastResult.toString());
        LOGGER.debug("Multicast ID : " + multicastResult.getMulticastId());
        LOGGER.debug("SUCCESS      : " + multicastResult.getSuccess());

        Assert.assertTrue(multicastResult.getSuccess() >= 1);
        Assert.assertNotNull(multicastResult.getMulticastId());
    }


    @Test
    public void testGCMPushNotification() throws JsonProcessingException {
        LOGGER.debug(" Test GCM Notifications ");

        PushNotificationRegistrationResource resource = new PushNotificationRegistrationResource();
        resource.setMessageText("Your first PushNotification");
        resource.setDeviceOS("android");
        resource.setContactId("e427baa3-27ac-4cb2-91d1-6089af6c490f");

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(resource);
        LOGGER.debug("JSON: " + json);
        HttpEntity<String> getEntity = new HttpEntity<String>(json, headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/pushNotification/gcm/send";

        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, getEntity, String.class);
        LOGGER.debug("Response : " + getResponse);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }
}
