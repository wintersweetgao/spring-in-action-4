package com.altruista.mp.rest.security;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

public class SecurityTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityTest.class);

    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = removeDoubleQuotes(jo.get("token").toString());
        LOGGER.debug("JWT :" + jwtToken);

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);

        RestTemplate rt = new RestTemplate();
        String URL = "http://localhost:8080/mp-rest/api/user";
        HttpEntity<String> _entity_ = new HttpEntity<String>(getRequest.toString(), headers);
        @SuppressWarnings("unused")
        ResponseEntity<String> resp = rt.exchange(URL, HttpMethod.GET, _entity_, String.class);

        setMemberId();
    }

    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }


    /**
     * Try login as Victoria and try to access Diagnosis details of Lona
     */
    @Test
    public void testDiagnosisOfLonaByVictoria() {
        LOGGER.debug("---  testDiagnosisOfVictoriaBySusan() ---");

        ResponseEntity<String> getResponse = null;
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/diagnosis/a763a65d-af63-4327-8096-f0be2045c0ad";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        } catch (RestClientException rce) {
            LOGGER.error(rce.getMessage());
            Assert.assertEquals("401 Unauthorized", rce.getMessage());
        }
    }


    /**
     * Try login as Victoria and try to access Calendar details of Lona
     */
    @Test
    public void testGoalsOfLonaByVictoria() {
        LOGGER.debug("---  testGoalsOfLonaByVictoria() ---");

        ResponseEntity<String> getResponse = null;
        HttpEntity<String> getEntity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/member/a763a65d-af63-4327-8096-f0be2045c0ad/goal";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getEntity, String.class);
        } catch (RestClientException rce) {
            LOGGER.error(rce.getMessage());
            Assert.assertEquals("401 Unauthorized", rce.getMessage());
        }
    }
}
