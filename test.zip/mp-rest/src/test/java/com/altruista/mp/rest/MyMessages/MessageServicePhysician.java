package com.altruista.mp.rest.MyMessages;

import com.altruista.mp.model.HealthSummaryType;
import com.altruista.mp.model.MessageType;
import com.altruista.mp.resources.MessageResource;
import com.altruista.mp.services.exceptions.ServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Arrays;

/*
 * 
 */
public class MessageServicePhysician {
    private static final Logger LOGGER = LoggerFactory.getLogger(MessageServicePhysician.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        // create request body
        JSONObject request = new JSONObject();
        request.put("username", "amanda");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);

        setMemberId();
    }

    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }


    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------------  Load the User from the mongodb -------------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("amanda", username);
        Assert.assertEquals("Jackson", removeDoubleQuotes(jo.get("lastName").toString()));
    }

    @Test
    public void testGetAllMessages() {
        LOGGER.info("--- testGetAllMessages ---");
        ResponseEntity<String> getResponse = null;
        HttpEntity<String> getentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/member/" + MEMBER_ID + "/message";
        getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, getentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void saveMessage() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        MessageResource message = new MessageResource();
        message.setMessageType(MessageType.INTERNAL);
        message.setSenderId("14b3f864-ad4d-4b30-b682-2357c8ba35e8");
        message.setRecipientIds(Arrays.asList("3d275be0-add2-4cae-b344-af643a7454e4"));
        message.setMemberId(MEMBER_ID);
        message.setSubject("Note: Happy Day");
        message.setBody("Note: Happy Day");
        message.setLocation("INBOX");
        message.setHealthSummary(HealthSummaryType.NONE);


        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        String json = mapper.writeValueAsString(message);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/message";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    // Archive will only be worked once
    //@Test
    public void setMessageLocation() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        MessageResource message = new MessageResource();
        message.setLocation("ARCHIVE");
        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        String json = mapper.writeValueAsString(message);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/message/2c89eacf-6349-4a64-8830-4601c51cf768/location";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void getMessagesByRecipientId() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        MessageResource message = new MessageResource();
        message.setLocation("ARCHIVE");
        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        String json = mapper.writeValueAsString(message);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/message/recipient/2c89eacf-6349-4a64-8830-4601c51cf768";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void getMessagesBySenderId() throws JsonProcessingException {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        MessageResource message = new MessageResource();
        message.setLocation("ARCHIVE");
        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        String json = mapper.writeValueAsString(message);

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest//api/message/sender/2c89eacf-6349-4a64-8830-4601c51cf768";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

}
