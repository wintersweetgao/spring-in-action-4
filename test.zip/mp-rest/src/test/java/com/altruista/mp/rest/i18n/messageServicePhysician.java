package com.altruista.mp.rest.i18n;

import com.altruista.mp.services.exceptions.ServiceException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Properties;

/*
 * 
 */
public class messageServicePhysician {
    private static final Logger LOGGER = LoggerFactory.getLogger(messageServicePhysician.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private Properties prop = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        prop = new Properties();
        prop.load(messageServicePhysician.class.getClassLoader().getResourceAsStream("physician.properties"));

        // create request body
        JSONObject request = new JSONObject();
        request.put("username", prop.getProperty("mp.username"));
        request.put("password", prop.getProperty("mp.password"));


        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Test
    public void API_USER_Test() throws ServiceException {
        LOGGER.debug("\n------------  Load the User from the mongodb -------------");

        HttpEntity<String> newentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, newentity, String.class);
        LOGGER.debug("USER : " + getResponse.getBody());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());
        String username = removeDoubleQuotes(jo.get("username").toString());

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("amanda", username);
        Assert.assertEquals("Jackson", removeDoubleQuotes(jo.get("lastName").toString()));
    }

    @Test
    public void getMessagesByMemberId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "[{\"senderId\":\"745a5158-2358-4d41-9282-2006c6958abb\",\"sender\":{\"contactType\":\"CARECOACH\",\"company\":\"Altruista Health\","
                + "\"salutation\":\"Mr.\",\"firstName\":\"John\",\"middleName\":\"B.\",\"lastName\":\"Lewis\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/745a5158-2358-4d41-9282-2006c6958abb\"}]},\"recipientIds\":[\"57bd5bb9-84c2-4821-8c9e-afe25466956d\"],"
                + "\"recipients\":[{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"Victoria\",\"middleName\":\"M.\","
                + "\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"Welcome to the Member Portal!\",\"body\":\"Thank you for joining.\",\"messagePriority\":\"MEDIUM\",\"location\":\"ARCHIVE\","
                + "\"viewed\":false,\"sentOn\":\"2015-03-05T12:55:17.134+0000\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/86623469-a267-4c04-a41f-bf08f7530df7\"}]},{\"messageType\":\"DIRECT\",\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\","
                + "\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\","
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},\"recipientIds\":[\"745a5158-2358-4d41-9282-2006c6958abb\"],"
                + "\"recipients\":[{\"contactType\":\"CARECOACH\",\"company\":\"Altruista Health\",\"salutation\":\"Mr.\","
                + "\"firstName\":\"John\",\"middleName\":\"B.\",\"lastName\":\"Lewis\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/745a5158-2358-4d41-9282-2006c6958abb\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"DIRECT ONE\",\"body\":\"DIRECT ONE\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-03-09T11:41:20.234+0000\","
                + "\"healthSummary\":\"LAST_TWO_YEARS\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/e8046287-6d15-411d-8efd-8b478e835e83\"}]},{\"messageType\":\"DIRECT\","
                + "\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\","
                + "\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"745a5158-2358-4d41-9282-2006c6958abb\"],\"recipients\":[{\"contactType\":\"CARECOACH\",\"company\":\"Altruista Health\","
                + "\"salutation\":\"Mr.\",\"firstName\":\"John\",\"middleName\":\"B.\",\"lastName\":\"Lewis\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/745a5158-2358-4d41-9282-2006c6958abb\"}]}],"
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"subject\":\"Hello\",\"body\":\"Hello\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-03-11T15:30:22.105+0000\","
                + "\"healthSummary\":\"LAST_TWO_YEARS\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/fddeba0b-220f-4635-b6bd-dbbab3120738\"}]},{\"messageType\":\"DIRECT\","
                + "\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"Victoria\","
                + "\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"4e4f451a-f207-47f0-af0c-42a14c0b4242\"],\"recipients\":[{\"contactType\":\"CARECOACH\",\"company\":\"Altruista Health\","
                + "\"salutation\":\"Ms.\",\"firstName\":\"Karen\",\"middleName\":\"L.\",\"lastName\":\"Smith\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/4e4f451a-f207-47f0-af0c-42a14c0b4242\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"Hello\",\"body\":\"Hello\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-03-12T07:08:49.293+0000\","
                + "\"healthSummary\":\"YEAR_TO_DATE\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/124b1140-379d-44b6-9d1f-10b5e761194e\"}]},{\"messageType\":\"DIRECT\","
                + "\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"Victoria\","
                + "\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"f03284f3-2f89-4970-97f7-916c0da5c77e\"],\"recipients\":[{\"contactType\":\"PHYSICIAN\",\"company\":\"Regional Wellness Clinic\","
                + "\"salutation\":\"Dr.\",\"firstName\":\"Maria\",\"middleName\":\"D.\",\"lastName\":\"Williams\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/f03284f3-2f89-4970-97f7-916c0da5c77e\"}]}],"
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"subject\":\"Hello\",\"body\":\"Hello\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-03-12T07:43:58.520+0000\","
                + "\"healthSummary\":\"LAST_TWO_YEARS\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/c7c4024c-936f-41fe-9d6f-a1235e0052f6\"}]},"
                + "{\"messageType\":\"DIRECT\",\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\","
                + "\"salutation\":\"Ms.\",\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"745a5158-2358-4d41-9282-2006c6958abb\"],\"recipients\":[{\"contactType\":\"CARECOACH\",\"company\":\"Altruista Health\","
                + "\"salutation\":\"Mr.\",\"firstName\":\"John\",\"middleName\":\"B.\",\"lastName\":\"Lewis\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/745a5158-2358-4d41-9282-2006c6958abb\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"subject\":\"Hello\","
                + "\"body\":\"New Hello\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-03-12T08:07:01.843+0000\",\"healthSummary\":\"LAST_TWO_YEARS\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/message/5efb0947-7361-4925-bf31-6669ba3ef8b8\"}]},{\"messageType\":\"DIRECT\",\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\""
                + ",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\""
                + ",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},\"recipientIds\":[\"5e53474c-aa84-4677-9832-64c1de93d12c\"],"
                + "\"recipients\":[{\"contactType\":\"CAREGIVER\",\"salutation\":\"Mr.\",\"firstName\":\"Bill\",\"middleName\":\"C.\",\"lastName\":\"Jefferson\","
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/5e53474c-aa84-4677-9832-64c1de93d12c\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"TEST MESSAGE\",\"body\":\"TEST MESSAGE\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-03-13T20:49:49.458+0000\","
                + "\"healthSummary\":\"LAST_TWO_YEARS\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/83cea93e-c73c-4842-8b74-55a9b1fbdb7b\"}]},{\"messageType\":\"INTERNAL\","
                + "\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\","
                + "\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"5e53474c-aa84-4677-9832-64c1de93d12c\"],\"recipients\":[{\"contactType\":\"CAREGIVER\",\"salutation\":\"Mr.\","
                + "\"firstName\":\"Bill\",\"middleName\":\"C.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/5e53474c-aa84-4677-9832-64c1de93d12c\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"Test Time\",\"body\":\"Test TimeZone\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-04-01T15:15:00.261+0000\","
                + "\"healthSummary\":\"NONE\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/5526dea6-c2e7-4a54-9aef-f69804073175\"}]},{\"messageType\":\"INTERNAL\","
                + "\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\","
                + "\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"5e53474c-aa84-4677-9832-64c1de93d12c\"],\"recipients\":[{\"contactType\":\"CAREGIVER\",\"salutation\":\"Mr.\","
                + "\"firstName\":\"Bill\",\"middleName\":\"C.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/5e53474c-aa84-4677-9832-64c1de93d12c\"}]}],"
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"subject\":\"Test Time\",\"body\":\"Test TimeZone\",\"location\":\"INBOX\","
                + "\"viewed\":false,\"sentOn\":\"2015-04-01T15:16:01.049+0000\",\"healthSummary\":\"NONE\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/message/286a4f7c-e1b5-4418-aef8-dbda21c5b1df\"}]},{\"messageType\":\"INTERNAL\","
                + "\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\","
                + "\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"745a5158-2358-4d41-9282-2006c6958abb\"],\"recipients\":[{\"contactType\":\"CARECOACH\",\"company\":\"Altruista Health\","
                + "\"salutation\":\"Mr.\",\"firstName\":\"John\",\"middleName\":\"B.\",\"lastName\":\"Lewis\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/745a5158-2358-4d41-9282-2006c6958abb\"}]}],"
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"subject\":\"test\",\"body\":\"test\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-04-01T15:24:43.262+0000\","
                + "\"healthSummary\":\"NONE\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/e8c38d44-5499-4cb4-a767-35244a378eb5\"}]},{\"messageType\":\"DIRECT\",\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\","
                + "\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\",\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\","
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"5e53474c-aa84-4677-9832-64c1de93d12c\"],\"recipients\":[{\"contactType\":\"CAREGIVER\",\"salutation\":\"Mr.\","
                + "\"firstName\":\"Bill\",\"middleName\":\"C.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/5e53474c-aa84-4677-9832-64c1de93d12c\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"Hello\",\"body\":\"Hello\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-04-23T08:36:11.218+0000\","
                + "\"healthSummary\":\"LAST_TWO_YEARS\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/1be38311-8d1a-4ab4-8974-7f8923b58f31\"}]},{\"messageType\":\"INTERNAL\","
                + "\"senderId\":\"efb487ba-686d-4c69-95d0-0db0b064e605\",\"sender\":{\"contactType\":\"CAREGIVER\",\"salutation\":\"Ms.\","
                + "\"firstName\":\"Susan\",\"middleName\":\"A.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/efb487ba-686d-4c69-95d0-0db0b064e605\"}]},\"recipientIds\":[\"5e53474c-aa84-4677-9832-64c1de93d12c\"],\"recipients\":[{\"contactType\":\"CAREGIVER\","
                + "\"salutation\":\"Mr.\",\"firstName\":\"Bill\",\"middleName\":\"C.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/5e53474c-aa84-4677-9832-64c1de93d12c\"}]}],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"Test\",\"body\":\"Test\",\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-04-29T09:40:58.704+0000\","
                + "\"healthSummary\":\"NONE\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/7dde1d11-f7e8-49fb-a4b5-1efe0329bcd3\"}]},{\"messageType\":\"INTERNAL\","
                + "\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\",\"salutation\":\"Ms.\","
                + "\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"4e4f451a-f207-47f0-af0c-42a14c0b4242\"],\"recipients\":[{\"contactType\":\"CARECOACH\",\"company\":\"Altruista Health\","
                + "\"salutation\":\"Ms.\",\"firstName\":\"Karen\",\"middleName\":\"L.\",\"lastName\":\"Smith\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/4e4f451a-f207-47f0-af0c-42a14c0b4242\"}]}],"
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"subject\":\"test\",\"body\":\"Test\","
                + "\"location\":\"INBOX\",\"viewed\":false,\"sentOn\":\"2015-04-29T17:20:48.557+0000\",\"healthSummary\":\"NONE\","
                + "\"links\":[{\"rel\":\"self\",\"href\":\"http://localhost:8000/mp-rest/api/message/3fd289d7-6216-480a-a2dc-047b40067840\"}]},"
                + "{\"messageType\":\"INTERNAL\",\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\",\"sender\":{\"contactType\":\"MEMBER\","
                + "\"salutation\":\"Ms.\",\"firstName\":\"Victoria\",\"middleName\":\"M.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/57bd5bb9-84c2-4821-8c9e-afe25466956d\"}]},"
                + "\"recipientIds\":[\"5e53474c-aa84-4677-9832-64c1de93d12c\"],\"recipients\":[{\"contactType\":\"CAREGIVER\",\"salutation\":\"Mr.\","
                + "\"firstName\":\"Bill\",\"middleName\":\"C.\",\"lastName\":\"Jefferson\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/contact/5e53474c-aa84-4677-9832-64c1de93d12c\"}]}],"
                + "\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\",\"subject\":\"test\",\"body\":\"test\",\"location\":\"INBOX\","
                + "\"viewed\":false,\"sentOn\":\"2015-04-29T18:18:10.423+0000\",\"healthSummary\":\"NONE\",\"links\":[{\"rel\":\"self\","
                + "\"href\":\"http://localhost:8000/mp-rest/api/message/94f4414a-030b-43d6-9dea-2469cfc2159e\"}]}]";
        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/message";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void saveMessage() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"messageType\":\"INTERNAL\",\"senderId\":\"57bd5bb9-84c2-4821-8c9e-afe25466956d\","
                + "\"recipientIds\":[\"efb487ba-686d-4c69-95d0-0db0b064e605\"],\"memberId\":\"ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7\","
                + "\"subject\":\"Suffering from fever\",\"body\":\"i want to visist your office\","
                + "\"location\":\"INBOX\",\"healthSummary\":\"NONE\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/message";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void setMessageLocation() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"location\":\"ARCHIVE\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/message/2c89eacf-6349-4a64-8830-4601c51cf768/location";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.PUT, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void getMessagesByRecipientId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"location\":\"ARCHIVE\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/message/recipient/2c89eacf-6349-4a64-8830-4601c51cf768";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

    @Test
    public void getMessagesBySenderId() {
        LOGGER.debug("\n------------  Get the Contact API ---------");

        String json = "{\"location\":\"ARCHIVE\"}";

        HttpEntity<String> putentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest//api/message/sender/2c89eacf-6349-4a64-8830-4601c51cf768";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);

		/*JsonParser jsonParser = new JsonParser();
		JsonObject jo = (JsonObject)jsonParser.parse(getResponse.getBody());*/

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

}
