package com.altruista.mp.rest.sso;

import com.altruista.mp.model.ContactType;
import com.altruista.mp.model.QuestionAnswer;
import com.altruista.mp.resources.PasswordResetCredentialResource;
import com.altruista.mp.resources.RegistrationCredentialResource;
import com.altruista.mp.resources.UsernameLookupResource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import net.minidev.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

public class SSOMemberSecurityTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SSOMemberSecurityTest.class);
    private static HttpHeaders headers = null;

    static {
        /** set headers */
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    /**
     * Try Member's Login when SSO flag is enabled i.e, true i.e, 1
     */
    // Member must authenticate using SSO.
    @Test
    public void testMemberBaicAuth() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        RestTemplate restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";

        try {
            ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);
            LOGGER.debug("Response : " + response);
        } catch (RestClientException restCE) {
            LOGGER.error(restCE.getMessage());
            Assert.assertEquals("401 Unauthorized", restCE.getMessage());
        }
    }


    /*
     * AHMEMBER-1459 - Test Members Authentication when SSO flag is enabled i.e) 1
     * Add custom Index
     * Used  guidingCare.member.indexes=MEMBER_ID MEDICAID_ID SUBSCRIBER_SSN ELIG_ID
     */
    @Test
    public void testauthenticateRegistrationAHMEMBER1459() throws JsonProcessingException {
        LOGGER.debug("Test Authenticate Registration");

        RestTemplate restTemplate = new RestTemplate();

        RegistrationCredentialResource resource = new RegistrationCredentialResource();
        resource.setContactType(ContactType.MEMBER);
        resource.setDob("1980-07-15");
        //resource.setMemberCode("gas0001");
        //resource.setMemberCode("123456000");
        resource.setMemberCode("900094836");

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(resource);
        HttpEntity<String> postEntity = new HttpEntity<String>(json, headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticateRegistration";

        ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, postEntity, String.class);
        LOGGER.debug("Response : " + response);

        Assert.assertNotNull(response);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }


    /**
     * Try to reset Member's password when SSO flag is enabled i.e, true i.e, 1
     *
     * @throws JsonProcessingException com.altruista.mp.rest.exceptions.InvalidCredentialException: Member must authenticate using SSO.
     */
    @Test
    public void testResetPasswordForMember() throws JsonProcessingException {
        LOGGER.debug("---- Reset the password of Member if SSO Flag is enabled ---");
        RestTemplate restTemplate = new RestTemplate();

        PasswordResetCredentialResource resource = new PasswordResetCredentialResource();
        resource.setUsername("victoria");
        resource.setDob("1950-9-16");
        QuestionAnswer qa = new QuestionAnswer();
        qa.setQuestion("What is your favorite color?");
        qa.setAnswer("blue");
        resource.setSecurityQuestionAnswer(qa);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(resource);
        HttpEntity<String> postEntity = new HttpEntity<String>(json, headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticatePasswordReset";
        try {
            ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, postEntity, String.class);
            LOGGER.debug("Response : " + response);
        } catch (RestClientException restCE) {
            LOGGER.error(restCE.getMessage());
            Assert.assertEquals("401 Unauthorized", restCE.getMessage());
        }
    }


    /**
     * Try to reset Member's UserName when SSO flag is enabled i.e, true i.e, 1
     *
     * @throws JsonProcessingException com.altruista.mp.rest.exceptions.InvalidCredentialException: Member must authenticate using SSO.
     */
    @Test
    public void testResetUserNameOfMember() throws JsonProcessingException {
        LOGGER.debug("---- Reset the UserName of Member if SSO Flag is enabled ---");
        RestTemplate restTemplate = new RestTemplate();
        UsernameLookupResource resource = new UsernameLookupResource();
        resource.setMemberCode("astar");
        resource.setPassword("Rest@n123");
        resource.setDob("1989-09-13");
        QuestionAnswer qa = new QuestionAnswer();
        qa.setQuestion("What is your favorite color?");
        qa.setAnswer("blue");
        resource.setSecurityQuestionAnswer(qa);

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(resource);
        HttpEntity<String> postEntity = new HttpEntity<String>(json, headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user/username";
        try {
            ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, postEntity, String.class);
            LOGGER.debug("Response : " + response);
        } catch (RestClientException restCE) {
            LOGGER.error(restCE.getMessage());
            Assert.assertEquals("401 Unauthorized", restCE.getMessage());
        }
    }

    /*
     * Test Members Authentication when SSO flag is enabled i.e) 1
     */
    @Test
    public void testauthenticateRegistration() throws JsonProcessingException {
        LOGGER.debug("Test Authenticate Registration");

        RestTemplate restTemplate = new RestTemplate();

        RegistrationCredentialResource resource = new RegistrationCredentialResource();
        resource.setContactType(ContactType.MEMBER);
        resource.setDob("7/17/1974");
        resource.setMemberCode("35743657");
        //resource.setPhoneNumber("601-111-1111");

        // Using Jackson Object Mapper
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JodaModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String json = mapper.writeValueAsString(resource);
        HttpEntity<String> postEntity = new HttpEntity<String>(json, headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticateRegistration";

        try {
            ResponseEntity<String> response = restTemplate.exchange(BASE_URL, HttpMethod.POST, postEntity, String.class);
            LOGGER.debug("Response : " + response);
        } catch (RestClientException restCE) {
            LOGGER.error(restCE.getMessage());
            Assert.assertEquals("401 Unauthorized", restCE.getMessage());
        }
    }

    @Test
    public void stripZeros() {
        String id = "0010770000";
        id = StringUtils.stripStart(id, "0");

        Assert.assertEquals(id, "10770000");
    }
}
