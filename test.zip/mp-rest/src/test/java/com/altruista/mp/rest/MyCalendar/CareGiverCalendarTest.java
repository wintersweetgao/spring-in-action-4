package com.altruista.mp.rest.MyCalendar;

import com.altruista.mp.resources.TaskResource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

/**
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by Prateek on 09/22/15
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CareGiverCalendarTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareGiverCalendarTest.class);

    private RestTemplate restTemplate = null;
    DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;
    private String MEMBER_ID = "";

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    public String removeDoubleQuotes(String str) {
        return str.replaceAll("\"", "").trim();
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "susan");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = removeDoubleQuotes(jo.get("token").toString());

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);

        RestTemplate rt = new RestTemplate();
        String URL = "http://localhost:8080/mp-rest/api/user";

        setMemberId();

        HttpEntity<String> _entity_ = new HttpEntity<String>(getRequest.toString(), headers);
        @SuppressWarnings("unused")
        ResponseEntity<String> resp = rt.exchange(URL, HttpMethod.GET, _entity_, String.class);
    }


    private void setMemberId() throws IOException {
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/user";
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse.getBody());

        Assert.assertNotNull(getResponse.getBody());
        Assert.assertEquals("OK", getResponse.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", getResponse.getStatusCode().toString().trim());

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(getResponse.getBody());

        MEMBER_ID = jo.get("selectedMemberId").getAsString();

        LOGGER.debug("MemberId : " + MEMBER_ID);
    }


    // https://demo.personalcarerecord.com:9443/DEVL-rest/api/member/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/task
    // /api/member/{memberId}/task
    // TODO
    @Test
    public void test1CalendarDashBoard() {
        LOGGER.info("***** testCalendarDashBoard() ******");
        ResponseEntity<String> getResponse = null;
        HttpEntity<String> postentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/member/" + MEMBER_ID + "/task";
        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, postentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // Crate Task
    // /api/task ==> POST
    @Test
    public void test2CreateCalendarEvent() throws JsonProcessingException {
        LOGGER.info("**** testCreateEvent() ****");

        TaskResource task = new TaskResource();
        task.setTitle("Weekly Test");
        task.setStart(formatter.parseDateTime("2015-10-05T04:00:00.000Z"));
        task.setEnd(formatter.parseDateTime("2015-10-05T04:30:00.000Z"));
        task.setStartTimezone("America/New_York");
        task.setEndTimezone("America/New_York");
        task.setReason("NewEvent");
        task.setStatus("Scheduled");
        task.setAllDay(false);
        task.setTaskType("Acupuncturist");
        task.setOwnerId("susan");
        task.setOwnerType("MEMBER");
        task.setMemberId(MEMBER_ID);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(task);

        ResponseEntity<String> getResponse = null;

        HttpEntity<String> postentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, postentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // Get all events if any new event is created
    @Test
    public void test3GetAllEventAfterNewEvent() {
        ResponseEntity<String> getResponse = null;
        HttpEntity<String> postentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/member/" + MEMBER_ID + "/task";
        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, postentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    //PUT
    @Test
    public void test4UpdateAnExsistingEvent() throws JsonProcessingException {
        LOGGER.debug("---- Update the exsisting event  ---");
        TaskResource task = new TaskResource();
        task.setTitle("NewEvent");
        task.setStart(formatter.parseDateTime("2015-10-05T04:00:00.000Z"));
        task.setEnd(formatter.parseDateTime("2015-10-05T04:30:00.000Z"));
        task.setStartTimezone("America/New_York");
        task.setEndTimezone("America/New_York");
        task.setReason("NewEvent");
        task.setStatus("Scheduled");
        task.setAllDay(false);
        task.setTaskType("Acupuncturist");
        task.setOwnerId("susan");
        task.setOwnerType("MEMBER");
        task.setMemberId(MEMBER_ID);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(task);

        ResponseEntity<String> getResponse = null;

        HttpEntity<String> postentity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task";

        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.POST, postentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // GET - Get All Event after any event updated
    @Test
    public void test5GetAllEventAfterAnyEventUpdated() {
        ResponseEntity<String> getResponse = null;
        HttpEntity<String> postentity = new HttpEntity<String>(getRequest.toString(), headers);

        String BASE_URL = "http://localhost:8080/mp-rest/api/member/" + MEMBER_ID + "/task";
        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, postentity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // Try to delete Susan's task event by Victoria
    //  /api/task/{taskId}
    @Test
    public void test6SusansEventByVictoria() throws JsonProcessingException {
        LOGGER.info("****** Delete event *****");

        TaskResource task = new TaskResource();
        task.setTitle("NewEvent1");
        task.setStart(formatter.parseDateTime("2015-10-05T04:00:00.000Z"));
        task.setEnd(formatter.parseDateTime("2015-10-05T04:30:00.000Z"));
        task.setStartTimezone("America/New_York");
        task.setEndTimezone("America/New_York");
        task.setStatus("Scheduled");
        task.setDescription("");
        task.setReason("NewEvent1");
        task.setAllDay(false);
        task.setTaskType("Acupuncturist");
        task.setOwnerId("susan");
        task.setOwnerType("MEMBER");
        task.setMemberId(MEMBER_ID);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(task);

        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task/5d6ef606-2210-4a3c-931b-e529892d0b0e";

        ResponseEntity<String> getResponse = null;
        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.DELETE, deleteEntity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }

    // Delete Event
    @Test
    public void test7DeleteEvent() throws JsonProcessingException {
        LOGGER.info("--- Delete event---");

        TaskResource task = new TaskResource();
        task.setTitle("Weekly Test");
        task.setStart(formatter.parseDateTime("2015-10-05T04:00:00.000Z"));
        task.setEnd(formatter.parseDateTime("2015-10-05T04:30:00.000Z"));
        task.setStartTimezone("America/New_York");
        task.setEndTimezone("America/New_York");
        task.setRecurrenceException("");
        task.setStatus("Scheduled");
        task.setDescription("");
        task.setReason("231");
        task.setAllDay(false);
        task.setTaskType("Acupuncturist");
        task.setOwnerId("susan");
        task.setOwnerType("MEMBER");
        task.setMemberId(MEMBER_ID);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new JodaModule());
        String json = mapper.writeValueAsString(task);

        HttpEntity<String> deleteEntity = new HttpEntity<String>(json, headers);
        String BASE_URL = "http://localhost:8080/mp-rest/api/task/154954fd-d7f9-42af-b9b0-537da2571d1a";

        ResponseEntity<String> getResponse = null;
        try {
            getResponse = restTemplate.exchange(BASE_URL, HttpMethod.DELETE, deleteEntity, String.class);
        } catch (RestClientException e) {
            LOGGER.error("Response : [" + getResponse + "]");
            LOGGER.error(e.getMessage());
            Assert.assertEquals("403 Forbidden", e.getMessage());
        }
    }
}
