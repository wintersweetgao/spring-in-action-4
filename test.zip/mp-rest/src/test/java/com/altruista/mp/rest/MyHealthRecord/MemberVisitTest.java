package com.altruista.mp.rest.MyHealthRecord;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minidev.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

public class MemberVisitTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberVisitTest.class);
    private RestTemplate restTemplate = null;
    private String jwtToken = "";
    private ResponseEntity<String> response = null;
    private static HttpHeaders headers = null;
    private JSONObject getRequest = null;

    static {
        // set headers
        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept-Language", "es");
        headers.add("Accept", "application/json, text/plain, */*");
        headers.add("Accept-Encoding", "gzip, deflate, sdch");
    }

    @Before
    public void beforeTest() throws IOException {
        /** create request body */
        JSONObject request = new JSONObject();
        request.put("username", "victoria");
        request.put("password", "rest@n");

        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

        /** send request and parse result */
        restTemplate = new RestTemplate();
        String BASE_URL = "http://localhost:8080/mp-rest/api/user/authenticate";
        response = restTemplate.exchange(BASE_URL, HttpMethod.POST, entity, String.class);

        JsonParser jsonParser = new JsonParser();
        JsonObject jo = (JsonObject) jsonParser.parse(response.getBody());
        jwtToken = jo.get("token").toString().replaceAll("\"", "").trim();

        /** user authentication assert */
        Assert.assertNotNull(jwtToken);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());

        headers.add("X-Auth-Token", jwtToken);

        getRequest = new JSONObject();
        getRequest.put("headers", headers);
    }

    @Test
    public void getLastVisitTest() {
        LOGGER.debug("----- Get Last Visit -----");
        HttpEntity<String> putentity = new HttpEntity<String>(getRequest.toString(), headers);
        String BASE_URL = "http://localhost:8000/mp-rest/api/visit/ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7/lastVisit";

        //Query: { "memberId" : "ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7" , "visitType" : "MC"}, Fields: null, Sort: { "visitOn" : -1}
        ResponseEntity<String> getResponse = restTemplate.exchange(BASE_URL, HttpMethod.GET, putentity, String.class);
        LOGGER.debug("Result : " + getResponse);

        Assert.assertNotNull(getResponse);
        Assert.assertEquals("OK", response.getStatusCode().getReasonPhrase());
        Assert.assertEquals("200", response.getStatusCode().toString().trim());
    }

}
