\rm -f /opt/tomcat/webapps/mp-rest.war
sleep 10
cp ./target/mp-rest.war /opt/tomcat/webapps
