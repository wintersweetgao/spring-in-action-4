package com.altruista.mp.tools;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by mwixson on 10/14/14.
 */
public class MPTool {
    public static void main(String[] args) {
        if (args.length < 1) {
            MPToolApp.help();
            return;
        }

        String config[] = {"applicationContext.xml"};
        ApplicationContext context =
                new ClassPathXmlApplicationContext(config);

        MPToolApp app = context.getBean(MPToolApp.class);
        app.run(args);
    }
}
