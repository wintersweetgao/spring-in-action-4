package com.altruista.mp.tools;

import com.altruista.mp.model.*;
import com.altruista.mp.repositories.ClientRepository;
import com.altruista.mp.repositories.UserRepository;
import com.altruista.mp.services.*;
import com.altruista.mp.utils.PropertiesLoaderUtility;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import org.apache.commons.cli.*;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.fluttercode.datafactory.impl.DataFactory;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.GeospatialIndex;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.TextIndexDefinition.TextIndexDefinitionBuilder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;


/**
 * Created by mwixson on 10/14/14.
 */
@Component
public class MPToolApp {
    @Autowired
    MongoTemplate mongoTemplate;
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MPToolApp.class);

    private String imageUrl = "images/";

    @Autowired
    ContactService contactService;
    @Autowired
    MemberService memberService;
    @Autowired
    MemberContactService memberContactService;
    @Autowired
    GoalService goalService;
    @Autowired
    ActionStepService stepService;
    @Autowired
    ConditionService conditionService;
    @Autowired
    DiagnosisService diagnosisService;
    @Autowired
    MedicationService medicationService;
    @Autowired
    MessageService messageService;
    @Autowired
    AlertService alertService;
    @Autowired
    VisitService visitService;
    @Autowired
    TaskService taskService;
    @Autowired
    ValidValueService validValueService;
    @Autowired
    MPDocumentService documentService;
    @Autowired
    AllergySensitivityService allergyService;
    @Autowired
    AssessmentService assessmentService;
    @Autowired
    AssessmentRunService assessmentRunService;
    @Autowired
    LobService lobService;
    @Autowired
    ProgramService programService;
    @Autowired
    UserRepository userRepository;
    @Autowired
    ClientRepository clientRepository;
    @Autowired
    UserService userService;
    @Autowired
    MemberIndexService indexService;

    DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyy-MM-dd");

    private Client altruista;
    private BCryptPasswordEncoder encoder;

    public MPToolApp() {
        encoder = new BCryptPasswordEncoder(8);      // Default strength is 10
    }

    public void run(String[] args) {
        CommandLineParser parser = new GnuParser();
        final Options gnuOptions = new Options();
        gnuOptions.addOption("d", false, "Load demo member data");
        gnuOptions.addOption("a", false, "Load demo assessment data");
        gnuOptions.addOption("r", true, "Load random member data");
        gnuOptions.addOption("n", false, "Load demo documents");
        gnuOptions.addOption("m", false, "Import documents using Excel manifest");
        gnuOptions.addOption("v", false, "Create views");
        gnuOptions.addOption("h", "Help", false, "Help");

        CommandLine commandLine;
        try {
            commandLine = parser.parse(gnuOptions, args);
            if (commandLine.hasOption("v")) {
                createIndexes();
            }
            if (commandLine.hasOption("d")) {
                addDemoMembers();
            }
            if (commandLine.hasOption("a")) {
                addDemoAssessments();
            }
            if (commandLine.hasOption("n")) {
                addDemoDocument();
            }
            if (commandLine.hasOption("m")) {
                readExeclFile();
            }

            if (commandLine.hasOption("r")) {
                long noMembers = Long.parseLong(commandLine.getOptionValue("r"));
                if (noMembers <= 0)
                    noMembers = 1;

                addRandomMembers(noMembers);
            }
            if (commandLine.hasOption("h")) {
                help();
                shutdown();
                return;
            }
        } catch (ParseException exc) {
            LOGGER.warn("Unable to parse command line: " + exc);
            help();
            shutdown();
            return;
        }

        shutdown();
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public static void help() {
        System.err.println("USAGE: java -jar MPTool [-d] [-a] [-nm] [-r #] [-v]");
        System.err.println("\t-d Load demo member data");
        System.err.println("\t-a Load demo assessment data");
        System.err.println("\t-n Load demo documents");
        System.err.println("\t-m Import documents using Excel manifest");
        System.err.println("\t-r # Load random member data where # is the number of members");
        System.err.println("\t-v Create indexes");
    }

    public void createIndexes() {
        LOGGER.info("BEGIN CREATING INDEXES");

        createActionStepIndexes();
        createAllergySensitivityIndexes();
        createCommunicationImpairmentIndexes();
        createConditionIndexes();
        createContactIndexes();
        createDiagnosisIndexes();
        createGoalIndexes();
        createDocumentIndexes();
        createMedicationIndexes();
        createMemberIndexes();
        createMemberContactIndexes();
        createMessageIndexes();
        createLobProgramIndexes();
        createTaskIndexes();
        createUserIndexes();
        createValidValueIndexes();
        createVisitIndexes();

        createTrackerCategoryIndexes();
        createTrackerIndexes();
        createTrackerRecordIndexes();

        createAssessmentRunIndexes();
        createEnrollmentIndexes();

        LOGGER.info("END CREATING INDEXES");
    }

    public void createEnrollmentIndexes() {
        mongoTemplate.indexOps(Enrollment.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Enrollment.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));
    }

    public void createActionStepIndexes() {
        mongoTemplate.indexOps(ActionStep.class).ensureIndex(new Index().on("goalId", Sort.Direction.ASC));
        mongoTemplate.indexOps(ActionStep.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(ActionStep.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(ActionStep.class).ensureIndex(new Index().on("status", Sort.Direction.ASC));
        mongoTemplate.indexOps(ActionStep.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));
    }

    public void createAllergySensitivityIndexes() {
        mongoTemplate.indexOps(AllergySensitivity.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(AllergySensitivity.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
    }

    public void createCommunicationImpairmentIndexes() {
        mongoTemplate.indexOps(CommunicationImpairment.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(CommunicationImpairment.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
    }

    public void createConditionIndexes() {
        mongoTemplate.indexOps(Condition.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));

        BasicDBObject memberIdCreatedOn = new BasicDBObject();
        memberIdCreatedOn.put("memberId", 1);
        memberIdCreatedOn.put("createdOn", 1);

        String colName = mongoTemplate.getCollectionName(Condition.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(memberIdCreatedOn);
    }

    public void createContactIndexes() {
        /** for FindProvider keywords search added on 10/14/15 */
        mongoTemplate.indexOps(Contact.class).ensureIndex(new TextIndexDefinitionBuilder().onField("salutation")
                .onField("firstName").onField("middleName").onField("lastName").onField("nameSuffix").onField("company").build());

        mongoTemplate.indexOps(Contact.class).ensureIndex(new Index().on("contactCode", Sort.Direction.ASC));
        mongoTemplate.indexOps(Contact.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));

        mongoTemplate.indexOps(Contact.class).ensureIndex(new GeospatialIndex("address.position"));

        BasicDBObject refIdContactType = new BasicDBObject();
        refIdContactType.put("refId", 1);
        refIdContactType.put("contactType", 1);

        String colName = mongoTemplate.getCollectionName(Contact.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(refIdContactType);
    }

    public void createDiagnosisIndexes() {
        mongoTemplate.indexOps(Diagnosis.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));

        BasicDBObject memberIdCreatedOn = new BasicDBObject();
        memberIdCreatedOn.put("memberId", 1);
        memberIdCreatedOn.put("createdOn", 1);

        String colName = mongoTemplate.getCollectionName(Diagnosis.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(memberIdCreatedOn);
    }

    public void createGoalIndexes() {
        mongoTemplate.indexOps(Goal.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Goal.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Goal.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));
    }

    public void createDocumentIndexes() {
        mongoTemplate.indexOps(MPDocument.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(MPDocument.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(MPDocument.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));
    }

    public void createMedicationIndexes() {
        mongoTemplate.indexOps(Medication.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));

        BasicDBObject memberIdCreatedOn = new BasicDBObject();
        memberIdCreatedOn.put("memberId", 1);
        memberIdCreatedOn.put("createdOn", 1);

        String colName = mongoTemplate.getCollectionName(Medication.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(memberIdCreatedOn);
    }

    public void createMemberIndexes() {
        mongoTemplate.indexOps(Member.class).ensureIndex(new Index().on("contactCode", Sort.Direction.ASC));
        mongoTemplate.indexOps(Member.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Member.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));

        BasicDBObject composite = new BasicDBObject();
        composite.put("refId", 1);
        composite.put("indexName", 1);
        composite.put("indexValue", 1);

        String colName = mongoTemplate.getCollectionName(MemberIndex.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(composite);
    }

    public void createMemberContactIndexes() {
        mongoTemplate.indexOps(MemberContact.class).ensureIndex(new Index().on("contactId", Sort.Direction.ASC));
        mongoTemplate.indexOps(MemberContact.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));

        BasicDBObject memberIdContactType = new BasicDBObject();
        memberIdContactType.put("memberId", 1);
        memberIdContactType.put("contactType", 1);

        String colName = mongoTemplate.getCollectionName(MemberContact.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(memberIdContactType);

        BasicDBObject refIdContactType = new BasicDBObject();
        refIdContactType.put("refId", 1);
        refIdContactType.put("contactType", 1);

        colName = mongoTemplate.getCollectionName(MemberContact.class);
        collection = mongoTemplate.getCollection(colName);
        collection.createIndex(refIdContactType);
    }

    public void createMessageIndexes() {
        mongoTemplate.indexOps(Message.class).ensureIndex(new Index().on("recipientIds", Sort.Direction.ASC));
        mongoTemplate.indexOps(Message.class).ensureIndex(new Index().on("senderId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Message.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Message.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));

        BasicDBObject memberIdCreatedOn = new BasicDBObject();
        memberIdCreatedOn.put("memberId", 1);
        memberIdCreatedOn.put("createdOn", 1);

        String colName = mongoTemplate.getCollectionName(Message.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(memberIdCreatedOn);
    }

    public void createLobProgramIndexes() {
        mongoTemplate.indexOps(Program.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Program.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Program.class).ensureIndex(new Index().on("lob", Sort.Direction.ASC));
        mongoTemplate.indexOps(Program.class).ensureIndex(new Index().on("plan", Sort.Direction.ASC));

        mongoTemplate.indexOps(Lob.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Lob.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Lob.class).ensureIndex(new Index().on("name", Sort.Direction.ASC));

        mongoTemplate.indexOps(ProgramEligibility.class).ensureIndex(new Index().on("programName", Sort.Direction.ASC));
    }

    private List<String> getTags() {
        List<String> tags = new ArrayList<>();
        tags.add("General Practice");
        tags.add("General Surgery");
        tags.add("Allergy/Immunology");
        tags.add("Therapeutic Radiology");
        tags.add("Geriatrics - Family Medicine");
        tags.add("Otolaryngology");
        tags.add("Dermatopathology");
        tags.add("Anesthesiology");
        tags.add("Adolescent Medicine: Family Medicine");
        tags.add("Adolescent Medicine: Pediatrics");
        tags.add("Behavioral Pediatrics");
        tags.add("Internal Medicine and Pediatrics");
        tags.add("Pediatric Rheumatology");
        tags.add("Cardiology");
        tags.add("Pediatric Infectious Disease");
        tags.add("Dermatology");
        tags.add("Spinal Cord Injury Medicine");
        tags.add("Pediatric Neurosurgery");
        tags.add("Pediatric Dermatology");
        tags.add("Pediatric Rehabilitation");
        tags.add("Cardiovascular Surgery");
        tags.add("Family Practice");

        return tags;
    }

    public void createTaskIndexes() {
        mongoTemplate.indexOps(Task.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Task.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));

        BasicDBObject memberIdCreatedOn = new BasicDBObject();
        memberIdCreatedOn.put("memberId", 1);
        memberIdCreatedOn.put("createdOn", 1);

        String colName = mongoTemplate.getCollectionName(Task.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(memberIdCreatedOn);
    }

    public void createUserIndexes() {
        mongoTemplate.indexOps(User.class).ensureIndex(new Index().on("contactCode", Sort.Direction.ASC));
        mongoTemplate.indexOps(User.class).ensureIndex(new Index().on("contactId", Sort.Direction.ASC));
        mongoTemplate.indexOps(User.class).ensureIndex(new Index().on("memberAuthorities.memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(User.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(User.class).ensureIndex(new Index().on("username", Sort.Direction.ASC));
    }

    public void createValidValueIndexes() {
        BasicDBObject nameRefId = new BasicDBObject();
        nameRefId.put("name", 1);
        nameRefId.put("refId", 1);

        String colName = mongoTemplate.getCollectionName(ValidValue.class);
        DBCollection collection = mongoTemplate.getCollection(colName);
        collection.createIndex(nameRefId);

        BasicDBObject nameValue = new BasicDBObject();
        nameValue.put("name", 1);
        nameValue.put("value", 1);

        colName = mongoTemplate.getCollectionName(ValidValue.class);
        collection = mongoTemplate.getCollection(colName);
        collection.createIndex(nameRefId);

        BasicDBObject nameDescription = new BasicDBObject();
        nameDescription.put("name", 1);
        nameDescription.put("description", 1);

        colName = mongoTemplate.getCollectionName(ValidValue.class);
        collection = mongoTemplate.getCollection(colName);
        collection.createIndex(nameDescription);
    }

    public void createVisitIndexes() {
        mongoTemplate.indexOps(Visit.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Visit.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
    }

    public void createTrackerCategoryIndexes() {
        mongoTemplate.indexOps(TrackerCategory.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
    }

    public void createTrackerIndexes() {
        mongoTemplate.indexOps(Tracker.class).ensureIndex(new Index().on("categoryId", Sort.Direction.ASC));
        mongoTemplate.indexOps(Tracker.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
    }

    public void createTrackerRecordIndexes() {
        mongoTemplate.indexOps(TrackerRecord.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(TrackerRecord.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
    }

    public void createAssessmentRunIndexes() {
        mongoTemplate.indexOps(AssessmentRun.class).ensureIndex(new Index().on("memberId", Sort.Direction.ASC));
        mongoTemplate.indexOps(AssessmentRun.class).ensureIndex(new Index().on("assessmentId", Sort.Direction.ASC));
        mongoTemplate.indexOps(AssessmentRun.class).ensureIndex(new Index().on("refId", Sort.Direction.ASC));
        mongoTemplate.indexOps(AssessmentRun.class).ensureIndex(new Index().on("syncedOn", Sort.Direction.ASC));
    }


    public void addRandomMembers(long noMembers) {
        LOGGER.info("BEGIN LOADING RANDOM DATA");

        try {

            // CLIENT INFORMATION
            // ---------------------------------------------------------------------
            altruista = new Client();
            altruista.setClientName("altruista");
            altruista.setTest(true);
            clientRepository.save(altruista);

            DataFactory df = new DataFactory();
            for (long i = 0; i < noMembers; i++) {
                LOGGER.info("Loading random member #" + i);

                String MEMBER_ID = UUID.randomUUID().toString();

                // USER INFORMATION
                // ---------------------------------------------------------------------
                // User Authorities and Members
                // ---------------------------------------
                List<String> memberAuths = new ArrayList<String>();
                memberAuths.add("API");
                memberAuths.add("HEALTH_RECORD");
                memberAuths.add("MESSAGES");
                memberAuths.add("EDIT_CAREPLAN");
                memberAuths.add("MANAGE_CALENDAR");
                memberAuths.add("FIND_PROVIDER");

                List<MemberACL> memberACL = new ArrayList<MemberACL>();
                memberACL.add(new MemberACL(MEMBER_ID, memberAuths));

                List<String> careGiverAuths = new ArrayList<String>();
                careGiverAuths.add("API");
                careGiverAuths.add("HEALTH_RECORD");
                careGiverAuths.add("MESSAGES");
                careGiverAuths.add("MANAGE_CALENDAR");
                careGiverAuths.add("FIND_PROVIDER");

                List<MemberACL> careGiverACL = new ArrayList<MemberACL>();
                careGiverACL.add(new MemberACL(MEMBER_ID, careGiverAuths));

                List<String> physicianAuths = new ArrayList<String>();
                physicianAuths.add("API");
                physicianAuths.add("HEALTH_RECORD");
                physicianAuths.add("MANAGE_CALENDAR");

                List<MemberACL> physicianACL = new ArrayList<MemberACL>();
                physicianACL.add(new MemberACL(MEMBER_ID, physicianAuths));

                // CREATE MEMBER
                // ---------------------------------------------------------------------
                MPDocument victoriaPhoto = new MPDocument();
                victoriaPhoto.setDescription("A picture of Victoria");
                victoriaPhoto.setDocumentType("png");
                victoriaPhoto.setDocumentUrl(imageUrl + "victoria.png");

                Contact memberContact = new Contact();
                //memberContact.setPhoto(victoriaPhoto);
                memberContact.setContactType(ContactType.MEMBER);
                //memberContact.setSalutation("Ms.");
                String lastname = df.getLastName();
                memberContact.setFirstName(df.getFirstName());
                memberContact.setMiddleName("M.");
                memberContact.setLastName(lastname);
                memberContact.setPrimaryEmail(df.getEmailAddress());
                memberContact.setPrimaryLanguage("ENGL");
                memberContact.setPreferredTimeOfContact("Morning");
                memberContact.setPhoneNumber(df.getNumberText(10));
                memberContact.setFaxNumber(df.getNumberText(10));
                memberContact.setDob(dtf.print(new DateTime(df.getBirthDate())));
                if (i % 2 == 0)
                    memberContact.setGender("F");
                else
                    memberContact.setGender("M");

                if (i % 2 == 0)
                    memberContact.setMaritalStatus("M");
                else
                    memberContact.setMaritalStatus("S");

                memberContact.setEthnicity("5");   // Other

                memberContact.setRegistrationStatus("Registration Required");
                memberContact.setTimezone("America/New_York");

                Address address = new Address();
                address.setAddress(df.getAddress());
                address.setAddress2(df.getAddressLine2());
                address.setCity(df.getCity());
                address.setStateProvince("VA");
                address.setPostalCode(df.getNumberText(5));
                address.setPrimary(true);
                memberContact.setAddress(address);
                String memberContactId = contactService.save(memberContact);
                memberContactService.save(new MemberContact(MEMBER_ID, memberContactId, ContactType.MEMBER));

                User user = new User();
                user.setSelectedMemberId(MEMBER_ID);
                user.setMemberAuthorities(memberACL);
                user.setContactId(memberContactId);
                user.setClientId(altruista.getId());
                String username = String.format("%s%d", lastname, i);
                user.setUsername(username);
                user.setPassword(encoder.encode("rest@n"));
                user.setCreatedBy("altruista");

                user.setAccountNonExpired(true);
                user.setAccountNonLocked(true);
                user.setCredentialsNonExpired(true);
                user.setEnabled(true);
                user.setTimezone("America/New_York");
                user.setTest(true);
                userRepository.save(user);

                // CREATE CAREGIVER
                // ----------------------------------
                // NO PHOTO FOR SUSAN
                Contact caregiver1Contact = new Contact();
                caregiver1Contact.setContactType(ContactType.CAREGIVER);
                //caregiver1Contact.setSalutation("Ms.");
                caregiver1Contact.setFirstName(df.getFirstName());
                caregiver1Contact.setMiddleName("A.");
                String caregiver1lastname = df.getLastName();
                caregiver1Contact.setLastName(caregiver1lastname);
                caregiver1Contact.setPrimaryEmail(df.getEmailAddress());
                caregiver1Contact.setPrimaryLanguage("ENGL");
                caregiver1Contact.setPreferredTimeOfContact("Morning");
                caregiver1Contact.setPhoneNumber(df.getNumberText(10));
                caregiver1Contact.setFaxNumber(df.getNumberText(10));
                caregiver1Contact.setRegistrationStatus("Registration Required");
                caregiver1Contact.setTimezone("America/New_York");
                caregiver1Contact.setRelationshipToMember("Daughter");

                Address caregiver1Address = new Address();
                caregiver1Address.setAddress(df.getAddress());
                caregiver1Address.setCity(df.getCity());
                caregiver1Address.setStateProvince("CA");
                caregiver1Address.setPostalCode(df.getNumberText(5));
                caregiver1Address.setPrimary(true);
                caregiver1Contact.setAddress(caregiver1Address);
                caregiver1Contact.setTest(true);
                String caregiver1ContactId = contactService.save(caregiver1Contact);
                memberContactService.save(new MemberContact(MEMBER_ID, caregiver1ContactId, ContactType.CAREGIVER));

                User caregiver1 = new User();
                caregiver1.setSelectedMemberId(MEMBER_ID);
                caregiver1.setMemberAuthorities(careGiverACL);
                caregiver1.setContactId(caregiver1ContactId);
                caregiver1.setClientId(altruista.getId());
                String caregiver1username = String.format("%s%d", caregiver1lastname, i);
                caregiver1.setUsername(caregiver1username);
                caregiver1.setPassword(encoder.encode("rest@n"));
                caregiver1.setCreatedBy("altruista");
                caregiver1.setAccountNonExpired(true);
                caregiver1.setAccountNonLocked(true);
                caregiver1.setCredentialsNonExpired(true);
                caregiver1.setEnabled(true);
                caregiver1.setTimezone("America/New_York");
                caregiver1.setTest(true);
                userRepository.save(caregiver1);

                // CREATE CAREGIVER 2
                // ----------------------------------
                // NO PHOTO FOR BILL
                Contact caregiver2Contact = new Contact();
                caregiver2Contact.setContactType(ContactType.CAREGIVER);
                //caregiver2Contact.setSalutation("Mr.");
                caregiver2Contact.setFirstName(df.getFirstName());
                caregiver2Contact.setMiddleName("C.");
                String caregiver2lastname = df.getLastName();
                caregiver2Contact.setLastName(caregiver2lastname);
                caregiver2Contact.setPrimaryEmail(df.getEmailAddress());
                caregiver2Contact.setPrimaryLanguage("ENGL");
                caregiver2Contact.setPreferredTimeOfContact("Morning");
                caregiver2Contact.setPhoneNumber(df.getNumberText(10));
                caregiver2Contact.setFaxNumber(df.getNumberText(10));
                caregiver2Contact.setRegistrationStatus("Registration Required");
                caregiver2Contact.setTimezone("America/New_York");
                caregiver2Contact.setRelationshipToMember("Son");

                Address caregiver2Address = new Address();
                caregiver2Address.setAddress(df.getAddress());
                caregiver2Address.setCity(df.getCity());
                caregiver2Address.setStateProvince("CA");
                caregiver2Address.setPostalCode(df.getNumberText(5));
                caregiver2Address.setPrimary(true);
                caregiver2Contact.setAddress(caregiver2Address);
                caregiver2Contact.setTest(true);
                String caregiver2ContactId = contactService.save(caregiver2Contact);
                memberContactService.save(new MemberContact(MEMBER_ID, caregiver2ContactId, ContactType.CAREGIVER));

                User caregiver2 = new User();
                caregiver2.setSelectedMemberId(MEMBER_ID);
                caregiver2.setMemberAuthorities(careGiverACL);
                caregiver2.setContactId(caregiver2ContactId);
                caregiver2.setClientId(altruista.getId());
                String caregiver2username = String.format("%s%d", caregiver2lastname, i);
                caregiver2.setUsername(caregiver2username);
                caregiver2.setPassword(encoder.encode("rest@n"));
                caregiver2.setCreatedBy("altruista");
                caregiver2.setAccountNonExpired(true);
                caregiver2.setAccountNonLocked(true);
                caregiver2.setCredentialsNonExpired(true);
                caregiver2.setEnabled(true);
                caregiver2.setTimezone("America/New_York");
                caregiver2.setTest(true);
                userRepository.save(caregiver2);

                // CREATE COACH
                // ----------------------------------
                MPDocument johnPhoto = new MPDocument();
                johnPhoto.setDescription("A picture of John");
                johnPhoto.setDocumentType("jpg");
                johnPhoto.setDocumentUrl(imageUrl + "JonathanLewis.jpg");

                Contact coach1Contact = new Contact();
                coach1Contact.setCompany(df.getBusinessName());
                //coach1Contact.setPhoto(johnPhoto);
                coach1Contact.setContactType(ContactType.CARECOACH);
                //coach1Contact.setSalutation("Mr.");
                coach1Contact.setFirstName(df.getFirstName());
                coach1Contact.setMiddleName("B.");
                coach1Contact.setLastName(df.getLastName());
                coach1Contact.setPrimaryEmail(df.getEmailAddress());
                coach1Contact.setPrimaryLanguage("ENGL");
                coach1Contact.setPhoneNumber(df.getNumberText(10));
                coach1Contact.setFaxNumber(df.getNumberText(10));
                coach1Contact.setRegistrationStatus("Registration Required");
                coach1Contact.setTimezone("America/New_York");
                coach1Contact.setTest(true);
                String coach1ContactId = contactService.save(coach1Contact);
                memberContactService.save(new MemberContact(MEMBER_ID, coach1ContactId, ContactType.CARECOACH));

                // CREATE COACH
                // ----------------------------------
                MPDocument karenPhoto = new MPDocument();
                karenPhoto.setDescription("A picture of Karen Smith");
                karenPhoto.setDocumentType("jpg");
                karenPhoto.setDocumentUrl(imageUrl + "KarenSmith.jpg");

                Contact coach2Contact = new Contact();
                coach2Contact.setCompany(df.getBusinessName());
                //coach2Contact.setPhoto(karenPhoto);
                coach2Contact.setContactType(ContactType.CARECOACH);
                //coach2Contact.setSalutation("Ms.");
                coach2Contact.setFirstName(df.getFirstName());
                coach2Contact.setMiddleName("L.");
                coach2Contact.setLastName(df.getLastName());
                coach2Contact.setPrimaryEmail(df.getEmailAddress());
                coach2Contact.setPrimaryLanguage("ENGL");
                coach2Contact.setPhoneNumber(df.getNumberText(10));
                coach2Contact.setFaxNumber(df.getNumberText(10));
                coach2Contact.setRegistrationStatus("Registration Required");
                coach2Contact.setTimezone("America/New_York");
                coach2Contact.setTest(true);
                String coach2ContactId = contactService.save(coach2Contact);
                memberContactService.save(new MemberContact(MEMBER_ID, coach2ContactId, ContactType.CARECOACH));

                // CREATE COACH
                // ----------------------------------
                Contact coach3Contact = new Contact();
                coach3Contact.setCompany(df.getBusinessName());
                coach3Contact.setContactType(ContactType.CARECOACH);
                //coach3Contact.setSalutation("Ms.");
                coach3Contact.setFirstName(df.getFirstName());
                coach3Contact.setMiddleName("L.");
                coach3Contact.setLastName(df.getLastName());
                coach3Contact.setPrimaryEmail(df.getEmailAddress());
                coach3Contact.setPrimaryLanguage("ENGL");
                coach3Contact.setPhoneNumber(df.getNumberText(10));
                coach3Contact.setFaxNumber(df.getNumberText(10));
                coach3Contact.setRegistrationStatus("Registration Required");
                coach3Contact.setTimezone("America/New_York");
                coach3Contact.setTest(true);
                String coach3ContactId = contactService.save(coach3Contact);
                memberContactService.save(new MemberContact(MEMBER_ID, coach3ContactId, ContactType.CARECOACH));

                // CREATE PHYSICIAN
                // ----------------------------------
                MPDocument amandaPhoto = new MPDocument();
                amandaPhoto.setDescription("A picture of Dr. Amanda");
                amandaPhoto.setDocumentType("jpg");
                amandaPhoto.setDocumentUrl(imageUrl + "AmandaJackson.jpg");

                Contact physician1Contact = new Contact();
                physician1Contact.setCompany(df.getBusinessName());
                //physician1Contact.setPhoto(amandaPhoto);
                physician1Contact.setContactType(ContactType.PHYSICIAN);
                physician1Contact.setSalutation("Dr.");
                physician1Contact.setFirstName(df.getFirstName());
                physician1Contact.setMiddleName("C.");
                String physician1lastname = df.getLastName();
                physician1Contact.setLastName(physician1lastname);
                physician1Contact.setPrimaryEmail(df.getEmailAddress());
                physician1Contact.setPrimaryLanguage("ENGL");
                physician1Contact.setPreferredTimeOfContact("Afternoon");
                physician1Contact.setPhoneNumber(df.getNumberText(10));
                physician1Contact.setFaxNumber(df.getNumberText(10));
                physician1Contact.setRegistrationStatus("Registration Required");
                physician1Contact.setTimezone("America/New_York");
                physician1Contact.setTest(true);
                String physician1ContactId = contactService.save(physician1Contact);
                memberContactService.save(new MemberContact(MEMBER_ID, physician1ContactId, ContactType.PHYSICIAN));

                User physician1 = new User();
                physician1.setSelectedMemberId(MEMBER_ID);
                physician1.setMemberAuthorities(physicianACL);
                physician1.setContactId(physician1ContactId);
                physician1.setClientId(altruista.getId());
                String physician1username = String.format("%s%d", physician1lastname, i);
                physician1.setUsername(physician1username);
                physician1.setPassword(encoder.encode("rest@n"));
                physician1.setCreatedBy("altruista");
                physician1.setAccountNonExpired(true);
                physician1.setAccountNonLocked(true);
                physician1.setCredentialsNonExpired(true);
                physician1.setEnabled(true);
                physician1.setTimezone("America/New_York");
                physician1.setTest(true);
                userRepository.save(physician1);

                // CREATE PHYSICIAN
                // ----------------------------------
                MPDocument mariaPhoto = new MPDocument();
                mariaPhoto.setDescription("A picture of Dr. Maria");
                mariaPhoto.setDocumentType("jpg");
                mariaPhoto.setDocumentUrl(imageUrl + "MariaWilliams.jpg");

                Contact physician2Contact = new Contact();
                physician2Contact.setCompany(df.getBusinessName());
                //physician2Contact.setPhoto(mariaPhoto);
                physician2Contact.setContactType(ContactType.PHYSICIAN);
                physician2Contact.setSalutation("Dr.");
                physician2Contact.setFirstName(df.getFirstName());
                physician2Contact.setMiddleName("D.");
                String physician2lastname = df.getLastName();
                physician2Contact.setLastName(physician2lastname);
                physician2Contact.setPrimaryEmail(df.getEmailAddress());
                physician2Contact.setPrimaryLanguage("ENGL");
                physician2Contact.setPreferredTimeOfContact("Afternoon");
                physician2Contact.setPhoneNumber(df.getNumberText(10));
                physician2Contact.setFaxNumber(df.getNumberText(10));
                physician2Contact.setRegistrationStatus("Registration Required");
                physician2Contact.setTimezone("America/New_York");
                physician2Contact.setTest(true);
                String physician2ContactId = contactService.save(physician2Contact);
                memberContactService.save(new MemberContact(MEMBER_ID, physician2ContactId, ContactType.PHYSICIAN));

                User physician2 = new User();
                physician2.setSelectedMemberId(MEMBER_ID);
                physician2.setMemberAuthorities(physicianACL);
                physician2.setContactId(physician2ContactId);
                physician2.setClientId(altruista.getId());
                String physician2username = String.format("%s%d", physician2lastname, i);
                physician2.setUsername(physician2username);
                physician2.setPassword(encoder.encode("rest@n"));
                physician2.setCreatedBy("altruista");
                physician2.setAccountNonExpired(true);
                physician2.setAccountNonLocked(true);
                physician2.setCredentialsNonExpired(true);
                physician2.setEnabled(true);
                physician2.setTimezone("America/New_York");
                physician2.setTest(true);
                userRepository.save(physician2);

                // MEMBER INFORMATION
                // ---------------------------------------------------------------------
                Member member = new Member();
                member.setId(MEMBER_ID);         // override Id with the specified MEMBER_ID
                member.setContactId(memberContactId);
                member.setContactCode("123456");
                //member.setRefId("123456");    // TEST MEMBERS SHOULD NOT HAVE A refId
                float number = df.getNumberBetween(1, 1000);
                member.setRiskScore(number);
                member.setRiskLevel("Yellow/Medium");
                member.setHeight(5.4f);
                member.setWeight(140);
                member.setClientRefId("2");
                member.setCareManager(String.format("%s %s", coach1Contact.getFirstName(), coach1Contact.getLastName()));

                allergyService.save(new AllergySensitivity(MEMBER_ID, "Antibiotics"));

                // MESSAGES
                // ---------------------------------------------------------------------
                Message msg1 = new Message();
                msg1.setMemberId(MEMBER_ID);
                msg1.setSenderId(coach1ContactId);

                Contact recipient1 = new Contact();
                recipient1.setContactType(ContactType.MEMBER);
                recipient1.setFirstName("Victoria");
                recipient1.setLastName("Jefferson");
                msg1.getRecipientIds().add(memberContactId);

                msg1.setSubject("Welcome to the Member Portal!");
                msg1.setBody("Thank you for joining.");
                msg1.setMessagePriority(MessagePriorityType.LOW);
                msg1.setViewed(false);
                msg1.setLocation("INBOX");
                msg1.setSentOn(DateTime.now());
                msg1.setMessagePriority(MessagePriorityType.MEDIUM);
                msg1.setTest(true);
                messageService.save(msg1);

                // MEDICAL CONDITIONS
                Condition cad = new Condition();
                cad.setMemberId(MEMBER_ID);
                cad.setName("Coronary Artery Disease");
                cad.setPrimary(true);
                cad.setCategory("CAD");
                cad.setSource("Claim");
                cad.setCreatedOn(DateTime.now());
                cad.setType(ConditionType.MEDICAL);
                cad.setRefCreatedOn(DateTime.now());
                cad.setTest(true);
                conditionService.save(cad);

                Condition arthritis = new Condition();
                arthritis.setMemberId(MEMBER_ID);
                arthritis.setName("Rheumatoid Arthritis");
                arthritis.setPrimary(false);
                arthritis.setCategory("OTHER");
                arthritis.setSource("Claim");
                arthritis.setCreatedOn(DateTime.now());
                arthritis.setType(ConditionType.MEDICAL);
                arthritis.setRefCreatedOn(DateTime.now());
                arthritis.setTest(true);
                conditionService.save(arthritis);

                Condition hypertension = new Condition();
                hypertension.setMemberId(MEMBER_ID);
                hypertension.setName("Hypertension");
                hypertension.setPrimary(false);
                hypertension.setCategory("OTHER");
                hypertension.setSource("EHR");
                hypertension.setCreatedOn(DateTime.now());
                hypertension.setType(ConditionType.MEDICAL);
                hypertension.setRefCreatedOn(DateTime.now());
                hypertension.setTest(true);
                conditionService.save(hypertension);

                Condition depression = new Condition();
                depression.setMemberId(MEMBER_ID);
                depression.setName("Depression");
                depression.setPrimary(true);
                depression.setCategory("OTHER");
                depression.setSource("EHR");
                depression.setCreatedOn(DateTime.now());
                depression.setType(ConditionType.BEHAVIORAL);
                depression.setRefCreatedOn(DateTime.now());
                depression.setTest(true);
                conditionService.save(depression);

                // LOB SERVICE
                Lob lob = new Lob();
                lob.setMemberId(MEMBER_ID);
                lob.setName("Medicaid");
                lob.setStartOn(DateTime.now());
                lob.setEndOn(new DateTime(2020, 1, 1, 0, 0));
                lob.setActive(true);
                lob.setTest(true);
                lobService.save(lob);

                // PROGRAMS
                programService.save(new Program(MEMBER_ID, "LOB", "PLAN", "Medicare"));
                programService.save(new Program(MEMBER_ID, "Medicaid", "UHC", "Medicaid NY"));

                // INDEXES
                indexService.save(new MemberIndex(MEMBER_ID, "SUBSCRIBER_SSN", "123456789"));
                indexService.save(new MemberIndex(MEMBER_ID, "MEDICAID_ID", "123456789"));

                // SAVE THE MEMBER
                member.setPrimaryMedicalProvider(String.format("%s %s", physician1Contact.getFirstName(), physician1Contact.getLastName()));
                member.setPrimaryMedicalCondition("Coronary Artery Disease");
                member.setPrimaryBehavioralCondition("Depression");
                member.setTest(true);
                memberService.save(member);

                // CARE PLAN
                // ---------------------------------------------------------------------
                Goal goal1 = new Goal();
                goal1.setRefId("1");
                goal1.setGoal("Keep my scheduled appointments");
                goal1.setMemberId(MEMBER_ID);
                goal1.setTest(true);
                String goal1id = goalService.save(goal1);

                DateTime goal1Step1StartOn = new DateTime(2014, 9, 24, 0, 0, 0);
                DateTime goal1Step1EndOn = new DateTime(2015, 9, 25, 0, 0, 0);

                ActionStep goal1Step1 = new ActionStep();
                goal1Step1.setRefId("1");
                goal1Step1.setMemberId(MEMBER_ID);
                goal1Step1.setGoalId(goal1id);
                goal1Step1.setIntervention("Visit doctor at least once a year");
                goal1Step1.setStep("Next doctor's visit: 9/24 at 9:00am");
                goal1Step1.setStatus("IN PROGRESS");
                goal1Step1.setMemberStatus("NEW");
                goal1Step1.setLob("DEMO");
                goal1Step1.setGoalGroup("General Care");
                goal1Step1.setCondition("General");
                goal1Step1.setTerm("Long Term");
                goal1Step1.setSignedOff(true);
                goal1Step1.setStartOn(goal1Step1StartOn);
                goal1Step1.setEndOn(goal1Step1EndOn);
                goal1Step1.setCreatedOn(DateTime.now());
                goal1Step1.setTest(true);
                stepService.save(goal1Step1);

                DateTime goal1Step2StartOn = new DateTime(2014, 11, 24, 0, 0, 0);
                DateTime goal1Step2EndOn = new DateTime(2015, 11, 25, 0, 0, 0);

                ActionStep goal1Step2 = new ActionStep();
                goal1Step2.setRefId("2");
                goal1Step2.setMemberId(MEMBER_ID);
                goal1Step2.setGoalId(goal1id);
                goal1Step2.setStep("Next dentist's visit: 11/24 at 10:00am");
                goal1Step2.setIntervention("Visit dentist at least once a year");
                goal1Step2.setMemberStatus("COMPLETE");
                goal1Step2.setStatus("TASK COMPLETED : GOAL MET");
                goal1Step2.setLob("DEMO");
                goal1Step2.setGoalGroup("General Care");
                goal1Step2.setCondition("General");
                goal1Step2.setTerm("Short Term");
                goal1Step2.setStartOn(goal1Step2StartOn);
                goal1Step2.setEndOn(goal1Step2EndOn);
                goal1Step2.setCreatedOn(DateTime.now());
                goal1Step2.setTest(true);
                stepService.save(goal1Step2);

                // ----------------------------
                Goal goal2 = new Goal();
                goal2.setRefId("2");
                goal2.setGoal("Take my medications on time");
                goal2.setMemberId(MEMBER_ID);
                goal2.setTest(true);
                String goal2id = goalService.save(goal2);

                ActionStep goal2Step1 = new ActionStep();
                goal2Step1.setRefId("1");
                goal2Step1.setMemberId(MEMBER_ID);
                goal2Step1.setGoalId(goal2id);
                goal2Step1.setStep("Use my medication log to track dosing");
                goal2Step1.setIntervention("Medication Compliance");
                goal2Step1.setMemberStatus("NEW");
                goal2Step1.setStatus("NEW");
                goal2Step1.setLob("DEMO");
                goal2Step1.setGoalGroup("General Care");
                goal2Step1.setCondition("General");
                goal2Step1.setTerm("Short Term");
                goal2Step1.setStartOn(goal1Step2StartOn);
                goal2Step1.setEndOn(goal1Step2EndOn);
                goal2Step1.setCreatedOn(DateTime.now());
                goal2Step1.setTest(true);
                stepService.save(goal2Step1);

                ActionStep goal2Step2 = new ActionStep();
                goal2Step2.setRefId("1");
                goal2Step2.setMemberId(MEMBER_ID);
                goal2Step2.setGoalId(goal2id);
                goal2Step2.setStep("Take one aspirin every day");
                goal2Step2.setIntervention("Reduce chance of heart attack");
                goal2Step2.setMemberStatus("IN-PROGRESS");
                goal2Step2.setStatus("IN PROGRESS");
                goal2Step2.setLob("DEMO");
                goal2Step2.setGoalGroup("General Care");
                goal2Step2.setCondition("General");
                goal2Step2.setTerm("Short Term");
                goal2Step2.setStartOn(goal1Step2StartOn);
                goal2Step2.setEndOn(goal1Step2EndOn);
                goal2Step2.setCreatedOn(DateTime.now());
                goal2Step2.setTest(true);
                stepService.save(goal2Step2);

                ActionStep goal2Step3 = new ActionStep();
                goal2Step3.setRefId("1");
                goal2Step3.setMemberId(MEMBER_ID);
                goal2Step3.setGoalId(goal2id);
                goal2Step3.setStep("Purchase pill organizer from pharmacy");
                goal2Step3.setIntervention("Medication Compliance");
                goal2Step3.setMemberStatus("COMPLETE");
                goal2Step3.setStatus("TASK COMPLETED");
                goal2Step3.setLob("DEMO");
                goal2Step3.setGoalGroup("General Care");
                goal2Step3.setCondition("General");
                goal2Step3.setTerm("Short Term");
                goal2Step3.setStartOn(goal1Step2StartOn);
                goal2Step3.setEndOn(goal1Step2EndOn);
                goal2Step3.setSignedOff(true);
                goal2Step3.setCreatedOn(DateTime.now());
                goal2Step3.setTest(true);
                stepService.save(goal2Step3);


                // ----------------------------
                Goal goal3 = new Goal();
                goal3.setRefId("3");
                goal3.setGoal("Quit smoking cigarettes");
                goal3.setMemberId(MEMBER_ID);
                goal3.setTest(true);
                String goal3id = goalService.save(goal3);

                ActionStep goal3Step1 = new ActionStep();
                goal3Step1.setMemberId(MEMBER_ID);
                goal3Step1.setRefId("1");
                goal3Step1.setGoalId(goal3id);
                goal3Step1.setStep("Contact QUIT hotline");
                goal3Step1.setMemberStatus("NEW");
                goal3Step1.setStatus("NEW");
                goal3Step1.setLob("DEMO");
                goal3Step1.setGoalGroup("General Care");
                goal3Step1.setCondition("Smoking");
                goal3Step1.setTerm("Short Term");
                goal3Step1.setStartOn(goal1Step2StartOn);
                goal3Step1.setEndOn(goal1Step2EndOn);
                goal3Step1.setCreatedOn(DateTime.now());
                goal3Step1.setTest(true);
                stepService.save(goal3Step1);

                // ----------------------------
                Goal goal4 = new Goal();
                goal4.setRefId("4");
                goal4.setGoal("Get my hearing checked");
                goal4.setMemberId(MEMBER_ID);
                goal4.setTest(true);
                String goal4id = goalService.save(goal4);

                ActionStep goal4Step1 = new ActionStep();
                goal4Step1.setMemberId(MEMBER_ID);
                goal4Step1.setRefId("1");
                goal4Step1.setGoalId(goal4id);
                goal4Step1.setStep("Appointment scheduled with Dr. Stephen Smith - Fri, 12/2");
                goal4Step1.setMemberStatus("COMPLETE");
                goal3Step1.setStatus("TASK COMPLETED");
                goal4Step1.setLob("DEMO");
                goal4Step1.setGoalGroup("General Care");
                goal4Step1.setCondition("General");
                goal4Step1.setTerm("Short Term");
                goal4Step1.setStartOn(goal1Step2StartOn);
                goal4Step1.setEndOn(goal1Step2EndOn);
                goal4Step1.setCreatedOn(DateTime.now());
                goal4Step1.setTest(true);
                stepService.save(goal4Step1);

                // DIAGNOSIS
                // ---------------------------------------------------------------------
                // I25.110
                Diagnosis diagnosis1 = new Diagnosis();
                diagnosis1.setName("Atherosclerotic heart disease of native coronary artery with unstable angina pectoris");
                diagnosis1.setMemberId(MEMBER_ID);
                diagnosis1.setPrimary(true);
                diagnosis1.setCategory("CAD");
                diagnosis1.setSource("Claim");
                diagnosis1.setRefCreatedOn(DateTime.now());
                diagnosis1.setTest(true);
                diagnosisService.save(diagnosis1);

                // M05.53
                Diagnosis diagnosis2 = new Diagnosis();
                diagnosis2.setName("Rheumatoid polyneuropathy with rheumatoid arthritis of wrist");
                diagnosis2.setMemberId(MEMBER_ID);
                diagnosis2.setPrimary(false);
                diagnosis2.setCategory("OTHER");
                diagnosis2.setSource("EHR");
                diagnosis2.setRefCreatedOn(DateTime.now());
                diagnosis2.setTest(true);
                diagnosisService.save(diagnosis2);

                SimpleDateFormat sdf = new SimpleDateFormat("M/dd/yyyy");

                // VISITS
                // ---------------------------------------------------------------------
                for (int v = 0; v < 20; v++) {
                    Visit visit = new Visit();
                    visit.setReason("Heart palpitation");
                    visit.setMemberId(MEMBER_ID);
                    visit.setPaidAmount(125.00f);
                    visit.setVisitType("MC");
                    visit.setProviderName(df.getBusinessName());
                    visit.setStatus("PAID");
                    visit.setSource("Claim");
                    visit.setVisitOn(new DateTime(df.getDateBetween(sdf.parse("01/01/2012"), DateTime.now().toDate())));
                    visit.setRefCreatedOn(DateTime.now());
                    visit.setTest(true);
                    visitService.save(visit);
                }

                // MEDICATIONS
                // ---------------------------------------------------------------------
                Medication med1 = new Medication();
                med1.setMemberId(MEMBER_ID);
                med1.setFrequency("Daily");
                med1.setDosage("10mg");
                med1.setStartDate(new DateTime(sdf.parse("01/01/2014")));
                med1.setEndDate(new DateTime(sdf.parse("12/31/2014")));
                med1.setQuantity("2.00");
                med1.setName("benazepril");
                med1.setDays(7);
                med1.setRefCreatedOn(DateTime.now());
                med1.setSource("MANUAL");
                med1.setTest(true);
                medicationService.save(med1);

                // DOCUMENTS
                // ---------------------------------------------------------------------
                /*MPDocument doc1 = new MPDocument();
                doc1.setMemberId(MEMBER_ID);
                doc1.setDocumentType("png");
                doc1.setName("Doc1 photo");
                doc1.setDocumentUrl(imageUrl + "article1-large.jpg");
                List<String> tags = new ArrayList<String>();
                tags.add("Picture");
                tags.add("Photo");
                doc1.setTags(tags);
                documentService.save(doc1);*/

            } // end for each member

        } catch (Exception exc) {
            LOGGER.error("Exception: " + exc);
        }

        LOGGER.info("END LOADING RANDOM DATA");
    }

    public void addDemoDocument() {
        LOGGER.info("BEGIN LOADING DEMO DOCUMENTATION DATA");
        try {
            // DOCUMENTS
            // ---------------------------------------------------------------------
            MPDocument doc1 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc1.setHeading("How can I keep myself mentally healthy?");
            doc1.setDocumentText("How can I keep myself mentally healthy");
            doc1.setDocumentType("png");
            doc1.setName("Doc1 photo");
            doc1.setThumbnail(imageUrl + "article1-large-Thumb.jpg");
            doc1.setDocumentUrl(imageUrl + "article1-large.jpg");
            List<String> tags = new ArrayList<String>();
            tags.add("head");
            tags.add("Hypertension");
            tags.add("Depression");
            doc1.setTags(tags);
            doc1.setTest(true);
            documentService.save(doc1);

            MPDocument doc2 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc2.setHeading("How can I keep myself mentally healthy?");
            doc2.setDocumentText("How can I keep myself mentally healthy");
            doc2.setDocumentType("pdf");
            doc2.setName("Pdf file");
            doc2.setThumbnail(imageUrl + "Sample-Pdf-Thumb.jpg");
            doc2.setDocumentUrl(imageUrl + "Multi_Page_Pdf.pdf");
            List<String> tags1 = new ArrayList<String>();
            tags1.add("head");
            tags1.add("Hypertension");
            tags1.add("Depression");
            doc2.setTags(tags1);
            doc2.setTest(true);
            documentService.save(doc2);

            MPDocument doc3 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc3.setHeading("How can I keep myself mentally healthy?");
            doc3.setDocumentText("How can I keep myself mentally healthy");
            doc3.setDocumentType("pdf");
            doc3.setName("Pdf file");
            doc3.setThumbnail(imageUrl + "Multi-Page-Pdf-Thumb.jpg");
            doc3.setDocumentUrl(imageUrl + "Multi_Page_Pdf.pdf");
            List<String> tags2 = new ArrayList<String>();
            tags1.add("head");
            tags1.add("Hypertension");
            tags1.add("Depression");
            doc3.setTags(tags2);
            doc3.setTest(true);
            documentService.save(doc3);

            MPDocument doc4 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc4.setHeading("Should I start a cardiac rehab program to make my heart stronger?");
            doc4.setDocumentText("Should I start a cardiac rehab program to make my heart stronger");
            doc4.setDocumentType("pdf");
            doc4.setName("Pdf file");
            doc4.setThumbnail(imageUrl + "Multi-Page-Pdf-Thumb.jpg");
            doc4.setDocumentUrl(imageUrl + "Multi_Page_Pdf.pdf");
            List<String> tags3 = new ArrayList<String>();
            tags3.add("heart");
            tags3.add("CAD");
            tags3.add("CHF");
            doc4.setTags(tags3);
            doc4.setTest(true);
            documentService.save(doc4);

            MPDocument doc5 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc5.setHeading("How can I prevent fractures?");
            doc5.setDocumentText("How can I prevent fractures");
            doc5.setDocumentType("pdf");
            doc5.setName("Pdf file");
            doc5.setThumbnail(imageUrl + "Multi-Page-Pdf-Thumb.jpg");
            doc5.setDocumentUrl(imageUrl + "Multi_Page_Pdf.pdf");
            List<String> tags4 = new ArrayList<String>();
            tags4.add("bone");
            tags4.add("Fracture");
            tags4.add("Osteoporosis");
            tags4.add("Arthritis");
            doc5.setTags(tags4);
            doc5.setTest(true);
            documentService.save(doc5);

            MPDocument doc6 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc6.setHeading("If I have an acute kidney problem, do you expect me to recover, and how long might that take?");
            doc6.setDocumentText("If I have an acute kidney problem, do you expect me to recover, and how long might that take");
            doc6.setDocumentType("png");
            doc6.setName("Doc1 photo");
            doc6.setThumbnail(imageUrl + "article1-large-Thumb.jpg");
            doc6.setDocumentUrl(imageUrl + "article1-large.jpg");
            List<String> tag5 = new ArrayList<String>();
            tag5.add("kidney");
            tag5.add("Kidney Stones");
            doc6.setTags(tag5);
            doc6.setTest(true);
            documentService.save(doc6);

            MPDocument doc7 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc7.setHeading("How quickly do we need to decide on treatment?");
            doc7.setDocumentText("How quickly do we need to decide on treatment");
            doc7.setDocumentType("png");
            doc7.setName("Doc1 photo");
            doc7.setThumbnail(imageUrl + "article1-large-Thumb.jpg");
            doc7.setDocumentUrl(imageUrl + "article1-large.jpg");
            List<String> tag6 = new ArrayList<String>();
            tag6.add("gas");
            doc7.setTags(tag6);
            doc7.setTest(true);
            documentService.save(doc7);

            MPDocument doc8 = new MPDocument();
            //doc1.setMemberId(MEMBER_ID);
            doc8.setHeading("How quickly do we need to decide on treatment?");
            doc8.setDocumentText("How quickly do we need to decide on treatment");
            doc8.setDocumentType("png");
            doc8.setName("Doc1 photo");
            doc8.setThumbnail(imageUrl + "article1-large-Thumb.jpg");
            doc8.setDocumentUrl(imageUrl + "article1-large.jpg");
            List<String> tag7 = new ArrayList<String>();
            tag7.add("circulatory");
            tag7.add("COPD");
            tag7.add("Diabetes");
            doc8.setTags(tag7);
            doc8.setTest(true);
            documentService.save(doc8);

        } catch (Exception exc) {
            LOGGER.error("Exception: " + exc);
        }

        LOGGER.info("END LOADING DEMO DOCUMENTATION DATA");
    }

    public void addDemoMembers() {
        LOGGER.info("BEGIN LOADING DEMO DATA");

        String MEMBER_ID = "ea3fa135-b50d-49f2-bbf0-ebb7298fa2b7";

        try {

            // CLIENT INFORMATION
            // ---------------------------------------------------------------------
            altruista = new Client();
            altruista.setClientName("altruista");
            altruista.setTest(true);
            clientRepository.save(altruista);


            // USER INFORMATION
            // ---------------------------------------------------------------------
            // User Authorities and Members
            // ---------------------------------------
            List<String> memberAuths = new ArrayList<String>();
            memberAuths.add("API");
            memberAuths.add("HEALTH_RECORD");
            memberAuths.add("MESSAGES");
            memberAuths.add("EDIT_CAREPLAN");
            memberAuths.add("MANAGE_CALENDAR");
            memberAuths.add("HEALTH_TRACKERS");
            memberAuths.add("HEALTH_ASSESSMENT");
            memberAuths.add("HEALTH_TIPS");
            memberAuths.add("FIND_PROVIDER");

            List<MemberACL> memberACL = new ArrayList<MemberACL>();
            memberACL.add(new MemberACL(MEMBER_ID, memberAuths));

            List<String> careGiverAuths = new ArrayList<String>();
            careGiverAuths.add("API");
            careGiverAuths.add("HEALTH_RECORD");
            careGiverAuths.add("MESSAGES");
            careGiverAuths.add("MANAGE_CALENDAR");
            careGiverAuths.add("HEALTH_TIPS");
            careGiverAuths.add("FIND_PROVIDER");

            List<MemberACL> careGiverACL = new ArrayList<MemberACL>();
            careGiverACL.add(new MemberACL(MEMBER_ID, careGiverAuths));

            List<String> physicianAuths = new ArrayList<String>();
            physicianAuths.add("API");
            physicianAuths.add("HEALTH_RECORD");
            physicianAuths.add("MANAGE_CALENDAR");
            physicianAuths.add("HEALTH_TIPS");

            List<MemberACL> physicianACL = new ArrayList<MemberACL>();
            physicianACL.add(new MemberACL(MEMBER_ID, physicianAuths));

            // CREATE MEMBER
            // ---------------------------------------------------------------------
            MPDocument victoriaPhoto = new MPDocument();
            victoriaPhoto.setDescription("A picture of Victoria");
            victoriaPhoto.setDocumentType("png");
            victoriaPhoto.setDocumentUrl(imageUrl + "victoria.png");

            Contact memberContact = new Contact();
            //memberContact.setPhoto(victoriaPhoto);
            memberContact.setContactType(ContactType.MEMBER);
            memberContact.setSalutation("Ms.");
            memberContact.setFirstName("Victoria");
            memberContact.setMiddleName("M.");
            memberContact.setLastName("Jefferson");
            memberContact.setPrimaryEmail("mwixson@altruistahealth.com");
            memberContact.setPrimaryLanguage("ENGL");
            memberContact.setPreferredTimeOfContact("Morning");
            memberContact.setPhoneNumber("619-555-1212");
            memberContact.setFaxNumber("619-555-1333");
            memberContact.setDob(dtf.print(new DateTime(1952, 9, 16, 0, 0)));
            memberContact.setGender("F");
            memberContact.setEthnicity("5");   // Other
            memberContact.setMaritalStatus("M");
            memberContact.setRegistrationStatus("Registration Required");
            memberContact.setTimezone("America/New_York");
            memberContact.setContactCode("35743657ARIZ1");

            Address address = new Address();
            address.setAddress("4414 Bluejay Court");
            address.setAddress2("Courtyard Terrace");
            address.setCity("Oakland");
            address.setStateProvince("CA");
            address.setPostalCode("92345");
            address.setPrimary(true);
            memberContact.setAddress(address);
            memberContact.setTest(true);
            String memberContactId = contactService.save(memberContact);
            memberContactService.save(new MemberContact(MEMBER_ID, memberContactId, ContactType.MEMBER));


            User user = new User();
            user.setSelectedMemberId(MEMBER_ID);
            user.setMemberAuthorities(memberACL);
            user.setContactId(memberContactId);
            user.setClientId(altruista.getId());
            user.setUsername("victoria");
            user.setPassword(encoder.encode("rest@n"));
            user.setCreatedBy("altruista");

            user.setAccountNonExpired(true);
            user.setAccountNonLocked(true);
            user.setCredentialsNonExpired(true);
            user.setEnabled(true);
            user.setTimezone("America/New_York");
            user.setTest(true);
            userRepository.save(user);

            // CREATE CAREGIVER
            // ----------------------------------
            // NO PHOTO FOR SUSAN
            Contact caregiver1Contact = new Contact();
            caregiver1Contact.setContactType(ContactType.CAREGIVER);
            caregiver1Contact.setSalutation("Ms.");
            caregiver1Contact.setFirstName("Susan");
            caregiver1Contact.setMiddleName("A.");
            caregiver1Contact.setLastName("Jefferson");
            caregiver1Contact.setPrimaryEmail("mwixson@altruistahealth.com");
            caregiver1Contact.setDob(dtf.print(new DateTime(2005, 9, 16, 0, 0)));
            caregiver1Contact.setPrimaryLanguage("ENGL");
            caregiver1Contact.setPreferredTimeOfContact("Morning");
            caregiver1Contact.setPrimaryEmail("susanj@website.com");
            caregiver1Contact.setPhoneNumber("909-555-1212");
            caregiver1Contact.setFaxNumber("909-555-1333");
            caregiver1Contact.setRegistrationStatus("Registration Required");
            caregiver1Contact.setTimezone("America/New_York");
            caregiver1Contact.setRelationshipToMember("Daughter");
            caregiver1Contact.setContactCode("35743658ARIZ2");

            Address caregiver1Address = new Address();
            caregiver1Address.setAddress("123 Street Ave.");
            caregiver1Address.setCity("Orange");
            caregiver1Address.setStateProvince("CA");
            caregiver1Address.setPostalCode("28908");
            caregiver1Address.setPrimary(true);
            caregiver1Contact.setAddress(caregiver1Address);
            caregiver1Contact.setTest(true);
            String caregiver1ContactId = contactService.save(caregiver1Contact);
            memberContactService.save(new MemberContact(MEMBER_ID, caregiver1ContactId, ContactType.CAREGIVER));

            User caregiver1 = new User();
            caregiver1.setSelectedMemberId(MEMBER_ID);
            caregiver1.setMemberAuthorities(careGiverACL);
            caregiver1.setContactId(caregiver1ContactId);
            caregiver1.setClientId(altruista.getId());
            caregiver1.setUsername("susan");
            caregiver1.setPassword(encoder.encode("rest@n"));
            caregiver1.setCreatedBy("altruista");
            caregiver1.setAccountNonExpired(true);
            caregiver1.setAccountNonLocked(true);
            caregiver1.setCredentialsNonExpired(true);
            caregiver1.setEnabled(true);
            caregiver1.setTimezone("America/New_York");
            caregiver1.setTest(true);
            userRepository.save(caregiver1);

            // CREATE CAREGIVER 2
            // ----------------------------------
            // NO PHOTO FOR BILL
            Contact caregiver2Contact = new Contact();
            caregiver2Contact.setContactType(ContactType.CAREGIVER);
            caregiver2Contact.setSalutation("Mr.");
            caregiver2Contact.setFirstName("Bill");
            caregiver2Contact.setMiddleName("C.");
            caregiver2Contact.setLastName("Jefferson");
            caregiver2Contact.setPrimaryEmail("mwixson@altruistahealth.com");
            caregiver2Contact.setPrimaryLanguage("ENGL");
            caregiver2Contact.setPreferredTimeOfContact("Morning");
            caregiver2Contact.setPrimaryEmail("billj@website.com");
            caregiver2Contact.setPhoneNumber("909-555-1267");
            caregiver2Contact.setFaxNumber("909-555-1355");
            caregiver2Contact.setRegistrationStatus("Registration Required");
            caregiver2Contact.setTimezone("America/New_York");
            caregiver2Contact.setRelationshipToMember("Son");

            Address caregiver2Address = new Address();
            caregiver2Address.setAddress("454 Anywhere Ave.");
            caregiver2Address.setCity("Orange");
            caregiver2Address.setStateProvince("CA");
            caregiver2Address.setPostalCode("28908");
            caregiver2Address.setPrimary(true);
            caregiver2Contact.setAddress(caregiver2Address);
            caregiver2Contact.setTest(true);
            String caregiver2ContactId = contactService.save(caregiver2Contact);
            memberContactService.save(new MemberContact(MEMBER_ID, caregiver2ContactId, ContactType.CAREGIVER));

            User caregiver2 = new User();
            caregiver2.setSelectedMemberId(MEMBER_ID);
            caregiver2.setMemberAuthorities(careGiverACL);
            caregiver2.setContactId(caregiver2ContactId);
            caregiver2.setClientId(altruista.getId());
            caregiver2.setUsername("bill");
            caregiver2.setPassword(encoder.encode("rest@n"));
            caregiver2.setCreatedBy("altruista");
            caregiver2.setAccountNonExpired(true);
            caregiver2.setAccountNonLocked(true);
            caregiver2.setCredentialsNonExpired(true);
            caregiver2.setEnabled(true);
            caregiver2.setTimezone("America/New_York");
            caregiver2.setTest(true);
            userRepository.save(caregiver2);

            // CREATE COACH
            // ----------------------------------
            MPDocument johnPhoto = new MPDocument();
            johnPhoto.setDescription("A picture of John");
            johnPhoto.setDocumentType("jpg");
            johnPhoto.setDocumentUrl(imageUrl + "JonathanLewis.jpg");

            Contact coach1Contact = new Contact();
            coach1Contact.setCompany("Altruista Health");
            //coach1Contact.setPhoto(johnPhoto);
            coach1Contact.setContactType(ContactType.CARECOACH);
            coach1Contact.setSalutation("Mr.");
            coach1Contact.setFirstName("John");
            coach1Contact.setMiddleName("B.");
            coach1Contact.setLastName("Lewis");
            coach1Contact.setPrimaryEmail("mwixson@altruistahealth.com");
            coach1Contact.setPrimaryLanguage("ENGL");
            coach1Contact.setPhoneNumber("703-111-1234");
            coach1Contact.setFaxNumber("703-211-4567");
            coach1Contact.setRegistrationStatus("Registration Required");
            coach1Contact.setTimezone("America/New_York");
            coach1Contact.setTest(true);

            Address coach1Address = new Address();
            coach1Address.setPrimary(true);
            coach1Address.setAddress("1946 Isaac");
            coach1Address.setAddress2("Newton Square");
            coach1Address.setCity("Reston");
            coach1Address.setStateProvince("VA");
            coach1Address.setPostalCode("20190");
            coach1Address.setPosition(new Double[]{-77.339565, 38.952340});
            coach1Contact.setAddress(coach1Address);

            String coach1ContactId = contactService.save(coach1Contact);
            memberContactService.save(new MemberContact(MEMBER_ID, coach1ContactId, ContactType.CARECOACH));

            // CREATE COACH
            // ----------------------------------
            MPDocument karenPhoto = new MPDocument();
            karenPhoto.setDescription("A picture of Karen Smith");
            karenPhoto.setDocumentType("jpg");
            karenPhoto.setDocumentUrl(imageUrl + "KarenSmith.jpg");

            Contact coach2Contact = new Contact();
            coach2Contact.setCompany("Altruista Health");
            //coach2Contact.setPhoto(karenPhoto);
            coach2Contact.setContactType(ContactType.CARECOACH);
            coach2Contact.setSalutation("Ms.");
            coach2Contact.setFirstName("Karen");
            coach2Contact.setMiddleName("L.");
            coach2Contact.setLastName("Smith");
            coach2Contact.setPrimaryEmail("mwixson@altruistahealth.com");
            coach2Contact.setPrimaryLanguage("ENGL");
            coach2Contact.setPhoneNumber("703-222-1111");
            coach2Contact.setFaxNumber("703-311-2222");
            coach2Contact.setRegistrationStatus("Registration Required");
            coach2Contact.setTimezone("America/New_York");
            coach2Contact.setTest(true);

            Address coach2Address = new Address();
            coach2Address.setPrimary(true);
            coach2Address.setAddress("1789 Ivy");
            coach2Address.setAddress2("Oak Square");
            coach2Address.setCity("Reston");
            coach2Address.setStateProvince("VA");
            coach2Address.setPostalCode("20190");
            coach2Address.setPosition(new Double[]{-77.348215, 38.956922});
            coach2Contact.setAddress(coach2Address);

            String coach2ContactId = contactService.save(coach2Contact);
            memberContactService.save(new MemberContact(MEMBER_ID, coach2ContactId, ContactType.CARECOACH));

            // CREATE COACH
            // ----------------------------------
            Contact coach3Contact = new Contact();
            coach3Contact.setCompany("Altruista Health");
            coach3Contact.setContactType(ContactType.CARECOACH);
            coach3Contact.setSalutation("Ms.");
            coach3Contact.setFirstName("Martha");
            coach3Contact.setMiddleName("L.");
            coach3Contact.setLastName("Jones");
            coach3Contact.setPrimaryEmail("mwixson@altruistahealth.com");
            coach3Contact.setPrimaryLanguage("ENGL");
            coach3Contact.setPhoneNumber("703-222-1111");
            coach3Contact.setFaxNumber("703-311-2223");
            coach3Contact.setRegistrationStatus("Registration Required");
            coach3Contact.setTimezone("America/New_York");
            coach3Contact.setTest(true);

            Address coach3Address = new Address();
            coach3Address.setPrimary(true);
            coach3Address.setAddress("11979 N");
            coach3Address.setAddress2("Shore Dr");
            coach3Address.setCity("Reston");
            coach3Address.setStateProvince("VA");
            coach3Address.setPostalCode("20190");
            coach3Address.setPosition(new Double[]{-77.336524, 38.958391});
            coach3Contact.setAddress(coach3Address);

            String coach3ContactId = contactService.save(coach3Contact);
            memberContactService.save(new MemberContact(MEMBER_ID, coach3ContactId, ContactType.CARECOACH));

            // CREATE PHYSICIAN
            // ----------------------------------
            MPDocument amandaPhoto = new MPDocument();
            amandaPhoto.setDescription("A picture of Dr. Amanda");
            amandaPhoto.setDocumentType("jpg");
            amandaPhoto.setDocumentUrl(imageUrl + "AmandaJackson.jpg");

            Contact physician1Contact = new Contact();
            physician1Contact.setCompany("Jackson Family Health");
            //physician1Contact.setPhoto(amandaPhoto);
            physician1Contact.setContactType(ContactType.PHYSICIAN);
            physician1Contact.setSalutation("Dr.");
            physician1Contact.setFirstName("Amanda");
            physician1Contact.setMiddleName("C.");
            physician1Contact.setLastName("Jackson");
            physician1Contact.setPrimaryEmail("mwixson@altruistahealth.com");
            physician1Contact.setPrimaryLanguage("ENGL");
            physician1Contact.setPreferredTimeOfContact("Afternoon");
            physician1Contact.setPhoneNumber("619-123-4567");
            physician1Contact.setFaxNumber("619-456-7890");
            physician1Contact.setRegistrationStatus("Registration Required");
            physician1Contact.setTimezone("America/New_York");
            physician1Contact.setTest(true);
            //Added tags for Physician on 10/14/15,
            physician1Contact.setTags(this.getTags());


            Address physician1Address = new Address();
            physician1Address.setAddress("11480 Sunset Hills Road");
            physician1Address.setCity("Reston");
            physician1Address.setStateProvince("VA");
            physician1Address.setPostalCode("20190");
            physician1Address.setPosition(new Double[]{-77.34952, 38.95451});
            physician1Address.setPrimary(true);
            physician1Contact.setAddress(physician1Address);

            String physician1ContactId = contactService.save(physician1Contact);
            memberContactService.save(new MemberContact(MEMBER_ID, physician1ContactId, ContactType.PHYSICIAN));

            User physician1 = new User();
            physician1.setSelectedMemberId(MEMBER_ID);
            physician1.setMemberAuthorities(physicianACL);
            physician1.setContactId(physician1ContactId);
            physician1.setClientId(altruista.getId());
            physician1.setUsername("amanda");
            physician1.setPassword(encoder.encode("rest@n"));
            physician1.setCreatedBy("altruista");
            physician1.setAccountNonExpired(true);
            physician1.setAccountNonLocked(true);
            physician1.setCredentialsNonExpired(true);
            physician1.setEnabled(true);
            physician1.setTimezone("America/New_York");
            physician1.setTest(true);
            userRepository.save(physician1);

            // CREATE PHYSICIAN
            // ----------------------------------
            MPDocument mariaPhoto = new MPDocument();
            mariaPhoto.setDescription("A picture of Dr. Maria");
            mariaPhoto.setDocumentType("jpg");
            mariaPhoto.setDocumentUrl(imageUrl + "MariaWilliams.jpg");

            Contact physician2Contact = new Contact();
            physician2Contact.setCompany("Regional Wellness Clinic");
            //physician2Contact.setPhoto(mariaPhoto);
            physician2Contact.setContactType(ContactType.PHYSICIAN);
            physician2Contact.setSalutation("Dr.");
            physician2Contact.setFirstName("Maria");
            physician2Contact.setMiddleName("D.");
            physician2Contact.setLastName("Williams");
            physician2Contact.setPrimaryEmail("mwixson@altruistahealth.com");
            physician2Contact.setPrimaryLanguage("ENGL");
            physician2Contact.setPreferredTimeOfContact("Afternoon");
            physician2Contact.setPhoneNumber("619-444-5252");
            physician2Contact.setFaxNumber("619-411-4343");
            physician2Contact.setRegistrationStatus("Registration Required");
            physician2Contact.setTimezone("America/New_York");
            physician2Contact.setTest(true);
            //Added tags for Physician on 10/14/15,
            physician2Contact.setTags(this.getTags());

            Address physician2Address = new Address();
            physician2Address.setAddress("611 S Carlin Springs Rd");
            physician2Address.setCity("Arlington");
            physician2Address.setStateProvince("VA");
            physician2Address.setPostalCode("22204");
            physician2Address.setPosition(new Double[]{-77.12129, 38.86212});
            physician2Address.setPrimary(true);
            physician2Contact.setAddress(physician2Address);

            String physician2ContactId = contactService.save(physician2Contact);
            memberContactService.save(new MemberContact(MEMBER_ID, physician2ContactId, ContactType.PHYSICIAN));

            User physician2 = new User();
            physician2.setSelectedMemberId(MEMBER_ID);
            physician2.setMemberAuthorities(physicianACL);
            physician2.setContactId(physician2ContactId);
            physician2.setClientId(altruista.getId());
            physician2.setUsername("maria");
            physician2.setPassword(encoder.encode("rest@n"));
            physician2.setCreatedBy("altruista");
            physician2.setAccountNonExpired(true);
            physician2.setAccountNonLocked(true);
            physician2.setCredentialsNonExpired(true);
            physician2.setEnabled(true);
            physician2.setTimezone("America/New_York");
            physician2.setTest(true);
            userRepository.save(physician2);

            // MEMBER INFORMATION
            // ---------------------------------------------------------------------
            Member member = new Member();
            member.setId(MEMBER_ID);        // override Id with the specified MEMBER_ID
            member.setClientRefId("2");     // 2 or 14 is required for UHC MMC testing
            member.setContactId(memberContactId);
            member.setContactCode("123456");
            //member.setRefId("123456");    // TEST MEMBERS SHOULD NOT HAVE A refId
            member.setRiskScore(610f);
            member.setRiskLevel("Yellow/Medium");
            member.setHeight(5.4f);
            member.setWeight(140);
            member.setCareManager("Cindy Smith");
            member.setClientRefId("2");
            member.setTest(true);

            allergyService.save(new AllergySensitivity(MEMBER_ID, "Antibiotics"));

            // MESSAGES
            // ---------------------------------------------------------------------
            Message msg1 = new Message();
            msg1.setMemberId(MEMBER_ID);
            msg1.setSenderId(coach1ContactId);

            Contact recipient1 = new Contact();
            recipient1.setContactType(ContactType.MEMBER);
            recipient1.setFirstName("Victoria");
            recipient1.setLastName("Jefferson");
            msg1.getRecipientIds().add(memberContactId);

            msg1.setSubject("Welcome to the Member Portal!");
            msg1.setBody("Thank you for joining.");
            msg1.setMessagePriority(MessagePriorityType.LOW);
            msg1.setViewed(false);
            msg1.setLocation("INBOX");
            msg1.setSentOn(DateTime.now());
            msg1.setMessagePriority(MessagePriorityType.MEDIUM);
            msg1.setTest(true);
            messageService.save(msg1);

            // MEDICAL CONDITIONS
            Condition cad = new Condition();
            cad.setMemberId(MEMBER_ID);
            cad.setName("Coronary Artery Disease");
            cad.setPrimary(true);
            cad.setCategory("CAD");
            cad.setSource("Claim");
            cad.setCreatedOn(DateTime.now());
            cad.setType(ConditionType.MEDICAL);
            cad.setRefCreatedOn(DateTime.now());
            cad.setTest(true);
            conditionService.save(cad);

            Condition arthritis = new Condition();
            arthritis.setMemberId(MEMBER_ID);
            arthritis.setName("Rheumatoid Arthritis");
            arthritis.setPrimary(false);
            arthritis.setCategory("OTHER");
            arthritis.setSource("Claim");
            arthritis.setCreatedOn(DateTime.now());
            arthritis.setType(ConditionType.MEDICAL);
            arthritis.setRefCreatedOn(DateTime.now());
            arthritis.setTest(true);
            conditionService.save(arthritis);

            Condition hypertension = new Condition();
            hypertension.setMemberId(MEMBER_ID);
            hypertension.setName("Hypertension");
            hypertension.setPrimary(false);
            hypertension.setCategory("OTHER");
            hypertension.setSource("EHR");
            hypertension.setCreatedOn(DateTime.now());
            hypertension.setType(ConditionType.MEDICAL);
            hypertension.setRefCreatedOn(DateTime.now());
            hypertension.setTest(true);
            conditionService.save(hypertension);

            Condition depression = new Condition();
            depression.setMemberId(MEMBER_ID);
            depression.setName("Depression");
            depression.setPrimary(false);
            depression.setCategory("OTHER");
            depression.setSource("EHR");
            depression.setCreatedOn(DateTime.now());
            depression.setType(ConditionType.BEHAVIORAL);
            depression.setRefCreatedOn(DateTime.now());
            depression.setTest(true);
            conditionService.save(depression);

            // LOB SERVICE
            Lob lob = new Lob();
            lob.setMemberId(MEMBER_ID);
            lob.setName("Medicaid");
            lob.setStartOn(DateTime.now());
            lob.setEndOn(new DateTime(2020, 1, 1, 0, 0));
            lob.setActive(true);
            lob.setTest(true);
            lobService.save(lob);

            // PROGRAMS
            programService.save(new Program(MEMBER_ID, "LOB", "PLAN", "Medicare"));
            programService.save(new Program(MEMBER_ID, "Medicaid", "UHC", "Medicaid NY"));

            // INDEXES
            indexService.save(new MemberIndex(MEMBER_ID, "SUBSCRIBER_SSN", "123456789"));
            indexService.save(new MemberIndex(MEMBER_ID, "MEDICAID_ID", "123456789"));

            // SAVE THE MEMBER
            member.setPrimaryMedicalProvider("Dr. John Malkovich");
            memberService.save(member);

            // CARE PLAN
            // ---------------------------------------------------------------------
            Goal goal1 = new Goal();
            goal1.setRefId("1");
            goal1.setGoal("Keep my scheduled appointments");
            goal1.setMemberId(MEMBER_ID);
            goal1.setTest(true);
            String goal1id = goalService.save(goal1);

            DateTime goal1Step1StartOn = new DateTime(2014, 9, 24, 0, 0, 0);
            DateTime goal1Step1EndOn = new DateTime(2015, 9, 25, 0, 0, 0);

            ActionStep goal1Step1 = new ActionStep();
            goal1Step1.setRefId("1");
            goal1Step1.setMemberId(MEMBER_ID);
            goal1Step1.setGoalId(goal1id);
            goal1Step1.setIntervention("Visit doctor at least once a year");
            goal1Step1.setStep("Next doctor's visit: 9/24 at 9:00am");
            goal1Step1.setStatus("IN PROGRESS");
            goal1Step1.setMemberStatus("InProgress");
            goal1Step1.setLob("DEMO");
            goal1Step1.setGoalGroup("General Care");
            goal1Step1.setCondition("General");
            goal1Step1.setTerm("Long Term");
            goal1Step1.setSignedOff(true);
            goal1Step1.setStartOn(goal1Step1StartOn);
            goal1Step1.setEndOn(goal1Step1EndOn);
            goal1Step1.setCreatedOn(DateTime.now());
            goal1Step1.setTest(true);
            stepService.save(goal1Step1);

            DateTime goal1Step2StartOn = new DateTime(2014, 11, 24, 0, 0);
            DateTime goal1Step2EndOn = new DateTime(2015, 11, 25, 0, 0);

            ActionStep goal1Step2 = new ActionStep();
            goal1Step2.setRefId("2");
            goal1Step2.setMemberId(MEMBER_ID);
            goal1Step2.setGoalId(goal1id);
            goal1Step2.setStep("Next dentist's visit: 11/24 at 10:00am");
            goal1Step2.setIntervention("Visit dentist at least once a year");
            goal1Step2.setMemberStatus("Completed");
            goal1Step2.setStatus("TASK COMPLETED : GOAL MET");
            goal1Step2.setLob("DEMO");
            goal1Step2.setGoalGroup("General Care");
            goal1Step2.setCondition("General");
            goal1Step2.setTerm("Short Term");
            goal1Step2.setStartOn(goal1Step2StartOn);
            goal1Step2.setEndOn(goal1Step2EndOn);
            goal1Step2.setCreatedOn(DateTime.now());
            goal1Step2.setTest(true);
            stepService.save(goal1Step2);

            // ----------------------------
            Goal goal2 = new Goal();
            goal2.setRefId("2");
            goal2.setGoal("Take my medications on time");
            goal2.setMemberId(MEMBER_ID);
            goal2.setTest(true);
            String goal2id = goalService.save(goal2);

            ActionStep goal2Step1 = new ActionStep();
            goal2Step1.setRefId("1");
            goal2Step1.setMemberId(MEMBER_ID);
            goal2Step1.setGoalId(goal2id);
            goal2Step1.setStep("Use my medication log to track dosing");
            goal2Step1.setIntervention("Medication Compliance");
            goal2Step1.setMemberStatus("New");
            goal2Step1.setStatus("NEW");
            goal2Step1.setLob("DEMO");
            goal2Step1.setGoalGroup("General Care");
            goal2Step1.setCondition("General");
            goal2Step1.setTerm("Short Term");
            goal2Step1.setStartOn(goal1Step2StartOn);
            goal2Step1.setEndOn(goal1Step2EndOn);
            goal2Step1.setCreatedOn(DateTime.now());
            goal2Step1.setTest(true);
            stepService.save(goal2Step1);

            ActionStep goal2Step2 = new ActionStep();
            goal2Step2.setRefId("1");
            goal2Step2.setMemberId(MEMBER_ID);
            goal2Step2.setGoalId(goal2id);
            goal2Step2.setStep("Take one aspirin every day");
            goal2Step2.setIntervention("Reduce chance of heart attack");
            goal2Step2.setMemberStatus("InProgress");
            goal2Step2.setStatus("IN PROGRESS");
            goal2Step2.setLob("DEMO");
            goal2Step2.setGoalGroup("General Care");
            goal2Step2.setCondition("General");
            goal2Step2.setTerm("Short Term");
            goal2Step2.setStartOn(goal1Step2StartOn);
            goal2Step2.setEndOn(goal1Step2EndOn);
            goal2Step2.setCreatedOn(DateTime.now());
            goal2Step2.setTest(true);
            stepService.save(goal2Step2);

            ActionStep goal2Step3 = new ActionStep();
            goal2Step3.setRefId("1");
            goal2Step3.setMemberId(MEMBER_ID);
            goal2Step3.setGoalId(goal2id);
            goal2Step3.setStep("Purchase pill organizer from pharmacy");
            goal2Step3.setIntervention("Medication Compliance");
            goal2Step3.setMemberStatus("Completed");
            goal2Step3.setStatus("TASK COMPLETED");
            goal2Step3.setLob("DEMO");
            goal2Step3.setGoalGroup("General Care");
            goal2Step3.setCondition("General");
            goal2Step3.setTerm("Short Term");
            goal2Step3.setStartOn(goal1Step2StartOn);
            goal2Step3.setEndOn(goal1Step2EndOn);
            goal2Step3.setSignedOff(true);
            goal2Step3.setCreatedOn(DateTime.now());
            goal2Step3.setTest(true);
            stepService.save(goal2Step3);

            // ----------------------------
            Goal goal3 = new Goal();
            goal3.setRefId("3");
            goal3.setGoal("Quit smoking cigarettes");
            goal3.setMemberId(MEMBER_ID);
            goal3.setTest(true);
            String goal3id = goalService.save(goal3);

            ActionStep goal3Step1 = new ActionStep();
            goal3Step1.setMemberId(MEMBER_ID);
            goal3Step1.setRefId("1");
            goal3Step1.setGoalId(goal3id);
            goal3Step1.setStep("Contact QUIT hotline");
            goal3Step1.setMemberStatus("New");
            goal3Step1.setStatus("NEW");
            goal3Step1.setLob("DEMO");
            goal3Step1.setGoalGroup("General Care");
            goal3Step1.setCondition("Smoking");
            goal3Step1.setTerm("Short Term");
            goal3Step1.setStartOn(goal1Step2StartOn);
            goal3Step1.setEndOn(goal1Step2EndOn);
            goal3Step1.setCreatedOn(DateTime.now());
            goal3Step1.setTest(true);
            stepService.save(goal3Step1);

            // ----------------------------
            Goal goal4 = new Goal();
            goal4.setRefId("4");
            goal4.setGoal("Get my hearing checked");
            goal4.setMemberId(MEMBER_ID);
            goal4.setTest(true);
            String goal4id = goalService.save(goal4);

            ActionStep goal4Step1 = new ActionStep();
            goal4Step1.setMemberId(MEMBER_ID);
            goal4Step1.setRefId("1");
            goal4Step1.setGoalId(goal4id);
            goal4Step1.setStep("Appointment scheduled with Dr. Stephen Smith - Fri, 12/2");
            goal4Step1.setMemberStatus("Completed");
            goal3Step1.setStatus("TASK COMPLETED");
            goal4Step1.setLob("DEMO");
            goal4Step1.setGoalGroup("General Care");
            goal4Step1.setCondition("General");
            goal4Step1.setTerm("Short Term");
            goal4Step1.setStartOn(goal1Step2StartOn);
            goal4Step1.setEndOn(goal1Step2EndOn);
            goal4Step1.setCreatedOn(DateTime.now());
            goal4Step1.setTest(true);
            stepService.save(goal4Step1);

            // DIAGNOSIS
            // ---------------------------------------------------------------------
            // I25.110
            Diagnosis diagnosis1 = new Diagnosis();
            diagnosis1.setName("Atherosclerotic heart disease of native coronary artery with unstable angina pectoris");
            diagnosis1.setMemberId(MEMBER_ID);
            diagnosis1.setPrimary(true);
            diagnosis1.setCategory("CAD");
            diagnosis1.setSource("Claim");
            diagnosis1.setRefCreatedOn(DateTime.now());
            diagnosis1.setTest(true);
            diagnosisService.save(diagnosis1);

            // M05.53
            Diagnosis diagnosis2 = new Diagnosis();
            diagnosis2.setName("Rheumatoid polyneuropathy with rheumatoid arthritis of wrist");
            diagnosis2.setMemberId(MEMBER_ID);
            diagnosis2.setPrimary(false);
            diagnosis2.setCategory("OTHER");
            diagnosis2.setSource("EHR");
            diagnosis2.setRefCreatedOn(DateTime.now());
            diagnosis2.setTest(true);
            diagnosisService.save(diagnosis2);

            // VISITS
            // ---------------------------------------------------------------------
            Visit visit1 = new Visit();
            visit1.setReason("Heart palpitation");
            visit1.setMemberId(MEMBER_ID);
            visit1.setPaidAmount(125.00f);
            visit1.setVisitType("MC");
            visit1.setProviderName("Dr. Ralph Peters");
            visit1.setStatus("PAID");
            visit1.setSource("Claim");
            visit1.setVisitOn(DateTime.now());
            visit1.setRefCreatedOn(DateTime.now());
            visit1.setTest(true);
            visitService.save(visit1);

            // MEDICATIONS
            // ---------------------------------------------------------------------
            Medication med1 = new Medication();
            med1.setMemberId(MEMBER_ID);
            med1.setFrequency("Daily");
            med1.setDosage("10mg");
            med1.setStartDate(new DateTime(2014, 1, 1, 0, 0));
            med1.setEndDate(new DateTime(2014, 12, 31, 0, 0));
            med1.setQuantity("2.00");
            med1.setName("benazepril");
            med1.setDays(7);
            med1.setRefCreatedOn(DateTime.now());
            med1.setSource("MANUAL");
            med1.setTest(true);
            medicationService.save(med1);


        } catch (Exception exc) {
            LOGGER.error("Exception: " + exc);
        }

        LOGGER.info("END LOADING DEMO DATA");
    }

    public void addDemoAssessments() {
        LOGGER.info("BEGIN LOADING DEMO ASSESSMENT DATA");

        // ASSESSMENTS
        List<AssessmentQuestion> as1qs = new ArrayList<AssessmentQuestion>();

        // QUESTION 1
        AssessmentQuestion as1q1 = new AssessmentQuestion();
        as1q1.setIsRequired(true);
        as1q1.setQuestion("Over the past 2 weeks, how often have you been bothered by feeling down, depressed or hopeless.");
        as1q1.setRefId("as1q1");
        as1q1.setOptionType("RadioButtonList");
        as1q1.setSequence(1);

        List<AssessmentQuestionOption> as1q1opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q1o1 = new AssessmentQuestionOption();
        as1q1o1.setRefId("as1q1o1");
        as1q1o1.setSequence(1);
        as1q1o1.setNextQuestionRefId("as1q2");
        as1q1o1.setNextQuestionSequence(2);
        as1q1o1.setOptionText("Not at all");
        as1q1o1.setOptionType("RadioButtonList");
        as1q1opts.add(as1q1o1);

        AssessmentQuestionOption as1q1o2 = new AssessmentQuestionOption();
        as1q1o2.setRefId("as1q1o2");
        as1q1o2.setSequence(2);
        as1q1o2.setNextQuestionRefId("as1q2");
        as1q1o2.setNextQuestionSequence(2);
        as1q1o2.setOptionText("Several Days");
        as1q1o2.setOptionType("RadioButtonList");
        as1q1opts.add(as1q1o2);

        AssessmentQuestionOption as1q1o3 = new AssessmentQuestionOption();
        as1q1o3.setRefId("as1q1o3");
        as1q1o3.setSequence(3);
        as1q1o3.setNextQuestionRefId("as1q2");
        as1q1o3.setNextQuestionSequence(2);
        as1q1o3.setOptionText("More than half the days");
        as1q1o3.setOptionType("RadioButtonList");
        as1q1opts.add(as1q1o3);

        AssessmentQuestionOption as1q1o4 = new AssessmentQuestionOption();
        as1q1o4.setRefId("as1q1o4");
        as1q1o4.setSequence(4);
        as1q1o4.setOptionText("Nearly every day");
        as1q1o4.setOptionType("RadioButtonList");
        as1q1opts.add(as1q1o4);

        List<AssessmentQuestionSubOption> as1q1o4opts = new ArrayList<AssessmentQuestionSubOption>();
        AssessmentQuestionSubOption as1q1o4s1 = new AssessmentQuestionSubOption();
        as1q1o4s1.setRefId("as1q1o4s1");
        as1q1o4s1.setSequence(1);
        as1q1o4s1.setOptionText("I am taking anti-depressants?");
        as1q1o4s1.setOptionType("RadioButtonList");
        as1q1o4opts.add(as1q1o4s1);

        AssessmentQuestionSubOption as1q1o4s2 = new AssessmentQuestionSubOption();
        as1q1o4s2.setRefId("as1q1o4s2");
        as1q1o4s2.setSequence(2);
        as1q1o4s2.setOptionText("I am not taking anti-depressants?");
        as1q1o4s2.setOptionType("RadioButtonList");
        as1q1o4opts.add(as1q1o4s2);
        as1q1o4.setSubOptions(as1q1o4opts);

        as1q1.setOptions(as1q1opts);
        as1qs.add(as1q1);

        // QUESTION 2
        AssessmentQuestion as1q2 = new AssessmentQuestion();
        as1q2.setIsRequired(true);
        as1q2.setQuestion("Over the past 2 weeks, how often have you been bothered by trouble falling asleep, staying asleep, or sleeping too much.");
        as1q2.setRefId("as1q2");
        as1q2.setOptionType("RadioButtonList");
        as1q2.setSequence(2);

        List<AssessmentQuestionOption> as1q2opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q2o1 = new AssessmentQuestionOption();
        as1q2o1.setRefId("as1q2o1");
        as1q2o1.setSequence(1);
        as1q2o1.setNextQuestionRefId("as1q3");
        as1q2o1.setNextQuestionSequence(3);
        as1q2o1.setOptionText("Not at all");
        as1q2o1.setOptionType("RadioButtonList");
        as1q2opts.add(as1q2o1);

        AssessmentQuestionOption as1q2o2 = new AssessmentQuestionOption();
        as1q2o2.setRefId("as1q2o2");
        as1q2o2.setSequence(2);
        as1q2o2.setNextQuestionRefId("as1q3");
        as1q2o2.setNextQuestionSequence(3);
        as1q2o2.setOptionText("Several Days");
        as1q2o2.setOptionType("RadioButtonList");
        as1q2opts.add(as1q2o2);

        AssessmentQuestionOption as1q2o3 = new AssessmentQuestionOption();
        as1q2o3.setRefId("as1q2o3");
        as1q2o3.setSequence(3);
        as1q2o3.setNextQuestionRefId("as1q3");
        as1q2o3.setNextQuestionSequence(3);
        as1q2o3.setOptionText("More than half the days");
        as1q2o3.setOptionType("RadioButtonList");
        as1q2opts.add(as1q2o3);

        AssessmentQuestionOption as1q2o4 = new AssessmentQuestionOption();
        as1q2o4.setRefId("as1q2o4");
        as1q2o4.setSequence(4);
        as1q2o4.setNextQuestionRefId("as1q3");
        as1q2o4.setNextQuestionSequence(3);
        as1q2o4.setOptionText("Nearly every day");
        as1q2o4.setOptionType("RadioButtonList");
        as1q2opts.add(as1q2o4);

        as1q2.setOptions(as1q2opts);
        as1qs.add(as1q2);

        // QUESTION 3
        AssessmentQuestion as1q3 = new AssessmentQuestion();
        as1q3.setIsRequired(false);
        as1q3.setQuestion("Over the past 2 weeks, how often have you been bothered by feeling tired or having little energy.");
        as1q3.setRefId("as1q3");
        as1q3.setOptionType("RadioButtonList");
        as1q3.setSequence(3);

        List<AssessmentQuestionOption> as1q3opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q3o1 = new AssessmentQuestionOption();
        as1q3o1.setRefId("as1q3o1");
        as1q3o1.setSequence(1);
        as1q3o1.setNextQuestionRefId("as1q4");
        as1q3o1.setNextQuestionSequence(4);
        as1q3o1.setOptionText("Not at all");
        as1q3o1.setOptionType("RadioButtonList");
        as1q3opts.add(as1q3o1);

        AssessmentQuestionOption as1q3o2 = new AssessmentQuestionOption();
        as1q3o2.setRefId("as1q3o2");
        as1q3o2.setSequence(2);
        as1q3o2.setNextQuestionRefId("as1q4");
        as1q3o2.setNextQuestionSequence(4);
        as1q3o2.setOptionText("Several Days");
        as1q3o2.setOptionType("RadioButtonList");
        as1q3opts.add(as1q3o2);

        AssessmentQuestionOption as1q3o3 = new AssessmentQuestionOption();
        as1q3o3.setRefId("as1q3o3");
        as1q3o3.setSequence(3);
        as1q3o3.setNextQuestionRefId("as1q4");
        as1q3o3.setNextQuestionSequence(4);
        as1q3o3.setOptionText("More than half the days");
        as1q3o3.setOptionType("RadioButtonList");
        as1q3opts.add(as1q3o3);

        AssessmentQuestionOption as1q3o4 = new AssessmentQuestionOption();
        as1q3o4.setRefId("as1q3o4");
        as1q3o4.setSequence(4);
        as1q3o4.setNextQuestionRefId("as1q4");
        as1q3o4.setNextQuestionSequence(4);
        as1q3o4.setOptionText("Nearly every day");
        as1q3o4.setOptionType("RadioButtonList");
        as1q3opts.add(as1q3o4);

        as1q3.setOptions(as1q3opts);
        as1qs.add(as1q3);

        // QUESTION 4
        AssessmentQuestion as1q4 = new AssessmentQuestion();
        as1q4.setIsRequired(true);
        as1q4.setQuestion("Over the past 2 weeks, how often have you been bothered by poor appetite or overeating.");
        as1q4.setRefId("as1q4");
        as1q4.setOptionType("RadioButtonList");
        as1q4.setSequence(4);

        List<AssessmentQuestionOption> as1q4opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q4o1 = new AssessmentQuestionOption();
        as1q4o1.setRefId("as1q4o1");
        as1q4o1.setSequence(1);
        as1q4o1.setNextQuestionRefId("as1q5");
        as1q4o1.setNextQuestionSequence(5);
        as1q4o1.setOptionText("Not at all");
        as1q4o1.setOptionType("RadioButtonList");
        as1q4opts.add(as1q4o1);

        AssessmentQuestionOption as1q4o2 = new AssessmentQuestionOption();
        as1q4o2.setRefId("as1q4o2");
        as1q4o2.setSequence(2);
        as1q4o2.setNextQuestionRefId("as1q5");
        as1q4o2.setNextQuestionSequence(5);
        as1q4o2.setOptionText("Several Days");
        as1q4o2.setOptionType("RadioButtonList");
        as1q4opts.add(as1q4o2);

        AssessmentQuestionOption as1q4o3 = new AssessmentQuestionOption();
        as1q4o3.setRefId("as1q4o3");
        as1q4o3.setSequence(3);
        as1q4o3.setNextQuestionRefId("as1q5");
        as1q4o3.setNextQuestionSequence(5);
        as1q4o3.setOptionText("More than half the days");
        as1q4o3.setOptionType("RadioButtonList");
        as1q4opts.add(as1q4o3);

        AssessmentQuestionOption as1q4o4 = new AssessmentQuestionOption();
        as1q4o4.setRefId("as1q4o4");
        as1q4o4.setSequence(4);
        as1q4o4.setNextQuestionRefId("as1q5");
        as1q4o4.setNextQuestionSequence(5);
        as1q4o4.setOptionText("Nearly every day");
        as1q4o4.setOptionType("RadioButtonList");
        as1q4opts.add(as1q4o4);

        as1q4.setOptions(as1q4opts);
        as1qs.add(as1q4);

        // QUESTION 5
        AssessmentQuestion as1q5 = new AssessmentQuestion();
        as1q5.setIsRequired(false);
        as1q5.setQuestion("Over the past 2 weeks, how often have you been bothered by feeling bad about yourself-or that he/she is a failure or have let themselves or their family down.");
        as1q5.setRefId("as1q5");
        as1q5.setOptionType("RadioButtonList");
        as1q5.setSequence(5);

        List<AssessmentQuestionOption> as1q5opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q5o1 = new AssessmentQuestionOption();
        as1q5o1.setRefId("as1q5o1");
        as1q5o1.setSequence(1);
        as1q5o1.setNextQuestionRefId("as1q6");
        as1q5o1.setNextQuestionSequence(6);
        as1q5o1.setOptionText("Not at all");
        as1q5o1.setOptionType("RadioButtonList");
        as1q5opts.add(as1q5o1);

        AssessmentQuestionOption as1q5o2 = new AssessmentQuestionOption();
        as1q5o2.setRefId("as1q5o2");
        as1q5o2.setSequence(2);
        as1q5o2.setNextQuestionRefId("as1q6");
        as1q5o2.setNextQuestionSequence(6);
        as1q5o2.setOptionText("Several Days");
        as1q5o2.setOptionType("RadioButtonList");
        as1q5opts.add(as1q5o2);

        AssessmentQuestionOption as1q5o3 = new AssessmentQuestionOption();
        as1q5o3.setRefId("as1q5o3");
        as1q5o3.setSequence(3);
        as1q5o3.setNextQuestionRefId("as1q6");
        as1q5o3.setNextQuestionSequence(6);
        as1q5o3.setOptionText("More than half the days");
        as1q5o3.setOptionType("RadioButtonList");
        as1q5opts.add(as1q5o3);

        AssessmentQuestionOption as1q5o4 = new AssessmentQuestionOption();
        as1q5o4.setRefId("as1q5o4");
        as1q5o4.setSequence(4);
        as1q5o4.setNextQuestionRefId("as1q6");
        as1q5o4.setNextQuestionSequence(6);
        as1q5o4.setOptionText("Nearly every day");
        as1q5o4.setOptionType("RadioButtonList");
        as1q5opts.add(as1q5o4);

        as1q5.setOptions(as1q5opts);
        as1qs.add(as1q5);

        // QUESTION 6
        AssessmentQuestion as1q6 = new AssessmentQuestion();
        as1q6.setIsRequired(false);
        as1q6.setQuestion("Over the past 2 weeks, how often have you been bothered by trouble concentrating on things, such as reading the newspaper or watching television.");
        as1q6.setRefId("as1q6");
        as1q6.setOptionType("RadioButtonList");
        as1q6.setSequence(6);

        List<AssessmentQuestionOption> as1q6opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q6o1 = new AssessmentQuestionOption();
        as1q6o1.setRefId("as1q6o1");
        as1q6o1.setSequence(1);
        as1q6o1.setNextQuestionRefId("as1q7");
        as1q6o1.setNextQuestionSequence(7);
        as1q6o1.setOptionText("Not at all");
        as1q6o1.setOptionType("RadioButtonList");
        as1q6opts.add(as1q6o1);

        AssessmentQuestionOption as1q6o2 = new AssessmentQuestionOption();
        as1q6o2.setRefId("as1q6o2");
        as1q6o2.setSequence(2);
        as1q6o2.setNextQuestionRefId("as1q7");
        as1q6o2.setNextQuestionSequence(7);
        as1q6o2.setOptionText("Several Days");
        as1q6o2.setOptionType("RadioButtonList");
        as1q6opts.add(as1q6o2);

        AssessmentQuestionOption as1q6o3 = new AssessmentQuestionOption();
        as1q6o3.setRefId("as1q6o3");
        as1q6o3.setSequence(3);
        as1q6o3.setNextQuestionRefId("as1q7");
        as1q6o3.setNextQuestionSequence(7);
        as1q6o3.setOptionText("More than half the days");
        as1q6o3.setOptionType("RadioButtonList");
        as1q6opts.add(as1q6o3);

        AssessmentQuestionOption as1q6o4 = new AssessmentQuestionOption();
        as1q6o4.setRefId("as1q6o4");
        as1q6o4.setSequence(4);
        as1q6o4.setNextQuestionRefId("as1q7");
        as1q6o4.setNextQuestionSequence(7);
        as1q6o4.setOptionText("Nearly every day");
        as1q6o4.setOptionType("RadioButtonList");
        as1q6opts.add(as1q6o4);

        as1q6.setOptions(as1q6opts);
        as1qs.add(as1q6);

        // QUESTION 7
        AssessmentQuestion as1q7 = new AssessmentQuestion();
        as1q7.setIsRequired(false);
        as1q7.setQuestion("Over the past 2 weeks, how often have you been bothered by moving or speaking so slowly that other people could have noticed. Or, the opposite- being so fidgety or restless that you have been moving around a lot more than usual.");
        as1q7.setRefId("as1q7");
        as1q7.setOptionType("RadioButtonList");
        as1q7.setSequence(7);

        List<AssessmentQuestionOption> as1q7opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q7o1 = new AssessmentQuestionOption();
        as1q7o1.setRefId("as1q7o1");
        as1q7o1.setSequence(1);
        as1q7o1.setNextQuestionRefId("as1q8");
        as1q7o1.setNextQuestionSequence(8);
        as1q7o1.setOptionText("Not at all");
        as1q7o1.setOptionType("RadioButtonList");
        as1q7opts.add(as1q7o1);

        AssessmentQuestionOption as1q7o2 = new AssessmentQuestionOption();
        as1q7o2.setRefId("as1q7o2");
        as1q7o2.setSequence(2);
        as1q7o2.setNextQuestionRefId("as1q8");
        as1q7o2.setNextQuestionSequence(8);
        as1q7o2.setOptionText("Several Days");
        as1q7o2.setOptionType("RadioButtonList");
        as1q7opts.add(as1q7o2);

        AssessmentQuestionOption as1q7o3 = new AssessmentQuestionOption();
        as1q7o3.setRefId("as1q7o3");
        as1q7o3.setSequence(3);
        as1q7o3.setNextQuestionRefId("as1q8");
        as1q7o3.setNextQuestionSequence(8);
        as1q7o3.setOptionText("More than half the days");
        as1q7o3.setOptionType("RadioButtonList");
        as1q7opts.add(as1q7o3);

        AssessmentQuestionOption as1q7o4 = new AssessmentQuestionOption();
        as1q7o4.setRefId("as1q7o4");
        as1q7o4.setSequence(4);
        as1q7o4.setNextQuestionRefId("as1q8");
        as1q7o4.setNextQuestionSequence(8);
        as1q7o4.setOptionText("Nearly every day");
        as1q7o4.setOptionType("RadioButtonList");
        as1q7opts.add(as1q7o4);

        as1q7.setOptions(as1q7opts);
        as1qs.add(as1q7);

        // QUESTION 8
        AssessmentQuestion as1q8 = new AssessmentQuestion();
        as1q8.setIsRequired(false);
        as1q8.setQuestion("Over the past 2 weeks, how often have you been bothered by thoughts that you would be better off dead or of hurting yourself in some way.");
        as1q8.setRefId("as1q8");
        as1q8.setOptionType("RadioButtonList");
        as1q8.setSequence(8);

        List<AssessmentQuestionOption> as1q8opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q8o1 = new AssessmentQuestionOption();
        as1q8o1.setRefId("as1q8o1");
        as1q8o1.setSequence(1);
        as1q8o1.setNextQuestionRefId("as1q9");
        as1q8o1.setNextQuestionSequence(9);
        as1q8o1.setOptionText("Not at all");
        as1q8o1.setOptionType("RadioButtonList");
        as1q8opts.add(as1q8o1);

        AssessmentQuestionOption as1q8o2 = new AssessmentQuestionOption();
        as1q8o2.setRefId("as1q8o2");
        as1q8o2.setSequence(2);
        as1q8o2.setNextQuestionRefId("as1q9");
        as1q8o2.setNextQuestionSequence(9);
        as1q8o2.setOptionText("Several Days");
        as1q8o2.setOptionType("RadioButtonList");
        as1q8opts.add(as1q8o2);

        AssessmentQuestionOption as1q8o3 = new AssessmentQuestionOption();
        as1q8o3.setRefId("as1q8o3");
        as1q8o3.setSequence(3);
        as1q8o3.setNextQuestionRefId("as1q9");
        as1q8o3.setNextQuestionSequence(9);
        as1q8o3.setOptionText("More than half the days");
        as1q8o3.setOptionType("RadioButtonList");
        as1q8opts.add(as1q8o3);

        AssessmentQuestionOption as1q8o4 = new AssessmentQuestionOption();
        as1q8o4.setRefId("as1q8o4");
        as1q8o4.setSequence(4);
        as1q8o4.setNextQuestionRefId("as1q9");
        as1q8o4.setNextQuestionSequence(9);
        as1q8o4.setOptionText("Nearly every day");
        as1q8o4.setOptionType("RadioButtonList");
        as1q8opts.add(as1q8o4);

        as1q8.setOptions(as1q8opts);
        as1qs.add(as1q8);

        // QUESTION 9
        AssessmentQuestion as1q9 = new AssessmentQuestion();
        as1q9.setIsRequired(false);
        as1q9.setQuestion("Do you currently have suicidal ideation?");
        as1q9.setRefId("as1q9");
        as1q9.setOptionType("RadioButtonList");
        as1q9.setSequence(9);

        List<AssessmentQuestionOption> as1q9opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q9o1 = new AssessmentQuestionOption();
        as1q9o1.setRefId("as1q9o1");
        as1q9o1.setSequence(1);
        as1q9o1.setNextQuestionRefId("as1q10");
        as1q9o1.setNextQuestionSequence(10);
        as1q9o1.setOptionText("Yes");
        as1q9o1.setOptionType("RadioButtonList");
        as1q9opts.add(as1q9o1);

        AssessmentQuestionOption as1q9o2 = new AssessmentQuestionOption();
        as1q9o2.setRefId("as1q9o2");
        as1q9o2.setSequence(2);
        as1q9o2.setNextQuestionRefId("as1q10");
        as1q9o2.setNextQuestionSequence(10);
        as1q9o2.setOptionText("No");
        as1q9o2.setOptionType("RadioButtonList");
        as1q9opts.add(as1q9o2);

        as1q9.setOptions(as1q9opts);
        as1qs.add(as1q9);

        // QUESTION 10
        AssessmentQuestion as1q10 = new AssessmentQuestion();
        as1q10.setIsRequired(false);
        as1q10.setQuestion("Have you ever been psychiatrically hospitalized?");
        as1q10.setRefId("as1q10");
        as1q10.setOptionType("RadioButtonList");
        as1q10.setSequence(10);

        List<AssessmentQuestionOption> as1q10opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q10o1 = new AssessmentQuestionOption();
        as1q10o1.setRefId("as1q10o1");
        as1q10o1.setSequence(1);
        as1q10o1.setNextQuestionRefId("as1q11");
        as1q10o1.setNextQuestionSequence(11);
        as1q10o1.setOptionText("Yes");
        as1q10o1.setOptionType("RadioButtonList");
        as1q10opts.add(as1q10o1);

        AssessmentQuestionOption as1q10o2 = new AssessmentQuestionOption();
        as1q10o2.setRefId("as1q10o2");
        as1q10o2.setSequence(2);
        as1q10o2.setNextQuestionRefId("as1q11");
        as1q10o2.setNextQuestionSequence(11);
        as1q10o2.setOptionText("No");
        as1q10o2.setOptionType("RadioButtonList");
        as1q10opts.add(as1q10o2);

        as1q10.setOptions(as1q10opts);
        as1qs.add(as1q10);

        // QUESTION 11
        AssessmentQuestion as1q11 = new AssessmentQuestion();
        as1q11.setIsRequired(false);
        as1q11.setQuestion("Are you interested in receiving counseling services?");
        as1q11.setRefId("as1q11");
        as1q11.setOptionType("RadioButtonList");
        as1q11.setSequence(11);

        List<AssessmentQuestionOption> as1q11opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q11o1 = new AssessmentQuestionOption();
        as1q11o1.setRefId("as1q11o1");
        as1q11o1.setSequence(1);
        as1q11o1.setNextQuestionRefId("as1q12");
        as1q11o1.setNextQuestionSequence(12);
        as1q11o1.setOptionText("Yes");
        as1q11o1.setOptionType("RadioButtonList");
        as1q11opts.add(as1q11o1);

        AssessmentQuestionOption as1q11o2 = new AssessmentQuestionOption();
        as1q11o2.setRefId("as1q11o2");
        as1q11o2.setSequence(2);
        as1q11o2.setNextQuestionRefId("as1q12");
        as1q11o2.setNextQuestionSequence(12);
        as1q11o2.setOptionText("No");
        as1q11o2.setOptionType("RadioButtonList");
        as1q11opts.add(as1q11o2);

        AssessmentQuestionOption as1q11o3 = new AssessmentQuestionOption();
        as1q11o3.setRefId("as1q11o3");
        as1q11o3.setSequence(3);
        as1q11o3.setNextQuestionRefId("as1q12");
        as1q11o3.setNextQuestionSequence(12);
        as1q11o3.setOptionText("Already receiving counseling");
        as1q11o3.setOptionType("RadioButtonList");
        as1q11opts.add(as1q11o3);

        as1q11.setOptions(as1q11opts);
        as1qs.add(as1q11);

        // QUESTION 12
        AssessmentQuestion as1q12 = new AssessmentQuestion();
        as1q12.setIsRequired(false);
        as1q12.setQuestion("Who prescribes your psychiatric medications?");
        as1q12.setRefId("as1q12");
        as1q12.setOptionType("RadioButtonList");
        as1q12.setSequence(12);

        List<AssessmentQuestionOption> as1q12opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as1q12o1 = new AssessmentQuestionOption();
        as1q12o1.setRefId("as1q12o1");
        as1q12o1.setSequence(1);
        as1q12o1.setOptionText("Primary Care Physician");
        as1q12o1.setOptionType("RadioButtonList");
        as1q12opts.add(as1q12o1);

        AssessmentQuestionOption as1q12o2 = new AssessmentQuestionOption();
        as1q12o2.setRefId("as1q12o2");
        as1q12o2.setSequence(2);
        as1q12o2.setOptionText("Psychiatrist");
        as1q12o2.setOptionType("RadioButtonList");
        as1q12opts.add(as1q12o2);

        as1q12.setOptions(as1q12opts);
        as1qs.add(as1q12);

        Assessment as1 = new Assessment();
        as1.setName("PHQ9-Depression Assessment");
        //  as1.setRefId("123456");
        as1.setActive(true);
        as1.setDuration(30L);
        as1.setQuestions(as1qs);
        as1.setTest(true);
        String as1id = assessmentService.save(as1);

        // ASSESSMENTS Next
        List<AssessmentQuestion> as2qs = new ArrayList<AssessmentQuestion>();

        // QUESTION 1
        AssessmentQuestion as2q1 = new AssessmentQuestion();
        as2q1.setIsRequired(true);
        as2q1.setQuestion("What exactly you are suffering from.");
        as2q1.setRefId("as2q1");
        as2q1.setOptionType("RadioButtonList");
        as2q1.setSequence(1);

        List<AssessmentQuestionOption> as2q1opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as2q1o1 = new AssessmentQuestionOption();
        as2q1o1.setRefId("as2q1o1");
        as2q1o1.setSequence(1);
        as2q1o1.setNextQuestionRefId("as2q2");
        as2q1o1.setNextQuestionSequence(2);
        as2q1o1.setOptionText("Fever");
        as2q1o1.setOptionType("RadioButtonList");
        as2q1opts.add(as2q1o1);

        AssessmentQuestionOption as2q1o2 = new AssessmentQuestionOption();
        as2q1o2.setRefId("as2q1o2");
        as2q1o2.setSequence(2);
        as2q1o2.setNextQuestionRefId("as2q2");
        as2q1o2.setNextQuestionSequence(2);
        as2q1o2.setOptionText("Diabetes");
        as2q1o2.setOptionType("RadioButtonList");
        as2q1opts.add(as2q1o2);

        as2q1.setOptions(as2q1opts);
        as2qs.add(as2q1);

        // QUESTION 2
        AssessmentQuestion as2q2 = new AssessmentQuestion();
        as2q2.setIsRequired(true);
        as2q2.setQuestion("Fever Name");
        as2q2.setRefId("as2q2");
        as2q2.setOptionType("CheckBoxList");
        as2q2.setSequence(2);

        List<AssessmentQuestionOption> as2q2opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as2q2o1 = new AssessmentQuestionOption();
        as2q2o1.setRefId("as2q2o1");
        as2q2o1.setSequence(1);
        as2q2o1.setNextQuestionRefId("as2q3");
        as2q2o1.setNextQuestionSequence(3);
        as2q2o1.setOptionText("Dengu");
        as2q2o1.setOptionType("TextBox");
        as2q2opts.add(as2q2o1);

        List<AssessmentQuestionSubOption> as2q2o1opts = new ArrayList<AssessmentQuestionSubOption>();
        AssessmentQuestionSubOption as2q2o1s1 = new AssessmentQuestionSubOption();
        as2q2o1s1.setRefId("as2q2o1s1");
        as2q2o1s1.setSequence(1);
        as2q2o1s1.setOptionText("I am taking anti-depressants?");
        as2q2o1s1.setOptionType("TextBox");
        as2q2o1opts.add(as2q2o1s1);
        as2q2o1.setSubOptions(as2q2o1opts);

        AssessmentQuestionOption as2q2o2 = new AssessmentQuestionOption();
        as2q2o2.setRefId("as2q2o2");
        as2q2o2.setSequence(2);
        as2q2o2.setNextQuestionRefId("as2q3");
        as2q2o2.setNextQuestionSequence(3);
        as2q2o2.setOptionText("Viral");
        as2q2opts.add(as2q2o2);

        as2q2.setOptions(as2q2opts);
        as2qs.add(as2q2);

        // QUESTION 3
        AssessmentQuestion as2q3 = new AssessmentQuestion();
        as2q3.setIsRequired(true);
        as2q3.setQuestion("Physician Name");
        as2q3.setRefId("as2q3");
        as2q3.setOptionType("TextBox");
        as2q3.setSequence(3);

        List<AssessmentQuestionOption> as2q3opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as2q3o1 = new AssessmentQuestionOption();
        as2q3o1.setRefId("as2q3o1");
        as2q3o1.setSequence(1);
        as2q3o1.setNextQuestionRefId("as2q4");
        as2q3o1.setNextQuestionSequence(4);
        as2q3o1.setOptionText("Name");
        as2q3.setOptionType("TextBox");
        as2q3opts.add(as2q3o1);

        AssessmentQuestionOption as2q3o2 = new AssessmentQuestionOption();
        as2q3o2.setRefId("as2q3o2");
        as2q3o2.setSequence(2);
        as2q3o2.setNextQuestionRefId("as2q4");
        as2q3o2.setNextQuestionSequence(4);
        as2q3o2.setOptionText("Last Name");
        as2q3o2.setOptionType("TextBox");
        as2q3opts.add(as2q3o2);


        as2q3.setOptions(as2q3opts);
        as2qs.add(as2q3);

        // QUESTION 4
        AssessmentQuestion as2q4 = new AssessmentQuestion();
        as2q4.setIsRequired(true);
        as2q4.setQuestion("Fever Cause");
        as2q4.setRefId("as2q4");
        as2q4.setOptionType("DropDownList");
        as2q4.setSequence(4);

        List<AssessmentQuestionOption> as2q4opts = new ArrayList<AssessmentQuestionOption>();
        AssessmentQuestionOption as2q4o1 = new AssessmentQuestionOption();
        as2q4o1.setRefId("as2q4o1");
        as2q4o1.setSequence(1);
        as2q4o1.setOptionText("Mosquito");
        as2q4opts.add(as2q4o1);

        AssessmentQuestionOption as2q4o2 = new AssessmentQuestionOption();
        as2q4o2.setRefId("as2q4o2");
        as2q4o2.setSequence(2);
        as2q4o2.setOptionText("Food Poison");
        as2q4o2.setOptionType("TextBox");
        as2q4opts.add(as2q4o2);

        List<AssessmentQuestionSubOption> as2q4o2opts = new ArrayList<AssessmentQuestionSubOption>();
        AssessmentQuestionSubOption as2q4o2s1 = new AssessmentQuestionSubOption();
        as2q4o2s1.setRefId("as2q4o2s1");
        as2q4o2s1.setSequence(1);
        as2q4o2s1.setOptionText("I am taking anti-depressants?");
        as2q4o2s1.setOptionType("TextBox");
        as2q4o2opts.add(as2q4o2s1);
        as2q4o2.setSubOptions(as2q4o2opts);

        as2q4.setOptions(as2q4opts);
        as2qs.add(as2q4);

        Assessment as2 = new Assessment();
        as2.setName("PHQ9-Blood Infection Assessment");
        // as2.setRefId("654321");
        as2.setDuration(40L);
        as2.setQuestions(as2qs);
        as2.setTest(true);
        String as2id = assessmentService.save(as2);

        // Associate the test assessments with all test members
        List<Member> members = memberService.findByTest(true);
        for (Member member : members) {
            AssessmentRun run1 = new AssessmentRun();
            run1.setMemberId(member.getId());
            run1.setAssessmentId(as1id);
            run1.setAssessmentName(as1.getName());
            run1.setSyncedOn(DateTime.now());
            run1.setTest(true);
            assessmentRunService.save(run1);

            AssessmentRun run2 = new AssessmentRun();
            run1.setMemberId(member.getId());
            run2.setAssessmentId(as2id);
            run2.setAssessmentName(as2.getName());
            run2.setSyncedOn(DateTime.now());
            run2.setTest(true);
            assessmentRunService.save(run2);
        }

        LOGGER.info("END LOADING DEMO ASSESSMENT DATA");
    }

    public void readExeclFile() {
        LOGGER.info("BEGIN LOADING DEMO DOCUMENT DATA");

        ArrayList<String> titles = new ArrayList<String>();
        int rowIndex = 0;
        try {
            FileInputStream inputStream = new FileInputStream(PropertiesLoaderUtility.getProperty("xlsAddress"));

            HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
            HSSFSheet sheet = workbook.getSheetAt(0);

            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                JSONObject jsonObject = new JSONObject();
                rowIndex++;
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                int rowLength = row.getPhysicalNumberOfCells();
                if (rowIndex == 1) {
                    while (cellIterator.hasNext()) {
                        Cell cell = (Cell) cellIterator.next();
                        titles.add(cell.getStringCellValue());
                    }
                } else {
                    for (int i = 0; i < rowLength; i++) {
                        Cell cell = (Cell) cellIterator.next();
                        jsonObject.put(titles.get(i), cell.getStringCellValue());
                    }

                    MPDocument doc = new MPDocument();
                    doc.setHeading(jsonObject.get("Title").toString());
                    doc.setName(jsonObject.get("Document Filename").toString());
                    String ext = FilenameUtils.getExtension(doc.getName());
                    doc.setDocumentType(ext.toLowerCase());
                    doc.setThumbnail(jsonObject.get("Thumbnail Filename").toString());

                    doc.setDocumentUrl(PropertiesLoaderUtility.getProperty("document.url.prefix") + jsonObject.get("Document Filename").toString());
                    System.out.println(PropertiesLoaderUtility.getProperty("document.url.prefix"));
                    doc.setDescription(jsonObject.get("Description").toString());
                    doc.setSource(jsonObject.get("Source").toString());
                    ArrayList<String> condition = new ArrayList<String>();

                    String listOfConditions = jsonObject.get("Conditions").toString();
                    String strArrary[] = listOfConditions.split(",");
                    for (int i = 0; i < strArrary.length; i++) {
                        condition.add(strArrary[i]);
                    }
                    ArrayList<String> tags = new ArrayList<String>();
                    String listOfTags = jsonObject.get("Tags").toString();
                    String strArray1[] = listOfTags.split(",");
                    for (int i = 0; i < strArray1.length; i++) {
                        tags.add(strArray1[i]);
                    }
                    tags.addAll(condition);

                    doc.setTags(tags);
                    //doc.setDocumentText(documentService.getEncodedImageFile(doc));
                    doc.setTest(true);
                    documentService.save(doc);

                }

            }

        } catch (Exception e) {
            LOGGER.error("Unable to load document: " + e);
        }


        LOGGER.info("END LOADING DEMO DOCUMENT DATA");
    }

    private void shutdown() {
    }

}
