package com.altruista.mp.dao;

import com.altruista.mp.model.MemberIndex;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/16/14.
 */
public class MemberIndexMapper {
    public static MemberIndex toMemberIndex(ResultSet rs) throws SQLException {
        MemberIndex index = new MemberIndex();
        index.setRefId(rs.getString("INDEX_ID"));
        index.setIndexName(rs.getString("INDEX_NAME"));
        index.setIndexValue(rs.getString("INDEX_VALUE"));
        index.setIndexType(rs.getString("INDEX_TYPE"));
        index.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return index;
    }
}
