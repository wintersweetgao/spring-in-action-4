package com.altruista.mp.dao;

import com.altruista.mp.model.Medication;
import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.MedicationService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class MedicationSyncImpl extends BaseSyncImpl implements MedicationSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MedicationSyncImpl.class);

    @Autowired
    private MedicationService medicationService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT M.PATIENT_ID "
                            + "FROM PATIENT_MEDICATION_SCHEDULE M "
                            + " LEFT OUTER JOIN CM_MEDICATIONS_FREQUENCY F ON F.FREQUENCY_ID = M.FREQUENCY_ID, "
                            + "PATIENT_MEDICATION_CODE C "
                            + "WHERE "
                            + " M.MEDICATION_CODE_ID = C.MEDICATION_ID "
                            + " AND (M.CREATED_ON >= :runDate OR M.UPDATED_ON >= :runDate) ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("medication");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        // Remaining column DAY_SUPPLY_ID-> DAY
        String sql =
                "SELECT M.PATIENT_ID, M.MEDICATION_ID, M.DOSAGE_ID, M.DAY_SUPPLY_ID, M.QUANTITY_SUPPLY_ID, "
                        + "MEDICATION_DESC, DOSAGE, "
                        + "FREQUENCY_NAME, SCHEDULE_FROM, SCHEDULE_TO, M.CREATED_ON "
                        + "FROM PATIENT_MEDICATION_SCHEDULE M "
                        + " LEFT OUTER JOIN CM_MEDICATIONS_FREQUENCY F ON F.FREQUENCY_ID = M.FREQUENCY_ID, "
                        + "PATIENT_MEDICATION_CODE C "
                        + "WHERE "
                        + " M.MEDICATION_CODE_ID = C.MEDICATION_ID "
                        + " AND (M.CREATED_ON >= ? OR M.UPDATED_ON >= ?) "
                        + " AND PATIENT_ID =?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(member, rs);
                    }
                });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        Medication medication = MedicationMapper
                .toMedication(rs);

        medication.setMemberId(member.getId());

        // Save the MEDICATION
        String medicationId = saveMedicationToMongodb(medication);

        LOGGER.debug("MEDICATION: Mongodb ["
                + medicationId + "] <= SQL [ "
                + medication.getRefId() + " ]");
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT MEDICATION_ID "
                        + "FROM PATIENT_MEDICATION_SCHEDULE "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("MEDICATION_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<Medication> meds = medicationService.findIdByRefId(refId);
        if (meds != null && meds.size() > 0)
            medicationService.delete(meds.get(0).getId());
    }

    private String saveMedicationToMongodb(Medication medication) {
        if (medication.getRefId() != null) {
            List<Medication> existing = medicationService.findIdByRefId(medication.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                medication.setId(existing.get(0).getId());
                medication.setVersion(existing.get(0).getVersion());
            } else
                medication.setId(UUID.randomUUID().toString());
        } else
            medication.setId(UUID.randomUUID().toString());

        return medicationService.save(medication, false);
    }
}
