package com.altruista.mp.dao;

import com.altruista.mp.model.MPDocument;
import com.altruista.mp.services.MPDocumentService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MPDocumentSyncImpl extends BaseSyncImpl implements MPDocumentSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MPDocumentSyncImpl.class);

    @Autowired
    private MPDocumentService mpDocumentService;

    @Override
    public void applyRemoteChanges(final DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql = " SELECT HEALTH_ARTICLE_ID, HEALTH_ARTICLE_HEADING, HEALTH_SHORT_DESC, "
                + "HEALTH_ARTICLE_TEXT, HEALTH_ARTICLE_IMAGE, HEALTH_FILE, "
                + "HEALTH_ARTICLE_DATE, HEALTH_ARTICLE_AUTHOR, C.ARTICLE_CATEGORY, "
                + "S.ARTICLE_SUBCATEGORY,HA.CREATED_ON "
                + "FROM HEALTH_ARTICLE HA, ARTICLE_CATEGORY C, ARTICLE_SUBCATEGORY S "
                + "WHERE HA.CATEGORY_ID = C.ARTICLE_CATEGORY_ID "
                + " AND HA.SUBCATEGORY_ID = S.ARTICLE_SUBCATEGORY_ID "
                + " AND (HA.CREATED_ON >= ? OR HA.UPDATED_ON >= ?)";

        template.setFetchSize(fetchsize); // process 100 rows at a time to
        // minimize memory consumption
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        // MPDocument
                        MPDocument mpDocument = MPDocumentMapper
                                .toMPDocument(rs);

                        // tags
                        List<String> tags = new ArrayList<String>();

                        String category = rs.getString("ARTICLE_CATEGORY");
                        String subCategory = rs
                                .getString("ARTICLE_SUBCATEGORY");

                        tags.add(category);
                        tags.add(subCategory);

                        mpDocument.setTags(tags);

                        // Save the Document
                        String mpDocumentId = saveMPDocumentToMongodb(mpDocument);

                        LOGGER.debug("MPDocument: Mongodb ["
                                + mpDocumentId + "] <= SQL [ "
                                + mpDocument.getRefId() + " ]");
                    }

                });
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT HEALTH_ARTICLE_ID "
                        + "FROM HEALTH_ARTICLE "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("HEALTH_ARTICLE_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<MPDocument> docs = mpDocumentService.findIdByRefId(refId);
        if (docs != null && docs.size() > 0)
            mpDocumentService.delete(docs.get(0).getId());
    }

    private String saveMPDocumentToMongodb(MPDocument mpDocument) {
        if (mpDocument.getRefId() != null) {
            List<MPDocument> existing = mpDocumentService.findIdByRefId(mpDocument.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                mpDocument.setId(existing.get(0).getId());
                mpDocument.setVersion(existing.get(0).getVersion());
            } else
                mpDocument.setId(UUID.randomUUID().toString());
        } else
            mpDocument.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        mpDocument.setSyncedOn(DateTime.now());
        mpDocumentService.setSyncEnabled(false);*/

        return mpDocumentService.save(mpDocument, false);
    }

}
