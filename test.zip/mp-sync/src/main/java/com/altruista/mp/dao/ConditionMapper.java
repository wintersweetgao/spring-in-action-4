package com.altruista.mp.dao;

import com.altruista.mp.model.Condition;
import com.altruista.mp.model.ConditionType;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ConditionMapper {
    public static Condition toCondition(ResultSet rs) throws SQLException {
        Condition condition = new Condition();

        String conType = rs.getString("NAME");
        if (conType.equals("Medical")) {
            condition.setType(ConditionType.MEDICAL);
        } else if (conType.equals("Behavioral")) {
            condition.setType(ConditionType.BEHAVIORAL);
        }
        condition.setName(rs.getString("CONDITION_NAME"));
        condition.setRefId(rs.getString("PATIENT_CONDITION_ID"));
        condition.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return condition;
    }
}
