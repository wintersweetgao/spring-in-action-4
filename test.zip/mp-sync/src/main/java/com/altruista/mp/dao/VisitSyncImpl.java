package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import com.altruista.mp.services.VisitService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class VisitSyncImpl extends BaseSyncImpl implements VisitSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(VisitSyncImpl.class);

    @Autowired
    private VisitService visitService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private ContactService contactService;
    @Autowired
    private SyncLogService syncLogService;


    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT PATIENT_ID "
                            + "FROM PATIENT_VISIT V "
                            + "WHERE (V.CREATED_ON >= :runDate OR V.UPDATED_ON >= :runDate)";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("visit");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql = "SELECT PATIENT_ID,PATIENT_VISIT_ID,PROVIDER_NAME,VISIT_REASON, "
                + "VISIT_DATE,SOURCE_TYPE,AMOUNT_PAID,PROCESSING_STATUS,V.CREATED_ON, "
                + "V.PHYSICIAN_ID, VT.NAME AS VISIT_TYPE_NAME "
                + "FROM PATIENT_VISIT V LEFT OUTER JOIN PHYSICIAN_DEMOGRAPHY D ON V.PHYSICIAN_ID = D.PHYSICIAN_ID, "
                + "VISIT_TYPE VT "
                + "WHERE (V.CREATED_ON >= ? OR V.UPDATED_ON >= ?) "
                + " AND VT.VISIT_TYPE = V.VISIT_TYPE"
                + " AND PATIENT_ID = ? ";

        template.setFetchSize(fetchsize);
        // env.getProperty("fetchSize");
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(rs);
                    }
                });
    }

    private void postChanges(ResultSet rs) throws SQLException {

        Visit visit = VisitMapper.toVisit(rs);

        List<Member> members = memberService.findIdByRefId(rs
                .getString("PATIENT_ID"));

        if (members != null && members.size() > 0) {
            visit.setMemberId(members.get(0).getId());

            // find physician in contacts
            List<Contact> physicians = contactService.findByRefIdAndContactType(rs
                    .getString("PHYSICIAN_ID"), ContactType.PHYSICIAN);

            // log the physician's contact information with the visit
            // (in case it changes over time)
            if (physicians != null && physicians.size() > 0) {
                visit.setProviderId(physicians.get(0).getId());
                visit.setProviderAddress(physicians.get(0).getAddress());

                // if provider name is not in visit, use the provider's company name
                if (visit.getProviderName() == null) {
                    visit.setProviderName(physicians.get(0).getCompany());
                }
            }
            // Save the VISIT
            String visitId = saveVisitToMongodb(visit);

            LOGGER.debug("VISIT: Mongodb [" + visitId
                    + "] <= SQL [ " + visit.getRefId() + " ]");
        }
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PATIENT_VISIT_ID "
                        + "FROM PATIENT_VISIT "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize);   // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                delete(rs.getString("PATIENT_VISIT_ID"));
            } // processRow
        }); // query
    }


    private void delete(String refId) {
        List<Visit> visits = visitService.findIdByRefId(refId);
        if (visits != null && visits.size() > 0)
            visitService.delete(visits.get(0).getId());
    }

    private String saveVisitToMongodb(Visit visit) {
        if (visit.getRefId() != null) {
            List<Visit> existing = visitService.findIdByRefId(visit.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                visit.setId(existing.get(0).getId());
                visit.setVersion(existing.get(0).getVersion());
            } else
                visit.setId(UUID.randomUUID().toString());
        } else
            visit.setId(UUID.randomUUID().toString());

        return visitService.save(visit, false);
    }

}
