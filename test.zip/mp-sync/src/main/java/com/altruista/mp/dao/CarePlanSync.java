package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import org.joda.time.DateTime;


public interface CarePlanSync extends BaseSync {
    void loadPatientIds(DateTime runDate);

    void applyRemoteChanges(long patientId, final Member member, DateTime runDate);

    void applyLocalChanges(DateTime runDate);

    void applyRemoteDeletes(DateTime runDate);
}