package com.altruista.mp.dao;

import org.joda.time.DateTime;

public interface ProviderSync extends BaseSync {

    void applyRemoteChanges(DateTime runDate);
}
