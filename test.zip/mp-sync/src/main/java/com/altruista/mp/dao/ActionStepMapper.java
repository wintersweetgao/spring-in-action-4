package com.altruista.mp.dao;

import com.altruista.mp.model.ActionStep;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;
import org.joda.time.Days;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ActionStepMapper {

    public static ActionStep toActionStep(ResultSet rs) throws SQLException {
        ActionStep actionStep = new ActionStep();

        // IMPORTANT: Use CARE_PLAN_ID, not GOAL_ID as RefId
        actionStep.setRefId(rs.getString("CARE_PLAN_ID").toString());
        actionStep.setGoalGroup(rs.getString("GOAL_GROUP_NAME"));
        actionStep.setStatus(rs.getString("STATUS_NAME"));
        String alias = rs.getString("INTERVENTION_ALIAS");
        String intervention = rs.getString("INTERVENTION_NAME");
        if (alias != null && alias.length() > 0)
            actionStep.setStep(alias);
        else
            actionStep.setStep(intervention);
        actionStep.setIntervention(intervention);
        actionStep.setPriority(rs.getString("PRIORITY_NAME"));
        actionStep.setLob(rs.getString("LOB_NAME"));
        actionStep.setCondition(rs.getString("CONDITION_NAME"));
        actionStep.setSignedOff(rs.getBoolean("IS_SIGN_OFF"));
        actionStep.setStartOn(DateHelper.getDate(rs.getDate("START_DATE")));
        actionStep.setEndOn(DateHelper.getDate(rs.getDate("END_DATE")));

        if (rs.getString("MEMBER_STATUS_NAME") != null)
            actionStep.setMemberStatus(rs.getString("MEMBER_STATUS_NAME"));
        else
            actionStep.setMemberStatus("New");

        // perform equivalent logic as that in CPL_CARE_PLAN_TERM
        int days = Days.daysBetween(
                new DateTime(actionStep.getStartOn()), new DateTime(actionStep.getEndOn())).getDays();
        if (days <= 45)
            actionStep.setTerm("Short Term");
        else
            actionStep.setTerm("Long Term");

        return actionStep;
    }

}
