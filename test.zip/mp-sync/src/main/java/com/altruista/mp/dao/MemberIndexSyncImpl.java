package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import com.altruista.mp.model.MemberIndex;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.MemberIndexService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class MemberIndexSyncImpl extends BaseSyncImpl implements MemberIndexSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MemberIndexSyncImpl.class);

    @Autowired
    private MemberIndexService memberIndexService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT "
                            + " DISTINCT PI.PATIENT_ID "
                            + " FROM PATIENT_INDEX PI"
                            + " WHERE (PI.CREATED_ON >= :runDate OR PI.UPDATED_ON >= :runDate) "
                            + " AND PI.PATIENT_ID IN "
                            + " (SELECT PATIENT_ID FROM PATIENT_DETAILS "
                            + " WHERE REGSTR_REQUIRED_ID IS NOT NULL) ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("memberIndex");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT "
                        + " I.INDEX_ID, I.INDEX_NAME, I.INDEX_TYPE, PI.PATIENT_ID, PI.INDEX_VALUE, PI.CREATED_ON "
                        + " FROM PATIENT_INDEX PI INNER JOIN INDEX_NAME I ON PI.INDEX_ID=I.INDEX_ID"
                        + " WHERE (PI.CREATED_ON >= ? OR PI.UPDATED_ON >= ?) "
                        + " AND PI.PATIENT_ID = ? ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(rs);
                    }
                });
    }


    private void postChanges(ResultSet rs) throws SQLException {

        MemberIndex index = MemberIndexMapper.toMemberIndex(rs);

        List<Member> members = memberService.findIdByRefId(rs
                .getString("PATIENT_ID"));

        if (members != null && members.size() > 0) {
            index.setMemberId(members.get(0).getId());

            // Save the MEMBER INDEX
            String indexId = saveMemberIndexToMongodb(index);

            LOGGER.debug("MEMBER INDEX: Mongodb ["
                    + indexId + "] <= SQL [ "
                    + index.getRefId() + " ]");
        }
    }

    private String saveMemberIndexToMongodb(MemberIndex index) {
        if (index.getRefId() != null) {
            List<MemberIndex> existing = memberIndexService.findIdByRefIdAndIndexNameAndIndexValue(index.getRefId(), index.getIndexName(), index.getIndexValue());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                index.setId(existing.get(0).getId());
                index.setVersion(existing.get(0).getVersion());
            } else
                index.setId(UUID.randomUUID().toString());
        } else
            index.setId(UUID.randomUUID().toString());


        return memberIndexService.save(index, false);
    }

    // DELETE_ON support
    @Override
    public void applyRemoteDeletes(DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PI.INDEX_ID, I.INDEX_NAME, PI.INDEX_VALUE "
                        + "FROM PATIENT_INDEX PI, INDEX_NAME I "
                        + "WHERE PI.INDEX_ID = I.INDEX_ID AND PI.DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete( rs.getString("INDEX_ID"),
                                rs.getString("INDEX_NAME"),
                                rs.getString("INDEX_VALUE"));
                    }
                });
    }

    private void delete(String refId, String name, String value) {
        List<MemberIndex> memberIndex = memberIndexService.findIdByRefIdAndIndexNameAndIndexValue(refId, name, value);
        if (!memberIndex.isEmpty())
            memberIndexService.delete(memberIndex.get(0).getId());
    }
}
