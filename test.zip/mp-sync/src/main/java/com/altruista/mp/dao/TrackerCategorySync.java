package com.altruista.mp.dao;

import org.joda.time.DateTime;

/**
 * Created by mwixson on 1/26/15.
 */
public interface TrackerCategorySync {
    void applyRemoteChanges(DateTime runDate);

    void applyRemoteDeletes(DateTime runDate);
}
