package com.altruista.mp.dao;

import org.joda.time.DateTime;

public interface MPDocumentSync extends BaseSync {
    void applyRemoteChanges(DateTime runDate);

    void applyRemoteDeletes(DateTime runDate);
}
