package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberContactService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.UUID;

@Component
public class MemberSyncImpl extends BaseSyncImpl implements MemberSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MemberSyncImpl.class);
    @Value("${guidingCare.timezone}")
    private String gcTimezone;
    @Autowired
    private MemberService memberService;
    @Autowired
    private ContactService contactService;
    @Autowired
    private MemberContactService memberContactService;
    @Autowired
    private RegisterContactImpl contactReg;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT P.PATIENT_ID "
                            + " FROM PATIENT_DETAILS P"
                            + " WHERE (P.CREATED_ON >= :runDate OR P.UPDATED_ON >= :runDate)";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("member");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }

        try {
            String addressSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT P.PATIENT_ID "
                            + " FROM PATIENT_ADDITIONAL_ADDRESS P"
                            + " WHERE (P.CREATED_ON >= :runDate OR P.UPDATED_ON >= :runDate)";

            NamedParameterJdbcTemplate addressTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource addressParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            addressTemplate.update(addressSQL, addressParameters);

        } catch (Exception exc) {
            LOGGER.error("Unable to load MP_TEMP table for PATIENT_ADDITIONAL_ADDRESS, exception: " + exc);
        }
    }

    public void applyRemoteChanges(long patientId, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql = "SELECT P.PATIENT_ID,P.CLIENT_ID,P.CLIENT_PATIENT_ID,M.USERNAME,NAME_PREFIX,FIRST_NAME,MIDDLE_NAME,LAST_NAME,PRIMARY_EMAIL,"
                + " HOME_PHONE,SEX,ETHNICITY_ID,BIRTH_YEAR,CELL_PHONE,FAX,PRIMARY_LANGUAGE_ID,"
                + " ALTERNATE_EMAIL,MARITAL_STATUS,PREFERED_TIME_OF_CALL,REG.REGSTR_STATUS,P.CREATED_ON,"
                + " PMC.CONDITION_NAME MEDICAL_CONDITION,PBC.CONDITION_NAME BEHAVIORAL_CONDITION, STATUS_NAME "
                + " FROM PATIENT_DETAILS P"
                + " INNER JOIN MEMBER M ON P.PATIENT_ID = M.MEMBER_ID "
                + " INNER JOIN MP_REGISTRATION_REQUIRED REG ON P.REGSTR_REQUIRED_ID = REG.REGSTR_REQUIRED_ID "
                + " LEFT OUTER JOIN CMN_STATUS S ON P.STATUS_ID = S.STATUS_ID "
                + " LEFT OUTER JOIN CPL_MANAGE_CONDITION PMC ON P.PRIMARY_MEDICAL_CONDITION_ID = PMC.CONDITION_ID "
                + " LEFT OUTER JOIN CPL_MANAGE_CONDITION PBC ON P.PRIMARY_BEHAVIOURAL_CONDITION_ID = PBC.CONDITION_ID "
                + " WHERE P.PATIENT_ID = ? AND (P.CREATED_ON >= ? OR P.UPDATED_ON >= ?)";

        template.setFetchSize(fetchsize); // process 100 rows
        template.query(sql, new Object[]{patientId, runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(rs);
                    }
                });
    }

    private void postChanges(ResultSet rs) throws SQLException {

        // MEMBER
        // --------------------------
        Member member = MemberMapper.toMember(rs);

        // CONTACT
        // --------------------------
        Contact contact = PatientMapper.toContact(rs);

        // import addresses
        contact.setAddress(getAddress(contact.getRefId()));

        // Save the contact
        String contactId = saveContactToMongodb(contact);
        contact.setId(contactId);
        member.setContactId(contactId);

        LOGGER.debug("CONTACT: Mongodb ["
                + contactId + "] <= SQL ["
                + contact.getRefId() + "]");

        // save the member
        String memberId = saveMemberToMongodb(member);
        LOGGER.debug("MEMBER: Mongodb [" + memberId
                + "] <= SQL [" + member.getRefId() + "]");

        // save the relationship
        MemberContact mc = new MemberContact(ContactType.MEMBER);
        mc.setRefId(contact.getRefId());    // same as Contact
        mc.setMemberId(memberId);
        mc.setContactId(contactId);
        mc.setPrimary(true);

        saveMemberContactToMongodb(mc);

        // register the MEMBER
        contactReg.register(contact, memberId);
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PATIENT_ID "
                        + "FROM PATIENT_DETAILS "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("PATIENT_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<Member> members = memberService.findIdByRefId(refId);
        if (members != null && members.size() > 0)
            memberService.delete(members.get(0).getId());
    }

    // Set Address
    @SuppressWarnings("rawtypes")
    private Address getAddress(String patientId) {
        final Address address = new Address();
        ;

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT ADDRESS_ID, ADDRESS_TYPE_NAME, ADDRESS_TEXT, CITY, STATE, ZIP, COUNTRY, "
                        + " IS_PRIMARY"
                        + " FROM PATIENT_ADDITIONAL_ADDRESS PAA "
                        + " LEFT OUTER JOIN ADDRESS_TYPE AT ON PAA.ADDRESS_TYPE_ID = AT.ADDRESS_TYPE_ID"
                        + " WHERE PATIENT_ID = ?";

        template.query(sql, new Object[]{patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        if (rs.getBoolean("IS_PRIMARY")) {
                            address.setRefId(rs.getString("ADDRESS_ID"));
                            address.setPrimary(rs.getBoolean("IS_PRIMARY"));
                            address.setAddressType(rs.getString("ADDRESS_TYPE_NAME"));
                            address.setAddress(rs.getString("ADDRESS_TEXT"));
                            address.setStateProvince(rs.getString("STATE"));
                            address.setCity(rs.getString("CITY"));
                            address.setPostalCode(rs.getString("ZIP"));
                            address.setCountry(rs.getString("COUNTRY"));
                        }
                    }
                });

        return address;
    }

    private String saveMemberToMongodb(Member member) {
        // see if member already exists
        if (member.getRefId() != null) {
            List<Member> existing = memberService.findIdByRefId(member.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                member.setId(existing.get(0).getId());
                member.setVersion(existing.get(0).getVersion());
            } else
                member.setId(UUID.randomUUID().toString());
        } else
            member.setId(UUID.randomUUID().toString());

        return memberService.save(member, false);
    }

    private String saveContactToMongodb(Contact contact) {
        // see if contact already exists
        if (contact.getRefId() != null) {
            List<Contact> existing = contactService.findIdByRefIdAndContactType(contact.getRefId(), ContactType.MEMBER);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                contact.setId(existing.get(0).getId());
                contact.setVersion(existing.get(0).getVersion());
            } else
                contact.setId(UUID.randomUUID().toString());
        } else
            contact.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        contact.setSyncedOn(DateTime.now());
        contactService.setSyncEnabled(false);*/

        return contactService.save(contact, false);
    }

    private String saveMemberContactToMongodb(MemberContact mc) {
        // see if contact already exists
        if (mc.getRefId() != null) {
            List<MemberContact> existing = memberContactService.findIdByRefIdAndContactType(mc.getRefId(), ContactType.MEMBER);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                mc.setId(existing.get(0).getId());
                mc.setVersion(existing.get(0).getVersion());
            } else
                mc.setId(UUID.randomUUID().toString());
        } else
            mc.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        mc.setSyncedOn(DateTime.now());
        memberContactService.setSyncEnabled(false);*/

        return memberContactService.save(mc, false);
    }

    public void applyLocalChanges(DateTime runDate) {
        List<Contact> contacts = contactService.findContactIdsToSync();

        for (Contact id : contacts) {
            Contact contact = contactService.get(id.getId());
            saveContactToSQL(contact);
        }
    }

    private void saveContactToSQL(Contact contact) {
        // update registration status
        contactReg.updateContactRegistrationStatus(contact, contact.getRegistrationStatus());

        // only allow updates to Members, skip others
        if (contact.getContactType() != ContactType.MEMBER) {

          /*  // IMPORTANT: set sync time to mark as ignored
            contact.setSyncedOn(DateTime.now());
            contactService.setSyncEnabled(false);*/

            contactService.save(contact, false);

            return;
        }

        // verify that the contact has a refId, ignore if not
        if (contact.getRefId() == null || contact.getRefId().length() == 0) {
            LOGGER.error("Member contact is missing refId, unable to save to SQL: " + contact.getId());

          /*  // IMPORTANT: set sync time to mark as ignored
            contact.setSyncedOn(DateTime.now());
            contactService.setSyncEnabled(false);*/

            contactService.save(contact, false);

            return;
        } else {
            LOGGER.debug("Saving Contact to SQL: " + contact.getId());
        }

        Long contactId = Long.parseLong(contact.getRefId());

        try {
            String contactSQL =
                    "UPDATE PATIENT_DETAILS SET " +
                            " FIRST_NAME = :firstName, " +
                            " MIDDLE_NAME = :middleName, " +
                            " LAST_NAME = :lastName, " +
                            " BIRTH_YEAR = :dob, " +
                            " HOME_PHONE = :homePhone, " +
                            " FAX = :fax, " +
                            " MARITAL_STATUS = :maritalStatusId, " +
                            " PREFERED_TIME_OF_CALL = :preferredTimeOfContact, " +
                            " SEX = :genderId ";

            // NOTE: Avoid changing UPDATED_ON, otherwise this will sync back to Member Portal

            // Convert DOB from UTC to Local time
            DateTime dob = new DateTime(contact.getDob(), DateTimeZone.UTC);
            DateTime utcDOB = new DateTime(dob.getYear(), dob.getMonthOfYear(), dob.getDayOfMonth(),
                    0, 0, 0, 0, DateTimeZone.UTC);
            NamedParameterJdbcTemplate contactTemplate = new NamedParameterJdbcTemplate(dataSource);
            MapSqlParameterSource parmsMap = new MapSqlParameterSource("firstName", contact.getFirstName())
                    .addValue("middleName", contact.getMiddleName())
                    .addValue("lastName", contact.getLastName())
                    .addValue("dob", utcDOB.toString())
                    .addValue("homePhone", contact.getPhoneNumber())
                    .addValue("fax", contact.getFaxNumber())
                    .addValue("maritalStatusId", contact.getMaritalStatus())
                    .addValue("preferredTimeOfContact", contact.getPreferredTimeOfContact())
                    .addValue("genderId", contact.getGender())
                    .addValue("patientId", contactId);

            // conditionally assign languageId to avoid NumberFormat exception
            if (contact.getPrimaryLanguage() != null && contact.getPrimaryLanguage().length() > 0) {
                contactSQL += ", PRIMARY_LANGUAGE_ID = :primaryLanguageId ";
                parmsMap.registerSqlType("primaryLanguageId", Types.BIGINT);
                parmsMap.addValue("primaryLanguageId", Long.parseLong(contact.getPrimaryLanguage()));
            }

            // conditionally assign ethnicityId to avoid NumberFormat exception
            if (contact.getEthnicity() != null && contact.getEthnicity().length() > 0) {
                contactSQL += ", ETHNICITY_ID = :ethnicityId ";
                parmsMap.registerSqlType("ethnicityId", Types.INTEGER);
                parmsMap.addValue("ethnicityId", Integer.parseInt(contact.getEthnicity()));
            }

            contactSQL += " WHERE PATIENT_ID = :patientId";
            SqlParameterSource contactNamedParameters = parmsMap;
            int rows = contactTemplate.update(contactSQL, contactNamedParameters);

            if (rows == 1) {
                LOGGER.debug("CONTACT: Mongodb [" + contact.getId()
                        + "] => SQL [" + contact.getRefId() + "]");
            } else if (rows > 1) {
                LOGGER.warn("CONTACT: Mongodb [" + contact.getId()
                        + "] => SQL [" + contact.getRefId() + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update PATIENT_DETAILS for contact: " + contact.getId() + ", no rows updated.");
            }

            saveMainAddressToSQL(contactId, contact.getAddress());

            contactService.save(contact, false);
        } catch (Exception exc) {
            LOGGER.error("Unable to update PATIENT_DETAILS for contact: " + contact.getId() + ", exception: " + exc);
        }
    }

    private void saveMainAddressToSQL(long patientId, Address address) {

        try {
            String addressSQL =
                    "UPDATE PATIENT_DETAILS SET " +
                            " ADDRESS = :address, " +
                            " CITY = :city, " +
                            " STATE = :state, " +
                            " ZIP = :zip " +
                            " WHERE PATIENT_ID = :patientId";
            // NOTE: Avoid changing UPDATED_ON, otherwise this will sync back to Member Portal

            NamedParameterJdbcTemplate addressTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource addressNamedParameters =
                    new MapSqlParameterSource("address", address.getAddress())
                            .addValue("city", address.getCity())
                            .addValue("state", address.getStateProvince())
                            .addValue("zip", address.getPostalCode())
                            .addValue("patientId", patientId);
            int rows = addressTemplate.update(addressSQL, addressNamedParameters);

            if (rows == 1) {
                LOGGER.debug("PATIENT_DETAILS ADDRESS: Mongodb [" + address.getId()
                        + "] => SQL [" + address.getRefId() + "]");
            } else if (rows > 1) {
                LOGGER.warn("PATIENT_DETAILS ADDRESS: Mongodb [" + address.getId()
                        + "] => SQL [" + address.getRefId() + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update primary ADDRESS: " + address.getId() + ", no rows updated.");
            }
        } catch (Exception exc) {
            LOGGER.error("Unable to update primary ADDRESS: " + address.getId() + ", exception: " + exc);
        }
    }

    public Member getCurrentMember(String refId) {
        List<Member> members = memberService.findIdByRefId(refId);

        if (members == null || members.isEmpty())
            return null;
        else
            return members.get(0);
    }
}