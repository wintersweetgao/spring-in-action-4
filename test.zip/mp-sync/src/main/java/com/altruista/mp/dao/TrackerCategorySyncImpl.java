package com.altruista.mp.dao;

import com.altruista.mp.model.TrackerCategory;
import com.altruista.mp.services.TrackerCategoryService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerCategorySyncImpl extends BaseSyncImpl implements TrackerCategorySync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(TrackerCategorySyncImpl.class);

    @Autowired
    TrackerCategoryService categoryService;

    @Override
    public void applyRemoteChanges(DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT IC.CATEGORY_ID, IC.CATEGORY_NAME, IC.CATEGORY_ACCESS, IC.CREATED_ON "
                        + "FROM HEALTH_INDICATOR_CAT IC "
                        + "WHERE IC.CATEGORY_NAME = 'Wellness' "
                        + "AND (IC.CREATED_ON >= ? OR IC.UPDATED_ON >= ?) ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        TrackerCategory category = TrackerCategoryMapper.toCategory(rs);

                        String categoryId = saveCategoryToMongodb(category);

                        LOGGER.debug("TRACKER_CATEGORY: Mongodb ["
                                + categoryId + "] <= SQL [ "
                                + category.getRefId() + " ]");
                    }
                });
    }

    private String saveCategoryToMongodb(TrackerCategory value) {
        if (value.getRefId() != null) {
            List<TrackerCategory> existing = categoryService.findByRefId(value.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                value.setId(existing.get(0).getId());
                value.setVersion(existing.get(0).getVersion());
            } else
                value.setId(UUID.randomUUID().toString());
        } else
            value.setId(UUID.randomUUID().toString());

        return categoryService.save(value, false);
    }

    @Override
    public void applyRemoteDeletes(DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT CATEGORY_ID "
                        + "FROM HEALTH_INDICATOR_CAT "
                        + "WHERE CATEGORY_NAME = 'Wellness' "
                        + "AND DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("CATEGORY_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<TrackerCategory> categories = categoryService.findByRefId(refId);
        if (categories != null && categories.size() > 0)
            categoryService.delete(categories.get(0).getId());
    }
}
