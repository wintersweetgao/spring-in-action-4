package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.*;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class LobProgramSyncImpl extends BaseSyncImpl implements LobProgramSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(LobProgramSyncImpl.class);

    @Autowired
    private LobService lobService;
    @Autowired
    private ProgramService programService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;
    @Autowired
    private ProgramEligibilityService programEligibilityService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "

                            + "SELECT "
                            + " DISTINCT MBP.MEMBER_ID "
                            + " FROM LOB L "
                            + " INNER JOIN LOB_BENF_PLAN LBP ON L.LOB_ID=LBP.LOB_ID"
                            + " INNER JOIN MEM_BENF_PLAN MBP ON MBP.LOB_BEN_ID=LBP.LOB_BEN_ID"
                            + " WHERE (MBP.CREATED_ON >= :runDate OR MBP.UPDATED_ON >= :runDate) AND MBP.MEMBER_ID IS NOT NULL "

                            + " UNION SELECT "
                            + " DISTINCT MBPG.MEMBER_ID "
                            + " FROM LOB L INNER JOIN LOB_BENF_PLAN LBP ON L.LOB_ID=LBP.LOB_ID"
                            + " INNER JOIN BENF_PLAN_PROG  BPP ON BPP.BENEFIT_PLAN_ID=LBP.BENEFIT_PLAN_ID"
                            + " INNER JOIN BENEFIT_PROGRAM  BPR ON BPR.BENEFIT_PROGRAM_ID=BPP.BENEFIT_PROGRAM_ID"
                            + " INNER JOIN BENEFIT_PLAN BP ON  BP.BENEFIT_PLAN_ID=BPP.BENEFIT_PLAN_ID"
                            + " INNER JOIN MEM_BENF_PLAN MBP ON MBP.LOB_BEN_ID=LBP.LOB_BEN_ID"
                            + " INNER JOIN MEM_BENF_PROG MBPG ON MBPG.LOB_BEN_ID=LBP.LOB_BEN_ID AND BPP.BEN_PLAN_PROG_ID=MBPG.BEN_PLAN_PROG_ID"
                            + " WHERE MBPG.MEMBER_ID = MBP.MEMBER_ID"
                            + " AND (MBPG.CREATED_ON >= :runDate OR MBPG.UPDATED_ON >= :runDate) ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("program");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        applyLobChanges(patientId, runDate);
        applyProgramChanges(patientId, runDate);
    }

    private void applyLobChanges(long patientId, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT "
                        + " MBP.MEM_BENF_PLAN_ID, MBP.MEMBER_ID, L.LOB_NAME, LBP.IS_ACTIVE, MBP.CREATED_ON "
                        + " FROM LOB L "
                        + " INNER JOIN LOB_BENF_PLAN LBP ON L.LOB_ID=LBP.LOB_ID"
                        + " INNER JOIN MEM_BENF_PLAN MBP ON MBP.LOB_BEN_ID=LBP.LOB_BEN_ID"
                        + " WHERE "
                        + " MBP.MEMBER_ID = ?"
                        + " AND (MBP.CREATED_ON >= ? OR MBP.UPDATED_ON >= ?) "
                        + " AND ? BETWEEN L.START_DATE AND ISNULL(L.END_DATE,'20990101') AND L.DELETED_ON IS NULL"
                        + " AND ? BETWEEN LBP.START_DATE AND ISNULL(LBP.END_DATE,'20990101') AND LBP.DELETED_ON IS NULL"
                        + " AND ? BETWEEN MBP.START_DATE AND ISNULL(MBP.END_DATE,'20990101') AND MBP.DELETED_ON IS NULL";

        Date today = DateTime.now().toDate();
        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{patientId,
                        runDate.toDate(), runDate.toDate(),
                        today, today, today},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postLobChanges(rs);
                    }
                });
    }

    private void postLobChanges(ResultSet rs) throws SQLException {

        Lob lob = LobMapper.toLob(rs);

        List<Member> members = memberService.findIdByRefId(rs
                .getString("MEMBER_ID"));

        if (members != null && members.size() > 0) {
            lob.setMemberId(members.get(0).getId());

            // Save the LOB
            String lobId = saveLobToMongodb(lob);

            LOGGER.debug("LOB: Mongodb ["
                    + lobId + "] <= SQL [ "
                    + lob.getRefId() + " ]");
        }
    }

    private String saveLobToMongodb(Lob lob) {
        if (lob.getRefId() != null) {
            List<Lob> existing = lobService.findIdByRefId(lob.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                lob.setId(existing.get(0).getId());
                lob.setVersion(existing.get(0).getVersion());
            } else
                lob.setId(UUID.randomUUID().toString());
        } else
            lob.setId(UUID.randomUUID().toString());

        return lobService.save(lob, false);
    }

    private void applyProgramChanges(long patientId, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT "
                        + " MBPG.MEM_BENF_PROG_ID, MBPG.MEMBER_ID, L.LOB_NAME, BP.PLAN_NAME, BPR.PROGRAM_NAME, BPR.IS_ACTIVE, MBPG.CREATED_ON "
                        + " FROM LOB L INNER JOIN LOB_BENF_PLAN LBP ON L.LOB_ID=LBP.LOB_ID"
                        + " INNER JOIN BENF_PLAN_PROG  BPP ON BPP.BENEFIT_PLAN_ID=LBP.BENEFIT_PLAN_ID"
                        + " INNER JOIN BENEFIT_PROGRAM  BPR ON BPR.BENEFIT_PROGRAM_ID=BPP.BENEFIT_PROGRAM_ID"
                        + " INNER JOIN BENEFIT_PLAN BP ON  BP.BENEFIT_PLAN_ID=BPP.BENEFIT_PLAN_ID"
                        + " INNER JOIN MEM_BENF_PLAN MBP ON MBP.LOB_BEN_ID=LBP.LOB_BEN_ID"
                        + " INNER JOIN MEM_BENF_PROG MBPG ON MBPG.LOB_BEN_ID=LBP.LOB_BEN_ID AND BPP.BEN_PLAN_PROG_ID=MBPG.BEN_PLAN_PROG_ID"
                        + " WHERE "
                        + " MBPG.MEMBER_ID = ? AND MBPG.MEMBER_ID = MBP.MEMBER_ID"
                        + " AND (MBPG.CREATED_ON >= ? OR MBPG.UPDATED_ON >= ?) "
                        + " AND ? BETWEEN L.START_DATE AND ISNULL(L.END_DATE,'20990101') AND L.DELETED_ON IS NULL"
                        + " AND ? BETWEEN LBP.START_DATE AND ISNULL(LBP.END_DATE,'20990101') AND LBP.DELETED_ON IS NULL"
                        + " AND ? BETWEEN BPP.START_DATE AND ISNULL(BPP.END_DATE,'20990101') AND BPP.DELETED_ON IS NULL"
                        + " AND ? BETWEEN BPR.START_DATE AND ISNULL(BPR.END_DATE,'20990101') AND BPR.DELETED_ON IS NULL"
                        + " AND ? BETWEEN BP.START_DATE AND ISNULL(BP.END_DATE,'20990101') AND BP.DELETED_ON IS NULL"
                        + " AND ? BETWEEN MBPG.START_DATE AND ISNULL(MBPG.END_DATE,'20990101') AND MBPG.DELETED_ON IS NULL"
                        + " AND ? BETWEEN MBP.START_DATE AND ISNULL(MBP.END_DATE,'20990101') AND MBP.DELETED_ON IS NULL";

        Date today = DateTime.now().toDate();
        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{patientId,
                        runDate.toDate(), runDate.toDate(),
                        today, today, today, today,
                        today, today, today},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postProgramChanges(rs);
                    }
                });
    }

    private void postProgramChanges(ResultSet rs) throws SQLException {

        Program program = ProgramMapper.toProgram(rs);

        List<Member> members = memberService.findIdByRefId(rs
                .getString("MEMBER_ID"));

        if (members != null && members.size() > 0) {
            program.setMemberId(members.get(0).getId());

            // Save the PROGRAM
            String programId = saveProgramToMongodb(program);

            LOGGER.debug("PROGRAM: Mongodb ["
                    + programId + "] <= SQL [ "
                    + program.getRefId() + " ]");
        }
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT MEM_BENF_PROG_ID "
                        + "FROM MEM_BENF_PROG "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize);   // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                delete(rs.getString("MEM_BENF_PROG_ID"));
            } // processRow
        }); // query
    }

    private void delete(String refId) {
        List<Program> progs = programService.findIdByRefId(refId);
        if (progs != null && progs.size() > 0)
            programService.delete(progs.get(0).getId());
    }

    private String saveProgramToMongodb(Program program) {
        if (program.getRefId() != null) {
            List<Program> existing = programService.findIdByRefId(program.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                program.setId(existing.get(0).getId());
                program.setVersion(existing.get(0).getVersion());
            } else
                program.setId(UUID.randomUUID().toString());
        } else
            program.setId(UUID.randomUUID().toString());

        return programService.save(program, false);
    }

    @Override
    public void loadStaticData() {
        LOGGER.debug("BEGIN LOADING PROGRAM ELIGIBILITY");

        // United Healthcare's MyMoneyConnect
        ProgramEligibility mmc = new ProgramEligibility();
        mmc.setProgramName("MyMoneyConnect");
        mmc.getLobs().add("CAN");
        mmc.getLobs().add("CHIP");
        mmc.getLobs().add("CRS");
        mmc.getLobs().add("FHP");
        mmc.getLobs().add("IA Dept-Public-Health");
        mmc.getLobs().add("Iowa Wellness Plan");
        mmc.getLobs().add("Long Term Care");
        mmc.getLobs().add("Medicaid");

        mmc.getClientRefIds().add("2");
        mmc.getClientRefIds().add("14");

        // if it exists, update instead of adding a dup
        ProgramEligibility existing = programEligibilityService.findOneByProgramName("MyMoneyConnect");
        if (existing != null) {
            mmc.setId(existing.getId());
        }

        programEligibilityService.save(mmc);

        LOGGER.debug("END LOADING PROGRAM ELIGIBILITY");

    }
}