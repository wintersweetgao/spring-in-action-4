package com.altruista.mp.dao;

import com.altruista.mp.model.Message;
import com.altruista.mp.model.MessageType;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.sql.ResultSet;
import java.sql.SQLException;


public class MessageMapper {

    public static Message toMessage(String gcTimezone, ResultSet rs) throws SQLException {

        Message message = new Message();
        message.setRefId(rs.getString("MESSAGE_ID"));
        message.setSubject(rs.getString("MESSAGE_SUBJECT"));
        message.setBody(rs.getString("MESSAGE_CONTENT"));
        message.setCareTeam(rs.getString("CARE_TEAM_ID"));
        message.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));
        message.setLocation("INBOX");   // new messages always go into INBOX

        DateTime local = new DateTime(rs.getTimestamp("DATE_SENT"), DateTimeZone.forID(gcTimezone));
        DateTime sentOn = local.toDateTime(DateTimeZone.UTC);
        message.setSentOn(sentOn);

        // Determine if active
        if (rs.getBoolean("IS_DIRECT"))
            message.setMessageType(MessageType.DIRECT);
        else
            message.setMessageType(MessageType.INTERNAL);

        return message;
    }
}
