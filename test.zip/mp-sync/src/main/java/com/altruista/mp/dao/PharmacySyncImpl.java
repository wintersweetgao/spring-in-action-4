package com.altruista.mp.dao;

import com.altruista.mp.model.Medication;
import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.MedicationService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class PharmacySyncImpl extends BaseSyncImpl implements PharmacySync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(DiagnosisSyncImpl.class);

    @Autowired
    private MemberService memberService;
    @Autowired
    private MedicationService medicationService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT V.PATIENT_ID "
                            + "FROM PATIENT_VISIT_RX R, PATIENT_VISIT V "
                            + "WHERE R.PATIENT_VISIT_ID = V.PATIENT_VISIT_ID AND "
                            + "(V.CREATED_ON >= :runDate OR V.UPDATED_ON >= :runDate)";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("pharmacy");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);

        //NDC , RX_NUMBER
        String sql =
                "SELECT V.PATIENT_ID,V.VISIT_DATE,PATIENT_VISIT_RX_ID,DESCRIPTION,DAYS_SUPPLY, "
                        + "R.QUANTITY "
                        + "FROM PATIENT_VISIT_RX R, PATIENT_VISIT V "
                        + "WHERE R.PATIENT_VISIT_ID = V.PATIENT_VISIT_ID AND "
                        + "(V.CREATED_ON >= ? OR V.UPDATED_ON >= ?) AND "
                        + "PATIENT_ID = ? ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(rs);
                    }
                });
    }

    private void postChanges(ResultSet rs) throws SQLException {
        Medication medication = PharmacyMapper.toMedication(rs);

        List<Member> members = memberService.findIdByRefId(rs
                .getString("PATIENT_ID"));

        if (members != null && members.size() > 0) {
            medication.setMemberId(members.get(0).getId());

            // Save the Medications
            String medicationId = savePharmacyToMongodb(medication);

            LOGGER.debug("PHARMACY: Mongodb ["
                    + medicationId + "] <= SQL [ "
                    + medication.getRefId() + " ]");
        }
    }

    private String savePharmacyToMongodb(Medication medication) {
        if (medication.getRefId() != null) {
            List<Medication> existing = medicationService.findIdByRefId(medication.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                medication.setId(existing.get(0).getId());
                medication.setVersion(existing.get(0).getVersion());
            } else
                medication.setId(UUID.randomUUID().toString());
        } else
            medication.setId(UUID.randomUUID().toString());

      /*  // IMPORTANT: set sync time to avoid sending it back to SQL
        medication.setSyncedOn(DateTime.now());
        medicationService.setSyncEnabled(false);*/

        return medicationService.save(medication, false);

    }

}
