package com.altruista.mp.dao;

import com.altruista.mp.model.CommunicationImpairment;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/16/14.
 */
public class CommunicationImpairmentMapper {
    public static CommunicationImpairment toCommunicationImpairment(ResultSet rs) throws SQLException {
        CommunicationImpairment impairment = new CommunicationImpairment();
        impairment.setRefId(rs.getString("IMPAIRMENT_ID"));
        impairment.setName(rs.getString("IMPAIRMENT_NAME"));
        impairment.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return impairment;
    }
}
