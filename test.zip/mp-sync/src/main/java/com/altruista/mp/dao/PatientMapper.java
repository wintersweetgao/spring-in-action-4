package com.altruista.mp.dao;

import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 8/4/14.
 */
public class PatientMapper {
    public static Contact toContact(ResultSet rs) throws SQLException {
        Contact member = new Contact();
        member.setRefId(rs.getString("PATIENT_ID"));
        member.setClientRefId(rs.getString("CLIENT_ID"));
        member.setGender(rs.getString("SEX"));
        member.setDob(DateHelper.getDateString(rs.getDate("BIRTH_YEAR")));
        member.setMaritalStatus(rs.getString("MARITAL_STATUS"));
        member.setEthnicity(rs.getString("ETHNICITY_ID"));
        member.setSalutation(rs.getString("NAME_PREFIX"));
        member.setFirstName(rs.getString("FIRST_NAME"));
        member.setMiddleName(rs.getString("MIDDLE_NAME"));
        member.setLastName(rs.getString("LAST_NAME"));
        member.setMobilePhoneNumber(rs.getString("CELL_PHONE"));
        member.setFaxNumber(rs.getString("FAX"));
        member.setPrimaryLanguage(rs.getString("PRIMARY_LANGUAGE_ID"));
        member.setPreferredTimeOfContact(rs.getString("PREFERED_TIME_OF_CALL"));
        member.setPrimaryEmail(rs.getString("PRIMARY_EMAIL"));
        member.setPhoneNumber(rs.getString("HOME_PHONE"));
        member.setEveningPhoneNumber(rs.getString("HOME_PHONE"));
        member.setAlternateEmail(rs.getString("ALTERNATE_EMAIL"));
        member.setStatus(rs.getString("STATUS_NAME"));
        member.setRegistrationStatus(rs.getString("REGSTR_STATUS"));
        member.setContactCode(rs.getString("CLIENT_PATIENT_ID"));

        //MEMBER
        member.setContactType(ContactType.MEMBER);

        return member;
    }
}
