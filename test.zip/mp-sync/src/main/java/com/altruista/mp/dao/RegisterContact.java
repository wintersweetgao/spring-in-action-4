package com.altruista.mp.dao;

import com.altruista.mp.model.Contact;

/**
 * Created by mwixson on 12/28/14.
 */
public interface RegisterContact {
    void register(Contact contact, String memberId);

    void updateContactRegistrationStatus(Contact contact, String status);
}
