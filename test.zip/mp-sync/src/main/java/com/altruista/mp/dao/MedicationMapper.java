package com.altruista.mp.dao;

import com.altruista.mp.model.Medication;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class MedicationMapper {

    public static Medication toMedication(ResultSet rs) throws SQLException {
        Medication medication = new Medication();

        //  medication.setDays(rs.getInt("DAYS"));
        medication.setRefId(rs.getString("MEDICATION_ID"));
        medication.setName(rs.getString("MEDICATION_DESC"));
        medication.setFrequency(rs.getString("FREQUENCY_NAME"));
        medication.setQuantity(rs.getString("QUANTITY_SUPPLY_ID"));
        medication.setDays(rs.getInt("DAY_SUPPLY_ID"));
        medication.setStartDate(DateHelper.getDate(rs.getDate("SCHEDULE_FROM")));
        medication.setEndDate(DateHelper.getDate(rs.getDate("SCHEDULE_TO")));
        medication.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));
        medication.setSource("MANUAL");

        String dosageId = rs.getString("DOSAGE_ID");
        // if the schedule contains the dosage, use that
        if (dosageId != null)
            medication.setDosage(rs.getString("DOSAGE_ID"));
            // otherwise default to the dosage for the medication
        else
            medication.setDosage(rs.getString("DOSAGE"));

        return medication;
    }
}
