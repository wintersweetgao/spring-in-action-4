package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.AssessmentResponseService;
import com.altruista.mp.services.AssessmentRunService;
import com.altruista.mp.services.AssessmentService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AssessmentSyncImpl extends BaseSyncImpl implements AssessmentSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory
            .getLogger(AssessmentSyncImpl.class);

    @Autowired
    private AssessmentService assessmentService;
    @Autowired
    private AssessmentRunService assessmentRunService;
    @Autowired
    private AssessmentResponseService assessmentResponseService;

    @Override
    public void applyRemoteChanges(DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);

        // detect scripts with any assessment, question, option or suboption changes
        String sql =
                "SELECT SS.SCRIPT_ID,SCRIPT_NAME,SS.NO_OF_QUESTION,SS.IS_ACTIVE,SS.DURATION, "
                        + "SS.CREATED_DATE,SS.UPDATED_DATE,SS.DELETED_DATE,SS.SCORE "
                        + "FROM SCPT_ADMIN_SCRIPT SS, "
                        + " GC_MODULE_NAME GM "
                        + "WHERE SS.MODULE_ID = GM.GC_MODULE_NAME_ID AND MODULE_NAME = 'MP'"
                        + " AND (SS.CREATED_DATE >= ? OR SS.UPDATED_DATE >= ? OR SS.DELETED_DATE >= ?) "
                        + " UNION "
                        + " SELECT SS.SCRIPT_ID,SCRIPT_NAME,SS.NO_OF_QUESTION,SS.IS_ACTIVE,SS.DURATION, "
                        + "SS.CREATED_DATE,SS.UPDATED_DATE,SS.DELETED_DATE,SS.SCORE "
                        + "FROM SCPT_ADMIN_SCRIPT SS, SCPT_ADMIN_QUESTION SQ, "
                        + " GC_MODULE_NAME GM "
                        + "WHERE SS.MODULE_ID = GM.GC_MODULE_NAME_ID AND MODULE_NAME = 'MP'"
                        + " AND SS.SCRIPT_ID = SQ.SCRIPT_ID "
                        + " AND (SQ.CREATED_DATE >= ? OR SQ.UPDATED_DATE >= ? OR SQ.DELETED_DATE >= ?) "
                        + " UNION "
                        + " SELECT SS.SCRIPT_ID,SCRIPT_NAME,SS.NO_OF_QUESTION,SS.IS_ACTIVE,SS.DURATION, "
                        + "SS.CREATED_DATE,SS.UPDATED_DATE,SS.DELETED_DATE,SS.SCORE "
                        + "FROM SCPT_ADMIN_SCRIPT SS, SCPT_ADMIN_QUESTION SQ, "
                        + " SCPT_ADMIN_QUESTION_OPTION QO, "
                        + " GC_MODULE_NAME GM "
                        + "WHERE SS.MODULE_ID = GM.GC_MODULE_NAME_ID AND MODULE_NAME = 'MP'"
                        + " AND SS.SCRIPT_ID = SQ.SCRIPT_ID "
                        + " AND SQ.QUESTION_ID = QO.QUESTION_ID "
                        + " AND (QO.CREATED_DATE >= ? OR QO.UPDATED_DATE >= ? OR QO.DELETED_DATE >= ?) "
                        + " UNION "
                        + " SELECT SS.SCRIPT_ID,SCRIPT_NAME,SS.NO_OF_QUESTION,SS.IS_ACTIVE,SS.DURATION, "
                        + "SS.CREATED_DATE,SS.UPDATED_DATE,SS.DELETED_DATE,SS.SCORE "
                        + "FROM SCPT_ADMIN_SCRIPT SS, SCPT_ADMIN_QUESTION SQ, "
                        + " SCPT_ADMIN_QUESTION_OPTION QO, "
                        + " SCPT_ADMIN_QUESTION_SUBOPTION SO, "
                        + " GC_MODULE_NAME GM "
                        + "WHERE SS.MODULE_ID = GM.GC_MODULE_NAME_ID AND MODULE_NAME = 'MP'"
                        + " AND SS.SCRIPT_ID = SQ.SCRIPT_ID "
                        + " AND SQ.QUESTION_ID = QO.QUESTION_ID "
                        + " AND SO.QUESTION_OPTION_ID  = QO.QUESTION_OPTION_ID "
                        + " AND (SO.CREATED_DATE >= ? OR SO.UPDATED_DATE >= ? OR SO.DELETED_ON >= ?) ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), runDate.toDate(),
                runDate.toDate(), runDate.toDate(), runDate.toDate(), runDate.toDate(),
                runDate.toDate(), runDate.toDate(), runDate.toDate(), runDate.toDate(),
                runDate.toDate()}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                postChanges(rs);
            }
        });
    }

    private void postChanges(ResultSet rs) throws SQLException {
        Assessment assessment = AssessmentMapper.toAssessment(rs);

        // Lookup existing Assessment in MongoDB
        if (assessment.getRefId() != null) {
            List<Assessment> existing = assessmentService.findByRefId(assessment.getRefId());
            if (existing != null && !existing.isEmpty()) {
                assessment.setId(existing.get(0).getId());
                assessment.setVersion(existing.get(0).getVersion());
            } else {
                assessment.setId(UUID.randomUUID().toString());
            }
        } else {
            assessment.setId(UUID.randomUUID().toString());
        }

        // check for delete
        if (rs.getDate("DELETED_DATE") != null) {
            assessmentService.delete(assessment);

            // Check for any Assessment Runs (in progress)
            updateAssessmentRuns(assessment.getId(), true);

            LOGGER.warn("ASSESSMENT: Removing assessment from Mongodb [" + assessment.getId() + "] <= SQL [ "
                    + assessment.getRefId() + " ]");
        }
        // update
        else {
            assessment.setQuestions(getQuestions(assessment.getRefId()));

            if (assessment.getQuestions() == null || assessment.getQuestions().isEmpty()) {
                assessmentService.delete(assessment);

                // Check for any Assessment Runs (in progress)
                updateAssessmentRuns(assessment.getId(), true);

                LOGGER.warn("ASSESSMENT: Removing assessment w/o questions from Mongodb [" + assessment.getId() + "] <= SQL [ "
                        + assessment.getRefId() + " ]");
            } else {
                // Save the Assessment
                String assessmentId = saveAssessmentToMongodb(assessment);

                // Check for any Assessment Runs (in progress)
                updateAssessmentRuns(assessmentId, false);

                LOGGER.debug("ASSESSMENT: Updating assessment in Mongodb [" + assessmentId + "] <= SQL [ "
                        + assessment.getRefId() + " ]");
            }
        }
    }

    private void updateAssessmentRuns(String assessmentId, boolean isDeleted) {
        List<AssessmentRun> runs = assessmentRunService.findByAssessmentIdAndStatus(assessmentId, "InProgress");

        // set the id so that cb knows to update it
        for (AssessmentRun run : runs) {

            // remove any historical responses for pending (not-completed) requests
            assessmentResponseService.deleteByRunId(run.getId());

            if (isDeleted) {
                LOGGER.warn("ASSESSMENT_RUN: Removing run due to GC Script update, Mongodb [\"" + run.getId() + "\"]");

                assessmentRunService.delete(run.getId());
            } else {
                LOGGER.warn("ASSESSMENT_RUN: Marking run as Modified due to GC Script update, Mongodb [\"" + run.getId() + "\"]");

                run.setStatus("Modified");    // update status to inform UI
                run.setLastSequence(0);       // start over from the beginning
                assessmentRunService.save(run, false);
            }

        } // for each run (assigned to the assessment)
    }

    private List<AssessmentQuestion> getQuestions(String scriptId) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT SQ.QUESTION, SQ.QUESTION_NO, "
                        + "SQ.REQUIRED_ANSWER,SQ.OPTION_TYPE_ID,SQ.QUESTION_ID, "
                        + "ST.OPTION_TYPE,ST.SCPT_ADMIN_OPTION_TYPE_ID "
                        + "FROM SCPT_ADMIN_SCRIPT SS, "
                        + "SCPT_ADMIN_QUESTION SQ, "
                        + "SCPT_ADMIN_OPTION_TYPE ST "
                        + "WHERE SS.SCRIPT_ID = SQ.SCRIPT_ID "
                        + "AND SQ.DELETED_DATE IS NULL "
                        + "AND SQ.OPTION_TYPE_ID = ST.SCPT_ADMIN_OPTION_TYPE_ID "
                        + "AND SS.SCRIPT_ID = ? ";

        List<AssessmentQuestion> questions = template.query(sql, new Object[]{Long.parseLong(scriptId)}, new AssessmentQuestionMapper());
        for (AssessmentQuestion question : questions) {
            question.setOptions(getOptions(question.getRefId(), questions));
        }

        return questions;
    }

    private List<AssessmentQuestionOption> getOptions(String questionId, List<AssessmentQuestion> questions) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT QUESTION_OPTION_ID,QUESTION_OPTION,QUESTION_ID,OPTION_NO, "
                        + "QUESTION_NEXT,OT.OPTION_TYPE "
                        + "FROM SCPT_ADMIN_QUESTION_OPTION QO, SCPT_ADMIN_OPTION_TYPE OT "
                        + "WHERE QO.QUESTION_ID = ? AND QO.DELETED_DATE IS NULL "
                        + "AND QO.OPTION_TYPE_ID = OT.SCPT_ADMIN_OPTION_TYPE_ID";

        List<AssessmentQuestionOption> options = template.query(sql, new Object[]{Long.parseLong(questionId)}, new AssessmentQuestionOptionMapper());
        for (AssessmentQuestionOption option : options) {
            // replace QUESTION_NEXT refId with the corresponding sequence number
            if (option.getNextQuestionRefId() != null) {
                for (AssessmentQuestion question : questions) {
                    if (option.getNextQuestionRefId().equals(question.getRefId())) {
                        option.setNextQuestionSequence(question.getSequence());
                        break;
                    }
                }
            }

            option.setSubOptions(getSubOptions(option.getRefId()));
        }
        return options;
    }

    private List<AssessmentQuestionSubOption> getSubOptions(String optionId) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT QUESTION_SUBOPTION_ID,QUESTION_SUBOPTION_TEXT,QUESTION_OPTION_ID, "
                        + "NOTES,OT.OPTION_TYPE "
                        + "FROM SCPT_ADMIN_QUESTION_SUBOPTION SO, SCPT_ADMIN_OPTION_TYPE OT "
                        + "WHERE SO.QUESTION_OPTION_ID = ? AND SO.DELETED_ON IS NULL "
                        + "AND SO.OPTION_TYPE_ID = OT.SCPT_ADMIN_OPTION_TYPE_ID";

        List<AssessmentQuestionSubOption> subOptions = template.query(sql, new Object[]{Long.parseLong(optionId)}, new AssessmentQuestionSubOptionMapper());
        return subOptions;
    }

    private String saveAssessmentToMongodb(Assessment assessment) {
        return assessmentService.save(assessment, false);
    }
}
