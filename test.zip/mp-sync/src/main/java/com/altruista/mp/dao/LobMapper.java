package com.altruista.mp.dao;

import com.altruista.mp.model.Lob;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/16/14.
 */
public class LobMapper {
    public static Lob toLob(ResultSet rs) throws SQLException {

        Lob lob = new Lob();
        lob.setRefId(rs.getString("MEM_BENF_PLAN_ID"));
        lob.setName(rs.getString("LOB_NAME"));
        lob.setActive(rs.getBoolean("IS_ACTIVE"));
        lob.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return lob;
    }
}
