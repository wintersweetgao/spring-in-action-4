package com.altruista.mp.dao;

import com.altruista.mp.model.AssessmentQuestionSubOption;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 4/21/15.
 */
public class AssessmentQuestionSubOptionMapper implements RowMapper<AssessmentQuestionSubOption> {
    public AssessmentQuestionSubOption mapRow(ResultSet rs, int rowNum) throws SQLException {

        AssessmentQuestionSubOption subOption = new AssessmentQuestionSubOption();
        subOption.setRefId(rs.getString("QUESTION_SUBOPTION_ID"));
        subOption.setOptionText(rs.getString("QUESTION_SUBOPTION_TEXT"));
        subOption.setNotes(rs.getString("NOTES"));
        subOption.setOptionType(rs.getString("OPTION_TYPE"));
        subOption.setSequence(rowNum);

        return subOption;
    }
}