package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import org.joda.time.DateTime;

/**
 * Created by mwixson on 9/24/15.
 */
public interface MemberIndexSync {
    void loadPatientIds(DateTime runDate);

    void applyRemoteChanges(long patientId, final Member member, DateTime runDate);

    void applyRemoteDeletes(DateTime runDate);
}
