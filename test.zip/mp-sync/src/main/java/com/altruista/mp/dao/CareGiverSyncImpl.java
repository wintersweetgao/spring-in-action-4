package com.altruista.mp.dao;


import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberContactService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class CareGiverSyncImpl extends BaseSyncImpl implements CareGiverSync {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareGiverSyncImpl.class);

    @Autowired
    private ContactService contactService;
    @Autowired
    private RegisterContactImpl contactReg;
    @Autowired
    private MemberContactService memberContactService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT C.PATIENT_ID "
                            + "FROM PATIENT_PRIMARY_CAREGIVER C, "
                            + " MP_REGISTRATION_REQUIRED R, "
                            + " PATIENT_PHYSICIAN PP, "
                            + " CARE_TEAM T "
                            + "WHERE (C.CREATED_ON >= :runDate OR C.UPDATED_ON >= :runDate OR PP.CREATED_ON >= :runDate OR PP.UPDATED_ON >= :runDate) "
                            + " AND C.REGSTR_REQUIRED_ID = R.REGSTR_REQUIRED_ID "
                            + " AND C.PATIENT_ID = PP.PATIENT_ID "
                            + " AND C.CARE_GIVER_ID = PP.PHYSICIAN_ID "
                            + " AND PP.CARE_TEAM_ID = T.CARE_TEAM_ID AND T.CARE_TEAM_TYPE = 'Caregiver'";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("careGiver");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        // Per Sridhar on 12/12/2014
        // Care teams for a member records is saved in PATIENT_PHYSICIAN table.
        // Patient physician table saves Providers, Internal, External, PCP and Caregivers.
        // Care team values are differentiated with Care_Team_ID value.
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT C.CARE_GIVER_ID,C.PATIENT_ID,FIRST_NAME,MIDDLE_NAME,LAST_NAME,EMAIL_ID, "
                        + " ADDRESS,CITY,STATE,ZIP,COUNTRY,HOME_PHONE,PATIENT_RELATION, "
                        + " SEX,ETHNICITY_ID,DOB,CELL_PHONE,FAX,REGSTR_STATUS,C.CREATED_ON, "
                        + " PP.START_DATE, PP.END_DATE, C.IS_PRIMARY, PP.IS_ACTIVE, ISNULL(IS_PCP,0) AS IS_PCP "
                        + " FROM PATIENT_PRIMARY_CAREGIVER C "
                        + " LEFT OUTER JOIN PATIENT_RELATION PR ON C.PATIENT_RELATION_ID = PR.PATIENT_RELATION_ID, "
                        + " MP_REGISTRATION_REQUIRED R, "
                        + " PATIENT_PHYSICIAN PP, "
                        + " CARE_TEAM T "
                        + "WHERE (C.CREATED_ON >= ? OR C.UPDATED_ON >= ? OR PP.CREATED_ON >= ? OR PP.UPDATED_ON >= ?) "
                        + " AND C.REGSTR_REQUIRED_ID = R.REGSTR_REQUIRED_ID "
                        + " AND C.PATIENT_ID = ? "
                        + " AND C.PATIENT_ID = PP.PATIENT_ID "
                        + " AND C.CARE_GIVER_ID = PP.PHYSICIAN_ID "
                        + " AND PP.CARE_TEAM_ID = T.CARE_TEAM_ID AND T.CARE_TEAM_TYPE = 'Caregiver'";

        template.setFetchSize(fetchsize);  // process 100 rows at a time
        template.query(sql, new Object[]{
                runDate.toDate(), runDate.toDate(), runDate.toDate(), runDate.toDate(),
                patientId}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                postChanges(member, rs);
            }
        });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        // CONTACT
        Contact contact = CareGiverMapper.toContact(rs);

        // Set the contact code as the member's code
        contact.setContactCode(member.getContactCode());

        // Save the CAREGIVER
        String contactId = saveCareGiverToMongodb(contact);
        LOGGER.debug("CAREGIVER: Mongodb [" + contactId + "] <= SQL [ " + contact.getRefId() + " ]");

        // save relationship
        MemberContact mc = new MemberContact(ContactType.CAREGIVER);
        mc.setRefId(contact.getRefId());    // same as Contact
        mc.setMemberId(member.getId());
        mc.setContactId(contactId);

        // Determine if primary care giver
        if (rs.getBoolean("IS_PRIMARY") || rs.getBoolean("IS_PCP"))
            mc.setPrimary(true);
        else
            mc.setPrimary(false);

        // Determine if active
        if (rs.getBoolean("IS_ACTIVE"))
            mc.setActive(true);
        else
            mc.setActive(false);

        if (rs.getString("START_DATE") != null) {
            mc.setStartOn(DateHelper.getDate(rs.getDate("START_DATE")));
        }

        if (rs.getString("END_DATE") != null) {
            mc.setEndOn(DateHelper.getDate(rs.getDate("END_DATE")));
        }

        saveMemberContactToMongodb(mc);

        // register the CARE GIVER
        contactReg.register(contact, mc.getMemberId());
    }

    @Override
    public void applyRemoteDeletes(DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT DISTINCT PHYSICIAN_ID, PP.PATIENT_ID "
                        + "FROM PATIENT_PHYSICIAN PP, CARE_TEAM T "
                        + "WHERE PP.DELETED_ON >= ? "
                        + " AND PP.CARE_TEAM_ID = T.CARE_TEAM_ID AND T.CARE_TEAM_TYPE = 'Caregiver'";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        // lookup the memberId
                        List<Member> members = memberService.findByRefId(rs.getString("PATIENT_ID"));
                        if (members != null && members.size() > 0) {
                            deleteMemberContact(rs.getString("PHYSICIAN_ID"), members.get(0).getId());
                        } else {
                            LOGGER.warn("Unable to delete caregiver, missing member for patient ID: " + rs.getString("PATIENT_ID"));
                        }
                    }
                });
    }

    private void deleteMemberContact(String refId, String memberId) {
        // Do NOT delete the contact, only the relationship

        // Delete relationship between the member and caregiver
        // Find all relationships for this caregiver
        List<MemberContact> mcs = memberContactService.findIdByRefIdAndContactType(refId,
                ContactType.CAREGIVER);
        if (mcs != null) {
            for (MemberContact mc : mcs) {
                // find the member related to this caregiver
                if (mc.getMemberId().equalsIgnoreCase(memberId)) {
                    memberContactService.delete(mc.getId());
                    LOGGER.debug("CAREGIVER: Deleting MemberContact: " + mc.getId());
                }
            }
        }
    }

    private String saveCareGiverToMongodb(Contact contact) {
        // see if contact already exists
        if (contact.getRefId() != null) {
            List<Contact> existing = contactService.findIdByRefIdAndContactType(contact.getRefId(), ContactType.CAREGIVER);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                contact.setId(existing.get(0).getId());
                contact.setVersion(existing.get(0).getVersion());
            } else
                contact.setId(UUID.randomUUID().toString());
        } else
            contact.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        contact.setSyncedOn(DateTime.now());
        contactService.setSyncEnabled(false);
*/
        return contactService.save(contact, false);

    }

    private String saveMemberContactToMongodb(MemberContact mc) {
        // see if contact already exists
        if (mc.getRefId() != null) {
            List<MemberContact> existing = memberContactService.findIdByRefIdAndContactType(mc.getRefId(), ContactType.CAREGIVER);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                mc.setId(existing.get(0).getId());
                mc.setVersion(existing.get(0).getVersion());
            } else
                mc.setId(UUID.randomUUID().toString());
        } else
            mc.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        mc.setSyncedOn(DateTime.now());
        memberContactService.setSyncEnabled(false);
*/
        return memberContactService.save(mc, false);
    }

}
