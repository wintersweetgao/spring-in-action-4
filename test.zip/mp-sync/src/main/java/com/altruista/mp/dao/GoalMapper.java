package com.altruista.mp.dao;

import com.altruista.mp.model.Goal;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GoalMapper {
    public static Goal toGoal(ResultSet rs) throws SQLException {
        Goal goal = new Goal();

        // IMPORTANT: Use CARE_PLAN_ID, not GOAL_ID as RefId
        goal.setRefId(rs.getString("CARE_PLAN_ID"));
        String alias = rs.getString("GOAL_ALIAS");
        String name = rs.getString("GOAL_NAME");
        if (alias != null && alias.length() > 0)
            goal.setGoal(alias);
        else
            goal.setGoal(name);
        goal.setInternalGoal(name);
        goal.setStatus(rs.getString("STATUS_NAME"));
        goal.setStartOn(DateHelper.getDate(rs.getDate("START_DATE")));
        goal.setEndOn(DateHelper.getDate(rs.getDate("END_DATE")));

        return goal;
    }
}
