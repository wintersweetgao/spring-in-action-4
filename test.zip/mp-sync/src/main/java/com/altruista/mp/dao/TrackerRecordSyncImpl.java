package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import com.altruista.mp.services.TrackerRecordService;
import com.altruista.mp.services.TrackerService;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerRecordSyncImpl extends BaseSyncImpl implements TrackerRecordSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(TrackerRecordSyncImpl.class);

    @Value("${guidingCare.timezone}")
    private String gcTimezone;
    @Autowired
    TrackerService trackerService;
    @Autowired
    TrackerRecordService recordService;
    @Autowired
    MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT PATIENT_ID "
                            + "FROM HEALTH_INDICATOR_RECORD "
                            + "WHERE (CREATED_ON >= :runDate OR UPDATED_ON >= :runDate) ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("trackerRecord");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT R.RECORD_ID, R.PARAMETER_ID, R.VALUE_ENTERED, R.RECORD_DATE, R.COMMENTS, "
                        + " P.INDICATOR_ID, P.PARAMETER_NAME, P.MEASUREMENT_UNIT, P.PARAMETER_TYPE, "
                        + " P.CREATED_ON "
                        + " FROM HEALTH_INDICATOR_RECORD R, HEALTH_INDICATOR_PARAMETER P "
                        + " WHERE R.PATIENT_ID = ? AND (R.CREATED_ON >= ? OR R.UPDATED_ON >= ?)"
                        + " AND R.PARAMETER_ID = P.PARAMETER_ID";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{patientId, runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        TrackerRecord record = TrackerRecordMapper.toRecord(rs);

                        // assign tracker record
                        String indRefId = rs.getString("INDICATOR_ID");
                        if (indRefId != null) {
                            // lookup the record
                            List<Tracker> tracks = trackerService.findByRefId(indRefId);
                            if (tracks.size() > 0)
                                record.setTrackerId(tracks.get(0).getId());
                        }

                        record.setMemberId(member.getId());

                        String recordId = saveRecordToMongodb(record);

                        LOGGER.debug("TRACKER_RECORD: Mongodb ["
                                + recordId + "] <= SQL [ "
                                + record.getRefId() + " ]");
                    }
                });
    }
    // Pending DELETED_ON support in GC schema
    /*public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT RECORD_ID "
                        + "FROM HEALTH_INDICATOR_RECORD "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("RECORD_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<TrackerRecord> records = recordService.findByRefId(refId);
        if (records != null && records.size() > 0)
            recordService.delete(records.get(0).getId());
    }*/

    private String saveRecordToMongodb(TrackerRecord record) {
        if (record.getRefId() != null) {
            List<TrackerRecord> existing = recordService.findByRefId(record.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                record.setId(existing.get(0).getId());
                record.setVersion(existing.get(0).getVersion());
            } else
                record.setId(UUID.randomUUID().toString());
        } else
            record.setId(UUID.randomUUID().toString());

        return recordService.save(record, false);
    }

    // NOTE: DELETED_ON is not provided

    public void applyLocalChanges(DateTime runDate) {

        List<TrackerRecord> records = recordService.findTrackerIdsToSync();
        for (TrackerRecord id : records) {
            TrackerRecord record = recordService.get(id.getId());
            saveTrackerToSQL(record);
        }
    }

    private void saveTrackerToSQL(TrackerRecord record) {

        if (record.getRefId() == null || record.getRefId().length() == 0) {
            LOGGER.debug("Adding record to SQL");

            try {
                Member member = memberService.get(record.getMemberId());
                if (member == null || member.getRefId() == null || member.getRefId().length() == 0) {
                    LOGGER.error("Member is missing refId, unable to save to SQL: " + member.getId());

                    recordService.save(record, false);

                    return;
                } else {
                    LOGGER.debug("Saving TRACKER RECORD to SQL: " + record.getId());
                }

                int sourceTypeId = 2;   // TODO: Use Lookup (2 = Member Portal)

                Long memberId = Long.parseLong(member.getRefId());

                DateTime utc = new DateTime(record.getRecordedOn().toDate(), DateTimeZone.UTC);
                DateTime gc = utc.toDateTime(DateTimeZone.forID(gcTimezone));
                DateTime utc2 = new DateTime(gc, DateTimeZone.UTC);
                Date recordDate = utc2.toDate();

                String fromSql = "INSERT INTO HEALTH_INDICATOR_RECORD (" +
                        " PARAMETER_ID, PATIENT_ID, VALUE_ENTERED, COMMENTS, SOURCE_TYPE_ID,"
                        + " RECORD_DATE, CREATED_ON)"
                        + " VALUES ( :parameterId, :patientId, :valueEntered, :comments, :sourceTypeId,"
                        + " :recordDate, :createdOn )";

                KeyHolder fromKeyHolder = new GeneratedKeyHolder();
                NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
                SqlParameterSource fromNamedParameters =
                        new MapSqlParameterSource("parameterId", record.getParameterId())
                                .addValue("patientId", memberId)
                                .addValue("valueEntered", record.getValue())
                                .addValue("comments", record.getComments())
                                .addValue("sourceTypeId", sourceTypeId)
                                .addValue("recordDate", recordDate)
                                .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()));

                toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

                record.setRefId(fromKeyHolder.getKey().toString());

                recordService.save(record, false);

                LOGGER.debug("Tracker Record: RECORD: Mongodb [" + record.getId()
                        + "] => SQL [" + fromKeyHolder.getKey() + "]");

            } catch (Exception exc) {
                LOGGER.error("Unable to insert into TRACKER_RECORD for record: " + record.getId() + ", exception: " + exc);

                recordService.save(record, false);
            }
        } else {
            LOGGER.debug("Tracker Record updates are not supported for : " + record.getId());

            recordService.save(record, false);
        }
    }
}
