package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import org.joda.time.DateTime;

/**
 * Created by mwixson on 5/13/15.
 */
public interface AssessmentRunSync {
    void loadPatientIds(DateTime runDate);

    void applyRemoteChanges(long patientId, final Member member, DateTime runDate);

    void applyLocalChanges(DateTime runDate);

    void applyRemoteDeletes(DateTime runDate);
}
