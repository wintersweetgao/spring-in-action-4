package com.altruista.mp.dao;

import com.altruista.mp.model.AllergySensitivity;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/16/14.
 */
public class AllergySensitivityMapper {
    public static AllergySensitivity toAllergySensitivity(ResultSet rs) throws SQLException {
        AllergySensitivity allergy = new AllergySensitivity();
        allergy.setRefId(rs.getString("ALLERGY_ID"));
        allergy.setMedicationCode(rs.getString("MEDICATION_CODE"));
        allergy.setName(rs.getString("DESCRIPTION"));
        allergy.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return allergy;
    }
}
