package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.SyncLogService;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ProviderSyncImpl extends BaseSyncImpl implements ProviderSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(PhysicianSyncImpl.class);

    private static final String ADDRESS_URL = "http://geocoding.geo.census.gov/geocoder/locations/onelineaddress?address=";
    private static final String BENCMARK = "&benchmark=Public_AR_Current&format=jsonp";

    @Autowired
    private ContactService contactService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void applyRemoteChanges(DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT P.PHYSICIAN_ID,PHYSICIAN_CODE,NAME_PREFIX,FIRST_NAME,MIDDLE_NAME,LAST_NAME, "
                        + "NAME_SUFFIX,GENDER,ADDRESS,ADDRESS_TEXT,PA.CITY,PA.STATE,COUNTRY,PA.ZIP, WORK_PHONE, "
                        + "HOME_PHONE,CELL_PHONE,PA.FAX,PA.EMAIL,DIRECT_EMAIL,P.CREATED_ON, "
                        + "PRIMARY_LANGUAGE,ETHNICITY_ID,PROVIDER_NAME,STATUS,PS.SPECIALITY, PT.PROVIDER_TYPE "
                        + "FROM PHYSICIAN_DEMOGRAPHY P "
                        + "LEFT OUTER JOIN PROVIDER_TYPE PT ON P.PROVIDER_TYPE_ID = PT.PROVIDER_TYPE_ID "
                        + "LEFT OUTER JOIN PROVIDER_SPECIALITY PS ON P.SPECIALITY_ID = PS.SPECIALITY_ID "
                        + "LEFT OUTER JOIN PROVIDER_ADDITIONAL_ADDRESS PA ON P.PHYSICIAN_ID = PA.PHYSICIAN_ID "
                        + "WHERE (P.CREATED_ON >= ? OR P.UPDATED_ON >= ?)";

        template.setFetchSize(fetchsize);   // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        try {
                            postChanges(rs);
                        } catch (UnsupportedEncodingException e) {
                            LOGGER.error("Unsupported Encoding Exception " + e);
                        }
                    }
                });
    }

    private void postChanges(ResultSet rs) throws SQLException, UnsupportedEncodingException {
        Contact contact = PhysicianMapper.toContact(rs, true);

        // reset to provider
        contact.setContactType(ContactType.PROVIDER);

        List<String> tags = new ArrayList<String>();

        String speciality = rs.getString("SPECIALITY");
        String providerType = rs.getString("PROVIDER_TYPE");
        tags.add(speciality);
        tags.add(providerType);

        contact.setTags(tags);

        /** Get the Lat and Lon values for Provider Address */
        contact = getLatAndLongFromNominatim(contact);

        String contactId = saveProviderToMongodb(contact);
        LOGGER.debug("PROVIDER: Mongodb [" + contactId + "] <= SQL [" + contact.getRefId() + "]");

    }

    private String saveProviderToMongodb(Contact contact) {
        // see if contact already exists
        if (contact.getRefId() != null) {
            List<Contact> existing = contactService.findIdByRefIdAndContactType(contact.getRefId(), ContactType.PROVIDER);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                contact.setId(existing.get(0).getId());
                contact.setVersion(existing.get(0).getVersion());
            } else
                contact.setId(UUID.randomUUID().toString());
        } else
            contact.setId(UUID.randomUUID().toString());

        return contactService.save(contact, false);
    }

    private Contact getLatAndLongFromNominatim(Contact contact) throws UnsupportedEncodingException {
        String space = ",";

        StringBuffer location = new StringBuffer();
        if (contact.getAddress().getAddress() != null && !contact.getAddress().getAddress().isEmpty())
            location.append(contact.getAddress().getAddress()).append(space);
        if (contact.getAddress().getCity() != null && !contact.getAddress().getCity().isEmpty())
            location.append(contact.getAddress().getCity()).append(space);
        if (contact.getAddress().getStateProvince() != null && !contact.getAddress().getStateProvince().isEmpty())
            location.append(contact.getAddress().getStateProvince()).append(space);

        /** formated PostalCode to five digits, because if we don't send 5 digits PostalCode to
         * TIGERWeb service, it may return more than one lat and lon for same address
         */
        if (contact.getAddress().getPostalCode() != null && !contact.getAddress().getPostalCode().isEmpty()) {
            location.append(formatPostalCodeToFiveDigits(contact.getAddress().getPostalCode()));
        }

        // format location / address to UTF-8
        String addressUTF = URLEncoder.encode(location.toString(), "UTF-8").replace("+", "%20");

        String finalAddress = ADDRESS_URL + addressUTF + BENCMARK;
        LOGGER.debug("Location : " + finalAddress);

        /** RestTemplate call to Nominatim hosted service */
        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(finalAddress, String.class);

        // XML should come for any garbage data
        if (result.contains("?xml version=\"1.0\"")) {
            logErrosForInvalidAddresses(contact);
        } else {
            // Represents elements of JSON
            JsonElement jelement = new JsonParser().parse(result);
            if (jelement.toString().equals("[]") || result.charAt(0) == '<') {
                logErrosForInvalidAddresses(contact);
            } else {
                // Represent Object type in JSON
                JsonObject jobject = jelement.getAsJsonObject();
                if (jobject.toString().contains("errors")) {
                    logErrosForInvalidAddresses(contact);
                } else if (jobject.get("result") != null) {
                    // get "result" element from JSON object
                    JsonElement jelement1 = jobject.get("result");
                    JsonObject jobject1 = jelement1.getAsJsonObject();

                    // get "addressMatches" element from JSON object
                    JsonElement jelement2 = jobject1.get("addressMatches");
                    JsonArray jarray = jelement2.getAsJsonArray();
                    if (!jarray.toString().equals("[]")) {
                        JsonObject jobject2 = jarray.get(0).getAsJsonObject();

                        // get "coordinates" element from JSON object
                        JsonElement jelement3 = jobject2.get("coordinates");
                        JsonObject jo = jelement3.getAsJsonObject();
                        if (jo != null) {
                            // x represents Latitude and y represents Longitude
                            String lat = jo.get("y").toString();
                            String lon = jo.get("x").toString();
                            LOGGER.debug("Latitude : [" + lat + "], Longitude : [" + lon + "]");

                            // set Positions to address object
                            Address PhysicianAddress = contact.getAddress();
                            PhysicianAddress.setPosition(new Double[]{Double.parseDouble(lat), Double.parseDouble(lon)});
                            contact.setAddress(PhysicianAddress);
                        }
                    } else {
                        logErrosForInvalidAddresses(contact);
                    }
                }
            }
        }
        return contact;
    }

    private void logErrosForInvalidAddresses(Contact contact) {
        SyncLog sl = new SyncLog();
        sl.setLevel(SyncLogLevelType.ERROR);
        sl.setObjectName("contact");
        sl.setObjectId(contact.getId());
        sl.setAction("getLatAndLongFromNominatim");
        sl.setDescription("Invalid address found to call TIGERweb services.");
        syncLogService.save(sl);
        LOGGER.error(sl.getDescription() + " Unable to save lat and lon into contact : " + contact.getId());
    }

    // format PostalCode to Five digits
    private StringBuffer formatPostalCodeToFiveDigits(String postalCode) {
        StringBuffer postalCodeFiveDigits = new StringBuffer();
        if (postalCode.length() == 5)
            postalCodeFiveDigits.append(postalCode);
        else if (postalCode.length() >= 5)
            postalCodeFiveDigits.append(postalCode.substring(0, 5));

        return postalCodeFiveDigits;
    }
}