package com.altruista.mp.dao;

import com.altruista.mp.model.ValidValue;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/25/14.
 */
public class LanguageMapper {
    public static ValidValue toValidValue(ResultSet rs) throws SQLException {
        ValidValue language = new ValidValue();
        language.setName("LANGUAGE");   // "Table" Name
        language.setRefId(rs.getString("LANGUAGE_ID"));
        language.setValue(rs.getString("LANGUAGE_ID"));
        language.setDescription(rs.getString("DESCRIPTION"));
        language.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return language;
    }
}
