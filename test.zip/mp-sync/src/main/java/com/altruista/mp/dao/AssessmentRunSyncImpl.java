package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.*;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by mwixson on 5/13/15.
 */
public class AssessmentRunSyncImpl extends BaseSyncImpl implements AssessmentRunSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory
            .getLogger(AssessmentRunSyncImpl.class);
    @Value("${guidingCare.timezone}")
    private String gcTimezone;
    @Autowired
    private AssessmentRunService assessmentRunService;
    @Autowired
    private AssessmentResponseService assessmentResponseService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private ContactService contactService;
    @Autowired
    private AssessmentService assessmentService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            // TBD: UNION to separate queries, one for PATIENT_FOLLOWUP AND one for SCPT_PATIENT_SCRIPT_RUN_LOG/PATIENT_FOLLOWUP
            // PART 1- SELECT DISTINCT PATIENT_ID FROM PATIENT_FOLLOWUP WHERE ACTIVITY_TYPE = 'Member Self Assessment'

            // PART 2- UNION
            // SELECT DISTINCT PATIENT_ID FROM PATIENT_FOLLOWUP, SCPT_PATIENT_SCRIPT_RUN_LOG WHERE ACTIVITY_TYPE = 'Member Self Assessment' AND ...

            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT F.PATIENT_ID "
                            + " FROM PATIENT_FOLLOWUP F, CARE_ACTIVITY_TYPE A"
                            + " WHERE F.CARE_ACTIVITY_TYPE_ID = A.CARE_ACTIVITY_TYPE_ID "
                            + " AND A.CARE_ACTIVITY_TYPE_NAME = 'Member Self Assessment'"
                            + " AND F.CREATED_DATE >= :runDate";
            // NOTE: Ignore updates, SCPT_PATIENT_SCRIPT_RUN_LOG will be used for updates

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            LOGGER.error("Unable to load MP_TEMP table, exception: " + exc);
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("assessmentRun");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        // Run two separate queries
        // PART 1- SELECT ... FROM PATIENT_FOLLOWUP WHERE ACTIVITY_TYPE = 'Member Self Assessment'
        // add matching values to AssessmentRun with status = 'Pending'

        // PART 2- SELECT DISTINCT PATIENT_ID FROM PATIENT_FOLLOWUP, SCPT_PATIENT_SCRIPT_RUN_LOG WHERE ACTIVITY_TYPE = 'Member Self Assessment' AND ...
        // add matching values to AssessmentRun with status matching GC status

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT F.PATIENT_FOLLOWUP_ID,F.SCRIPT_ID,F.PATIENT_ID,F.CALL_STATUS, "
                        + " SS.SCRIPT_NAME "
                        + " FROM PATIENT_FOLLOWUP F, CARE_ACTIVITY_TYPE A, SCPT_ADMIN_SCRIPT SS"
                        + " WHERE F.CARE_ACTIVITY_TYPE_ID = A.CARE_ACTIVITY_TYPE_ID "
                        + " AND A.CARE_ACTIVITY_TYPE_NAME = 'Member Self Assessment'"
                        + " AND F.SCRIPT_ID = SS.SCRIPT_ID"
                        + " AND F.PATIENT_ID = ?"
                        + " AND F.CREATED_DATE >= ?";
        // NOTE: Ignore updates, SCPT_PATIENT_SCRIPT_RUN_LOG will be used for updates

        template.setFetchSize(fetchsize);
        template.query(sql, new Object[]{patientId, runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(member, rs);
                    }
                });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {
        AssessmentRun assessmentRun = AssessmentRunMapper.followupToAssessmentRun(rs);
        assessmentRun.setMemberId(member.getId());

        // Lookup Assessment
        List<Assessment> assessments = assessmentService.findByRefId(rs.getString("SCRIPT_ID"));
        if (assessments == null || assessments.isEmpty()) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("assessmentRun");
            sl.setObjectId(assessmentRun.getId());
            sl.setMemberId(member.getId());
            sl.setAction("saveAssessmentRunToMongodb");
            sl.setDescription("Unable to find assessment by refId: " + rs.getString("SCRIPT_ID"));
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", skipping Run: " + assessmentRun.getId());

            return;
        }

        assessmentRun.setAssessmentId(assessments.get(0).getId());

        // Save AssessmentRun
        String assessmentRunId = saveAssessmentRunToMongodb(assessmentRun);

        LOGGER.debug("ASSESSMENT_RUN: Mongodb [" + assessmentRunId + "] <= SQL [ "
                + assessmentRun.getRefId() + " ]");
    }

    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PF.PATIENT_FOLLOWUP_ID, SR.SCRIPT_RUN_LOG_ID "
                        + "FROM PATIENT_FOLLOWUP PF, SCPT_PATIENT_SCRIPT_RUN_LOG SR "
                        + "WHERE PF.PATIENT_FOLLOWUP_ID = SR.PATIENT_FOLLOWUP_ID "
                        + "AND (PF.DELETED_ON >= ? OR SR.DELETED_ON >= ?) ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        deleteByRunLogId(rs.getString("SCRIPT_RUN_LOG_ID"));
                        deleteByFollowupId(rs.getString("PATIENT_FOLLOWUP_ID"));
                    }
                });
    }

    private void deleteByRunLogId(String refId) {
        List<AssessmentRun> runs = assessmentRunService.findByRefId(refId);
        for (AssessmentRun run : runs)
            assessmentRunService.delete(run.getId());
    }

    private void deleteByFollowupId(String followupRefId) {
        List<AssessmentRun> runs = assessmentRunService.findByFollowupRefId(followupRefId);
        for (AssessmentRun run : runs)
            assessmentRunService.delete(run.getId());

    }

    private String saveAssessmentRunToMongodb(AssessmentRun assessmentRun) {
        if (assessmentRun.getFollowupRefId() != null) {
            List<AssessmentRun> existing = assessmentRunService.findByFollowupRefId(assessmentRun.getFollowupRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                assessmentRun.setId(existing.get(0).getId());
                assessmentRun.setVersion(existing.get(0).getVersion());
            } else
                assessmentRun.setId(UUID.randomUUID().toString());
        } else
            assessmentRun.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        assessmentRun.setSyncedOn(DateTime.now());*/

        return assessmentRunService.save(assessmentRun, false);
    }

    @Override
    public void applyLocalChanges(DateTime runDate) {

        List<AssessmentRun> assessmentRun = assessmentRunService.findRunIdsToSync();
        for (AssessmentRun id : assessmentRun) {
            AssessmentRun assessments = assessmentRunService.get(id.getId());
            saveAssessmentRunToSQL(assessments, runDate);
        }
        List<AssessmentResponse> responses = assessmentResponseService.findResponseIdsToSync();
        for (AssessmentResponse id : responses) {
            AssessmentResponse response = assessmentResponseService.get(id.getId());
            saveAssessmentResponseToSQL(response);
        }
    }

    private void saveAssessmentRunToSQL(AssessmentRun assessmentRun, DateTime runDate) {

        try {
            Member member = memberService.get(assessmentRun.getMemberId());
            if (member.getRefId() == null || member.getRefId().length() == 0) {
                SyncLog sl = new SyncLog();
                sl.setLevel(SyncLogLevelType.WARN);
                sl.setObjectName("assessmentRun");
                sl.setObjectId(assessmentRun.getId());
                sl.setMemberId(member.getId());
                sl.setAction("saveAssessmentRunToSQL");
                sl.setDescription("Member is missing refId, unable to save to SQL: " + member.getId());
                syncLogService.save(sl);

                LOGGER.error(sl.getDescription() + ", skipping Run: " + assessmentRun.getId());

               /* // IMPORTANT: set sync time to mark as ignored
                assessmentRun.setSyncedOn(DateTime.now());
                assessmentRunService.setSyncEnabled(false);*/

                assessmentRunService.save(assessmentRun, false);

                return;
            } else {
                LOGGER.debug("Saving Assessment Run to SQL: " + assessmentRun.getId());
            }
            Long memberId = Long.parseLong(member.getRefId());

            if (member.getCareManagerId() == null) {
                SyncLog sl = new SyncLog();
                sl.setLevel(SyncLogLevelType.WARN);
                sl.setObjectName("assessmentRun");
                sl.setObjectId(assessmentRun.getId());
                sl.setMemberId(member.getId());
                sl.setAction("saveAssessmentRunToSQL");
                sl.setDescription("Member is missing Care Manager, unable to save to SQL: " + member.getId());
                syncLogService.save(sl);

                LOGGER.error(sl.getDescription() + ", skipping Run: " + assessmentRun.getId());

               /* // IMPORTANT: set sync time to mark as ignored
                assessmentRun.setSyncedOn(DateTime.now());
                assessmentRunService.setSyncEnabled(false);*/

                assessmentRunService.save(assessmentRun, false);

                return;
            }

            Contact careManager = contactService.get(member.getCareManagerId());
            Long staffId = null;
            if (careManager != null) {
                staffId = Long.parseLong(careManager.getRefId());
            }

            Date startedOn = null;
            Date endedOn = null;

            if (assessmentRun.getStartedOn() != null) {
                DateTime utc = new DateTime(assessmentRun.getStartedOn().toDate(), DateTimeZone.UTC);
                DateTime gc = utc.toDateTime(DateTimeZone.forID(gcTimezone));
                startedOn = gc.toDate();
            }

            if (assessmentRun.getEndedOn() != null) {
                DateTime utc = new DateTime(assessmentRun.getEndedOn().toDate(), DateTimeZone.UTC);
                DateTime gc = utc.toDateTime(DateTimeZone.forID(gcTimezone));
                endedOn = gc.toDate();
            }

            int statusId = getStatusId(assessmentRun.getStatus());
            LOGGER.debug("statusId ::" + statusId);
            int scriptIsSinglePage = 0;
            int callType = 1;

            // update followup table
            Long followupRefId = null;
            if (assessmentRun.getFollowupRefId() != null || assessmentRun.getFollowupRefId().length() != 0) {

                followupRefId = Long.parseLong(assessmentRun.getFollowupRefId());

                int CALL_STATUS = 0;
                if (!assessmentRun.getStatus().equals("Pending")) {
                    CALL_STATUS = 1;
                }

                String assessmentSQL =
                        "UPDATE PATIENT_FOLLOWUP SET " +
                                " CALL_STATUS = :callStatus " +
                                " WHERE PATIENT_FOLLOWUP_ID = :followupRefId ";

                NamedParameterJdbcTemplate assessmentTemplate = new NamedParameterJdbcTemplate(dataSource);
                MapSqlParameterSource parmsMap =
                        new MapSqlParameterSource("callStatus", CALL_STATUS)
                                .addValue("followupRefId", followupRefId);

                int rows = assessmentTemplate.update(assessmentSQL, parmsMap);

                if (rows == 1) {
                    LOGGER.debug("UPDATE PATIENT_FOLLOWUP: Mongodb [" + assessmentRun.getId()
                            + "] => SQL [" + assessmentRun.getRefId() + "]");
                } else if (rows > 1) {
                    LOGGER.warn("PATIENT_FOLLOWUP: Mongodb [" + assessmentRun.getId()
                            + "] => SQL [" + assessmentRun.getRefId() + "] updated " + rows + " rows.");
                } else {
                    LOGGER.error("Unable to update PATIENT_FOLLOWUP for Assessment Run: " + assessmentRun.getId() + ", no rows updated.");
                }

               /* // IMPORTANT: set sync time to mark as synchronized
                assessmentRun.setSyncedOn(DateTime.now());
                assessmentRunService.setSyncEnabled(false);*/

                assessmentRunService.save(assessmentRun, false);
            }

            if (assessmentRun.getRefId() == null || assessmentRun.getRefId().length() == 0) {
                LOGGER.debug("Adding in Assessment Run to SQL: " + assessmentRun.getId());

                // :patientFollowupId, / PATIENT_FOLLOWUP_ID,
                String fromSql = "INSERT INTO SCPT_PATIENT_SCRIPT_RUN_LOG ("
                        + " PATIENT_ID, START_DATE, END_DATE, STATUS_ID, STAFF_ID, SCRIPT_IS_SINGLE_PAGE,"
                        + " CALL_TYPE, PATIENT_FOLLOWUP_ID)"
                        + " VALUES ( :patientId, :startDate, :endDate,"
                        + " :statusId, :staffId, :scriptIsSinglePage, :callType, :patientFollowupId )";

                KeyHolder fromKeyHolder = new GeneratedKeyHolder();
                NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
                SqlParameterSource fromNamedParameters =
                        new MapSqlParameterSource("patientId", memberId)
                                .addValue("startDate", startedOn)
                                .addValue("endDate", endedOn)
                                .addValue("statusId", statusId)
                                .addValue("staffId", staffId)
                                .addValue("scriptIsSinglePage", scriptIsSinglePage)
                                .addValue("callType", callType)
                                .addValue("patientFollowupId", followupRefId);

                toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

                assessmentRun.setRefId(fromKeyHolder.getKey().toString());

                // IMPORTANT: set sync time to mark as synchronized
               /* assessmentRun.setSyncedOn(DateTime.now());
                assessmentRunService.setSyncEnabled(false);*/

                assessmentRunService.save(assessmentRun, false);

                LOGGER.debug("Assessment Run RECORD: Mongodb [" + assessmentRun.getId()
                        + "] => SQL [" + fromKeyHolder.getKey() + "]");

            } else {
                LOGGER.debug("Updating Assessment Run " + assessmentRun.getRefId());

                Long scriptRunLogId = Long.parseLong(assessmentRun.getRefId());

                String assessmentSQL =
                        "UPDATE SCPT_PATIENT_SCRIPT_RUN_LOG SET " +
                                " PATIENT_ID = :patientId, " +
                                " STAFF_ID = :staffId, " +
                                " START_DATE = :startDate, " +
                                " END_DATE = :endDate, " +
                                " STATUS_ID = :statusId, " +
                                " CALL_TYPE = :callType, " +
                                " SCRIPT_IS_SINGLE_PAGE = :scriptIsSinglePage " +
                                " WHERE SCRIPT_RUN_LOG_ID = :scriptRunLogId ";

                NamedParameterJdbcTemplate assessmentTemplate = new NamedParameterJdbcTemplate(dataSource);
                MapSqlParameterSource parmsMap =
                        new MapSqlParameterSource("patientId", memberId)
                                .addValue("staffId", staffId)
                                .addValue("startDate", startedOn)
                                .addValue("endDate", endedOn)
                                .addValue("statusId", statusId)
                                .addValue("callType", callType)
                                .addValue("scriptIsSinglePage", scriptIsSinglePage)
                                .addValue("scriptRunLogId", scriptRunLogId);

                int rows = assessmentTemplate.update(assessmentSQL, parmsMap);

                if (rows == 1) {
                    LOGGER.debug("UPDATE SCPT_PATIENT_SCRIPT_RUN_LOG: Mongodb [" + assessmentRun.getId()
                            + "] => SQL [" + assessmentRun.getRefId() + "]");
                } else if (rows > 1) {
                    LOGGER.warn("SCPT_PATIENT_SCRIPT_RUN_LOG: Mongodb [" + assessmentRun.getId()
                            + "] => SQL [" + assessmentRun.getRefId() + "] updated " + rows + " rows.");
                } else {
                    LOGGER.error("Unable to update SCPT_PATIENT_SCRIPT_RUN_LOG for Assessment Run: " + assessmentRun.getId() + ", no rows updated.");
                }

               /* // IMPORTANT: set sync time to mark as synchronized
                assessmentRun.setSyncedOn(DateTime.now());
                assessmentRunService.setSyncEnabled(false);*/

                assessmentRunService.save(assessmentRun, false);

            }
        } catch (Exception exc) {
           /* // IMPORTANT: set sync time to mark as ignored
            assessmentRun.setSyncedOn(DateTime.now());
            assessmentRunService.setSyncEnabled(false);*/

            assessmentRunService.save(assessmentRun, false);

            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("assessmentRun");
            sl.setObjectId(assessmentRun.getId());
            sl.setAction("saveAssessmentRunToSQL");
            sl.setDescription("Unable to save Assessment Run: " + assessmentRun.getId());
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    private void saveAssessmentResponseToSQL(AssessmentResponse response) {
        try {
            AssessmentRun assessmentRun = assessmentRunService.get(response.getRunId());

            Member member = memberService.get(assessmentRun.getMemberId());
            if (member.getRefId() == null || member.getRefId().length() == 0) {
                SyncLog sl = new SyncLog();
                sl.setLevel(SyncLogLevelType.ERROR);
                sl.setObjectName("assessmentResponse");
                sl.setObjectId(response.getId());
                sl.setMemberId(member.getId());
                sl.setAction("saveAssessmentResponseToSQL");
                sl.setDescription("Member is missing refId, unable to save to SQL: " + member.getId());
                syncLogService.save(sl);

                LOGGER.error(sl.getDescription() + ", skipping response: " + response.getId());

                assessmentResponseService.save(response, false);

                return;
            } else {
                LOGGER.debug("Saving Assessment Response to SQL: " + assessmentRun.getId());
            }

            if (member.getCareManagerId() == null) {
                SyncLog sl = new SyncLog();
                sl.setLevel(SyncLogLevelType.WARN);
                sl.setObjectName("assessmentResponse");
                sl.setObjectId(assessmentRun.getId());
                sl.setMemberId(member.getId());
                sl.setAction("saveAssessmentResponseToSQL");
                sl.setDescription("Member is missing Care Manager, unable to save to SQL: " + member.getId());
                syncLogService.save(sl);

                LOGGER.warn(sl.getDescription() + ", skipping response: " + response.getId());

               /* // IMPORTANT: set sync time to mark as ignored
                assessmentRun.setSyncedOn(DateTime.now());
                assessmentRunService.setSyncEnabled(false);*/

                assessmentResponseService.save(response, false);

                return;
            }

            Contact careManager = contactService.get(member.getCareManagerId());
            Long staffId = null;
            if (careManager != null) {
                staffId = Long.parseLong(careManager.getRefId());
            }
            Long runLogId = Long.parseLong(assessmentRun.getRefId());

            int isActive = 1;

            Assessment assessment = assessmentService.get(assessmentRun.getAssessmentId());
            if (assessment == null) {
                SyncLog sl = new SyncLog();
                sl.setLevel(SyncLogLevelType.WARN);
                sl.setObjectName("assessmentResponse");
                sl.setObjectId(assessmentRun.getId());
                sl.setMemberId(member.getId());
                sl.setAction("saveAssessmentResponseToSQL");
                sl.setDescription("Invalid or missing assessment id, unable to save to SQL: " + assessmentRun.getAssessmentId());
                syncLogService.save(sl);

                LOGGER.warn(sl.getDescription() + ", skipping response: " + response.getId());

               /* // IMPORTANT: set sync time to mark as ignored
                assessmentRun.setSyncedOn(DateTime.now());
                assessmentRunService.setSyncEnabled(false);*/

                assessmentResponseService.save(response, false);

                return;
            }

            // script ID is the assessment's refId
            Long scriptId = Long.parseLong(assessment.getRefId());

            Long questionId = null;
            if (response.getQuestion() != null) {
                AssessmentQuestion question = response.getQuestion();
                questionId = Long.parseLong(question.getRefId());
            }

            Long scriptRunLogDetailId = null;
            if (response.getRefId() == null || response.getRefId().length() == 0) {
                LOGGER.debug("Adding Assessment Response.");

                String logDetailSql =
                        "INSERT INTO SCPT_PATIENT_SCRIPT_RUN_LOG_DETAIL ( " +
                                "SCRIPT_RUN_LOG_ID, STAFF_ID, SCRIPT_ID, QUESTION_ID, IS_RESPONDED, IS_CONFIDENTIAL, CREATED_ON ) "
                                + "VALUES ( :scriptRunLogId, :staffId, :scriptId, :questionId, :isResponded, :isConfidential, :createdOn) ";

                KeyHolder logDetailKeyHolder = new GeneratedKeyHolder();
                NamedParameterJdbcTemplate logDetailTemplate = new NamedParameterJdbcTemplate(dataSource);
                SqlParameterSource logDetailParameters =
                        new MapSqlParameterSource("scriptRunLogId", runLogId)
                                .addValue("staffId", staffId)
                                .addValue("scriptId", scriptId)
                                .addValue("questionId", questionId)
                                .addValue("isResponded", true)
                                .addValue("isConfidential", true)
                                .addValue("createdOn", response.getCreatedOn().toDate());

                logDetailTemplate.update(logDetailSql, logDetailParameters, logDetailKeyHolder);

                LOGGER.debug("ASSESSMENTS: SCPT_PATIENT_SCRIPT_RUN_LOG_DETAIL: Mongodb [" + response.getId()
                        + "] => SQL [" + logDetailKeyHolder.getKey() + "]");

                // use the run log detail ID as the primary refId
                response.setDetailRefId(logDetailKeyHolder.getKey().toString());

                Number runLogDetailKey = logDetailKeyHolder.getKey();
                if (runLogDetailKey != null)
                    scriptRunLogDetailId = runLogDetailKey.longValue();
            } else {
                LOGGER.debug("Updating Assessment Response " + response.getRefId());

                scriptRunLogDetailId = Long.parseLong(response.getDetailRefId());

                String responseSQL =
                        "UPDATE SCPT_PATIENT_SCRIPT_RUN_LOG_DETAIL SET " +
                                " SCRIPT_RUN_LOG_ID = :runLogId, " +
                                " STAFF_ID = :staffId, " +
                                " QUESTION_ID = :questionId, " +
                                " SCRIPT_ID = :scriptId, " +
                                " IS_CONFIDENTIAL = :isConfidential, " +
                                " IS_RESPONDED = :isResponded, " +
                                " UPDATED_ON = :updatedOn " +
                                " WHERE SCRIPT_RUN_LOG_DETAIL_ID =:scriptRunLogDetailId";

                NamedParameterJdbcTemplate responseTemplate = new NamedParameterJdbcTemplate(dataSource);
                MapSqlParameterSource parmsMap =
                        new MapSqlParameterSource("runLogId", runLogId)
                                .addValue("staffId", staffId)
                                .addValue("questionId", questionId)
                                .addValue("scriptId", scriptId)
                                .addValue("isConfidential", true)
                                .addValue("isResponded", true)
                                .addValue("updatedOn", response.getUpdatedOn().toDate())
                                .addValue("scriptRunLogDetailId", scriptRunLogDetailId);

                int rows = responseTemplate.update(responseSQL, parmsMap);

                if (rows == 1) {
                    LOGGER.debug("UPDATE SCPT_PATIENT_SCRIPT_RUN_LOG_DETAIL: Mongodb [" + response.getId()
                            + "] => SQL [" + response.getRefId() + "]");
                } else if (rows > 1) {
                    LOGGER.warn("SCPT_PATIENT_SCRIPT_RUN_LOG_DETAIL: Mongodb [" + response.getId()
                            + "] => SQL [" + response.getRefId() + "] updated " + rows + " rows.");
                } else {
                    LOGGER.error("Unable to update SCPT_PATIENT_SCRIPT_RUN_LOG_DETAIL for Assessment Response: " + response.getId() + ", no rows updated.");
                }
            }

            if (response.getQuestion() == null || response.getQuestion().getOptions() == null)
                return;

            for (AssessmentQuestionOption opt : response.getQuestion().getOptions()) {
                Long questionOptionId = Long.parseLong(opt.getRefId());

                // insert / update at option level if no suboptions
                if (opt.getSubOptions() == null || opt.getSubOptions().isEmpty()) {

                    // only add if option has a value
                    if (opt.getValue() != null && opt.getValue().length() > 0) {

                        String questionResponseRefId = insertQuestionResponseSQL(scriptRunLogDetailId,
                                questionOptionId, opt.getValue(),
                                null, null,
                                staffId, isActive, response.getCreatedOn().toDate());

                        LOGGER.debug("INSERT SCPT_QUESTION_RESPONSE (OPT): Mongodb [" + response.getId()
                                + "] => SQL [" + questionResponseRefId + "]");

                        // remember the refId
                        opt.setDetailRefId(questionResponseRefId);
                    }
                }
                // insert / update at suboption level if suboptions supported
                else {
                    for (AssessmentQuestionSubOption subOpt : opt.getSubOptions()) {
                        Long subOptionId = Long.parseLong(subOpt.getRefId());

                        // only add if subOption has a value
                        if (subOpt.getValue() != null && subOpt.getValue().length() > 0) {

                            String questionResponseRefId = insertQuestionResponseSQL(scriptRunLogDetailId,
                                    questionOptionId, opt.getValue(),
                                    subOptionId, subOpt.getValue(),
                                    staffId, isActive, response.getCreatedOn().toDate());

                            LOGGER.debug("INSERT SCPT_QUESTION_RESPONSE (SUBOPT): Mongodb [" + response.getId()
                                    + "] => SQL [" + questionResponseRefId + "]");

                            // remember the refId
                            subOpt.setDetailRefId(questionResponseRefId);
                        }
                    } // for each subOption
                } // if option has suboptions
            } // for each option

           /* // IMPORTANT: set sync time to mark as synchronized
            response.setSyncedOn(DateTime.now());
            assessmentResponseService.setSyncEnabled(false);*/

            assessmentResponseService.save(response, false);
        } catch (Exception exc) {

            assessmentResponseService.save(response, false);

            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("assessmentResponse");
            sl.setObjectId(response.getId());
            sl.setAction("saveAssessmentResponseToSQL");
            sl.setDescription("Unable to save Assessment Response: " + response.getId());
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    private String insertQuestionResponseSQL(Long scriptRunLogDetailId,
                                             Long optionId, String optionValue,
                                             Long subOptionId, String subOptionValue,
                                             Long staffId, int isActive,
                                             Date createdOn) {

        String responseSql =
                "INSERT INTO SCPT_QUESTION_RESPONSE ( " +
                        "SCRIPT_RUN_LOG_DETAIL_ID, QUESTION_OPTION_ID, OPTION_VALUE, "
                        + "SUB_OPTION_ID, SUB_OPTION_VALUE, CREATED_BY, IS_ACTIVE, CERATED_ON) "
                        + "VALUES ( :scriptRunLogDetailId, :questionOptionId, "
                        + ":optionValue, :subOptionId, :subOptionValue, :createdBy, :isActive, :createdOn) ";

        KeyHolder responseKeyHolder = new GeneratedKeyHolder();
        NamedParameterJdbcTemplate responseTemplate = new NamedParameterJdbcTemplate(dataSource);
        SqlParameterSource responseParameters =
                new MapSqlParameterSource("scriptRunLogDetailId", scriptRunLogDetailId)
                        .addValue("questionOptionId", optionId)
                        .addValue("optionValue", optionValue)
                        .addValue("subOptionId", subOptionId)
                        .addValue("subOptionValue", subOptionValue)
                        .addValue("createdBy", staffId)
                        .addValue("isActive", isActive)
                        .addValue("createdOn", createdOn);

        responseTemplate.update(responseSql, responseParameters, responseKeyHolder);

        return responseKeyHolder.getKey().toString();
    }

    private int updateQuestionResponseSQL(Long questionResponseId,
                                          Long scriptRunLogDetailId,
                                          Long optionId, String optionValue,
                                          Long subOptionId, String subOptionValue,
                                          int isActive) {

        //for response table
        String respSQL =
                "UPDATE SCPT_QUESTION_RESPONSE SET " +
                        " SCRIPT_RUN_LOG_DETAIL_ID = :scriptRunLogDetailId, " +
                        " QUESTION_OPTION_ID = :questOptId, " +
                        " OPTION_VALUE = :questValue, " +
                        " SUB_OPTION_ID = :subOptId, " +
                        " SUB_OPTION_VALUE = :subOptValue, " +
                        " IS_ACTIVE = :isActive " +
                        " WHERE QUESTION_RESPONSE_ID =:questionResponseId";

        NamedParameterJdbcTemplate respTemplate = new NamedParameterJdbcTemplate(dataSource);
        MapSqlParameterSource parmMap =
                new MapSqlParameterSource("scriptRunLogDetailId", scriptRunLogDetailId)
                        .addValue("questOptId", optionId)
                        .addValue("questValue", optionValue)
                        .addValue("subOptId", subOptionId)
                        .addValue("subOptValue", subOptionValue)
                        .addValue("isActive", isActive)
                        .addValue("questionResponseId", questionResponseId);

        int rowsCount = respTemplate.update(respSQL, parmMap);

        return rowsCount;
    }

    private int getStatusId(String statusValue) {
        String sql = "SELECT STATUS_ID, VALUE FROM SCPT_SCRIPT_RUN_STATUS ";
        NamedParameterJdbcTemplate haTemplate = new NamedParameterJdbcTemplate(dataSource);
        Map<String, String> parms = new HashMap<String, String>();
        List<Map<String, Object>> list = haTemplate.queryForList(sql, parms);

        HashMap<String, String> statusMap = new HashMap<String, String>();
        for (Map<String, Object> map : list) {
            statusMap.put(map.get("VALUE").toString(), map.get("STATUS_ID").toString());
        }

        // 1 Completed
        // 2 Pending

        String status = "Pending";
        if (statusValue.equalsIgnoreCase("New"))
            status = "Pending";
        else if (statusValue.equalsIgnoreCase("Pending"))
            status = "Pending";
        else if (statusValue.equalsIgnoreCase("Completed"))
            status = "Completed";

        int statusId = 1;
        if (statusMap.containsKey(status))
            statusId = Integer.parseInt(statusMap.get(status));
        else
            LOGGER.warn("Invalid Status: " + status);

        return statusId;
    }
}