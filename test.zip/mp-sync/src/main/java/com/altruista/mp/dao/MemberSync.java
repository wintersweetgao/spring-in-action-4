package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import org.joda.time.DateTime;

public interface MemberSync extends BaseSync {
    void loadPatientIds(DateTime runDate);

    void applyRemoteChanges(long patientId, DateTime runDate);

    void applyRemoteDeletes(DateTime runDate);

    void applyLocalChanges(DateTime runDate);

    Member getCurrentMember(String refId);
}

