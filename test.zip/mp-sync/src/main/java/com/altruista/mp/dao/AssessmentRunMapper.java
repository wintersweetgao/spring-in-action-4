package com.altruista.mp.dao;

import com.altruista.mp.model.AssessmentRun;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AssessmentRunMapper {
    public static AssessmentRun followupToAssessmentRun(ResultSet rs) throws SQLException {
        AssessmentRun assessmentRun = new AssessmentRun();

        assessmentRun.setAssessmentName(rs.getString("SCRIPT_NAME"));
        assessmentRun.setFollowupRefId(rs.getString("PATIENT_FOLLOWUP_ID"));

        if (rs.getString("CALL_STATUS").equals("0"))
            assessmentRun.setStatus("Pending");
        else
            assessmentRun.setStatus("Completed");

        return assessmentRun;
    }
}
