package com.altruista.mp.dao;

import com.altruista.mp.model.Condition;
import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.ConditionService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class ConditionSyncImpl extends BaseSyncImpl implements ConditionSync {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConditionSyncImpl.class);

    @Autowired
    private ConditionService conditionService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT PC.PATIENT_ID "
                            + "FROM PATIENT_CONDITION PC, CPL_MANAGE_CONDITION MC, CPL_MANAGE_CONDITION_TYPE MCT "
                            + "WHERE PC.CONDITION_ID = MC.CONDITION_ID "
                            + " AND MC.CONDITION_TYPE_ID = MCT.CONDITION_TYPE_ID "
                            + " AND PC.LABEL_ID IS NULL "
                            + " AND (PC.CREATED_ON >= :runDate OR PC.UPDATED_ON >= :runDate) ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("condition");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql = "SELECT PC.PATIENT_ID, PATIENT_CONDITION_ID, CONDITION_NAME, MCT.NAME, PC.CREATED_ON "
                + "FROM PATIENT_CONDITION PC, CPL_MANAGE_CONDITION MC, CPL_MANAGE_CONDITION_TYPE MCT "
                + "WHERE PC.CONDITION_ID = MC.CONDITION_ID "
                + " AND MC.CONDITION_TYPE_ID = MCT.CONDITION_TYPE_ID "
                + " AND PC.LABEL_ID IS NULL "
                + " AND (PC.CREATED_ON >= ? OR PC.UPDATED_ON >= ?) "
                + " AND PC.PATIENT_ID = ? ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(member, rs);
                    }
                });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        Condition condition = ConditionMapper.toCondition(rs);

        condition.setMemberId(member.getId());

        // Save the CONDITION
        String conditionId = saveConditionToMongodb(condition);

        LOGGER.debug("Condition: Mongodb ["
                + conditionId + "] <= SQL [ "
                + condition.getRefId() + " ]");

    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PATIENT_CONDITION_ID "
                        + "FROM PATIENT_CONDITION "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("PATIENT_CONDITION_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<Condition> conditions = conditionService.findIdByRefId(refId);
        if (conditions != null && conditions.size() > 0)
            conditionService.delete(conditions.get(0).getId());
    }

    private String saveConditionToMongodb(Condition condition) {
        // see if condition already exists
        if (condition.getRefId() != null) {
            List<Condition> existing = conditionService.findIdByRefId(condition.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                condition.setId(existing.get(0).getId());
                condition.setVersion(existing.get(0).getVersion());
            } else
                condition.setId(UUID.randomUUID().toString());
        } else
            condition.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        condition.setSyncedOn(DateTime.now());
        conditionService.setSyncEnabled(false);*/

        return conditionService.save(condition, false);

    }

}
