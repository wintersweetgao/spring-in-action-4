package com.altruista.mp.dao;

import com.altruista.mp.model.Tracker;
import com.altruista.mp.model.TrackerCategory;
import com.altruista.mp.model.TrackerParameter;
import com.altruista.mp.services.TrackerCategoryService;
import com.altruista.mp.services.TrackerService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerSyncImpl extends BaseSyncImpl implements TrackerSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(TrackerSyncImpl.class);

    @Autowired
    TrackerService trackerService;
    @Autowired
    TrackerCategoryService categoryService;

    @Override
    public void applyRemoteChanges(DateTime runDate) {
        // NOTE: To simplify sync and subsequent access
        // all parameters are reassigned even if only 1 indicator or 1 parameter has changed
        applyIndicatorChanges(runDate);
        applyParameterChanges(runDate);
    }

    private void applyIndicatorChanges(DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        //  int categoryId = 59;

        String sql =
                "SELECT INDICATOR_ID, IC.CATEGORY_ID, INDICATOR_NAME, IC.CREATED_ON "
                        + " FROM HEALTH_INDICATOR HI, HEALTH_INDICATOR_CAT IC"
                        + " WHERE IC.CATEGORY_ID = HI.CATEGORY_ID "
                        + " AND IC.CATEGORY_NAME = 'Wellness' "
                        + " AND (HI.CREATED_ON >= ? OR HI.UPDATED_ON >= ? OR"
                        + " IC.CREATED_ON >= ? OR IC.UPDATED_ON >= ?)";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        Tracker tracker = TrackerMapper.toTracker(rs);

                        // assign tracker category
                        String catRefId = rs.getString("CATEGORY_ID");
                        if (catRefId != null) {
                            // lookup the category
                            List<TrackerCategory> cats = categoryService.findByRefId(catRefId);
                            if (cats.size() > 0)
                                tracker.setCategoryId(cats.get(0).getId());
                        }

                        // assign health indicator parameters
                        tracker.setParameters(
                                getHealthTrackerParameters(tracker.getRefId()));

                        String trackerId = saveCategoryToMongodb(tracker);

                        LOGGER.debug("TRACKER: Mongodb ["
                                + trackerId + "] <= SQL [ "
                                + tracker.getRefId() + " ]");
                    }
                });
    }

    private void applyParameterChanges(DateTime runDate) {
        // NOTE: Subselect avoids duplicate processing of parameters
        //	int categoryId = 59;
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT DISTINCT INDICATOR_ID "
                        + " FROM HEALTH_INDICATOR_PARAMETER "
                        + " WHERE (CREATED_ON >= ? OR UPDATED_ON >= ?)"
                        + " AND INDICATOR_ID IN "
                        + " (SELECT INDICATOR_ID"
                        + " FROM HEALTH_INDICATOR HI, HEALTH_INDICATOR_CAT IC"
                        + " WHERE IC.CATEGORY_ID = HI.CATEGORY_ID "
                        + " AND IC.CATEGORY_NAME = 'Wellness')";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        List<Tracker> trackers = trackerService.findByRefId(rs.getString("INDICATOR_ID"));

                        if (trackers.size() > 0) {
                            Tracker tracker = trackers.get(0);
                            tracker.setParameters(
                                    getHealthTrackerParameters(tracker.getRefId()));

                            String trackerId = saveCategoryToMongodb(tracker);

                            LOGGER.debug("TRACKER (PARAMETERS): Mongodb ["
                                    + trackerId + "] <= SQL [ "
                                    + tracker.getRefId() + " ]");
                        } else
                            LOGGER.warn("Unable to update PARAMETERS for TRACKER with refId: " + rs.getString("INDICATOR_ID"));
                    }
                });
    }

    private String saveCategoryToMongodb(Tracker tracker) {
        if (tracker.getRefId() != null) {
            List<Tracker> existing = trackerService.findByRefId(tracker.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                tracker.setId(existing.get(0).getId());
                tracker.setVersion(existing.get(0).getVersion());
            } else
                tracker.setId(UUID.randomUUID().toString());
        } else
            tracker.setId(UUID.randomUUID().toString());

        return trackerService.save(tracker, false);
    }

    private List<TrackerParameter> getHealthTrackerParameters(String indicatorRefId) {
        final List<TrackerParameter> parms = new ArrayList<TrackerParameter>();

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PARAMETER_ID, PARAMETER_NAME, PARAMETER_DESCRIPTION, "
                        + " MEASUREMENT_UNIT, MAXIMUM_VALUE, MINIMUM_VALUE, "
                        + " PARAMETER_TYPE"
                        + " FROM HEALTH_INDICATOR_PARAMETER "
                        + " WHERE INDICATOR_ID = ?";

        template.query(sql, new Object[]{indicatorRefId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        TrackerParameter parm = TrackerParameterMapper.toParameter(rs);
                        parms.add(parm);
                    }
                });

        return parms;
    }

    @Override
    public void applyRemoteDeletes(DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT INDICATOR_ID "
                        + "FROM HEALTH_INDICATOR "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("INDICATOR_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<Tracker> categories = trackerService.findByRefId(refId);
        if (categories != null && categories.size() > 0)
            trackerService.delete(categories.get(0).getId());
    }
}
