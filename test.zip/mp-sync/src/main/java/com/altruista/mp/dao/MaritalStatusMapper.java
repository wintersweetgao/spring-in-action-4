package com.altruista.mp.dao;

import com.altruista.mp.model.ValidValue;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/25/14.
 */
public class MaritalStatusMapper {
    public static ValidValue toValidValue(ResultSet rs) throws SQLException {
        ValidValue maritalStatus = new ValidValue();
        maritalStatus.setName("MARITAL_STATUS");   // "Table" Name
        maritalStatus.setRefId(rs.getString("MARITAL_STATUS"));
        maritalStatus.setValue(rs.getString("MARITAL_STATUS"));
        maritalStatus.setDescription(rs.getString("MARITAL_DESCRIPTION"));

        return maritalStatus;
    }
}
