package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberContactService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;


public class CareStaffSyncImpl extends BaseSyncImpl implements CareStaffSync {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareStaffSyncImpl.class);

    @Autowired
    private ContactService contactService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private MemberContactService memberContactService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            // sync if either the care team or the care manager has changed
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + " SELECT DISTINCT PP.PATIENT_ID"
                            + " FROM PATIENT_PHYSICIAN PP, CARE_TEAM T, CARE_STAFF_DETAILS S"
                            + " WHERE PP.CARE_TEAM_ID = T.CARE_TEAM_ID"
                            + " AND T.CARE_TEAM_TYPE = 'Internal Care Team'"
                            + " AND PP.PHYSICIAN_ID = S.MEMBER_ID"
                            + " AND (S.CREATED_ON >= :runDate OR S.UPDATED_ON >= :runDate OR PP.CREATED_ON >= :runDate OR PP.UPDATED_ON >= :runDate)"
                            + " UNION"
                            + " SELECT DISTINCT PATIENT_ID"
                            + " FROM MEMBER_CARESTAFF"
                            + " WHERE (CREATED_ON >= :runDate OR UPDATED_ON >= :runDate)"
                            + " AND IS_ACTIVE = 1 AND IS_PRIMARY = 1";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("careStaff");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(final long patientId, final Member member, DateTime runDate) {
        // Per Sridhar on 12/12/2014
        // Care teams for a member records is saved in PATIENT_PHYSICIAN table.
        // Patient physician table saves Providers, Internal, External, PCP and Caregivers.
        // Care team values are differentiated with Care_Team_ID value.
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT MEMBER_ID,TITLE,FIRST_NAME,MIDDLE_NAME,LAST_NAME,PRIMARY_EMAIL,DIRECT_EMAIL,MOBILE_PHONE,FAX, "
                        + "ADDRESS,CITY,STATE,COUNTRY,ZIP,CSD.CREATED_ON,CS.STATUS_NAME, "
                        + "PP.PATIENT_PHYSICIAN_ID, PP.PHYSICIAN_ID, PP.PATIENT_ID, "
                        + "PP.START_DATE, PP.END_DATE, PP.IS_ACTIVE, ISNULL(IS_PCP,0) AS IS_PCP "
                        + "FROM CARE_STAFF_DETAILS CSD, PATIENT_PHYSICIAN PP, CMN_STATUS CS, CARE_TEAM T "
                        + "WHERE PP.PATIENT_ID = ?"
                        + " AND PP.PHYSICIAN_ID = CSD.MEMBER_ID"
                        + " AND PP.CARE_TEAM_ID = T.CARE_TEAM_ID"
                        + " AND T.CARE_TEAM_TYPE = 'Internal Care Team'"
                        + " AND CSD.STATUS_ID = CS.STATUS_ID "
                        + " AND (CSD.CREATED_ON >= ? OR CSD.UPDATED_ON >= ? OR PP.CREATED_ON >= ? OR PP.UPDATED_ON >= ?)";

        template.setFetchSize(fetchsize);    // process 100 rows at a time to minimize memory consumption
        template.query(sql, new Object[]{patientId,
                runDate.toDate(), runDate.toDate(),
                runDate.toDate(), runDate.toDate()}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                // CONTACT
                Contact contact = CareStaffMapper.toContact(rs);

                String contactId = saveCareStaffDetailToMongodb(contact);
                LOGGER.debug("CARE_STAFF_DETAILS: Mongodb [" + contactId + "] <= SQL [" + contact.getRefId() + "]");

                MemberContact mc = new MemberContact(ContactType.CARECOACH);
                mc.setRefId(rs.getString("PATIENT_PHYSICIAN_ID"));

                // Determine if primary care physician
                if (rs.getBoolean("IS_PCP"))
                    mc.setPrimary(true);
                else
                    mc.setPrimary(false);

                // Determine if active
                if (rs.getBoolean("IS_ACTIVE"))
                    mc.setActive(true);
                else
                    mc.setActive(false);

                if (rs.getString("START_DATE") != null) {
                    mc.setStartOn(DateHelper.getDate(rs.getDate("START_DATE")));
                }

                if (rs.getString("END_DATE") != null) {
                    mc.setEndOn(DateHelper.getDate(rs.getDate("END_DATE")));
                }

                // Assign Member Id
                mc.setMemberId(member.getId());

                // Lookup CareCoach Contact Id
                List<Contact> coaches = contactService.findIdByRefIdAndContactType(
                        rs.getString("PHYSICIAN_ID"), ContactType.CARECOACH
                );
                // If CareCoach not found, save the relationship
                if (coaches.size() > 0) {
                    mc.setContactId(coaches.get(0).getId());

                    String mcId = saveMemberContactToMongodb(mc);
                    LOGGER.debug("MEMBER_CARESTAFF: Mongodb [" + mcId + "] <= SQL [" + mc.getRefId() + "]");

                    // if the coach is the primary care manager, update the primary care manager
                    if (isPrimaryCareManager(patientId, rs.getString("PHYSICIAN_ID"))) {
                        String careManagerName;
                        if (coaches.get(0).getFirstName() != null &&
                                coaches.get(0).getLastName() != null) {
                            careManagerName = String.format("%s %s",
                                    coaches.get(0).getFirstName(),
                                    coaches.get(0).getLastName());
                        } else {
                            careManagerName = coaches.get(0).getCompany();
                        }

                        // set the care manager
                        member.setCareManagerId(coaches.get(0).getId());
                        member.setCareManager(careManagerName);
                        memberService.save(member, false);
                    }
                } else {
                    LOGGER.warn("MEMBER_CARESTAFF: CareCoach contact not found for refId=" + rs.getString("PHYSICIAN_ID"));
                }
            }
        });

        applyPrimaryCareManagerChanges(patientId, member, runDate);
    }

    private boolean isPrimaryCareManager(long patientId, String careStaffId) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT IS_PRIMARY "
                        + "FROM MEMBER_CARESTAFF "
                        + "WHERE PATIENT_ID = ? AND MEMBER_ID = ? AND IS_ACTIVE = 1";

        try {
            Boolean isPrimary = template.queryForObject(sql, new Object[]{patientId, careStaffId}, Boolean.class);

            if (isPrimary != null && isPrimary.booleanValue())
                return true;
            else
                return false;
        } catch (EmptyResultDataAccessException e) {
            LOGGER.info("No Care Manager found for patientId: " + patientId + ", careStaffId: " + careStaffId + ", exception: " + e);
            return false;
        }
    }

    private void applyPrimaryCareManagerChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT DISTINCT MEMBER_CARESTAFF_ID,PATIENT_ID,MEMBER_ID,IS_PRIMARY "
                        + "FROM MEMBER_CARESTAFF "
                        + "WHERE (CREATED_ON >= ? OR UPDATED_ON >= ?) "
                        + " AND IS_ACTIVE = 1 AND IS_PRIMARY = 1 "
                        + " AND PATIENT_ID = ? ";

        template.setFetchSize(fetchsize);   // process 100 rows at a time to minimize memory consumption
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {

                // Lookup CareCoach Contact Id
                List<Contact> coaches = contactService.findIdByRefIdAndContactType(
                        rs.getString("MEMBER_ID"), ContactType.CARECOACH
                );
                if (!coaches.isEmpty()) {

                    String careManagerName;
                    if (coaches.get(0).getFirstName() != null &&
                            coaches.get(0).getLastName() != null) {
                        careManagerName = String.format("%s %s",
                                coaches.get(0).getFirstName(),
                                coaches.get(0).getLastName());
                    } else {
                        careManagerName = coaches.get(0).getCompany();
                    }

                    member.setCareManagerId(coaches.get(0).getId());
                    member.setCareManager(careManagerName);
                    memberService.save(member, false);
                } else {
                    LOGGER.warn("MEMBER_CARESTAFF: CareManager contact not found for refId=" + rs.getString("MEMBER_ID"));
                }

            } // processRow
        }); // query
    }

    @Override
    public void applyRemoteDeletes(DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT DISTINCT PATIENT_PHYSICIAN_ID "
                        + "FROM PATIENT_PHYSICIAN PP, CARE_TEAM T "
                        + "WHERE PP.DELETED_ON >= ? "
                        + " AND PP.CARE_TEAM_ID = T.CARE_TEAM_ID "
                        + " AND T.CARE_TEAM_TYPE = 'Internal Care Team'";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        deleteMemberContact(rs.getString("PATIENT_PHYSICIAN_ID"));
                    }
                });
    }

    private void deleteMemberContact(String refId) {
        // Do NOT delete the contact, only the relationship

        // Delete relationship between the member and carecoach
        // Find all relationships for this carecoach
        List<MemberContact> mcs = memberContactService.findIdByRefIdAndContactType(refId,
                ContactType.CARECOACH);
        if (mcs != null && mcs.size() > 0) {
            memberContactService.delete(mcs.get(0).getId());
            LOGGER.debug("CARE_STAFF_DETAILS: Deleting MemberContact: " + mcs.get(0).getId());
        }
    }

    private String saveCareStaffDetailToMongodb(Contact contact) {
        // see if contact already exists
        if (contact.getRefId() != null) {
            List<Contact> existing = contactService.findIdByRefIdAndContactType(contact.getRefId(), ContactType.CARECOACH);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                contact.setId(existing.get(0).getId());
                contact.setVersion(existing.get(0).getVersion());
            } else
                contact.setId(UUID.randomUUID().toString());
        } else
            contact.setId(UUID.randomUUID().toString());
/*
        // IMPORTANT: set sync time to avoid sending it back to SQL
        contact.setSyncedOn(DateTime.now());
        contactService.setSyncEnabled(false);*/

        return contactService.save(contact, false);
    }

    private String saveMemberContactToMongodb(MemberContact mc) {
        // see if contact already exists
        if (mc.getRefId() != null) {
            List<MemberContact> existing = memberContactService.findIdByRefIdAndContactType(mc.getRefId(), ContactType.CARECOACH);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                mc.setId(existing.get(0).getId());
                mc.setVersion(existing.get(0).getVersion());
            } else
                mc.setId(UUID.randomUUID().toString());
        } else
            mc.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        mc.setSyncedOn(DateTime.now());
        memberContactService.setSyncEnabled(false);*/

        return memberContactService.save(mc, false);
    }

}
