package com.altruista.mp.dao;

import com.altruista.mp.model.User;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 8/4/14.
 */
public class UserMapper {
    public static User toUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setRefId(rs.getString("PATIENT_ID"));

        return user;
    }
}
