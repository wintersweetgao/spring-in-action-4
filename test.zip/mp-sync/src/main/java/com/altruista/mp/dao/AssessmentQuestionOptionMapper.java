package com.altruista.mp.dao;

import com.altruista.mp.model.AssessmentQuestionOption;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 4/21/15.
 */
public class AssessmentQuestionOptionMapper implements RowMapper<AssessmentQuestionOption> {
    public AssessmentQuestionOption mapRow(ResultSet rs, int rowNum) throws SQLException {

        AssessmentQuestionOption option = new AssessmentQuestionOption();
        option.setRefId(rs.getString("QUESTION_OPTION_ID"));
        option.setNextQuestionRefId(rs.getString("QUESTION_NEXT"));
        option.setOptionText(rs.getString("QUESTION_OPTION"));
        option.setOptionType(rs.getString("OPTION_TYPE"));
        option.setSequence(rs.getInt("OPTION_NO"));

        return option;
    }
}