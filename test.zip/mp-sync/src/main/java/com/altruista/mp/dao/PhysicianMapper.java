package com.altruista.mp.dao;

import com.altruista.mp.model.Address;
import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PhysicianMapper {
    public static Contact toContact(ResultSet rs, boolean hasAddressText) throws SQLException {
        Contact contact = new Contact();
        contact.setRefId(rs.getString("PHYSICIAN_ID"));
        contact.setContactCode(rs.getString("PHYSICIAN_CODE"));
        contact.setSalutation(rs.getString("NAME_PREFIX"));
        contact.setFirstName(rs.getString("FIRST_NAME"));
        contact.setMiddleName(rs.getString("MIDDLE_NAME"));
        contact.setLastName(rs.getString("LAST_NAME"));
        contact.setPhoneNumber(rs.getString("WORK_PHONE"));
        contact.setNameSuffix(rs.getString("NAME_SUFFIX"));
        contact.setDaytimePhoneNumber(rs.getString("WORK_PHONE"));
        contact.setEveningPhoneNumber(rs.getString("HOME_PHONE"));
        contact.setMobilePhoneNumber(rs.getString("CELL_PHONE"));
        contact.setGender(rs.getString("GENDER"));
        contact.setPrimaryEmail(rs.getString("EMAIL"));
        contact.setDirectEmail(rs.getString("DIRECT_EMAIL"));
        contact.setFaxNumber(rs.getString("FAX"));
        contact.setPrimaryLanguage(rs.getString("PRIMARY_LANGUAGE"));
        contact.setEthnicity(rs.getString("ETHNICITY_ID"));
        contact.setCompany(rs.getString("PROVIDER_NAME"));
        contact.setStatus(rs.getString("STATUS"));
        contact.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        Address address = new Address();
        if (rs.getString("ADDRESS") != null)
            address.setAddress(rs.getString("ADDRESS"));
        else if (hasAddressText)
            address.setAddress(rs.getString("ADDRESS_TEXT"));

        address.setCity(rs.getString("CITY"));
        address.setStateProvince(rs.getString("STATE"));
        address.setCountry(rs.getString("COUNTRY"));
        address.setPostalCode(rs.getString("ZIP"));
        contact.setAddress(address);

        // FOR PHYSICIAN
        contact.setContactType(ContactType.PHYSICIAN);

        return contact;
    }
}
