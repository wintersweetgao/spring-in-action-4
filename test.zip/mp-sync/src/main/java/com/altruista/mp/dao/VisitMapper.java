package com.altruista.mp.dao;

import com.altruista.mp.model.Visit;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;


public class VisitMapper {

    public static Visit toVisit(ResultSet rs) throws SQLException {
        Visit visit = new Visit();

        // The VISIT_SOURCE_TYPE table is not populated in GC?
        // Manually assign values
        String sourceType = rs.getString("SOURCE_TYPE");
        if (sourceType.equalsIgnoreCase("MC"))
            visit.setSource("Medical Claim");
        else if (sourceType.equalsIgnoreCase("PC"))
            visit.setSource("Pharmacy Claim");
        else
            visit.setSource("Unclassified");

        visit.setRefId(rs.getString("PATIENT_VISIT_ID"));
        visit.setReason(rs.getString("VISIT_REASON"));
        visit.setVisitType(rs.getString("VISIT_TYPE_NAME"));
        visit.setVisitOn(DateHelper.getDate(rs.getDate("VISIT_DATE")));
        visit.setProviderName(rs.getString("PROVIDER_NAME"));
        visit.setPaidAmount(rs.getFloat("AMOUNT_PAID"));
        visit.setStatus(rs.getString("PROCESSING_STATUS"));
        visit.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return visit;
    }
}
