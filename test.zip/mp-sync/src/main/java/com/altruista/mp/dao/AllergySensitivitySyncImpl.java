package com.altruista.mp.dao;

import com.altruista.mp.model.AllergySensitivity;
import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.AllergySensitivityService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class AllergySensitivitySyncImpl extends BaseSyncImpl implements AllergySensitivitySync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(AllergySensitivitySyncImpl.class);

    @Autowired
    private AllergySensitivityService allergyService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT PATIENT_ID "
                            + "FROM ALLERGY_SENSITIVITY "
                            + "WHERE (CREATED_ON >= :runDate OR UPDATED_ON >= :runDate)";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("allergySensitivity");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT DISTINCT ALLERGY_ID, PATIENT_ID, MEDICATION_CODE, DESCRIPTION, CREATED_ON "
                        + "FROM ALLERGY_SENSITIVITY "
                        + "WHERE (CREATED_ON >= ? OR UPDATED_ON >= ?) "
                        + " AND PATIENT_ID = ? ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(member, rs);
                    }
                });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        AllergySensitivity allergy = AllergySensitivityMapper.toAllergySensitivity(rs);
        allergy.setMemberId(member.getId());

        // Save the ALLERGY
        String allergyId = saveAllergySensitivityToMongodb(allergy);

        LOGGER.debug("ALLERGY: Mongodb ["
                + allergyId + "] <= SQL [ "
                + allergy.getRefId() + " ]");
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT ALLERGY_ID "
                        + "FROM ALLERGY_SENSITIVITY "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("ALLERGY_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<AllergySensitivity> allergies = allergyService.findIdByRefId(refId);
        if (allergies != null && !allergies.isEmpty())
            allergyService.delete(allergies.get(0).getId());
    }

    private String saveAllergySensitivityToMongodb(AllergySensitivity allergy) {
        if (allergy.getRefId() != null) {
            List<AllergySensitivity> existing = allergyService.findIdByRefId(allergy.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                allergy.setId(existing.get(0).getId());
                allergy.setVersion(existing.get(0).getVersion());
            } else
                allergy.setId(UUID.randomUUID().toString());
        } else
            allergy.setId(UUID.randomUUID().toString());

        return allergyService.save(allergy, false);
    }

}
