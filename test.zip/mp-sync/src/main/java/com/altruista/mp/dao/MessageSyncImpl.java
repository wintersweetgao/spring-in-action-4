package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.MessageService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class MessageSyncImpl extends BaseSyncImpl implements MessageSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MessageSyncImpl.class);

    public static final String DATE_PATTERN = "MM/dd/yyyy";

    @Value("${guidingCare.timezone}")
    private String gcTimezone;

    @Autowired
    private MessageService messageService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private ContactService contactService;
    @Autowired
    private SyncLogService syncLogService;

    private String memberRefId;
    HashMap<String, String> contactTypes = null;
    HashMap<String, String> careTeamTypes = null;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + " SELECT DISTINCT ST.SENT_TO "
                            + " FROM MP_MEMBER_SENTTO_DETAILS ST, MP_MEMBER_MA_TYPE MTT "
                            + " WHERE MTT.SENT_TYPE = 'member'"
                            + " AND ST.TYPE_ID = MTT.SENT_TYPE_ID"
                            + " AND ST.MESSAGE_ID IN"
                            + " (SELECT SF.MESSAGE_ID "
                            + " FROM MP_MEMBER_SENTFROM_DETAILS SF, MP_MEMBER_MA_TYPE MT "
                            + " WHERE (SF.CREATED_ON >= :runDate OR SF.UPDATED_ON >= :runDate) "
                            + " AND SF.SENT_TYPE_ID = MT.SENT_TYPE_ID AND MT.SENT_TYPE != 'Care Giver')";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("message");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        // AHMEMBER-579 - Avoid duplicating sent messages
        // Messages sent from MP->GC were coming back to MP as duplicates
        // by only retrieving messages SENT_TO members (not FROM members)

        // AHMEMBER-650 Message:Messages received from Caregiver appears twice
        // added criteria to exclude messages sent by Care Givers SENT_TYPE != 'Caregiver'

        JdbcTemplate toTemplate = new JdbcTemplate(dataSource);
        String toSql =
                " SELECT SF.MESSAGE_ID,SF.MESSAGE_SUBJECT,SF.MESSAGE_CONTENT, "
                        + " SF.DATE_SENT, SF.IS_DIRECT, "
                        + " SF.SENT_FROM, MT.SENT_TYPE, "
                        + " SF.CREATED_ON, SF.CARE_TEAM_ID "
                        + " FROM MP_MEMBER_SENTFROM_DETAILS SF,MP_MEMBER_MA_TYPE MT "
                        + " WHERE (SF.CREATED_ON >= ? OR SF.UPDATED_ON >= ?) "
                        + " AND SF.SENT_TYPE_ID = MT.SENT_TYPE_ID AND MT.SENT_TYPE != 'Care Giver'"
                        + " AND SF.MESSAGE_ID IN "
                        + " (SELECT MESSAGE_ID "
                        + " FROM MP_MEMBER_SENTTO_DETAILS ST, MP_MEMBER_MA_TYPE MTT "
                        + " WHERE MTT.SENT_TYPE = 'member' AND ST.SENT_TO = ?"
                        + " AND ST.TYPE_ID = MTT.SENT_TYPE_ID)";

        toTemplate.setFetchSize(fetchsize); // process 100 rows at a time
        toTemplate.query(toSql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(rs);
                    }
                });
    }

    private void postChanges(ResultSet rs) throws SQLException {

        Message message = MessageMapper.toMessage(gcTimezone, rs);
        String gcMessageId = rs.getString("MESSAGE_ID");
        memberRefId = null;

        String sentFromType = rs.getString("SENT_TYPE");
        ContactType senderType = null;
        if (sentFromType == null)
            senderType = null;
        else if (sentFromType.equalsIgnoreCase("Care Team"))
            senderType = ContactType.CARECOACH;
        else if (sentFromType.equalsIgnoreCase("Provider"))
            senderType = ContactType.PHYSICIAN;
        else if (sentFromType.equalsIgnoreCase("Care Giver"))
            senderType = ContactType.CAREGIVER;
        else if (sentFromType.equalsIgnoreCase("member")) {
            senderType = ContactType.MEMBER;
            memberRefId = rs.getString("SENT_FROM");
        }

        if (senderType != null) {
            // Convert Sender RefId to Contact Id
            List<Contact> sender = contactService.findByRefIdAndContactType(rs
                    .getString("SENT_FROM"), senderType);

            if (sender != null && sender.size() > 0) {
                message.setSenderId(sender.get(0).getId());


                // Find recipients and attach as Contact Ids
                message.setRecipientIds(getRecipientIds(gcMessageId));

                // Set the memberId for this message
                List<Member> members = memberService.findIdByRefId(memberRefId);
                if (members != null && members.size() > 0) {
                    message.setMemberId(members.get(0).getId());
                }

                // Save the Messages
                String messageId = saveMessageToMongodb(message);

                LOGGER.debug("MESSAGE: Mongodb ["
                        + messageId + "] <= SQL [ "
                        + message.getRefId() + " ]");
            } else {
                LOGGER.error("Unknown Sender RefId: " + rs.getString("SENT_FROM") + " for GC message: " + gcMessageId);
            }
        } else {
            LOGGER.error("Unsupported Sender Type: " + sentFromType + " for GC message: " + gcMessageId);
        }
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT MESSAGE_ID "
                        + "FROM MP_MEMBER_SENTFROM_DETAILS "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("MESSAGE_ID"));
                    }
                });
    }

    private List<String> getRecipientIds(String messageId) {
        final List<String> recipientIds = new ArrayList<String>();

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql = " SELECT ST.MESSAGE_ID, ST.SENT_TO, MT.SENT_TYPE "
                + " FROM MP_MEMBER_SENTTO_DETAILS ST, MP_MEMBER_MA_TYPE MT "
                + " WHERE ST.MESSAGE_ID = ? "
                + " AND ST.TYPE_ID = MT.SENT_TYPE_ID";
        template.query(sql, new Object[]{messageId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        String gcMessageId = rs.getString("MESSAGE_ID");

                        String sentToType = rs.getString("SENT_TYPE");
                        ContactType recipientType = null;
                        if (sentToType == null)
                            recipientType = null;
                        else if (sentToType.equalsIgnoreCase("Care Team"))
                            recipientType = ContactType.CARECOACH;
                        else if (sentToType.equalsIgnoreCase("Provider"))
                            recipientType = ContactType.PHYSICIAN;
                        else if (sentToType.equalsIgnoreCase("Care Giver"))
                            recipientType = ContactType.CAREGIVER;
                        else if (sentToType.equalsIgnoreCase("member")) {
                            recipientType = ContactType.MEMBER;
                            memberRefId = rs.getString("SENT_TO");
                        }

                        if (recipientType != null) {
                            String sentTo = rs.getString("SENT_TO");
                            List<Contact> recipient = contactService.findIdByRefIdAndContactType(sentTo, recipientType);

                            if (recipient != null && recipient.size() > 0) {
                                recipientIds.add(recipient.get(0).getId());
                            }
                        } else {
                            LOGGER.error("Unsupported Recipient Type: " + sentToType + " for GC message: " + gcMessageId);
                        }
                    }
                });

        return recipientIds;
    }

    private void delete(String refId) {
        List<Message> msgs = messageService.findIdByRefId(refId);
        if (msgs != null && msgs.size() > 0)
            messageService.delete(msgs.get(0).getId());
    }

    private String saveMessageToMongodb(Message message) {
        if (message.getRefId() != null) {
            List<Message> existing = messageService.findIdByRefId(message.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                message.setId(existing.get(0).getId());
                message.setVersion(existing.get(0).getVersion());
            } else
                message.setId(UUID.randomUUID().toString());
        } else
            message.setId(UUID.randomUUID().toString());

        return messageService.save(message, false);
    }

    public void applyLocalChanges(DateTime runDate) {
        List<Message> messages = messageService.findMessageIdsToSync();
        for (Message id : messages) {
            Message message = messageService.get(id.getId());
            saveMessageToSQL(message);
        }
    }


    private void saveMessageToSQL(Message message) {
        if (message.getRefId() == null || message.getRefId().length() == 0) {
            LOGGER.debug("Adding message to SQL");

            try {
                // Lookup the Sender's refId and refType
                Contact sender = contactService.get(message.getSenderId());
                if (sender.getRefId() == null || sender.getRefId().length() == 0) {
                    LOGGER.error("Sender contact is missing refId, unable to save to SQL: " + sender.getId());

                    messageService.save(message, false);

                    return;
                } else {
                    LOGGER.debug("Saving Message to SQL: " + message.getId());
                }

                Long senderId = Long.parseLong(sender.getRefId());
                int senderTypeId = getContactTypeId(sender.getContactType());

                // Per Giri's email on 11/21/14, use 4 for caregiver, 0 otherwise
                int senderCareTeamId = 0;
                if (sender.getContactType() == ContactType.CAREGIVER)
                    senderCareTeamId = 4;

                int sourceTypeId = 2;   // TODO: Use Lookup (2 = Member Portal)

                // Direct Message Support requires overriding Sender Information:
                Boolean isDirect = null;
                Boolean isCCDA = null;
                String directEmail = null;
                Boolean sentMsg = false;
                Boolean sentStatus = null;

                // override message sent from id with the care manager's id for ALL direct messages
                Member member = memberService.get(message.getMemberId());

                // get the patient Id for the message
                Long patientId = null;
                if (member != null) {
                    patientId = Long.parseLong(member.getRefId());
                }

                if (message.getMessageType() == MessageType.DIRECT) {
                    isDirect = true;

                    if (message.getHealthSummary() != null && message.getHealthSummary() != HealthSummaryType.NONE)
                        isCCDA = true;

                    // override sender care team id (TODO: Verify this)
                    senderCareTeamId = 0;
                    sentStatus = false;

                    // override sender type id
                    senderTypeId = getContactTypeId(ContactType.CARECOACH);

                    // override message sent from id with the care manager's id for ALL direct messages
                    if (member != null) {
                        Contact careManager = contactService.get(member.getCareManagerId());
                        if (careManager != null) {
                            senderId = Long.parseLong(careManager.getRefId());
                            directEmail = careManager.getDirectEmail();
                        } else
                            LOGGER.warn("Unable to find care manager contact by refId: " + member.getCareManagerId());
                    } else
                        LOGGER.warn("Unable to find member for message by memberId: " + message.getMemberId());
                }

                String fromSql = "INSERT INTO MP_MEMBER_SENTFROM_DETAILS (" +
                        " MESSAGE_SUBJECT, MESSAGE_CONTENT, SENT_FROM, SENT_TYPE_ID, CARE_TEAM_ID, DATE_SENT, CREATED_ON, IS_DIRECT, IS_CCDA, DIRECT_EMAIL, SOURCE_TYPE_ID, SENT_MSG, SENT_STATUS, PATIENT_ID)" +
                        " VALUES ( :subject, :content, :sentFrom, :sentTypeId, :careTeamId, :dateSent, :createdOn, :isDirect, :isCCDA, :directEmail, :sourceTypeId, :sentMsg, :sentStatus, :patientId)";

                KeyHolder fromKeyHolder = new GeneratedKeyHolder();
                NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
                SqlParameterSource fromNamedParameters = new MapSqlParameterSource("subject", message.getSubject())
                        .addValue("content", message.getBody())
                        .addValue("sentFrom", senderId)
                        .addValue("sentTypeId", senderTypeId)
                        .addValue("careTeamId", senderCareTeamId)
                        .addValue("dateSent", new java.sql.Timestamp(message.getSentOn().getMillis()))
                        .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                        .addValue("isDirect", isDirect)
                        .addValue("isCCDA", isCCDA)
                        .addValue("directEmail", directEmail)
                        .addValue("sourceTypeId", sourceTypeId)
                        .addValue("sentMsg", sentMsg)
                        .addValue("sentStatus", sentStatus)
                        .addValue("patientId", patientId);
                //	.addValue("isProcessed", isProcessed)
                //	.addValue("msgControlId", msgControlId)


                toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

                LOGGER.debug("MESSAGE: MP_MEMBER_SENTFROM_DETAILS: Mongodb [" + message.getId()
                        + "] => SQL [" + fromKeyHolder.getKey() + "]");

                Number messageId = fromKeyHolder.getKey();

                // update the main thread id (as required by G7)
                String fromUpdateSql =
                        "UPDATE MP_MEMBER_SENTFROM_DETAILS " +
                                " SET MAIN_THREAD_ID = :threadId " +
                                " WHERE MESSAGE_ID = :messageId";
                NamedParameterJdbcTemplate fromUpdateTemplate = new NamedParameterJdbcTemplate(dataSource);
                SqlParameterSource fromUpdateNamedParameters =
                        new MapSqlParameterSource("threadId", messageId.intValue())
                                .addValue("messageId", messageId.intValue());
                fromUpdateTemplate.update(fromUpdateSql, fromUpdateNamedParameters);

                addAttachment(messageId.intValue(), message);

                // add recipients
                for (String recipId : message.getRecipientIds()) {
                    // Lookup the Recipient's refId and refType
                    Contact recipient = contactService.get(recipId);
                    if (recipient.getRefId() == null || recipient.getRefId().length() == 0) {
                        LOGGER.error("Recipient contact is missing refId, unable to save to SQL: " + recipient.getId());
                        continue;
                    }

                    Long recipientId = Long.parseLong(recipient.getRefId());
                    int recipientTypeId = getContactTypeId(recipient.getContactType());
                    int careTeamId = getCareTeamId(recipient.getContactType());

                    String toSql = "INSERT INTO MP_MEMBER_SENTTO_DETAILS (" +
                            " SENT_TO, TYPE_ID, MESSAGE_ID, CARE_TEAM_ID, DIRECT_EMAIL, CREATED_ON)" +
                            " VALUES ( :sentTo, :sentToType, :messageId, :careTeamId, :directEmail, :createdOn )";
                    KeyHolder toKeyHolder = new GeneratedKeyHolder();
                    SqlParameterSource toNamedParameters =
                            new MapSqlParameterSource("sentTo", recipientId)
                                    .addValue("sentToType", recipientTypeId)
                                    .addValue("messageId", messageId.intValue())
                                    .addValue("careTeamId", careTeamId)
                                    .addValue("directEmail", recipient.getDirectEmail())
                                    .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()));
                    toTemplate.update(toSql, toNamedParameters, toKeyHolder);

                    messageService.save(message, false);

                    LOGGER.debug("MESSAGE: MP_MEMBER_SENTTO_DETAILS [" + message.getId() + "] => SQL [" + toKeyHolder.getKey() + "]");
                }
            } catch (Exception exc) {

                messageService.save(message, false);

                SyncLog sl = new SyncLog();
                sl.setLevel(SyncLogLevelType.ERROR);
                sl.setObjectName("message");
                sl.setObjectId(message.getId());
                sl.setAction("saveMessageToSQL");
                sl.setDescription("Unable to insert into MP_MEMBER_SENTXXXX_DETAILS for message: " + message.getId());
                syncLogService.save(sl);

                LOGGER.error(sl.getDescription() + ", exception: " + exc);
            }

        } else {
            LOGGER.debug("Message updates are not supported for message: " + message.getId());

            messageService.save(message, false);
        }
    }

    /*
     *  This code will be adding an DIRECT attachments with start date and
     *  depending and end date value
     *  type of HealthSummary
     */
    private void addAttachment(int messageId, Message message) {
        String startDate = null;
        String endDate = null;
        int attachmentTypeID = 1;   // TODO: Replace hard coded value with table lookup

        DateTimeFormatter jodaFormatter = DateTimeFormat.forPattern(DATE_PATTERN);

        HealthSummaryType healthSummary = message.getHealthSummary();
        if (healthSummary != null) {
            switch (healthSummary) {
                case YEAR_TO_DATE:
                    /** get the first day of the relative year */
                    startDate = jodaFormatter.print(new LocalDate().dayOfYear().withMinimumValue());
                    endDate = jodaFormatter.print(DateTime.now());
                    LOGGER.debug("YEAR_TO_DATE ==> START_DT : " + startDate + ", END_DATE : " + endDate);
                    break;

                case LAST_TWO_YEARS:
                    startDate = jodaFormatter.print(DateTime.now());
                    endDate = jodaFormatter.print(DateTime.now().minusYears(2));
                    LOGGER.debug("LAST_TWO_YEARS ==> START_DT : " + startDate + ", END_DATE : " + endDate);
                    break;

                case FULL_HISTORY:
                    break;

                case NONE:
                default:
                    return; // Do not create attachment if Health Summary Type is None
            }
        }

        String messageAttachmentSql = "INSERT INTO MP_MEMBER_MESSAGE_ATTACHMENTS (" +
                " START_DATE, END_DATE, MESSAGE_ID, ATTACHMENT_TYPE_ID, CREATED_ON) VALUES (:startDate, :endDate, :messageId, :attachmentTypeId, :createdOn)";

        KeyHolder messageKeyHolder = new GeneratedKeyHolder();
        NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
        SqlParameterSource tomessageNamedParameters =
                new MapSqlParameterSource()
                        .addValue("messageId", messageId)
                        .addValue("attachmentTypeId", attachmentTypeID)
                        .addValue("startDate", startDate)
                        .addValue("endDate", endDate)
                        .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()));

        toTemplate.update(messageAttachmentSql, tomessageNamedParameters, messageKeyHolder);
    }


    private int getContactTypeId(ContactType contactType) {

        if (contactTypes == null) {
            String sql = "SELECT SENT_TYPE, SENT_TYPE_ID FROM MP_MEMBER_MA_TYPE";
            NamedParameterJdbcTemplate ctTemplate = new NamedParameterJdbcTemplate(dataSource);
            Map<String, String> parms = new HashMap<String, String>();
            List<Map<String, Object>> list = ctTemplate.queryForList(sql, parms);

            contactTypes = new HashMap<String, String>();
            for (Map<String, Object> map : list) {
                contactTypes.put(map.get("SENT_TYPE").toString(), map.get("SENT_TYPE_ID").toString());
            }
        }

        //        1	member
        //        2	Care Team
        //        3	Provider
        //        4	Care Giver
        //        5	Care Team

        String sentType = "MEMBER"; // default
        if (contactType == ContactType.MEMBER)
            sentType = "MEMBER";
        else if (contactType == ContactType.CARECOACH)
            sentType = "Care Team";
        else if (contactType == ContactType.PHYSICIAN)
            sentType = "Provider";
        else if (contactType == ContactType.CAREGIVER)
            sentType = "Care Giver";

        int contactTypeId = 1; // default to one
        if (contactTypes.containsKey(sentType))
            contactTypeId = Integer.parseInt(contactTypes.get(sentType));
        else
            LOGGER.warn("Invalid contact type: " + sentType);

        return contactTypeId;
    }

    private int getCareTeamId(ContactType contactType) {

        if (careTeamTypes == null) {
            String sql = "SELECT CARE_TEAM_TYPE, CARE_TEAM_ID FROM CARE_TEAM";
            NamedParameterJdbcTemplate ctTemplate = new NamedParameterJdbcTemplate(dataSource);
            Map<String, String> parms = new HashMap<String, String>();
            List<Map<String, Object>> list = ctTemplate.queryForList(sql, parms);

            careTeamTypes = new HashMap<String, String>();
            for (Map<String, Object> map : list) {
                careTeamTypes.put(map.get("CARE_TEAM_TYPE").toString(), map.get("CARE_TEAM_ID").toString());
            }
        }

        //        1	Internal Care Team
        //        2	External Care Team
        //        3	Provider
        //        4	Caregiver
        //        5	PCP History

        String careTeamType = "Internal Care Team"; // default
        if (contactType == ContactType.MEMBER)
            careTeamType = "Internal Care Team";
        else if (contactType == ContactType.CARECOACH)
            careTeamType = "Internal Care Team";
        else if (contactType == ContactType.PHYSICIAN)
            careTeamType = "Provider";
        else if (contactType == ContactType.CAREGIVER)
            careTeamType = "Caregiver";

        int careTeamId = 1; // default to one
        if (careTeamTypes.containsKey(careTeamType))
            careTeamId = Integer.parseInt(careTeamTypes.get(careTeamType));
        else
            LOGGER.warn("Invalid care team type: " + careTeamType);

        return careTeamId;
    }
}