package com.altruista.mp.dao;

import com.altruista.mp.model.ValidValue;
import com.altruista.mp.services.ValidValueService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class ValidValuesSyncImpl extends BaseSyncImpl implements ValidValuesSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ValidValuesSync.class);

    @Autowired
    private ValidValueService validValueService;

    @Override
    public void applyRemoteChanges(final DateTime runDate) {
        loadLanguages(runDate);
    }

    private void loadLanguages(final DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT LANGUAGE_ID, LANGUAGE_NAME, LANGUAGE_CODE, DESCRIPTION, CREATED_ON "
                        + " FROM LANGUAGE WHERE CREATED_ON >= ? OR UPDATED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        ValidValue language = LanguageMapper.toValidValue(rs);

                        String languageId = saveValidValueToMongodb(language);

                        LOGGER.debug("LANGUAGE: Mongodb ["
                                + languageId + "] <= SQL [ "
                                + language.getRefId() + " ]");
                    }
                });
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {
        deleteLanguages(runDate);
    }

    private void deleteLanguages(final DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT LANGUAGE_ID "
                        + "FROM LANGUAGE "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete("LANGUAGE", rs.getString("LANGUAGE_ID"));
                    }
                });
    }

    private void delete(String name, String refId) {
        List<ValidValue> values = validValueService.findByNameAndRefId(name, refId);
        if (values != null && values.size() > 0)
            validValueService.delete(values.get(0).getId());
    }

    private String saveValidValueToMongodb(ValidValue value) {
        List<ValidValue> existing;
        if (value.getRefId() != null) {
            existing = validValueService.findByNameAndRefId(value.getName(), value.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                value.setId(existing.get(0).getId());
                value.setVersion(existing.get(0).getVersion());
            } else
                value.setId(UUID.randomUUID().toString());
        } else
            value.setId(UUID.randomUUID().toString());

        return validValueService.save(value, false);
    }

    @Override
    public void loadStaticData() {
        loadEthnicity();
        loadMaritalStatus();
        loadGender();
        loadTaskStatus();
    }

    private void loadEthnicity() {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT ETHNICITY_ID, ETHNICITY "
                        + " FROM ETHNICITY";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        ValidValue ethnicity = EthnicityMapper.toValidValue(rs);

                        String ethnicityId = saveValidValueToMongodb(ethnicity);

                        LOGGER.debug("ETHNICITY: Mongodb ["
                                + ethnicityId + "] <= SQL [ "
                                + ethnicity.getRefId() + " ]");
                    }
                });
    }

    private void loadMaritalStatus() {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT MARITAL_STATUS, MARITAL_DESCRIPTION "
                        + " FROM PATIENT_MARITAL_STATUS";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        ValidValue maritalStatus = MaritalStatusMapper.toValidValue(rs);

                        String maritalStatusId = saveValidValueToMongodb(maritalStatus);

                        LOGGER.debug("MARITAL_STATUS: Mongodb ["
                                + maritalStatusId + "] <= SQL [ "
                                + maritalStatus.getRefId() + " ]");
                    }
                });
    }

    private void loadGender() {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT GENDER, NAME "
                        + " FROM GENDER";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        ValidValue gender = GenderMapper.toValidValue(rs);

                        String genderId = saveValidValueToMongodb(gender);

                        LOGGER.debug("GENDER: Mongodb ["
                                + genderId + "] <= SQL [ "
                                + gender.getRefId() + " ]");
                    }
                });
    }

    private void loadTaskStatus() {
        LOGGER.debug("BEGIN LOADING STATUSES");

        ValidValue v;
        v = new ValidValue("RQ", "TASK_STATUS", "Requested", "Requested");
        validValueService.save(v, false);
        v = new ValidValue("AP", "TASK_STATUS", "Approved", "Approved");
        validValueService.save(v, false);
        v = new ValidValue("CL", "TASK_STATUS", "Canceled", "Canceled");
        validValueService.save(v, false);
        v = new ValidValue("RJ", "TASK_STATUS", "Rejected", "Rejected");
        validValueService.save(v, false);

        LOGGER.debug("END LOADING STATUSES");
    }
}
