package com.altruista.mp.dao;

import org.springframework.beans.factory.annotation.Autowired;

import javax.sql.DataSource;

/**
 * Created by mwixson on 12/26/14.
 */
public class BaseSyncImpl implements BaseSync {
    @Autowired
    protected DataSource dataSource;
    protected Integer fetchsize = null;

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Integer getFetchsize() {
        return fetchsize;
    }

    public void setFetchsize(Integer fetchsize) {
        this.fetchsize = fetchsize;
    }
}
