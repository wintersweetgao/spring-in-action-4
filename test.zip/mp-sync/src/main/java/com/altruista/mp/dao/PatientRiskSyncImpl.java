package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by mwixson on 10/17/14.
 */
public class PatientRiskSyncImpl extends BaseSyncImpl implements PatientRiskSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(PatientRiskSyncImpl.class);

    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT PATIENT_ID "
                            + " FROM PATIENT_RISK PR, RISK_CATEGORY RC, RISK_TYPE RT "
                            + " WHERE PR.RISK_CATEGORY_ID = RC.RISK_CATEGORY_ID "
                            + " AND RC.RISK_TYPE_ID = RT.RISK_TYPE_ID "
                            + " AND LABEL IS NULL "
                            + " AND (PR.CREATED_ON >= :runDate OR PR.UPDATED_ON >= :runDate) ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("patientRisk");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        LOGGER.debug("PATIENT_RISK: Applying remote changes for date:" + runDate);

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PATIENT_ID, PATIENT_RISK_ID, RISK_CATEGORY_NAME, RISK_SCORE "
                        + " FROM PATIENT_RISK PR, RISK_CATEGORY RC, RISK_TYPE RT "
                        + " WHERE PR.RISK_CATEGORY_ID = RC.RISK_CATEGORY_ID "
                        + " AND RC.RISK_TYPE_ID = RT.RISK_TYPE_ID "
                        + " AND LABEL IS NULL "
                        + " AND (PR.CREATED_ON >= ? OR PR.UPDATED_ON >= ?) "
                        + " AND PATIENT_ID = ? "
                        + " ORDER BY PR.PATIENT_RISK_ID";   // process in order

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(rs);
                    }
                });
    }

    private void postChanges(ResultSet rs) throws SQLException {

        String refId = rs.getString("PATIENT_ID");
        LOGGER.debug("PATIENT_RISK: Processing for refId:" + refId);

        float riskScore = rs.getFloat("RISK_SCORE");
        String riskLevel = rs.getString("RISK_CATEGORY_NAME");

        List<Member> members = memberService.findByRefId(refId);

        if (members != null && members.size() > 0) {
            Member updated = members.get(0);
            updated.setRiskLevel(riskLevel);
            updated.setRiskScore(riskScore);
            String memberId = memberService.save(updated, false);

            LOGGER.debug("PATIENT_RISK: Mongodb ["
                    + memberId + "] <= SQL [ "
                    + refId + " ]");
        } else
            LOGGER.debug("PATIENT_RISK: Member not found for refId:" + refId);
    }
}