package com.altruista.mp.dao;

import org.joda.time.DateTime;

public interface EnrollmentSync extends BaseSync {
    void applyLocalChanges(DateTime runDate);
}
