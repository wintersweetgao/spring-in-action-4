package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import org.joda.time.DateTime;

/**
 * Created by mwixson on 10/17/14.
 */
public interface PatientRiskSync extends BaseSync {
    void loadPatientIds(DateTime runDate);

    void applyRemoteChanges(long patientId, final Member member, DateTime runDate);
}