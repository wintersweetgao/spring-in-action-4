package com.altruista.mp.dao;

import com.altruista.mp.model.TrackerCategory;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerCategoryMapper {
    public static TrackerCategory toCategory(ResultSet rs) throws SQLException {
        //CATEGORY_ID, CATEGORY_NAME, CATEGORY_ACCESS, CREATED_ON

        TrackerCategory category = new TrackerCategory();
        category.setName(rs.getString("CATEGORY_NAME"));
        category.setRefId(rs.getString("CATEGORY_ID"));
        category.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));
        if (rs.getString("CATEGORY_ACCESS") != null && !rs.getString("CATEGORY_ACCESS").equalsIgnoreCase("Read/Write"))
            category.setReadOnly(true);
        else
            category.setReadOnly(false);

        return category;
    }
}
