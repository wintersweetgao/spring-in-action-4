package com.altruista.mp.dao;

import com.altruista.mp.model.Address;
import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CareStaffMapper {
    public static Contact toContact(ResultSet rs) throws SQLException {
        Contact contact = new Contact();

        contact.setRefId(rs.getString("MEMBER_ID"));
        contact.setTitle(rs.getString("TITLE"));
        contact.setFirstName(rs.getString("FIRST_NAME"));
        contact.setMiddleName(rs.getString("MIDDLE_NAME"));
        contact.setLastName(rs.getString("LAST_NAME"));
        contact.setMobilePhoneNumber(rs.getString("MOBILE_PHONE"));
        contact.setFaxNumber(rs.getString("FAX"));
        contact.setPrimaryEmail(rs.getString("PRIMARY_EMAIL"));
        contact.setDirectEmail(rs.getString("DIRECT_EMAIL"));
        contact.setStatus(rs.getString("STATUS_NAME"));
        contact.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        Address address = new Address();
        address.setAddress(rs.getString("ADDRESS"));
        address.setCity(rs.getString("CITY"));
        address.setStateProvince(rs.getString("STATE"));
        address.setCountry(rs.getString("COUNTRY"));
        address.setPostalCode(rs.getString("ZIP"));

        contact.setAddress(address);

        // CARECOACH
        contact.setContactType(ContactType.CARECOACH);

        return contact;
    }
}
