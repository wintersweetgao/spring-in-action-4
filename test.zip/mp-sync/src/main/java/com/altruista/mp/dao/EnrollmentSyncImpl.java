package com.altruista.mp.dao;

import com.altruista.mp.model.Enrollment;
import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.EnrollmentService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import com.altruista.mp.utils.CryptoHelper;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import java.util.List;

public class EnrollmentSyncImpl extends BaseSyncImpl implements EnrollmentSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory
            .getLogger(EnrollmentSyncImpl.class);

    @Autowired
    private EnrollmentService enrollmentService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;
    private long mpUserId = -1;
    private final DateTime MP_END_DATE = new DateTime(2099, 12, 31, 0, 0);
    private final String MP_USER_NAME = "MemberPortal";

    public void applyLocalChanges(DateTime runDate) {

        List<Enrollment> enrollments = enrollmentService.findEnrollmentIdsToSync();
        for (Enrollment id : enrollments) {
            Enrollment enrollment = enrollmentService.get(id.getId());

            // lookup member for refId
            Member member = memberService.get(enrollment.getMemberId());

            if (member.getRefId() == null || member.getRefId().isEmpty()) {
                LOGGER.debug("Skipping updates to member without refId: " + member.getId());
                continue;
            }

            // first update member information
            saveMemberIdentifiersToSQL(enrollment, member);
            saveMailingAddressToSQL(enrollment, member);
            saveEmailToSQL(enrollment, member);
            saveCellPhoneToSQL(enrollment, member);

            // then save the plan/program information
            saveEnrollmentToSQL(enrollment, member);

            // finally, mark enrollment as processed
            enrollmentService.save(enrollment, false);
        }
    }

    private void saveEmailToSQL(Enrollment enrollment, Member member) {
        // do not replace email address if nothing provided by member
        if (enrollment.getPrimaryEmail() == null || enrollment.getPrimaryEmail().isEmpty())
            return;

        try {
            String updateSQL =
                    "UPDATE PATIENT_DETAILS SET " +
                            " PRIMARY_EMAIL = :primaryEmail, " +
                            " UPDATED_ON = :updatedOn, " +
                            " UPDATED_BY = :updatedBy " +
                            " WHERE PATIENT_ID = :patientID";

            NamedParameterJdbcTemplate cpTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource cpNamedParameters =
                    new MapSqlParameterSource()
                            .addValue("primaryEmail", enrollment.getPrimaryEmail())
                            .addValue("updatedOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("updatedBy", getGuidingCareUserIdForMP())
                            .addValue("patientID", member.getRefId());

            int rows = cpTemplate.update(updateSQL, cpNamedParameters);

            if (rows == 1) {
                LOGGER.debug("PRIMARY_EMAIL: Mongodb [" + enrollment.getId()
                        + "] => SQL [" + enrollment.getRefId() + "]");
            } else if (rows > 1) {
                LOGGER.warn("PRIMARY_EMAIL: Mongodb [" + enrollment.getId()
                        + "] => SQL [" + enrollment.getRefId() + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update PRIMARY_EMAIL for enrollment: " + enrollment.getId() + ", no rows updated.");
            }

        } catch (Exception exc) {

            enrollmentService.save(enrollment, false);

            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("enrollment");
            sl.setObjectId(enrollment.getId());
            sl.setAction("saveEmailToSQL");
            sl.setDescription("Unable to save primary email for enrollment: "
                    + enrollment.getId());
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    private void saveCellPhoneToSQL(Enrollment enrollment, Member member) {
        // do not replace email address if nothing provided by member
        if (enrollment.getMobilePhoneNumber() == null || enrollment.getMobilePhoneNumber().isEmpty())
            return;

        try {
            String updateSQL =
                    "UPDATE PATIENT_DETAILS SET " +
                            " CELL_PHONE = :cellPhone, " +
                            " UPDATED_ON = :updatedOn, " +
                            " UPDATED_BY = :updatedBy " +
                            " WHERE PATIENT_ID = :patientID";

            NamedParameterJdbcTemplate cpTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource cpNamedParameters =
                    new MapSqlParameterSource()
                            .addValue("cellPhone", enrollment.getMobilePhoneNumber())
                            .addValue("updatedOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("updatedBy", getGuidingCareUserIdForMP())
                            .addValue("patientID", member.getRefId());

            int rows = cpTemplate.update(updateSQL, cpNamedParameters);

            if (rows == 1) {
                LOGGER.debug("CELL_PHONE: Mongodb [" + enrollment.getId()
                        + "] => SQL [" + enrollment.getRefId() + "]");
            } else if (rows > 1) {
                LOGGER.warn("CELL_PHONE: Mongodb [" + enrollment.getId()
                        + "] => SQL [" + enrollment.getRefId() + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update CELL_PHONE for enrollment: " + enrollment.getId() + ", no rows updated.");
            }

        } catch (Exception exc) {

            enrollmentService.save(enrollment, false);

            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("enrollment");
            sl.setObjectId(enrollment.getId());
            sl.setAction("saveCellPhoneToSQL");
            sl.setDescription("Unable to save cell phone for enrollment: "
                    + enrollment.getId());
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    private void saveMailingAddressToSQL(Enrollment enrollment, Member member) {
        try {
            long addressTypeId = getAddressTypeId("Mailing Address");
            addAddress(member.getRefId(), addressTypeId, enrollment);
        } catch (Exception exc) {

            enrollmentService.save(enrollment, false);

            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("enrollment");
            sl.setObjectId(enrollment.getId());
            sl.setAction("saveMailingAddressToSQL");
            sl.setDescription("Unable to save address for enrollment: "
                    + enrollment.getId());
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    private void saveEnrollmentToSQL(Enrollment enrollment, Member member) {

        if (enrollment.getRefId() == null || enrollment.getRefId().length() == 0) {
            LOGGER.debug("Adding enrollment to SQL");

            try {
                long programStatusId = getProgramStatusId("Pending");
                String planId = getMemberBenefitPlanId(enrollment, member.getRefId(), programStatusId);

                String fromProgSql = "INSERT INTO MEM_BENF_PROG (MEMBER_ID, MEM_BENF_PLAN_ID, BEN_PLAN_PROG_ID, "
                        + "START_DATE, END_DATE, PROGRAM_STATUS_ID, LOB_BEN_ID, REFERRAL_TYPE_ID, CREATED_ON, CREATED_BY) "
                        + " VALUES ( :memberId, :planId, :progId, :startDate, :endDate, :programStatusId, "
                        + " :lobBenId, :referralTypeId, :createdOn, :createdBy)";

                KeyHolder fromProgKeyHolder = new GeneratedKeyHolder();
                NamedParameterJdbcTemplate toProgTemplate = new NamedParameterJdbcTemplate(dataSource);
                SqlParameterSource fromProgNamedParameters =
                        new MapSqlParameterSource("memberId", member.getRefId())
                                .addValue("planId", planId)
                                .addValue("progId", getBenefitPlanProgramId())
                                .addValue("startDate", DateTime.now().toDate())
                                .addValue("endDate", MP_END_DATE.toDate())
                                .addValue("programStatusId", programStatusId)
                                .addValue("lobBenId", getLobBenefitPlanId("Program Enrollment", "Enrollment"))
                                .addValue("referralTypeId", getReferralTypeId("MyMoneyConnect"))
                                .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                                .addValue("createdBy", getGuidingCareUserIdForMP());

                toProgTemplate.update(fromProgSql, fromProgNamedParameters, fromProgKeyHolder);

                LOGGER.info("ENROLLMENT: MEM_BENF_PROG [" + enrollment.getId()
                        + "] => SQL [" + fromProgKeyHolder.getKey() + "]");


            } catch (Exception exc) {

                enrollmentService.save(enrollment, false);

                SyncLog sl = new SyncLog();
                sl.setLevel(SyncLogLevelType.ERROR);
                sl.setObjectName("enrollment");
                sl.setObjectId(enrollment.getId());
                sl.setAction("saveEnrollmentToSQL");
                sl.setDescription("Unable to insert into plan/program information for enrollment: "
                        + enrollment.getId());
                syncLogService.save(sl);

                LOGGER.error(sl.getDescription() + ", exception: " + exc);
            }
        } else {
            LOGGER.warn("Enrollment Insert is not supported for : " + enrollment.getId());

            enrollmentService.save(enrollment, false);
        }
    }

    private long getAddressTypeId(String addressType) {
        String sql = "SELECT ADDRESS_TYPE_ID FROM ADDRESS_TYPE WHERE ADDRESS_TYPE_NAME = ? AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{addressType}, String.class);

        if (!idList.isEmpty()) {
            return Long.parseLong(idList.get(0));
        } else {
            // insert a new address type
            String fromSql = "INSERT INTO ADDRESS_TYPE (ADDRESS_TYPE_NAME, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:addressTypeName, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("addressTypeName", addressType)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);
            return fromKeyHolder.getKey().longValue();
        }
    }

    private void addAddress(String refId, long addressTypeId, Enrollment enrollment) {

        String sql = "SELECT ADDRESS_ID FROM PATIENT_ADDITIONAL_ADDRESS"
                + " WHERE PATIENT_ID = ? AND ADDRESS_TYPE_ID = ? AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{refId, addressTypeId}, String.class);

        if (!idList.isEmpty()) {
            String addressId = idList.get(0);

            String updateSQL =
                    "UPDATE PATIENT_ADDITIONAL_ADDRESS SET " +
                            " CITY = :city, " +
                            " STATE = :state, " +
                            " COUNTRY = :country, " +
                            " ZIP = :zip, " +
                            " ADDRESS_TEXT = :addressText, " +
                            " UPDATED_ON = :updatedOn, " +
                            " UPDATED_BY = :updatedBy " +
                            " WHERE ADDRESS_ID = :addressId";

            NamedParameterJdbcTemplate cpTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource cpNamedParameters =
                    new MapSqlParameterSource()
                            .addValue("city", enrollment.getAddress().getCity())
                            .addValue("state", enrollment.getAddress().getStateProvince())
                            .addValue("country", enrollment.getAddress().getCountry())
                            .addValue("zip", enrollment.getAddress().getPostalCode())
                            .addValue("addressText", enrollment.getAddress().getAddress())
                            .addValue("updatedOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("updatedBy", getGuidingCareUserIdForMP())
                            .addValue("addressId", addressId);

            int rows = cpTemplate.update(updateSQL, cpNamedParameters);

            if (rows == 1) {
                LOGGER.debug("PATIENT_ADDITIONAL_ADDRESS: Mongodb [" + enrollment.getId()
                        + "] => SQL [" + enrollment.getRefId() + "]");
            } else if (rows > 1) {
                LOGGER.warn("PATIENT_ADDITIONAL_ADDRESS: Mongodb [" + enrollment.getId()
                        + "] => SQL [" + enrollment.getRefId() + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update PATIENT_ADDITIONAL_ADDRESS for enrollment: " + enrollment.getId() + ", no rows updated.");
            }

        } else {
            // insert a new plan
            String fromSql = "INSERT INTO PATIENT_ADDITIONAL_ADDRESS (PATIENT_ID, CITY, "
                    + "STATE, COUNTRY, ZIP, ADDRESS_TEXT, ADDRESS_TYPE_ID, IS_PRIMARY, CREATED_ON, CREATED_BY) "
                    + "VALUES (:patientId, :city, :state, :country, :zip, :addressText, :addressTypeId, "
                    + "0, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("patientId", refId)
                            .addValue("city", enrollment.getAddress().getCity())
                            .addValue("state", enrollment.getAddress().getStateProvince())
                            .addValue("country", enrollment.getAddress().getCountry())
                            .addValue("zip", enrollment.getAddress().getPostalCode())
                            .addValue("addressText", enrollment.getAddress().getAddress())
                            .addValue("addressTypeId", addressTypeId)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);
        }
    }

    private long getLobBenefitPlanId(String lob, String plan) {
        long lobId = getLobId(lob);
        long planId = getBenefitPlanId(plan);

        String sql = "SELECT LOB_BEN_ID FROM LOB_BENF_PLAN WHERE LOB_ID = ? AND BENEFIT_PLAN_ID = ? AND "
                + " ? BETWEEN START_DATE AND END_DATE AND IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{lobId, planId, DateTime.now().toDate()}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {
            // insert a new plan
            String fromSql = "INSERT INTO LOB_BENF_PLAN (LOB_ID, BENEFIT_PLAN_ID, START_DATE, END_DATE, IS_ACTIVE, HAS_EXPIRED, CREATED_ON, CREATED_BY) "
                    + " VALUES (:lobId, :planId, :startDate, :endDate, 1, 0, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("lobId", lobId)
                            .addValue("planId", planId)
                            .addValue("startDate", DateTime.now().toDate())
                            .addValue("endDate", MP_END_DATE.toDate())
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

            return fromKeyHolder.getKey().longValue();
        }
    }

    private long getLobId(String lob) {

        String sql = "SELECT LOB_ID FROM LOB WHERE LOB_NAME = ? AND ? BETWEEN START_DATE AND END_DATE AND "
                + " IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{lob, DateTime.now().toDate()}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {
            // insert a new plan
            String fromSql = "INSERT INTO LOB (LOB_NAME, LOB_DESC, START_DATE, END_DATE, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:lobName, :lobDesc, :startDate, :endDate, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("lobName", lob)
                            .addValue("lobDesc", lob)
                            .addValue("startDate", DateTime.now().toDate())
                            .addValue("endDate", MP_END_DATE.toDate())
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

            return fromKeyHolder.getKey().longValue();
        }
    }

    private long getProgramStatusId(String programStatus) {
        String sql = "SELECT PROGRAM_STATUS_ID FROM PROGRAM_STATUS WHERE PROGRAM_STATUS_NAME = ? AND "
                + " IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{programStatus}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {

            // insert a new plan
            String fromSql = "INSERT INTO PROGRAM_STATUS (PROGRAM_STATUS_NAME, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:programStatus, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("programStatus", programStatus)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);
            return fromKeyHolder.getKey().longValue();
        }
    }

    private long getProgramReasonId(String programReason, long programStatusId) {
        String sql = "SELECT PROGRAM_REASON_ID FROM INTERNAL_PROGRAM_REASON WHERE REASON_DESCRIPTION = ? AND PROGRAM_STATUS_ID = ? AND "
                + " IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{programReason, programStatusId}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {
            // insert a new plan
            String fromSql = "INSERT INTO INTERNAL_PROGRAM_REASON (REASON_DESCRIPTION, PROGRAM_STATUS_ID, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:programReason, :programStatusId, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("programReason", programReason)
                            .addValue("programStatusId", programStatusId)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

            return fromKeyHolder.getKey().longValue();
        }
    }

    private long getBenefitPlanId(String plan) {

        String sql = "SELECT BENEFIT_PLAN_ID FROM BENEFIT_PLAN WHERE PLAN_NAME = ? AND"
                + " ? BETWEEN START_DATE AND END_DATE AND IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{plan, DateTime.now().toDate()}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {
            // insert a new plan
            String fromSql = "INSERT INTO BENEFIT_PLAN (PLAN_NAME, PLAN_DESC, START_DATE, END_DATE, HAS_EXPIRED, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:planName, :planDesc, :startDate, :endDate, 0, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("planName", plan)
                            .addValue("planDesc", plan)
                            .addValue("startDate", DateTime.now().toDate())
                            .addValue("endDate", MP_END_DATE.toDate())
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

            return fromKeyHolder.getKey().longValue();
        }
    }

    private long getBenefitProgramId(String program) {
        String sql = "SELECT BENEFIT_PROGRAM_ID FROM BENEFIT_PROGRAM WHERE PROGRAM_NAME = ? AND "
                + " ? BETWEEN START_DATE AND END_DATE AND IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{program, DateTime.now().toDate()}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {
            // insert a new program
            String fromSql = "INSERT INTO BENEFIT_PROGRAM (PROGRAM_NAME, PROGRAM_DESC, START_DATE, END_DATE, HAS_EXPIRED, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:programName, :programDesc, :startDate, :endDate, 0, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("programName", program)
                            .addValue("programDesc", program)
                            .addValue("startDate", DateTime.now().toDate())
                            .addValue("endDate", MP_END_DATE.toDate())
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

            return fromKeyHolder.getKey().longValue();
        }
    }

    private long getBenefitPlanProgramId() {
        long planId = getBenefitPlanId("Enrollment");
        long programId = getBenefitProgramId("MyMoneyConnect");

        String sql = "SELECT BEN_PLAN_PROG_ID FROM BENF_PLAN_PROG WHERE BENEFIT_PLAN_ID = ? AND BENEFIT_PROGRAM_ID = ? AND "
                + " ? BETWEEN START_DATE AND END_DATE AND IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{planId, programId, DateTime.now().toDate()}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {
            // insert a new program
            String fromSql = "INSERT INTO BENF_PLAN_PROG (BENEFIT_PLAN_ID, BENEFIT_PROGRAM_ID, START_DATE, END_DATE, HAS_EXPIRED, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:planId, :programId, :startDate, :endDate, 0, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("planId", planId)
                            .addValue("programId", programId)
                            .addValue("startDate", DateTime.now().toDate())
                            .addValue("endDate", MP_END_DATE.toDate())
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);

            return fromKeyHolder.getKey().longValue();
        }
    }

    private String getMemberBenefitPlanId(Enrollment enrollment, String memberRefId, long programStatusId) {

        long programReasonId = getProgramReasonId("MyMoneyConnect", programStatusId);
        long lobBenefitPlanId = getLobBenefitPlanId("Program Enrollment", "Enrollment");

        String sql = "SELECT MEM_BENF_PLAN_ID FROM MEM_BENF_PLAN WHERE MEMBER_ID = ? AND LOB_BEN_ID = ? AND "
                + " ? BETWEEN START_DATE AND END_DATE AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{memberRefId, lobBenefitPlanId, DateTime.now().toDate()}, String.class);

        if (!idList.isEmpty()) {
            return idList.get(0);
        } else {
            String fromSql = "INSERT INTO MEM_BENF_PLAN (MEMBER_ID, LOB_BEN_ID, START_DATE, END_DATE, IS_VISIBLE, PROGRAM_REASON_ID, PROGRAM_STATUS_ID, "
                    + " CREATED_ON, CREATED_BY) "
                    + " VALUES ( :memberId, :lobBenId, :startDate, :endDate, 1, :programReasonId, :programStatusId, "
                    + " :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("memberId", memberRefId)
                            .addValue("lobBenId", lobBenefitPlanId)
                            .addValue("startDate", DateTime.now().toDate())
                            .addValue("endDate", MP_END_DATE.toDate())
                            .addValue("programReasonId", programReasonId)
                            .addValue("programStatusId", programStatusId)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);
            enrollment.setRefId(fromKeyHolder.getKey().toString());

            LOGGER.info("ENROLLMENT: MEM_BENF_PLAN [" + enrollment.getId()
                    + "] => SQL [" + fromKeyHolder.getKey() + "]");

            return fromKeyHolder.getKey().toString();
        }
    }

    private long getGuidingCareUserIdForMP() {
        // return immediately if already available
        if (mpUserId >= 0)
            return mpUserId;


        String sql = "SELECT MEMBER_ID FROM MEMBER WHERE USERNAME = ?";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{MP_USER_NAME}, String.class);

        if (!idList.isEmpty())
            mpUserId = Long.parseLong(idList.get(0));
        else {
            // insert a new user
            String fromSql = "INSERT INTO MEMBER (USERNAME, CREATED_ON)"
                    + " VALUES (:username, :createdOn)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("username", MP_USER_NAME)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()));

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);
            mpUserId = fromKeyHolder.getKey().longValue();

            // insert a new care staff (coach) for MP
            String careStaffSql = "INSERT INTO CARE_STAFF_DETAILS (MEMBER_ID, ROLE_ID, FIRST_NAME, LAST_NAME, CREATED_ON)"
                    + " VALUES (:memberId, 2, :firstName, :lastName, :createdOn)";

            NamedParameterJdbcTemplate csTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource csNamedParameters =
                    new MapSqlParameterSource("memberId", mpUserId)
                            .addValue("firstName", "Member")
                            .addValue("lastName", "Portal")
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()));

            csTemplate.update(careStaffSql, csNamedParameters);
        }

        return mpUserId;
    }

    private long getReferralTypeId(String referralType) {
        String sql = "SELECT REFERRAL_TYPE_ID FROM PATIENT_REFERRAL_TYPE WHERE REFERRAL_TYPE = ? "
                + " AND IS_ACTIVE = 1 AND DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{referralType}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {
            // insert a new plan
            String fromSql = "INSERT INTO PATIENT_REFERRAL_TYPE (REFERRAL_TYPE, IS_ACTIVE, CREATED_ON, CREATED_BY) "
                    + " VALUES (:referralType, 1, :createdOn, :createdBy)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("referralType", referralType)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);
            return fromKeyHolder.getKey().longValue();
        }
    }

    private void saveMemberIdentifiersToSQL(Enrollment enrollment, Member member) {
        savePatientIndex(member.getRefId(), "MMC_SSN", enrollment.getSsn(), member.getClientRefId());
        savePatientIndex(member.getRefId(), "MMC_ITIN", enrollment.getItin(), member.getClientRefId());
        savePatientIndex(member.getRefId(), "MMC_REFUGEE_ID", enrollment.getRefugeeNumber(), member.getClientRefId());
    }

    private boolean savePatientIndex(String patientId, String indexName, String indexValue, String clientRefId) {
        // do not store empty values
        if (indexValue == null || indexValue.isEmpty())
            return false;

        long indexId = getPatientIndexId(indexName, clientRefId);

        // Decrypt the value for lookup in GC
        String clearValue = CryptoHelper.decryptString(indexValue);

        // do not store duplicates
        String sql = "SELECT INDEX_ID FROM PATIENT_INDEX WHERE PATIENT_ID = ? AND INDEX_ID = ? AND INDEX_VALUE = ? AND "
                + " DELETED_ON IS NULL";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{patientId, indexId, clearValue}, String.class);

        if (!idList.isEmpty())
            return false;
        else {

            // insert a new plan
            String fromSql = "INSERT INTO PATIENT_INDEX (INDEX_VALUE, INDEX_ID, DISPLAY_VALUE, PATIENT_ID, CREATED_ON, CREATED_BY) "
                    + " VALUES (:indexValue, :indexId, :displayValue, :patientId, :createdOn, :createdBy)";

            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("indexValue", clearValue)
                            .addValue("indexId", indexId)
                            .addValue("displayValue", clearValue)
                            .addValue("patientId", patientId)
                            .addValue("createdOn", new java.sql.Timestamp(DateTime.now().getMillis()))
                            .addValue("createdBy", getGuidingCareUserIdForMP());

            toTemplate.update(fromSql, fromNamedParameters);

            return true;
        }
    }

    private long getPatientIndexId(String indexName, String clientRefId) {
        String sql = "SELECT INDEX_ID FROM INDEX_NAME WHERE INDEX_NAME = ? AND IS_ACTIVE = 1";
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> idList = jdbcTemplate.queryForList(sql, new Object[]{indexName}, String.class);

        if (!idList.isEmpty())
            return Long.parseLong(idList.get(0));
        else {

            if (clientRefId == null)
                clientRefId = "1";

            // insert a new plan
            String fromSql = "INSERT INTO INDEX_NAME (INDEX_NAME, INDEX_DESCRIPTION, INDEX_TYPE, SOURCE_TYPE, SOURCE_ID, SOURCE_NAME, IS_ACTIVE) "
                    + " VALUES (:indexName, :indexName, 'P', 'C', :clientId, 'Client', 1)";

            KeyHolder fromKeyHolder = new GeneratedKeyHolder();
            NamedParameterJdbcTemplate toTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource fromNamedParameters =
                    new MapSqlParameterSource("indexName", indexName)
                            .addValue("clientId", clientRefId);

            toTemplate.update(fromSql, fromNamedParameters, fromKeyHolder);
            return fromKeyHolder.getKey().longValue();
        }
    }

}
