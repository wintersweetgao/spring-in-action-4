package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixs_000 on 7/16/2014.
 */
public class MemberMapper {
    public static Member toMember(ResultSet rs) throws SQLException {
        Member member = new Member();
        member.setRefId(rs.getString("PATIENT_ID"));
        member.setPrimaryMedicalCondition(rs.getString("MEDICAL_CONDITION"));
        member.setPrimaryBehavioralCondition(rs.getString("BEHAVIORAL_CONDITION"));
        member.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));
        member.setContactCode(rs.getString("CLIENT_PATIENT_ID"));
        member.setClientRefId(rs.getString("CLIENT_ID"));

        return member;
    }
}
