package com.altruista.mp.dao;

import com.altruista.mp.model.ValidValue;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/25/14.
 */
public class EthnicityMapper {
    public static ValidValue toValidValue(ResultSet rs) throws SQLException {
        ValidValue ethnicity = new ValidValue();
        ethnicity.setName("ETHNICITY");   // "Table" Name
        ethnicity.setRefId(rs.getString("ETHNICITY_ID"));
        ethnicity.setValue(rs.getString("ETHNICITY_ID"));
        ethnicity.setDescription(rs.getString("ETHNICITY"));

        return ethnicity;
    }
}
