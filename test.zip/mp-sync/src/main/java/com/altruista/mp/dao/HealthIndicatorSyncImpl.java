package com.altruista.mp.dao;

import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by mwixson on 10/17/14.
 */
public class HealthIndicatorSyncImpl extends BaseSyncImpl implements HealthIndicatorSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(HealthIndicatorSyncImpl.class);

    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT PATIENT_ID "
                            + " FROM "
                            + " HEALTH_INDICATOR_RECORD HR,"
                            + " HEALTH_INDICATOR_PARAMETER,"
                            + " HEALTH_INDICATOR,"
                            + " HEALTH_INDICATOR_CAT"
                            + " WHERE"
                            + " HR.PARAMETER_ID = HEALTH_INDICATOR_PARAMETER.PARAMETER_ID"
                            + " AND HEALTH_INDICATOR_PARAMETER.INDICATOR_ID = HEALTH_INDICATOR.INDICATOR_ID"
                            + " AND HEALTH_INDICATOR.CATEGORY_ID = HEALTH_INDICATOR_CAT.CATEGORY_ID"
                            + " AND (HR.CREATED_ON >= :runDate OR HR.UPDATED_ON >= :runDate)"
                            + " AND INDICATOR_NAME in ('Height', 'Weight')"
                            + " AND HR.PATIENT_ID IS NOT NULL";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("healthIndicator");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT PATIENT_ID, INDICATOR_NAME, RECORD_DATE, VALUE_ENTERED, MEASUREMENT_UNIT "
                        + " FROM "
                        + " HEALTH_INDICATOR_RECORD HR,"
                        + " HEALTH_INDICATOR_PARAMETER,"
                        + " HEALTH_INDICATOR,"
                        + " HEALTH_INDICATOR_CAT"
                        + " WHERE"
                        + " HR.PARAMETER_ID = HEALTH_INDICATOR_PARAMETER.PARAMETER_ID"
                        + " AND HEALTH_INDICATOR_PARAMETER.INDICATOR_ID = HEALTH_INDICATOR.INDICATOR_ID"
                        + " AND HEALTH_INDICATOR.CATEGORY_ID = HEALTH_INDICATOR_CAT.CATEGORY_ID"
                        + " AND (HR.CREATED_ON >= ? OR HR.UPDATED_ON >= ?) "
                        + " AND INDICATOR_NAME in ('Height', 'Weight') "
                        + " AND PATIENT_ID = ? "
                        + " ORDER BY RECORD_DATE";   // process in order

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(rs);
                    }
                });
    }

    private void postChanges(ResultSet rs) throws SQLException {

        String refId = rs.getString("PATIENT_ID");
        LOGGER.debug("HEALTH_INDICATOR: Processing for refId:" + refId);

        List<Member> members = memberService.findByRefId(refId);

        if (members != null && members.size() > 0) {

            String indicator = rs.getString("INDICATOR_NAME");
            String units = rs.getString("MEASUREMENT_UNIT");
            float value = rs.getFloat("VALUE_ENTERED");

            Member updated = members.get(0);
            if (indicator.equalsIgnoreCase("Height")) {
                updated.setHeight(value);
                updated.setHeightUnits(units);
            } else if (indicator.equalsIgnoreCase("Weight")) {
                updated.setWeight(value);
                updated.setWeightUnits(units);
            } else {
                LOGGER.warn("Unsupported health indicator: " + indicator);
                return;
            }

            String memberId = memberService.save(updated, false);

            LOGGER.debug("HEALTH_INDICATOR: Mongodb ["
                    + memberId + "] <= SQL [ "
                    + refId + " ]");
        } else
            LOGGER.debug("HEALTH_INDICATOR: Member not found for refId:" + refId);
    }
}