package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ActionStepService;
import com.altruista.mp.services.GoalService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Component
public class CarePlanSyncImpl extends BaseSyncImpl implements CarePlanSync {
    private static final Logger LOGGER = LoggerFactory.getLogger(CarePlanSyncImpl.class);
    @Autowired
    private GoalService goalService;
    @Autowired
    private ActionStepService actionStepService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT CP.PATIENT_ID "
                            + "FROM CPL_CARE_PLAN CP "
                            + "LEFT OUTER JOIN CPL_GOAL G ON CP.GOAL_ID = G.GOAL_ID "
                            + "LEFT OUTER JOIN CPL_INTERVENTION I ON CP.INTERVENTION_ID = I.INTERVENTION_ID "
                            + "LEFT OUTER JOIN CPL_STATUS S ON CP.STATUS_ID = S.STATUS_ID "
                            + "LEFT OUTER JOIN LOB L ON CP.LOB_ID = L.LOB_ID "
                            + "LEFT OUTER JOIN CPL_GOAL_GROUP GG ON CP.GOAL_GROUP_ID=GG.GOAL_GROUP_ID "
                            + "LEFT OUTER JOIN CPL_MANAGE_CONDITION MC ON CP.CONDITION_ID= MC.CONDITION_ID "
                            + "LEFT OUTER JOIN CPL_PRIORITY P ON CP.PRIORITY_ID= P.PRIORITY_ID "
                            + "LEFT OUTER JOIN CPL_MEMBER_STATUS MS ON CP.MEMBER_STATUS_ID = MS.STATUS_ID "
                            + "WHERE "
                            + "((G.CREATED_ON >= :runDate OR G.UPDATED_ON >= :runDate) OR "
                            + "(CP.CREATED_ON >= :runDate OR CP.UPDATED_ON >= :runDate) OR "
                            + "(I.CREATED_ON >= :runDate OR I.UPDATED_ON >= :runDate)) "
                            + " AND CP.STATUS_ID = S.STATUS_ID";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("carePlan");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT G.GOAL_ID, G.ALIAS_NAME AS GOAL_ALIAS, G.GOAL_NAME, "
                        + "CP.CARE_PLAN_ID, CP.PATIENT_ID, I.ALIAS_NAME AS INTERVENTION_ALIAS, I.INTERVENTION_NAME, "
                        + "S.STATUS_NAME, GG.GOAL_GROUP_NAME, MC.CONDITION_NAME, MS.STATUS_NAME AS MEMBER_STATUS_NAME, "
                        + "L.LOB_NAME, P.PRIORITY_NAME, CP.START_DATE, CP.END_DATE, CP.IS_SIGN_OFF "
                        + "FROM CPL_CARE_PLAN CP "
                        + "LEFT OUTER JOIN CPL_GOAL G ON CP.GOAL_ID = G.GOAL_ID "
                        + "LEFT OUTER JOIN CPL_INTERVENTION I ON CP.INTERVENTION_ID = I.INTERVENTION_ID "
                        + "LEFT OUTER JOIN CPL_STATUS S ON CP.STATUS_ID = S.STATUS_ID "
                        + "LEFT OUTER JOIN LOB L ON CP.LOB_ID = L.LOB_ID "
                        + "LEFT OUTER JOIN CPL_GOAL_GROUP GG ON CP.GOAL_GROUP_ID=GG.GOAL_GROUP_ID "
                        + "LEFT OUTER JOIN CPL_MANAGE_CONDITION MC ON CP.CONDITION_ID= MC.CONDITION_ID "
                        + "LEFT OUTER JOIN CPL_PRIORITY P ON CP.PRIORITY_ID= P.PRIORITY_ID "
                        + "LEFT OUTER JOIN CPL_MEMBER_STATUS MS ON CP.MEMBER_STATUS_ID = MS.STATUS_ID "
                        + "WHERE "
                        + "((G.CREATED_ON >= ? OR G.UPDATED_ON >= ?) OR "
                        + "(CP.CREATED_ON >= ? OR CP.UPDATED_ON >= ?) OR "
                        + "(I.CREATED_ON >= ? OR I.UPDATED_ON >= ?)) "
                        + " AND CP.PATIENT_ID = ? AND CP.STATUS_ID = S.STATUS_ID";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), runDate.toDate(),
                runDate.toDate(), runDate.toDate(), runDate.toDate(), patientId}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                postChanges(member, rs);
            }
        });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        Goal goal = GoalMapper.toGoal(rs);
        ActionStep actionStep = ActionStepMapper.toActionStep(rs);

        goal.setMemberId(member.getId());

        // Save the GOAL
        String goalId = saveGoalToMongodb(goal);
        LOGGER.debug("GOAL: Mongodb [" + goalId
                + "] <= SQL [ " + goal.getRefId() + " ]");

        // FOR ACTION_STEP
        actionStep.setMemberId(member.getId());
        actionStep.setGoalId(goalId);

        // Save the ACTION STEP
        String actionStepId = saveActionStepToMongodb(actionStep);
        LOGGER.debug("ACTION STEP: Mongodb ["
                + actionStepId + "] <= SQL [ "
                + actionStep.getRefId() + " ]");
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT CARE_PLAN_ID "
                        + "FROM CPL_CARE_PLAN "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        deleteActionStep(rs.getString("CARE_PLAN_ID"));
                        deleteGoal(rs.getString("CARE_PLAN_ID"));
                    }
                });
    }

    private void deleteGoal(String refId) {
        List<Goal> goals = goalService.findIdByRefId(refId);
        if (goals != null && goals.size() > 0)
            goalService.delete(goals.get(0).getId());
    }

    private void deleteActionStep(String refId) {
        List<ActionStep> steps = actionStepService.findIdByRefId(refId);
        if (steps != null && steps.size() > 0)
            actionStepService.delete(steps.get(0).getId());
    }

    private String saveGoalToMongodb(Goal goal) {
        if (goal.getRefId() != null) {
            List<Goal> existing = goalService.findIdByRefId(goal.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                goal.setId(existing.get(0).getId());
                goal.setVersion(existing.get(0).getVersion());
            } else
                goal.setId(UUID.randomUUID().toString());
        } else
            goal.setId(UUID.randomUUID().toString());

        return goalService.save(goal, false);
    }

    private String saveActionStepToMongodb(ActionStep actionStep) {
        if (actionStep.getRefId() != null) {
            List<ActionStep> existing = actionStepService.findIdByRefId(actionStep.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                actionStep.setId(existing.get(0).getId());
                actionStep.setVersion(existing.get(0).getVersion());
            } else
                actionStep.setId(UUID.randomUUID().toString());
        } else
            actionStep.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        actionStep.setSyncedOn(DateTime.now());
        actionStepService.setSyncEnabled(false);*/

        return actionStepService.save(actionStep, false);
    }

    @Override
    public void applyLocalChanges(DateTime runDate) {
        HashMap<String, String> cplMemberStatusMap = getCplMemberStatusMap();
        List<ActionStep> actionSteps = actionStepService
                .findActionStepIdsToSync();

        for (ActionStep as : actionSteps) {
            ActionStep actionStep = actionStepService.get(as.getId());
            saveActionStepToSQL(actionStep, cplMemberStatusMap);
        }
    }

    private void saveActionStepToSQL(ActionStep actionStep, HashMap<String, String> statusMap) {

        // verify that the actionStep has a refId, ignore if not
        if (actionStep.getRefId() == null || actionStep.getRefId().length() == 0) {
            LOGGER.error("ActionStep is missing refId, unable to save to SQL: " + actionStep.getId());

           /* // IMPORTANT: set sync time to mark as ignored
            actionStep.setSyncedOn(DateTime.now());
            actionStepService.setSyncEnabled(false);*/

            actionStepService.save(actionStep, false);

            return;
        } else {
            LOGGER.debug("Saving ActionStep to SQL: " + actionStep.getId());
        }

        Long carePlanId = Long.parseLong(actionStep.getRefId());

        try {
            String actionStepSQL =
                    "UPDATE CPL_CARE_PLAN SET " +
                            " IS_SIGN_OFF = :isSignOff, " +
                            " MEMBER_STATUS_ID = :memberStatusId, " +
                            " MEMBER_VOICE_COMMENT = :comment " +
                            " WHERE CARE_PLAN_ID = :carePlanId";
            // NOTE: Avoid changing UPDATED_ON, otherwise this will sync back to Member Portal
            String tempId = statusMap.get(actionStep.getMemberStatus());
            if (tempId == null || tempId.length() == 0) {
                LOGGER.error("ActionStep has invalid member status: [" + actionStep.getMemberStatus() + "], unable to save to SQL: " + actionStep.getId());
                return;
            }
            int memberStatusId = Integer.parseInt(tempId);

            int isSignOff = 0;
            if (actionStep.getSignedOff() != null && actionStep.getSignedOff())
                isSignOff = 1;

            NamedParameterJdbcTemplate cpTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource cpNamedParameters =
                    new MapSqlParameterSource()
                            .addValue("isSignOff", isSignOff)
                            .addValue("memberStatusId", memberStatusId)
                            .addValue("comment", actionStep.getNotes())
                            .addValue("carePlanId", carePlanId);
            int rows = cpTemplate.update(actionStepSQL, cpNamedParameters);

            if (rows == 1) {
                LOGGER.debug("CPL_CARE_PLAN: Mongodb [" + actionStep.getId()
                        + "] => SQL [" + actionStep.getRefId() + "]");
            } else if (rows > 1) {
                LOGGER.warn("CPL_CARE_PLAN: Mongodb [" + actionStep.getId()
                        + "] => SQL [" + actionStep.getRefId() + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update CPL_CARE_PLAN for actionStep: " + actionStep.getId() + ", no rows updated.");
            }

            actionStepService.save(actionStep, false);
        } catch (Exception exc) {
            LOGGER.error("Unable to update CPL_CARE_PLAN for actionStep: " + actionStep.getId() + ", exception: " + exc);
        }
    }

    private HashMap<String, String> getCplMemberStatusMap() {
        String sql = "SELECT STATUS_NAME, STATUS_ID FROM CPL_MEMBER_STATUS";
        NamedParameterJdbcTemplate cpTemplate = new NamedParameterJdbcTemplate(dataSource);
        Map<String, String> parms = new HashMap<String, String>();
        List<Map<String, Object>> list = cpTemplate.queryForList(sql, parms);

        HashMap<String, String> statusMap = new HashMap<String, String>();
        for (Map<String, Object> map : list) {
            statusMap.put(map.get("STATUS_NAME").toString(), map.get("STATUS_ID").toString());
        }

        return statusMap;
    }
}