package com.altruista.mp.dao;

import com.altruista.mp.model.Tracker;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerMapper {
    public static Tracker toTracker(ResultSet rs) throws SQLException {

        Tracker tracker = new Tracker();
        tracker.setName(rs.getString("INDICATOR_NAME"));
        tracker.setRefId(rs.getString("INDICATOR_ID"));
        tracker.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return tracker;
    }
}