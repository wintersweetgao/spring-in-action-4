package com.altruista.mp.dao;

import com.altruista.mp.model.Diagnosis;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DiagnosisMapper {
    public static Diagnosis toDiagnosis(ResultSet rs) throws SQLException {
        Diagnosis diagnosis = new Diagnosis();

        String key = String.format("%s|%s", rs.getString("PATIENT_ID"), rs.getString("DIAGNOSIS_CODE"));
        diagnosis.setRefId(key);
        diagnosis.setName(rs.getString("DESCRIPTION"));
        diagnosis.setCategory(rs.getString("DIAGNOSIS_CODE"));
        diagnosis.setRank(rs.getInt("RANK"));
        diagnosis.setRefCreatedOn(DateHelper.getDate(rs.getDate("MIN_VISIT_DATE")));

        // The VISIT_SOURCE_TYPE table is not populated in GC?
        // Manually assign values
        String sourceType = rs.getString("SOURCE_TYPE");
        if (sourceType.equalsIgnoreCase("MC"))
            diagnosis.setSource("Medical Claim");
        else if (sourceType.equalsIgnoreCase("PC"))
            diagnosis.setSource("Pharmacy Claim");
        else
            diagnosis.setSource("Unclassified");

        return diagnosis;
    }
}
