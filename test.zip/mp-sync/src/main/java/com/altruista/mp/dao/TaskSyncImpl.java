package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import com.altruista.mp.services.TaskService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

@Component
public class TaskSyncImpl extends BaseSyncImpl implements TaskSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(TaskSyncImpl.class);

    @Value("${guidingCare.timezone}")
    private String gcTimezone;
    @Autowired
    private TaskService taskService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private ContactService contactService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + " SELECT DISTINCT A.PATIENT_ID "
                            + " FROM APPOINTMENT A, APPOINTMENT_STATUS AST, APPOINTMENT_TYPE APT, APPOINTMENT_PROVIDER_MAPPING APM"
                            + " WHERE (A.CREATED_ON >= :runDate OR A.UPDATED_ON >= :runDate) "
                            + " AND A.APPOINTMENT_TYPE_ID=APT.APPOINTMENT_TYPE_ID "
                            + " AND A.APPOINTMENT_STATUS=AST.APPOINTMENT_STATUS_ID "
                            + " AND A.APPOINTMENT_ID=APM.APPOINTMENT_ID ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("task");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);

        String sql =
                " SELECT A.PATIENT_ID, A.APPOINTMENT_ID, AT.APPOINTMENT_TYPE_NAME, A.APPOINTMENT_REASON, AST.APPOINTMENT_STATUS_NAME,"
                        + " A.APPOINTMENT_NAME, A.APPOINTMENT_DATE, A.APPOINTMENT_NOTES, A.APPOINTMENT_PRIORITY, "
                        + " APM.PROVIDER_ID, A.CREATED_BY, A.CREATED_ON "
                        + " FROM APPOINTMENT A, APPOINTMENT_STATUS AST, APPOINTMENT_TYPE AT, APPOINTMENT_PROVIDER_MAPPING APM"
                        + " WHERE (A.CREATED_ON >= ? OR A.UPDATED_ON >= ?) "
                        + " AND A.APPOINTMENT_TYPE_ID=AT.APPOINTMENT_TYPE_ID "
                        + " AND A.APPOINTMENT_STATUS=AST.APPOINTMENT_STATUS_ID "
                        + " AND A.APPOINTMENT_ID=APM.APPOINTMENT_ID "
                        + " AND A.PATIENT_ID = ? ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                postChanges(member, rs);
            }
        });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        String refId = rs.getString("PATIENT_ID");
        LOGGER.debug("APPOINTMENT: Processing for refId:" + refId + ", TZ: " + gcTimezone);

        Task task = TaskMapper.toTask(gcTimezone, rs);

        task.setMemberId(member.getId());

        List<Contact> provider = contactService.findIdByRefIdAndContactType(rs.getString(
                "PROVIDER_ID"), ContactType.PHYSICIAN);
        if (provider != null && provider.size() > 0) {
            task.setContactId(provider.get(0).getId());
        }

        List<Contact> coach = contactService.findIdByRefIdAndContactType(rs.getString(
                "CREATED_BY"), ContactType.CARECOACH);
        if (coach != null && coach.size() > 0) {
            task.setOwnerId(coach.get(0).getId());
        }

        String taskId = saveTaskToMongodb(task);
        LOGGER.debug("APPOINTMENT: Mongodb [" + taskId
                + "] <= SQL [ " + task.getRefId() + " ]");
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT APPOINTMENT_ID "
                        + "FROM APPOINTMENT "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize);   // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                delete(rs.getString("APPOINTMENT_ID"));
            } // processRow
        }); // query
    }

    private void delete(String refId) {
        List<Task> tasks = taskService.findIdByRefId(refId);
        if (tasks != null && tasks.size() > 0)
            taskService.delete(tasks.get(0).getId());
    }

    private String saveTaskToMongodb(Task task) {
        // see if Task already exists
        if (task.getRefId() != null) {
            List<Task> existing = taskService.findIdByRefId(task.getRefId());
            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                task.setId(existing.get(0).getId());
                task.setVersion(existing.get(0).getVersion());
            } else
                task.setId(UUID.randomUUID().toString());
        } else
            task.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        task.setSyncedOn(DateTime.now());
        taskService.setSyncEnabled(false);*/

        return taskService.save(task, false);
    }

    public void applyLocalChanges(DateTime runDate) {
        List<Task> tasks = taskService.findTaskIdsToSync();
        for (Task id : tasks) {
            Task taskId = taskService.get(id.getId());
            // saveTaskToSQL(taskId);
            LOGGER.debug("Task Id:" + taskId.getMemberId());
        }
    }

    private void saveTaskToSQL(Task task) {
        if (task.getRefId() == null || task.getRefId().length() == 0) {
            LOGGER.debug("Skipping Task sync - No RefId for: "
                    + task.getId());
            return;
        } else {
            LOGGER.debug("Saving Task to SQL: " + task.getId());
        }

        String sql = "UPDATE APPOINTMENT SET " + "APPOINTMENT_ID=?, "
                + "APPOINTMENT_REASON=?, " + "APPOINTMENT_NAME=?, "
                + "APPOINTMENT_NOTES=? " + "WHERE PATIENT_ID=?";

        JdbcTemplate template = new JdbcTemplate(dataSource);
        int rows = template.update(sql, new Object[]{task.getRefId()});

        if (rows != 1) {
            LOGGER.debug(rows + " were updated.");
        } else {
            LOGGER.debug("TASK: Mongodb [" + task.getId()
                    + "] => SQL [" + task.getRefId() + "]");
        }

       /* // IMPORTANT: set sync time to mark as synchronized
        task.setSyncedOn(DateTime.now());*/
        taskService.save(task, false);
    }

}
