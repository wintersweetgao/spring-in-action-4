package com.altruista.mp.dao;

import com.altruista.mp.model.ValidValue;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/25/14.
 */
public class GenderMapper {
    public static ValidValue toValidValue(ResultSet rs) throws SQLException {
        ValidValue gender = new ValidValue();
        gender.setName("GENDER");   // "Table" Name
        gender.setRefId(rs.getString("GENDER"));
        gender.setValue(rs.getString("GENDER"));
        gender.setDescription(rs.getString("NAME"));

        return gender;
    }
}
