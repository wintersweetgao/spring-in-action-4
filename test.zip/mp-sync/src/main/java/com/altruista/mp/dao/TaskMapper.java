package com.altruista.mp.dao;

import com.altruista.mp.model.Task;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * Created by mwixs_000 on 7/16/2014.
 */
public class TaskMapper {

    public static Task toTask(String gcTimezone, ResultSet rs) throws SQLException {
        Task task = new Task();
        task.setRefId(rs.getString("APPOINTMENT_ID"));
        String taskType = rs.getString("APPOINTMENT_TYPE_NAME");
        String name = rs.getString("APPOINTMENT_NAME");
        // set the title to the name (if provided) or the task type
        if (name != null && name.length() > 0)
            task.setTitle(name);
        else
            task.setTitle(taskType);
        task.setTaskType(taskType);
        task.setReason(rs.getString("APPOINTMENT_REASON"));
        task.setStatus(rs.getString("APPOINTMENT_STATUS_NAME"));
        task.setDescription(rs.getString("APPOINTMENT_NOTES"));
        task.setPriority(rs.getInt("APPOINTMENT_PRIORITY"));
        task.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));
        task.setAllDay(false);
        task.setOwnerType("TEAM");      // all synced tasks are by-definition, TEAM tasks

        // convert GC local to UTC (using Joda)
        DateTime local = new DateTime(rs.getTimestamp("APPOINTMENT_DATE"), DateTimeZone.forID(gcTimezone));
        DateTime startDate = local.toDateTime(DateTimeZone.UTC);
        DateTime endDate = startDate.plusHours(1);  // add 1 hour to create the endDate
        task.setStart(startDate);
        task.setEnd(endDate);
        task.setStartTimezone(gcTimezone);  // associate GC's timezone with the event
        task.setEndTimezone(gcTimezone);

        return task;
    }
}
