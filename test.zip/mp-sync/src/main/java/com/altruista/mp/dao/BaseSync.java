package com.altruista.mp.dao;

import javax.sql.DataSource;

/**
 * Created by mwixson on 12/26/14.
 */
public interface BaseSync {
    void setDataSource(DataSource dataSource);

    Integer getFetchsize();

    void setFetchsize(Integer fetchsize);
}
