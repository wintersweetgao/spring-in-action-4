package com.altruista.mp.dao;

import com.altruista.mp.model.TrackerParameter;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerParameterMapper {
    public static TrackerParameter toParameter(ResultSet rs) throws SQLException {

        TrackerParameter parameter = new TrackerParameter();
        parameter.setRefId(rs.getString("PARAMETER_ID"));
        parameter.setName(rs.getString("PARAMETER_NAME"));
        parameter.setDescription(rs.getString("PARAMETER_DESCRIPTION"));
        parameter.setMaxValue(rs.getString("MAXIMUM_VALUE"));
        parameter.setMinValue(rs.getString("MINIMUM_VALUE"));
        parameter.setParameterType(rs.getString("PARAMETER_TYPE"));
        parameter.setUom(rs.getString("MEASUREMENT_UNIT"));

        return parameter;
    }
}
