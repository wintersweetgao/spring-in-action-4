package com.altruista.mp.dao;

import com.altruista.mp.model.TrackerRecord;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 1/26/15.
 */
public class TrackerRecordMapper {
    public static TrackerRecord toRecord(ResultSet rs) throws SQLException {
        // R.RECORD_ID, R.PARAMETER_ID, R.VALUE_ENTERED, R.RECORD_DATE, R.COMMENTS,
        // P.INDICATOR_ID, P.PARAMETER_NAME, P.MEASUREMENT_UNIT, P.PARAMETER_TYPE

        TrackerRecord record = new TrackerRecord();
        record.setRefId(rs.getString("RECORD_ID"));
        record.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));
        record.setParameterId(rs.getString("PARAMETER_ID"));
        record.setValue(rs.getString("VALUE_ENTERED"));
        record.setRecordedOn(DateHelper.getDate(rs.getDate("RECORD_DATE")));
        record.setComments(rs.getString("COMMENTS"));
        record.setParameterName(rs.getString("PARAMETER_NAME"));
        record.setUom(rs.getString("MEASUREMENT_UNIT"));
        record.setParameterType(rs.getString("PARAMETER_TYPE"));

        return record;
    }
}