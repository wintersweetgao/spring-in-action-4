package com.altruista.mp.dao;

import com.altruista.mp.model.Medication;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PharmacyMapper {
    public static Medication toMedication(ResultSet rs) throws SQLException {
        Medication medication = new Medication();

        medication.setRefId(rs.getString("PATIENT_VISIT_RX_ID"));
        medication.setName(rs.getString("DESCRIPTION"));
        medication.setQuantity(rs.getString("QUANTITY"));
        medication.setDays(rs.getInt("DAYS_SUPPLY"));
        medication.setRefCreatedOn(new DateTime(DateHelper.getDate(rs.getDate("VISIT_DATE"))));
        medication.setSource("CLAIM");

        return medication;
    }
}
