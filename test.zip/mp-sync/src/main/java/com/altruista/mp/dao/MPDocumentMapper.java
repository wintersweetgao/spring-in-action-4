package com.altruista.mp.dao;

import com.altruista.mp.model.MPDocument;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by sourabh on 8/20/2014..
 */
public class MPDocumentMapper {
    public static MPDocument toMPDocument(ResultSet rs) throws SQLException {
        MPDocument mpDocument = new MPDocument();
        mpDocument.setMemberId(null);
        mpDocument.setRefId(rs.getString("HEALTH_ARTICLE_ID"));
        mpDocument.setHeading(rs.getString("HEALTH_ARTICLE_HEADING"));
        mpDocument.setDescription(rs.getString("HEALTH_SHORT_DESC"));
        mpDocument.setDocumentText(rs.getString("HEALTH_ARTICLE_TEXT"));
        mpDocument.setThumbnail(rs.getString("HEALTH_ARTICLE_IMAGE"));
        mpDocument.setDocumentUrl(rs.getString("HEALTH_FILE"));
        mpDocument.setCreatedOn(DateHelper.getDate(rs.getDate("HEALTH_ARTICLE_DATE")));
        mpDocument.setSource(rs.getString("HEALTH_ARTICLE_AUTHOR"));
        mpDocument.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return mpDocument;
    }
}
