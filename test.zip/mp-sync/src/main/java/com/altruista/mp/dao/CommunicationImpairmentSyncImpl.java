package com.altruista.mp.dao;

import com.altruista.mp.model.CommunicationImpairment;
import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.CommunicationImpairmentService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class CommunicationImpairmentSyncImpl extends BaseSyncImpl implements CommunicationImpairmentSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(CommunicationImpairmentSyncImpl.class);

    @Autowired
    private CommunicationImpairmentService impairmentService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT PATIENT_ID "
                            + "FROM PATIENT_COMMUNICATION_IMPAIRMENTS PCI, CM_COMMUNICATION_IMPAIRMENTS CMI "
                            + "WHERE (PCI.CREATED_ON >= :runDate OR CMI.UPDATED_ON >= :runDate) "
                            + " AND PCI.IMPAIRMENT_ID = CMI.IMPAIRMENT_ID ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("communicationImpairment");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        // IMPORTANT:
        String sql = "SELECT PCI.IMPAIRMENT_ID, PATIENT_ID, IMPAIRMENT_NAME, PCI.CREATED_ON "
                + "FROM PATIENT_COMMUNICATION_IMPAIRMENTS PCI, CM_COMMUNICATION_IMPAIRMENTS CMI "
                + "WHERE (PCI.CREATED_ON >= ? OR CMI.UPDATED_ON >= ?) "
                + " AND PCI.IMPAIRMENT_ID = CMI.IMPAIRMENT_ID "
                + " AND PATIENT_ID = ? ";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(member, rs);
                    }
                });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        CommunicationImpairment impairment = CommunicationImpairmentMapper.toCommunicationImpairment(rs);
        impairment.setMemberId(member.getId());

        // Save the IMPAIRMENT
        String impairmentId = saveCommunicationImpairmentToMongodb(impairment);

        LOGGER.debug("COMM IMPAIRMENT: Mongodb ["
                + impairmentId + "] <= SQL [ "
                + impairment.getRefId() + " ]");
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT IMPAIRMENT_ID "
                        + "FROM PATIENT_COMMUNICATION_IMPAIRMENTS "
                        + "WHERE DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        delete(rs.getString("IMPAIRMENT_ID"));
                    }
                });
    }

    private void delete(String refId) {
        List<CommunicationImpairment> imps = impairmentService.findIdByRefId(refId);
        if (imps != null && imps.size() > 0)
            impairmentService.delete(imps.get(0).getId());
    }

    private String saveCommunicationImpairmentToMongodb(CommunicationImpairment impairment) {
        if (impairment.getRefId() != null) {
            List<CommunicationImpairment> existing = impairmentService.findIdByRefId(impairment.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                impairment.setId(existing.get(0).getId());
                impairment.setVersion(existing.get(0).getVersion());
            } else
                impairment.setId(UUID.randomUUID().toString());
        } else
            impairment.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        impairment.setSyncedOn(DateTime.now());
        impairmentService.setSyncEnabled(false);*/

        return impairmentService.save(impairment, false);
    }

}
