package com.altruista.mp.dao;

import com.altruista.mp.model.Program;
import com.altruista.mp.utils.DateHelper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 10/16/14.
 */
public class ProgramMapper {
    public static Program toProgram(ResultSet rs) throws SQLException {
        Program program = new Program();
        program.setRefId(rs.getString("MEM_BENF_PROG_ID"));
        program.setLob(rs.getString("LOB_NAME"));
        program.setPlan(rs.getString("PLAN_NAME"));
        program.setName(rs.getString("PROGRAM_NAME"));
        program.setActive(rs.getBoolean("IS_ACTIVE"));
        program.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));

        return program;
    }
}
