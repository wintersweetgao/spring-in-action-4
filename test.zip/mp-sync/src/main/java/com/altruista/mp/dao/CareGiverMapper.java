package com.altruista.mp.dao;

import com.altruista.mp.model.Address;
import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;
import com.altruista.mp.utils.DateHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CareGiverMapper {
    private static final Logger LOGGER = LoggerFactory.getLogger(CareGiverMapper.class);

    public static Contact toContact(ResultSet rs) throws SQLException {
        Contact contact = new Contact();
        contact.setRefId(rs.getString("CARE_GIVER_ID"));
        contact.setFirstName(rs.getString("FIRST_NAME"));
        contact.setMiddleName(rs.getString("MIDDLE_NAME"));
        contact.setLastName(rs.getString("LAST_NAME"));
        contact.setPhoneNumber(rs.getString("HOME_PHONE"));
        contact.setEveningPhoneNumber(rs.getString("HOME_PHONE"));
        contact.setMobilePhoneNumber(rs.getString("CELL_PHONE"));
        contact.setFaxNumber(rs.getString("FAX"));
        contact.setGender(rs.getString("SEX"));
        contact.setPrimaryEmail(rs.getString("EMAIL_ID"));
        contact.setRegistrationStatus(rs.getString("REGSTR_STATUS"));
        contact.setRelationshipToMember(rs.getString("PATIENT_RELATION"));

        try {
            contact.setDob(DateHelper.getDateString(rs.getDate("DOB")));
        } catch (Exception exc) {
            LOGGER.warn("Unable to map DOB for CareGiver: " + contact.getRefId() + ", exception: " + exc);
        }

        try {
            contact.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_ON")));
        } catch (Exception exc) {
            LOGGER.warn("Unable to map CREATED_ON for CareGiver: " + contact.getRefId() + ", exception: " + exc);
        }

        Address address = new Address();
        address.setAddress(rs.getString("ADDRESS"));
        address.setCity(rs.getString("CITY"));
        address.setStateProvince(rs.getString("STATE"));
        address.setPostalCode(rs.getString("ZIP"));
        address.setCountry(rs.getString("COUNTRY"));

        contact.setAddress(address);

        // FOR CARE GIVER
        contact.setContactType(ContactType.CAREGIVER);

        return contact;
    }
}
