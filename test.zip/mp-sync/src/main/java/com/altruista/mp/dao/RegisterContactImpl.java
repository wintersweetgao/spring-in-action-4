package com.altruista.mp.dao;

import com.altruista.mp.model.Contact;
import com.altruista.mp.model.ContactType;
import com.altruista.mp.model.MemberACL;
import com.altruista.mp.model.User;
import com.altruista.mp.services.UserService;
import com.altruista.mp.services.exceptions.ServiceException;
import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.*;

public class RegisterContactImpl extends BaseSyncImpl implements RegisterContact {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(RegisterContactImpl.class);

    @Value("${time.zone}")
    private String timeZone;
    @Value("${created.by}")
    private String createdBy;

    @Autowired
    private UserService userService;
    private BCryptPasswordEncoder encoder;

    private String clientName;
    private String clientId;
    HashMap<String, String> registrationStatuses = null;

    public RegisterContactImpl() {
        encoder = new BCryptPasswordEncoder(8);
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public boolean isValidEmailAddress(String email) {
        if (email == null)
            return false;
        else
            return EmailValidator.getInstance().isValid(email);
    }

    public void register(Contact contact, String memberId) {
        LOGGER.debug("Checking registration for: " + contact.getRefId() + ", status: " + contact.getRegistrationStatus());
        if (contact.getRegistrationStatus() == null)
            return;

        // NOTE: Used to include Pending Activation
        // || contact.getRegistrationStatus().equalsIgnoreCase("Pending Activation")
        if (contact.getRegistrationStatus().equalsIgnoreCase("Required") ||
                contact.getRegistrationStatus().equalsIgnoreCase("Registration Required")) {

            List<User> users = userService.findByContactId(contact.getId());
            if (users == null || users.isEmpty()) {
                // register a new user
                String username = UUID.randomUUID().toString();

                User newUser = new User();
                newUser.setContactCode(contact.getContactCode());
                newUser.setSelectedMemberId(memberId);
                newUser.setContactId(contact.getId());
                newUser.setClientId(clientId);
                newUser.setUsername(username);
                newUser.setPassword(encoder.encode(contact.getContactCode()));
                newUser.setAccountNonExpired(true);
                newUser.setAccountNonLocked(true);
                newUser.setCredentialsNonExpired(true);
                newUser.setEnabled(true);
                newUser.setTimezone(timeZone.trim());
                newUser.setCreatedBy(createdBy.trim());

                // Grant User access to the specified member
                List<String> userAuths = new ArrayList<String>();
                userAuths.add("API");
                userAuths.add("HEALTH_RECORD");
                userAuths.add("MESSAGES");
                userAuths.add("EDIT_CAREPLAN");
                userAuths.add("MANAGE_CALENDAR");
                userAuths.add("HEALTH_TRACKERS");
                userAuths.add("HEALTH_TIPS");
                userAuths.add("FIND_PROVIDER");

                // assessment is only valid for members
                if (contact.getContactType() == ContactType.MEMBER)
                    userAuths.add("HEALTH_ASSESSMENT");

                MemberACL acl = new MemberACL(memberId, userAuths);
                List<MemberACL> acls = new ArrayList<MemberACL>();
                acls.add(acl);
                newUser.setMemberAuthorities(acls);

                try {
                    LOGGER.debug("Registering username: " + username);
                    userService.save(newUser, false);

                    // all new users are pending activation until they register
                    updateContactRegistrationStatus(contact, "Pending Activation");

                    // note: used to send email / letter notifications here
                } catch (ServiceException e) {
                    LOGGER.error("Exception while registering user: " + e);
                }
            } else {
                // activate an existing user
                User existing = users.get(0);
                try {
                    LOGGER.debug("Activating user: " + existing.getUsername());
                    existing.setEnabled(true);
                    existing.setUserLocked(false);
                    userService.save(existing, false);

                    updateContactRegistrationStatus(contact, "Pending Activation");

                } catch (ServiceException e) {
                    LOGGER.error("Exception while activating user: " + e);
                }
            }

        } else if (contact.getRegistrationStatus().equalsIgnoreCase("Pending Suspension") ||
                contact.getRegistrationStatus().equalsIgnoreCase("Suspended")) {
            List<User> users = userService.findByContactId(contact.getId());
            if (users != null && users.size() > 0) {
                User existing = users.get(0);
                try {
                    LOGGER.debug("Suspending user: " + existing.getUsername());
                    existing.setEnabled(false);
                    existing.setUserLocked(true);
                    userService.save(existing, false);

                    updateContactRegistrationStatus(contact, "Suspended");

                } catch (ServiceException e) {
                    LOGGER.error("Exception while suspending user: " + e);
                }
            }
        } else if (contact.getRegistrationStatus().equalsIgnoreCase("Pending Revoke") ||
                contact.getRegistrationStatus().equalsIgnoreCase("Revoked")) {
            List<User> users = userService.findByContactId(contact.getId());
            if (users != null && users.size() > 0) {
                User existing = users.get(0);
                try {
                    LOGGER.debug("Revoking user: " + existing.getUsername());
                    existing.setEnabled(false);
                    existing.setUserLocked(true);
                    userService.save(existing, false);

                    updateContactRegistrationStatus(contact, "Revoked");

                } catch (ServiceException e) {
                    LOGGER.error("Exception while revoking user: " + e);
                }
            }
        }
    }

    @Override
    public void updateContactRegistrationStatus(Contact contact, String status) {
        switch (contact.getContactType()) {
            case MEMBER:
                updateMemberRegistrationStatus(contact.getRefId(), status);
                break;
            case CAREGIVER:
                updateCareGiverRegistrationStatus(contact.getRefId(), status);
                break;
            default:
                // registration of other contact types is not supported,
                // silently ignore
                break;
        }
    }

    private void updateMemberRegistrationStatus(String refId, String status) {
        if (refId == null || refId.length() == 0) {
            LOGGER.warn("Unable to update member registration status, missing refId, skipping...");
            return;
        }

        long patientId = Long.parseLong(refId);

        try {
            String patientSQL =
                    "UPDATE PATIENT_DETAILS SET " +
                            " REGSTR_REQUIRED_ID = :statusId " +
                            " WHERE PATIENT_ID = :patientId";
            // NOTE: Avoid changing UPDATED_ON, otherwise this will sync back to Member Portal

            int registrationStatusId = getRegistrationStatusId(status);

            NamedParameterJdbcTemplate patientTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource addressNamedParameters =
                    new MapSqlParameterSource()
                            .addValue("statusId", registrationStatusId)
                            .addValue("patientId", patientId);
            int rows = patientTemplate.update(patientSQL, addressNamedParameters);

            if (rows == 1) {
                LOGGER.debug("PATIENT_DETAILS REGISTRATION => SQL [" + patientId + "]");
            } else if (rows > 1) {
                LOGGER.warn("PATIENT_DETAILS REGISTRATION => SQL [" + patientId + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update PATIENT_DETAILS REGISTRATION: " + patientId + ", no rows updated.");
            }
        } catch (Exception exc) {
            LOGGER.error("Unable to update PATIENT_DETAILS REGISTRATION: " + patientId + ", exception: " + exc);
        }
    }

    private void updateCareGiverRegistrationStatus(String refId, String status) {
        if (refId == null || refId.length() == 0) {
            LOGGER.warn("Unable to update caregiver registration status, missing refId, skipping...");
            return;
        }

        long careGiverId = Long.parseLong(refId);

        try {
            String patientSQL =
                    "UPDATE PATIENT_PRIMARY_CAREGIVER SET " +
                            " REGSTR_REQUIRED_ID = :statusId " +
                            " WHERE CARE_GIVER_ID = :careGiverId";
            // NOTE: Avoid changing UPDATED_ON, otherwise this will sync back to Member Portal

            int registrationStatusId = getRegistrationStatusId(status);

            NamedParameterJdbcTemplate patientTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource addressNamedParameters =
                    new MapSqlParameterSource()
                            .addValue("statusId", registrationStatusId)
                            .addValue("careGiverId", careGiverId);
            int rows = patientTemplate.update(patientSQL, addressNamedParameters);

            if (rows == 1) {
                LOGGER.debug("PATIENT_PRIMARY_CAREGIVER REGISTRATION => SQL [" + careGiverId + "]");
            } else if (rows > 1) {
                LOGGER.warn("PATIENT_PRIMARY_CAREGIVER REGISTRATION => SQL [" + careGiverId + "] updated " + rows + " rows.");
            } else {
                LOGGER.error("Unable to update PATIENT_PRIMARY_CAREGIVER REGISTRATION: " + careGiverId + ", no rows updated.");
            }
        } catch (Exception exc) {
            LOGGER.error("Unable to update PATIENT_PRIMARY_CAREGIVER REGISTRATION: " + careGiverId + ", exception: " + exc);
        }
    }


    private int getRegistrationStatusId(String status) {

        if (registrationStatuses == null) {
            String sql = "SELECT REGSTR_STATUS, REGSTR_REQUIRED_ID FROM MP_REGISTRATION_REQUIRED";
            NamedParameterJdbcTemplate ctTemplate = new NamedParameterJdbcTemplate(dataSource);
            Map<String, String> parms = new HashMap<String, String>();
            List<Map<String, Object>> list = ctTemplate.queryForList(sql, parms);

            registrationStatuses = new HashMap<String, String>();
            for (Map<String, Object> map : list) {
                registrationStatuses.put(map.get("REGSTR_STATUS").toString(), map.get("REGSTR_REQUIRED_ID").toString());
            }
        }

        int registrationStatusId = 1; // default to one
        if (registrationStatuses.containsKey(status))
            registrationStatusId = Integer.parseInt(registrationStatuses.get(status));
        else
            LOGGER.warn("Invalid registration status: " + status);

        return registrationStatusId;
    }


}
