package com.altruista.mp.dao;

import com.altruista.mp.model.AssessmentQuestion;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by mwixson on 4/21/15.
 */
public class AssessmentQuestionMapper implements RowMapper<AssessmentQuestion> {
    public AssessmentQuestion mapRow(ResultSet rs, int rowNum) throws SQLException {

        AssessmentQuestion question = new AssessmentQuestion();
        question.setRefId(rs.getString("QUESTION_ID"));
        question.setQuestion(rs.getString("QUESTION"));
        question.setOptionType(rs.getString("OPTION_TYPE"));
        question.setSequence(rs.getInt("QUESTION_NO"));
        question.setIsRequired(rs.getBoolean("REQUIRED_ANSWER"));

        return question;
    }
}
