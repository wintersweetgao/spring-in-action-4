package com.altruista.mp.dao;

import com.altruista.mp.model.Assessment;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AssessmentMapper {
    public static Assessment toAssessment(ResultSet rs) throws SQLException {
        Assessment assessment = new Assessment();
        assessment.setRefId(rs.getString("SCRIPT_ID"));
        assessment.setName(rs.getString("SCRIPT_NAME"));
        assessment.setDuration(rs.getLong("DURATION"));
        assessment.setScore(rs.getFloat("Score"));
        assessment.setNumOfQuestions(rs.getInt("NO_OF_QUESTION"));
        assessment.setActive(rs.getBoolean("IS_ACTIVE"));
        assessment.setRefCreatedOn(DateHelper.getDate(rs.getDate("CREATED_DATE")));
        assessment.setSyncedOn(DateTime.now());

        return assessment;
    }
}
