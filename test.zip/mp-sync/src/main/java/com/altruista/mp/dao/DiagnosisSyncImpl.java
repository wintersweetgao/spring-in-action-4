package com.altruista.mp.dao;

import com.altruista.mp.model.Diagnosis;
import com.altruista.mp.model.Member;
import com.altruista.mp.model.SyncLog;
import com.altruista.mp.model.SyncLogLevelType;
import com.altruista.mp.services.DiagnosisService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class DiagnosisSyncImpl extends BaseSyncImpl implements DiagnosisSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(DiagnosisSyncImpl.class);

    @Autowired
    private DiagnosisService diagnosisService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + "SELECT DISTINCT V.PATIENT_ID "
                            + "FROM PATIENT_VISIT_DIAGNOSIS D, PATIENT_VISIT V "
                            + "WHERE V.PATIENT_VISIT_ID = D.PATIENT_VISIT_ID "
                            + " AND (D.CREATED_ON >= :runDate OR D.UPDATED_ON >= :runDate) ";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("diagnosis");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT V.PATIENT_ID,DESCRIPTION,DIAGNOSIS_CODE,SOURCE_TYPE, "
                        + " COUNT(*) AS RANK, MIN(V.VISIT_DATE) AS MIN_VISIT_DATE "
                        + "FROM PATIENT_VISIT_DIAGNOSIS D, PATIENT_VISIT V "
                        + "WHERE V.PATIENT_VISIT_ID = D.PATIENT_VISIT_ID "
                        + " AND (D.CREATED_ON >= ? OR D.UPDATED_ON >= ?) "
                        + " AND PATIENT_ID = ? "
                        + " GROUP BY V.PATIENT_ID,DESCRIPTION,DIAGNOSIS_CODE,SOURCE_TYPE";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate(), runDate.toDate(), patientId},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        postChanges(member, rs);
                    }

                });
    }

    private void postChanges(Member member, ResultSet rs) throws SQLException {

        Diagnosis diagnosis = DiagnosisMapper.toDiagnosis(rs);

        diagnosis.setMemberId(member.getId());

        // Save the DIAGNOSIS
        String diagnosisId = saveDiagnosisToMongodb(diagnosis);

        LOGGER.debug("DIAGNOSIS: Mongodb ["
                + diagnosisId + "] <= SQL [ "
                + diagnosis.getRefId() + " ]");
    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {

        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT DISTINCT V.PATIENT_ID,DIAGNOSIS_CODE "
                        + "FROM PATIENT_VISIT_DIAGNOSIS D, PATIENT_VISIT V "
                        + "WHERE V.PATIENT_VISIT_ID = D.PATIENT_VISIT_ID AND "
                        + "D.DELETED_ON >= ?";

        template.setFetchSize(fetchsize); // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()},
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        String key = String.format("%s|%s", rs.getString("PATIENT_ID"), rs.getString("DIAGNOSIS_CODE"));
                        delete(key);
                    }
                });
    }

    private void delete(String refId) {
        List<Diagnosis> diags = diagnosisService.findIdByRefId(refId);
        if (diags != null && diags.size() > 0)
            diagnosisService.delete(diags.get(0).getId());
    }

    private String saveDiagnosisToMongodb(Diagnosis diagnosis) {
        if (diagnosis.getRefId() != null) {
            List<Diagnosis> existing = diagnosisService.findIdByRefId(diagnosis.getRefId());

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                diagnosis.setId(existing.get(0).getId());
                diagnosis.setVersion(existing.get(0).getVersion());
            } else
                diagnosis.setId(UUID.randomUUID().toString());
        } else
            diagnosis.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        diagnosis.setSyncedOn(DateTime.now());
        diagnosisService.setSyncEnabled(false);*/

        return diagnosisService.save(diagnosis, false);
    }

}
