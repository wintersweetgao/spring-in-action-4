package com.altruista.mp.dao;

import com.altruista.mp.model.*;
import com.altruista.mp.services.ContactService;
import com.altruista.mp.services.MemberContactService;
import com.altruista.mp.services.MemberService;
import com.altruista.mp.services.SyncLogService;
import com.altruista.mp.utils.DateHelper;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class PhysicianSyncImpl extends BaseSyncImpl implements PhysicianSync {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(PhysicianSyncImpl.class);

    @Autowired
    private ContactService contactService;
    @Autowired
    private MemberService memberService;
    @Autowired
    private MemberContactService memberContactService;
    @Autowired
    private SyncLogService syncLogService;

    @Override
    public void loadPatientIds(DateTime runDate) {
        try {
            String tempSQL =
                    "INSERT INTO MP_TEMP(PATIENT_ID) "
                            + " SELECT DISTINCT PP.PATIENT_ID"
                            + " FROM PATIENT_PHYSICIAN PP, CARE_TEAM T, PHYSICIAN_DEMOGRAPHY P"
                            + " WHERE PP.CARE_TEAM_ID = T.CARE_TEAM_ID"
                            + " AND T.CARE_TEAM_TYPE IN ('Provider', 'External Care Team')"
                            + " AND (P.CREATED_ON >= :runDate OR P.UPDATED_ON >= :runDate OR PP.CREATED_ON >= :runDate OR PP.UPDATED_ON >= :runDate)"
                            + " AND PP.PHYSICIAN_ID = P.PHYSICIAN_ID"
                            + " AND PP.PHYSICIAN_ID IN ("
                            + " SELECT CASE WHEN ISNUMERIC(CONFIG_VAL) = 1 THEN CONFIG_VAL ELSE -1 END AS PROVIDER_ID"
                            + " FROM CFG_ADMIN_CONFIG  CAC INNER JOIN CFG_USER_CONFIG CUS ON CUS.CFG_ADMIN_CONFIG_ID=CAC.CFG_ADMIN_CONFIG_ID"
                            + " INNER JOIN CFG_CONFIGURATION CC ON CC.CFG_ADMIN_CONFIG_ID=CUS.CFG_ADMIN_CONFIG_ID"
                            + " INNER JOIN CFG_ADMIN_CONFIG_TYPE CT ON CT.CFG_ADMIN_CONFIG_TYPE_ID=CC.CFG_ADMIN_CONFIG_TYPE_ID"
                            + " INNER JOIN PHYSICIAN_DEMOGRAPHY PD ON PD.PHYSICIAN_ID=IIF( ISNUMERIC(CONFIG_VAL) = 1, CONFIG_VAL, -1)"
                            + " WHERE CT.CONFIG_NAME = 'PROVIDER'"
                            + " UNION "
                            + " SELECT DISTINCT PROVIDER_ID AS PROVIDER_ID"
                            + " FROM CFG_ADMIN_CONFIG  CAC INNER JOIN CFG_USER_CONFIG CUS ON CUS.CFG_ADMIN_CONFIG_ID=CAC.CFG_ADMIN_CONFIG_ID"
                            + " INNER JOIN CFG_CONFIGURATION CC ON CC.CFG_ADMIN_CONFIG_ID=CUS.CFG_ADMIN_CONFIG_ID"
                            + " INNER JOIN CFG_ADMIN_CONFIG_TYPE CT ON CT.CFG_ADMIN_CONFIG_TYPE_ID=CC.CFG_ADMIN_CONFIG_TYPE_ID"
                            + " INNER JOIN PROVIDER_NETWORK PN ON PN.TAX_ID=CONFIG_VAL"
                            + " INNER JOIN PHYSICIAN_DEMOGRAPHY PD ON PD.PHYSICIAN_ID=PROVIDER_ID"
                            + " WHERE CT.CONFIG_NAME = 'TAX ID')";

            NamedParameterJdbcTemplate listTemplate = new NamedParameterJdbcTemplate(dataSource);
            SqlParameterSource listParameters =
                    new MapSqlParameterSource()
                            .addValue("runDate", runDate.toDate());
            listTemplate.update(tempSQL, listParameters);

        } catch (Exception exc) {
            SyncLog sl = new SyncLog();
            sl.setLevel(SyncLogLevelType.ERROR);
            sl.setObjectName("physician");
            sl.setAction("loadPatientIds");
            sl.setDescription("Unable to load MP_TEMP table");
            syncLogService.save(sl);

            LOGGER.error(sl.getDescription() + ", exception: " + exc);
        }
    }

    @Override
    public void applyRemoteChanges(long patientId, final Member member, DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT P.PHYSICIAN_ID,PHYSICIAN_CODE, "
                        + " NAME_PREFIX,FIRST_NAME,MIDDLE_NAME,LAST_NAME,NAME_SUFFIX, "
                        + " GENDER,ADDRESS,CITY,STATE,COUNTRY,ZIP, "
                        + " WORK_PHONE,HOME_PHONE,CELL_PHONE,FAX,EMAIL,DIRECT_EMAIL,P.CREATED_ON, "
                        + " PRIMARY_LANGUAGE,ETHNICITY_ID,PROVIDER_NAME,STATUS, "
                        + " PP.PATIENT_ID,ISNULL(PRIMARY_BEHAVIORAL,0) AS IS_BEHAVIORAL, "
                        + " PP.START_DATE, PP.END_DATE, PP.IS_ACTIVE, ISNULL(IS_PCP,0) AS IS_PCP "
                        + " FROM PATIENT_PHYSICIAN PP, CARE_TEAM T, PHYSICIAN_DEMOGRAPHY P"
                        + " WHERE PP.PATIENT_ID = ?"
                        + " AND PP.PHYSICIAN_ID = P.PHYSICIAN_ID"
                        + " AND PP.CARE_TEAM_ID = T.CARE_TEAM_ID"
                        + " AND T.CARE_TEAM_TYPE IN ('Provider', 'External Care Team')"
                        + " AND (P.CREATED_ON >= ? OR P.UPDATED_ON >= ? OR PP.CREATED_ON >= ? OR PP.UPDATED_ON >= ?)"
                        + " AND PP.PHYSICIAN_ID IN ("
                        + " SELECT CASE WHEN ISNUMERIC(CONFIG_VAL) = 1 THEN CONFIG_VAL ELSE -1 END AS PROVIDER_ID"
                        + " FROM CFG_ADMIN_CONFIG  CAC INNER JOIN CFG_USER_CONFIG CUS ON CUS.CFG_ADMIN_CONFIG_ID=CAC.CFG_ADMIN_CONFIG_ID"
                        + " INNER JOIN CFG_CONFIGURATION CC ON CC.CFG_ADMIN_CONFIG_ID=CUS.CFG_ADMIN_CONFIG_ID"
                        + " INNER JOIN CFG_ADMIN_CONFIG_TYPE CT ON CT.CFG_ADMIN_CONFIG_TYPE_ID=CC.CFG_ADMIN_CONFIG_TYPE_ID"
                        + " INNER JOIN PHYSICIAN_DEMOGRAPHY PD ON PD.PHYSICIAN_ID=IIF( ISNUMERIC(CONFIG_VAL) = 1, CONFIG_VAL, -1)"
                        + " WHERE CT.CONFIG_NAME = 'PROVIDER'"
                        + " UNION "
                        + " SELECT DISTINCT PROVIDER_ID AS PROVIDER_ID"
                        + " FROM CFG_ADMIN_CONFIG  CAC INNER JOIN CFG_USER_CONFIG CUS ON CUS.CFG_ADMIN_CONFIG_ID=CAC.CFG_ADMIN_CONFIG_ID"
                        + " INNER JOIN CFG_CONFIGURATION CC ON CC.CFG_ADMIN_CONFIG_ID=CUS.CFG_ADMIN_CONFIG_ID"
                        + " INNER JOIN CFG_ADMIN_CONFIG_TYPE CT ON CT.CFG_ADMIN_CONFIG_TYPE_ID=CC.CFG_ADMIN_CONFIG_TYPE_ID"
                        + " INNER JOIN PROVIDER_NETWORK PN ON PN.TAX_ID=CONFIG_VAL"
                        + " INNER JOIN PHYSICIAN_DEMOGRAPHY PD ON PD.PHYSICIAN_ID=PROVIDER_ID"
                        + " WHERE CT.CONFIG_NAME = 'TAX ID')";

        template.setFetchSize(fetchsize);   // process 100 rows at a time
        template.query(sql, new Object[]{patientId,
                runDate.toDate(), runDate.toDate(),
                runDate.toDate(), runDate.toDate()}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                postChanges(rs);
            }
        });
    }

    private void postChanges(ResultSet rs) throws SQLException {
        Contact contact = PhysicianMapper.toContact(rs, false);

        String contactId = savePhysicianDemographyToMongodb(contact);
        LOGGER.debug("PHYSICIAN_DEMOGRAPHY: Mongodb [" + contactId + "] <= SQL [" + contact.getRefId() + "]");

        MemberContact mc = new MemberContact(ContactType.PHYSICIAN);
        String key = String.format("%s|%s", rs.getString("PHYSICIAN_ID"), rs.getString("PATIENT_ID"));
        mc.setRefId(key);

        // Determine if primary care physician
        if (rs.getBoolean("IS_PCP"))
            mc.setPrimary(true);
        else
            mc.setPrimary(false);

        // Determine if active
        if (rs.getBoolean("IS_ACTIVE"))
            mc.setActive(true);
        else
            mc.setActive(false);

        if (rs.getString("START_DATE") != null) {
            mc.setStartOn(DateHelper.getDate(rs.getDate("START_DATE")));
        }

        if (rs.getString("END_DATE") != null) {
            mc.setEndOn(DateHelper.getDate(rs.getDate("END_DATE")));
        }

        // Lookup Physician Contact Id
        String providerName = null;
        List<Contact> physicians = contactService.findByRefIdAndContactType(
                rs.getString("PHYSICIAN_ID"), ContactType.PHYSICIAN
        );
        if (physicians.size() > 0) {
            mc.setContactId(physicians.get(0).getId());

            if (physicians.get(0).getFirstName() != null &&
                    physicians.get(0).getLastName() != null) {
                providerName = String.format("%s %s",
                        physicians.get(0).getFirstName(),
                        physicians.get(0).getLastName());
            } else {
                providerName = physicians.get(0).getCompany();
            }
        }

        // Lookup Member Id
        List<Member> members = memberService.findIdByRefId(
                rs.getString("PATIENT_ID")
        );
        if (members.size() > 0) {
            mc.setMemberId(members.get(0).getId());

            // if this is a primary provider
            // set the primary medical or behavioral provider
            if (mc.isPrimary()) {
                Member member = members.get(0);

                Boolean behavioral = rs.getBoolean("IS_BEHAVIORAL");
                if (behavioral != null && behavioral) {
                    member.setPrimaryBehavioralProvider(providerName);
                } else {
                    member.setPrimaryMedicalProvider(providerName);
                }
                memberService.save(member, false);
            }
        }

        // If member and physician found, save the relationship
        if (members.size() > 0 && physicians.size() > 0) {
            // FUTURE USE: notify the physician, if appropriate
            // contactReg.register(physicians.get(0), mc.getMemberId());

            String mcId = saveMemberContactToMongodb(mc);
            LOGGER.debug("PATIENT_PHYSICIAN: Mongodb [" + mcId + "] <= SQL [" + mc.getRefId() + "]");
        }

    }

    @Override
    public void applyRemoteDeletes(final DateTime runDate) {
        JdbcTemplate template = new JdbcTemplate(dataSource);
        String sql =
                "SELECT DISTINCT PHYSICIAN_ID, PP.PATIENT_ID "
                        + "FROM PATIENT_PHYSICIAN PP, CARE_TEAM T "
                        + "WHERE PP.DELETED_ON >= ? "
                        + " AND PP.CARE_TEAM_ID = T.CARE_TEAM_ID "
                        + " AND T.CARE_TEAM_TYPE IN ('Provider', 'External Care Team')";

        template.setFetchSize(fetchsize);   // process 100 rows at a time
        template.query(sql, new Object[]{runDate.toDate()}, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                String key = String.format("%s|%s", rs.getString("PHYSICIAN_ID"), rs.getString("PATIENT_ID"));
                deleteMemberContact(key);
            } // processRow
        }); // query
    }

    private void deleteMemberContact(String refId) {
        // NOTE: DELETED_ON not provided for PHYSICIAN_DEMOGRAPHY?

        List<MemberContact> mcs = memberContactService.findIdByRefIdAndContactType(
                refId, ContactType.PHYSICIAN);
        if (mcs != null && mcs.size() > 0) {
            memberContactService.delete(mcs.get(0).getId());
            LOGGER.debug("PHYSICIAN_DEMOGRAPHY: Deleting MemberContact: " + mcs.get(0).getId());
        }
    }

    private String savePhysicianDemographyToMongodb(Contact contact) {
        // see if contact already exists
        if (contact.getRefId() != null) {
            List<Contact> existing = contactService.findIdByRefIdAndContactType(contact.getRefId(), ContactType.PHYSICIAN);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                contact.setId(existing.get(0).getId());
                contact.setVersion(existing.get(0).getVersion());
            } else
                contact.setId(UUID.randomUUID().toString());
        } else
            contact.setId(UUID.randomUUID().toString());

        return contactService.save(contact, false);
    }

    private String saveMemberContactToMongodb(MemberContact mc) {
        // see if contact already exists
        if (mc.getRefId() != null) {
            List<MemberContact> existing = memberContactService.findIdByRefIdAndContactType(mc.getRefId(), ContactType.PHYSICIAN);

            // set the id so that cb knows to update it
            if (existing != null && !existing.isEmpty()) {
                mc.setId(existing.get(0).getId());
                mc.setVersion(existing.get(0).getVersion());
            } else
                mc.setId(UUID.randomUUID().toString());
        } else
            mc.setId(UUID.randomUUID().toString());

       /* // IMPORTANT: set sync time to avoid sending it back to SQL
        mc.setSyncedOn(DateTime.now());
        memberContactService.setSyncEnabled(false);*/

        return memberContactService.save(mc, false);
    }

}
