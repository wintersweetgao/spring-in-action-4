package com.altruista.mp.model;

import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * Created by mwixson on 6/19/14.
 */
@Document
public class Visit extends MPModel {
    @Field
    private String memberId;
    @Field
    private String reason;
    @Field
    private String providerId;
    @Field
    private String providerName;
    @Field
    private Address providerAddress;
    @Field
    private String status;
    @Field
    private String visitType;
    @Field
    private DateTime visitOn;
    @Field
    private float paidAmount;
    @Field
    private String source;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getProviderName() {
        return providerName;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public Address getProviderAddress() {
        return providerAddress;
    }

    public void setProviderAddress(Address providerAddress) {
        this.providerAddress = providerAddress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVisitType() {
        return visitType;
    }

    public void setVisitType(String visitType) {
        this.visitType = visitType;
    }

    public DateTime getVisitOn() {
        return visitOn;
    }

    public void setVisitOn(DateTime visitOn) {
        this.visitOn = visitOn;
    }

    public float getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(float paidAmount) {
        this.paidAmount = paidAmount;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

}
