package com.altruista.mp.model;

import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Message represents communication from a sender to a recipient.   The senderType and recipientType identify
 * the type of sender and recipient, such as:  PATIENT, CAREGIVER, COACH or PHYSICIAN.
 * <p/>
 * Messages can be assign a priority of: LOW, MEDIUM, HIGH, CRITICAL
 *
 * @author Matt Wixson
 * @version %I%, %G%
 */
@Document
@XmlRootElement(name = "message")
public class Message extends MPModel {
    @Field
    private MessageType messageType;
    @Field
    private String senderId;
    @Field
    private List<String> recipientIds;
    @Field
    private String memberId;
    @Field
    private String subject;
    @Field
    private String careTeam;
    @Field
    private String body;
    @Field
    private MessagePriorityType messagePriority;
    @Field
    private HealthSummaryType healthSummary;

    /**
     * location is the "folder" where the message resides, such as "INBOX", "ARCHIVE", etc.
     */
    @Field
    private String location;
    /**
     * viewed indicates whether or not the message has been viewed by the recipient
     */
    @Field
    private boolean viewed;
    @Field
    private DateTime sentOn;
    @Field
    private DateTime viewedOn;

    public DateTime getViewedOn() {
        return viewedOn;
    }

    public void setViewedOn(DateTime viewedOn) {
        this.viewedOn = viewedOn;
    }

    public MessageType getMessageType() {
        return messageType;
    }

    public void setMessageType(MessageType messageType) {
        this.messageType = messageType;
    }

    public DateTime getSentOn() {
        return sentOn;
    }

    public void setSentOn(DateTime sentOn) {
        this.sentOn = sentOn;
    }

    public HealthSummaryType getHealthSummary() {
        return healthSummary;
    }

    public void setHealthSummary(HealthSummaryType healthSummary) {
        this.healthSummary = healthSummary;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public List<String> getRecipientIds() {
        if (recipientIds == null)
            recipientIds = new ArrayList<String>();
        return recipientIds;
    }

    public void setRecipientIds(List<String> recipientIds) {
        this.recipientIds = recipientIds;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getCareTeam() {
        return careTeam;
    }

    public void setCareTeam(String careTeam) {
        this.careTeam = careTeam;
    }

    public MessagePriorityType getMessagePriority() {
        return messagePriority;
    }

    public void setMessagePriority(MessagePriorityType messagePriority) {
        this.messagePriority = messagePriority;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isViewed() {
        return viewed;
    }

    public void setViewed(boolean viewed) {
        this.viewed = viewed;
    }
}
