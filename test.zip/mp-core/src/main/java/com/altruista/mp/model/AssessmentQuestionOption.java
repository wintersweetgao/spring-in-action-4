package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 2/12/15.
 */
@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssessmentQuestionOption {
    @Field
    private String refId;
    @Field
    private String optionText;
    @Field
    private String optionType;
    @Field
    private int sequence;
    @Field
    private String nextQuestionRefId;
    @Field
    private int nextQuestionSequence;
    @Field
    private AssessmentVariable variable;
    @Field
    private String detailRefId;
    @Field
    private String value;
    @Field
    List<AssessmentQuestionSubOption> subOptions;

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getOptionText() {
        return optionText;
    }

    public void setOptionText(String optionText) {
        this.optionText = optionText;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public String getNextQuestionRefId() {
        return nextQuestionRefId;
    }

    public void setNextQuestionRefId(String nextQuestionRefId) {
        this.nextQuestionRefId = nextQuestionRefId;
    }

    public int getNextQuestionSequence() {
        return nextQuestionSequence;
    }

    public void setNextQuestionSequence(int nextQuestionSequence) {
        this.nextQuestionSequence = nextQuestionSequence;
    }

    public AssessmentVariable getVariable() {
        return variable;
    }

    public void setVariable(AssessmentVariable variable) {
        this.variable = variable;
    }

    public List<AssessmentQuestionSubOption> getSubOptions() {
        if (subOptions == null)
            subOptions = new ArrayList<AssessmentQuestionSubOption>();
        return subOptions;
    }

    public void setSubOptions(List<AssessmentQuestionSubOption> subOptions) {
        this.subOptions = subOptions;
    }

    public String getDetailRefId() {
        return detailRefId;
    }

    public void setDetailRefId(String detailRefId) {
        this.detailRefId = detailRefId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
