package com.altruista.mp.model;

import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/*
 * Copyright 2015 Altruista Health. All Rights Reserved
 * Developed by Prateek on 10/19/15
 */
@Document
@XmlRootElement(name = "pushNotification")
public class PushNotificationRegistration extends MPModel {
    @Field
    private String deviceOS;
    @Field
    private String deviceToken;
    @Field
    private String regID;
    @Field
    private String contactId;
    @Transient
    private String messageText;
    @Transient
    private int badge;

    public String getDeviceOS() {
        return deviceOS;
    }

    public void setDeviceOS(String deviceOS) {
        this.deviceOS = deviceOS;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public String getRegID() {
        return regID;
    }

    public void setRegID(String regID) {
        this.regID = regID;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public int getBadge() {
        return badge;
    }

    public void setBadge(int badge) {
        this.badge = badge;
    }
}