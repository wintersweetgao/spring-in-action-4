package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document
public class ActionStep extends MPModel {
    @Field
    private String goalId;
    @Field
    private String goalGroup;
    @Field
    private String memberId;
    @Field
    private String priority;
    @Field
    private String lob;
    @Field
    private String condition;
    @Field
    private String step;            // member alias
    @Field
    private String intervention;    // internal name
    @Field
    private String status;
    @Field
    private String memberStatus;
    @Field
    private Boolean signedOff;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime signedOffOn;
    @Field
    private String notes;
    @Field
    private String term;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime startOn;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime endOn;

    public String getGoalId() {
        return goalId;
    }

    public void setGoalId(String goalId) {
        this.goalId = goalId;
    }

    public String getGoalGroup() {
        return goalGroup;
    }

    public void setGoalGroup(String goalGroup) {
        this.goalGroup = goalGroup;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getIntervention() {
        return intervention;
    }

    public void setIntervention(String intervention) {
        this.intervention = intervention;
    }

    public Boolean getSignedOff() {
        return signedOff;
    }

    public void setSignedOff(Boolean signedOff) {
        this.signedOff = signedOff;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMemberStatus() {
        return memberStatus;
    }

    public void setMemberStatus(String memberStatus) {
        this.memberStatus = memberStatus;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String comment) {
        this.notes = comment;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public DateTime getSignedOffOn() {
        return signedOffOn;
    }

    public void setSignedOffOn(DateTime signedOffOn) {
        this.signedOffOn = signedOffOn;
    }

    public DateTime getStartOn() {
        return startOn;
    }

    public void setStartOn(DateTime startOn) {
        this.startOn = startOn;
    }

    public DateTime getEndOn() {
        return endOn;
    }

    public void setEndOn(DateTime endOn) {
        this.endOn = endOn;
    }
}
