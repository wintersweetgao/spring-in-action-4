package com.altruista.mp.model;

/**
 * Created by mwixson on 10/16/14.
 */

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.UUID;

/**
 * Created by mwixson on 6/19/14.
 */
@Document
@XmlRootElement(name = "allergy")
public class AllergySensitivity extends MPModel {
    @Field
    private String memberId;
    @Field
    private String medicationCode;
    @Field
    private String name;

    public AllergySensitivity(String refId, String memberId, String medicationCode, String name) {
        super(UUID.randomUUID().toString(), refId);
        this.memberId = memberId;
        this.medicationCode = medicationCode;
        this.name = name;
    }

    public AllergySensitivity(String memberId, String name) {
        super();
        this.memberId = memberId;
        this.name = name;
    }

    public AllergySensitivity() {
        // default constructor for convenience
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMedicationCode() {
        return medicationCode;
    }

    public void setMedicationCode(String medicationCode) {
        this.medicationCode = medicationCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}