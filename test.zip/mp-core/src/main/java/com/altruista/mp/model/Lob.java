package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 10/8/15.
 */
@Document
@XmlRootElement(name = "lob")
public class Lob extends MPModel {
    @Field
    private String memberId;
    @Field
    private String name;
    @Field
    private Boolean active;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime startOn;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime endOn;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public DateTime getStartOn() {
        return startOn;
    }

    public void setStartOn(DateTime startOn) {
        this.startOn = startOn;
    }

    public DateTime getEndOn() {
        return endOn;
    }

    public void setEndOn(DateTime endOn) {
        this.endOn = endOn;
    }
}
