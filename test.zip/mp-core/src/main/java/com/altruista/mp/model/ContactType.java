package com.altruista.mp.model;

public enum ContactType {
    MEMBER, CAREGIVER, CARECOACH, PHYSICIAN, PROVIDER
}
