package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 5/22/15.
 */
@Document
@XmlRootElement(name = "syncLog")
public class SyncLog extends MPModel {
    @Field
    private String objectName;
    @Field
    private String objectId;
    @Field
    private String memberId;
    @Field
    private String action;
    @Field
    private SyncLogLevelType level;
    @Field
    private String description;
    @Field
    private String details;

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public SyncLogLevelType getLevel() {
        return level;
    }

    public void setLevel(SyncLogLevelType level) {
        this.level = level;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

}
