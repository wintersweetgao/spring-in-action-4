package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 9/24/15.
 */
@Document
@XmlRootElement(name = "index")
public class MemberIndex extends MPModel {
    @Field
    private String memberId;
    @Field
    private String indexName;
    @Field
    private String indexValue;
    @Field
    private String indexType;

    public MemberIndex(String memberId, String name, String value) {
        this.memberId = memberId;
        this.indexName = name;
        this.indexValue = value;
        indexType = "P";    // plain
    }

    public MemberIndex(String memberId, String name, String value, String indexType) {
        this.memberId = memberId;
        this.indexName = name;
        this.indexValue = value;
        this.indexType = indexType;
    }

    public MemberIndex() {
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public String getIndexValue() {
        return indexValue;
    }

    public void setIndexValue(String indexValue) {
        this.indexValue = indexValue;
    }

    public String getIndexType() {
        return indexType;
    }

    public void setIndexType(String indexType) {
        this.indexType = indexType;
    }
}
