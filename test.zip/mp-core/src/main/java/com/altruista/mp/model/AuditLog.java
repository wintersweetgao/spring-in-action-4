package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 7/17/14.
 */
@Document
@XmlRootElement(name = "auditLog")
public class AuditLog extends MPModel {
    @Field
    private String userName;
    @Field
    private String memberId;
    @Field
    private String description;
    @Field
    private String userIpAddress;
    @Field
    private String action;
    @Field
    private String actionMethod;
    @Field
    private String status;
    @Field
    private long runtimeMillis;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserIpAddress() {
        return userIpAddress;
    }

    public void setUserIpAddress(String userIpAddress) {
        this.userIpAddress = userIpAddress;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getActionMethod() {
        return actionMethod;
    }

    public void setActionMethod(String actionMethod) {
        this.actionMethod = actionMethod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getRuntimeMillis() {
        return runtimeMillis;
    }

    public void setRuntimeMillis(long runtimeMillis) {
        this.runtimeMillis = runtimeMillis;
    }
}
