package com.altruista.mp.model;

import java.io.Serializable;

/**
 * Developed by Prateek on 06/02/15
 */
public class Claim implements Serializable {
    private static final long serialVersionUID = 3978848597488738176L;

    private String claimType;
    private String claimValue;

    public Claim(String claimType, String claimValue) {
        super();
        this.claimType = claimType;
        this.claimValue = claimValue;
    }

    public String getClaimType() {
        return claimType;
    }

    public void setClaimType(String claimType) {
        this.claimType = claimType;
    }

    public String getClaimValue() {
        return claimValue;
    }

    public void setClaimValue(String claimValue) {
        this.claimValue = claimValue;
    }

    @Override
    public String toString() {
        return "Claim [claimType=" + claimType + ", claimValue=" + claimValue + "]";
    }
}
