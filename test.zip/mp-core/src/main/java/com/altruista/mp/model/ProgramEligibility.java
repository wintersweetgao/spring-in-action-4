package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 10/2/15.
 */
@Document
@XmlRootElement(name = "eligibility")
public class ProgramEligibility extends MPModel {
    @Field
    String programName;
    @Field
    List<String> lobs;
    @Field
    List<String> clientRefIds;

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public List<String> getLobs() {
        if (lobs == null)
            lobs = new ArrayList<String>();

        return lobs;
    }

    public void setLobs(List<String> lobs) {
        this.lobs = lobs;
    }

    public List<String> getClientRefIds() {
        if (clientRefIds == null)
            clientRefIds = new ArrayList<String>();

        return clientRefIds;
    }

    public void setClientRefIds(List<String> clientRefIds) {
        this.clientRefIds = clientRefIds;
    }
}
