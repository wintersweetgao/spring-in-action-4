package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document
public class Goal extends MPModel {
    @Field
    private String memberId;
    @Field
    private String goal;
    @Field
    private String internalGoal;
    @Field
    private String status;
    @Field
    private String notes;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime startOn;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime endOn;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getInternalGoal() {
        return internalGoal;
    }

    public void setInternalGoal(String internalGoal) {
        this.internalGoal = internalGoal;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public DateTime getStartOn() {
        return startOn;
    }

    public void setStartOn(DateTime startOn) {
        this.startOn = startOn;
    }

    public DateTime getEndOn() {
        return endOn;
    }

    public void setEndOn(DateTime endOn) {
        this.endOn = endOn;
    }
}
