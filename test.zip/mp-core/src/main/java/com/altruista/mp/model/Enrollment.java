package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 9/21/15.
 */
@Document
@XmlRootElement(name = "enrollment")
public class Enrollment extends Contact {
    @Field
    private String memberId;
    @Field
    private String ssn;
    @Field
    private String refugeeNumber;
    @Field
    private String itin;
    @Field
    private String programName;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getRefugeeNumber() {
        return refugeeNumber;
    }

    public void setRefugeeNumber(String refugeeNumber) {
        this.refugeeNumber = refugeeNumber;
    }

    public String getItin() {
        return itin;
    }

    public void setItin(String itin) {
        this.itin = itin;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }
}
