package com.altruista.mp.model;

/**
 * Created by mwixson on 1/12/15.
 */
public enum MessageType {
    INTERNAL, DIRECT
}
