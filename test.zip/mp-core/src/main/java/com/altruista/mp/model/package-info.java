/**
 * @author mwixson
 */
/**
 * @author mwixson
 *
 */
@javax.xml.bind.annotation.XmlSchema(
        namespace = "http://www.altruista.com/mp/model/1.0",
        elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED
        //attributeFormDefault = javax.xml.bind.annotation.XmlNsForm.UNQUALIFIED
)

package com.altruista.mp.model;