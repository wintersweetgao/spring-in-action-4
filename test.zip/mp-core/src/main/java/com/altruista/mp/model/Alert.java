package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

@Document
@XmlRootElement(name = "Alert")
public class Alert extends MPModel {
    @Field
    private String memberId;
    @Field
    private String messageCode;
    @Field
    private String message;
    @Field
    private String urlMessageCode;
    @Field
    private String urlMessage;
    @Field
    private String url;
    @Field
    private Integer count;
    @Field
    private String source;
    @Field
    private boolean viewed;

    public Alert() {
        // empty constructor to make it easier to instantiate
    }

    public Alert(String memberId, String messageCode, String source, Integer count) {
        this.memberId = memberId;
        this.messageCode = messageCode;
        this.source = source;
        this.count = count;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(String messageCode) {
        this.messageCode = messageCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUrlMessageCode() {
        return urlMessageCode;
    }

    public void setUrlMessageCode(String urlMessageCode) {
        this.urlMessageCode = urlMessageCode;
    }

    public String getUrlMessage() {
        return urlMessage;
    }

    public void setUrlMessage(String urlMessage) {
        this.urlMessage = urlMessage;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public boolean isViewed() {
        return viewed;
    }

    public void setViewed(boolean viewed) {
        this.viewed = viewed;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
