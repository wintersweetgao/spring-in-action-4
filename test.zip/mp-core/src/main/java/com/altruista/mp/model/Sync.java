package com.altruista.mp.model;

import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 10/15/14.
 */
@Document
@XmlRootElement(name = "sync")
public class Sync extends MPModel {
    private DateTime sqlSyncedOn;

    public DateTime getSqlSyncedOn() {
        return sqlSyncedOn;
    }

    public void setSqlSyncedOn(DateTime sqlSyncedOn) {
        this.sqlSyncedOn = sqlSyncedOn;
    }
}
