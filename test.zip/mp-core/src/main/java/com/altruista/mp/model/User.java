package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.joda.time.DateTime;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* Mongo */
/* Jackson */

/**
 * User is used to track all users in the system including: Providers, Sponsors,
 * Members, etc.
 */

@Document
@XmlRootElement(name = "user")
public class User extends MPModel implements org.springframework.security.core.userdetails.UserDetails {
    @Field
    private String contactId;
    @Field
    private String contactCode;
    @Field
    private String username;
    @Field
    private String password;
    @Field
    private DateTime accessedOn;
    @Field
    private DateTime priorAccessedOn;
    @Field
    private int failedAccessAttempts;
    @Field
    private String selectedMemberId;
    @Field
    private boolean isUserLocked;

    // Spring Security
    @Field
    private boolean accountNonExpired;
    @Field
    private boolean accountNonLocked;
    @Field
    private boolean credentialsNonExpired;
    @Field
    private boolean ssoEnabled;
    @Field
    private boolean enabled;
    @Field
    private List<MemberACL> memberAuthorities;
    @Field
    private String timezone;

    @Transient
    private Contact contact;
    @Field
    private DateTime lastFailedAccessOn;
    @Field
    private List<QuestionAnswer> securityQuestionAnswers;
    @Field
    private List<Tile> tiles;

    public List<Tile> getTiles() {
        if (tiles == null)
            tiles = new ArrayList<Tile>();
        return tiles;
    }

    public void setTiles(List<Tile> tiles) {
        this.tiles = tiles;
    }

    public List<QuestionAnswer> getSecurityQuestionAnswers() {
        if (securityQuestionAnswers == null)
            securityQuestionAnswers = new ArrayList<QuestionAnswer>();
        return securityQuestionAnswers;
    }

    public void setSecurityQuestionAnswers(
            List<QuestionAnswer> securityQuestionAnswers) {
        this.securityQuestionAnswers = securityQuestionAnswers;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getContactCode() {
        return contactCode;
    }

    public void setContactCode(String contactCode) {
        this.contactCode = contactCode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isAccountNonExpired() {
        return this.accountNonExpired;
    }

    public void setAccountNonExpired(boolean isNotExpired) {
        this.accountNonExpired = isNotExpired;
    }

    public boolean isAccountNonLocked() {
        return this.accountNonLocked;
    }

    public void setAccountNonLocked(boolean isNotLocked) {
        this.accountNonLocked = isNotLocked;
    }

    public boolean isCredentialsNonExpired() {
        return this.credentialsNonExpired;
    }

    public void setCredentialsNonExpired(boolean isNotExpired) {
        this.credentialsNonExpired = isNotExpired;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean isEnabled) {
        this.enabled = isEnabled;
    }

    public void setIsUserLocked(boolean isUserLocked) {
        this.isUserLocked = isUserLocked;
    }

    public boolean isSsoEnabled() {
        return ssoEnabled;
    }

    public void setSsoEnabled(boolean ssoEnabled) {
        this.ssoEnabled = ssoEnabled;
    }

    public List<MemberACL> getMemberAuthorities() {
        return memberAuthorities;
    }

    public void setMemberAuthorities(List<MemberACL> memberAuthorities) {
        this.memberAuthorities = memberAuthorities;
    }

    public String getSelectedMemberId() {
        return selectedMemberId;
    }

    public void setSelectedMemberId(String selectedMemberId) {
        this.selectedMemberId = selectedMemberId;
    }

    public DateTime getAccessedOn() {
        return accessedOn;
    }

    public void setAccessedOn(DateTime accessedOn) {
        this.accessedOn = accessedOn;
    }

    public DateTime getPriorAccessedOn() {
        return priorAccessedOn;
    }

    public void setPriorAccessedOn(DateTime priorAccessedOn) {
        this.priorAccessedOn = priorAccessedOn;
    }

    public int getFailedAccessAttempts() {
        return failedAccessAttempts;
    }

    public void setFailedAccessAttempts(int failedAccessAttempts) {
        this.failedAccessAttempts = failedAccessAttempts;
    }

    /**
     * Determine if the user's role has the authority requested
     */
    @JsonIgnore
    public Collection<GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> list = new ArrayList<GrantedAuthority>();

        for (String authority : getAuthorityList(selectedMemberId)) {
            list.add(new SimpleGrantedAuthority(authority));
        }

        return list;
    }

    public List<String> getAuthorityList(String memberId) {
        List<String> authorities = new ArrayList<String>();

        // find the ACL for the selected member and return it
        for (MemberACL acl : getMemberAuthorities()) {

            if (acl.getMemberId().equals(selectedMemberId)) {
                authorities = acl.getAuthorities();
                break;
            }
        }

        // add contact type as a built-in role
        if (contact != null) {
            authorities.add(contact.getContactType().toString());
        }

        return authorities;
    }

    public List<String> getMemberIds() {
        List<String> memberIds = new ArrayList<String>();

        // find the ACL for the selected member and return it
        for (MemberACL acl : getMemberAuthorities()) {
            memberIds.add(acl.getMemberId());
        }
        return memberIds;
    }

    /**
     * Determine if the user is a member of the specified role
     */
    public boolean hasAuthority(String authority) {
        List<String> authorities = getAuthorityList(selectedMemberId);

        if (authorities != null) {
            for (String right : authorities) {
                if (right.equals(authority))
                    return true;
            }
        }

        return false;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public boolean isUserLocked() {
        return isUserLocked;
    }

    public void setUserLocked(boolean isUserLocked) {
        this.isUserLocked = isUserLocked;
    }

    public DateTime getLastFailedAccessOn() {
        return lastFailedAccessOn;
    }

    public void setLastFailedAccessOn(DateTime lastFailedAccessOn) {
        this.lastFailedAccessOn = lastFailedAccessOn;
    }

}