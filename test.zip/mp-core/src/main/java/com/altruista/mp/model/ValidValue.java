package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.UUID;

@Document
public class ValidValue extends MPModel {
    @Field
    private String name;
    @Field
    private String value;
    @Field
    private String description;

    public ValidValue() {
        super(UUID.randomUUID().toString());
    }

    public ValidValue(String refId, String name, String value, String description) {
        super(UUID.randomUUID().toString(), refId);
        this.name = name;
        this.value = value;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}