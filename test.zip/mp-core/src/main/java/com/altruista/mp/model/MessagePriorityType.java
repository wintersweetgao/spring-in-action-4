package com.altruista.mp.model;

public enum MessagePriorityType {
    LOW, MEDIUM, HIGH, CRITICAL
}
