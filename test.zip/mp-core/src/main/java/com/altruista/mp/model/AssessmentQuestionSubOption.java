package com.altruista.mp.model;

/**
 * Created by mwixson on 2/12/15.
 */

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * Created by mwixson on 2/12/15.
 */
@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssessmentQuestionSubOption {
    @Field
    private String refId;
    @Field
    private String optionText;
    @Field
    private String optionType;
    @Field
    private int sequence;
    @Field
    private String notes;
    @Field
    private AssessmentVariable variable;
    @Field
    private String detailRefId;
    @Field
    private String value;

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getOptionText() {
        return optionText;
    }

    public void setOptionText(String optionText) {
        this.optionText = optionText;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public AssessmentVariable getVariable() {
        return variable;
    }

    public void setVariable(AssessmentVariable variable) {
        this.variable = variable;
    }

    public String getDetailRefId() {
        return detailRefId;
    }

    public void setDetailRefId(String detailRefId) {
        this.detailRefId = detailRefId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
