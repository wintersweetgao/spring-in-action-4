package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
@Document
public class Tracker extends MPModel {
    @Field
    private String name;
    @Field
    private String categoryId;
    @Field
    private List<TrackerParameter> parameters;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public List<TrackerParameter> getParameters() {
        return parameters;
    }

    public void setParameters(List<TrackerParameter> parameters) {
        this.parameters = parameters;
    }
}
