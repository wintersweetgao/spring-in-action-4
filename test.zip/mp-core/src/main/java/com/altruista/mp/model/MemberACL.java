package com.altruista.mp.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 10/11/14.
 */
public class MemberACL {
    private String memberId;
    private List<String> authorities;

    public MemberACL(String memberId, List<String> authorities) {
        this.memberId = memberId;
        this.authorities = authorities;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public List<String> getAuthorities() {
        if (authorities == null)
            authorities = new ArrayList<String>();
        return authorities;
    }

    public void setAuthorities(List<String> authorities) {
        this.authorities = authorities;
    }

    public void removeAuthority(String authority) {
        if (authorities != null)
            authorities.remove(authority);
    }

    public void addAuthority(String authority) {
        // only add the authority if not present
        if (authorities != null && authorities.indexOf(authority) == -1) {
            authorities.add(authority);
        }
    }
}
