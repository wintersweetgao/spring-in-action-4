package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 2/17/15.
 */
@Document
@XmlRootElement(name = "AssessmentResponse")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssessmentResponse extends MPModel {
    @Field
    private String runId;
    @Field
    private String detailRefId;
    @Field
    private AssessmentQuestion question;

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

    public String getDetailRefId() {
        return detailRefId;
    }

    public void setDetailRefId(String detailRefId) {
        this.detailRefId = detailRefId;
    }

    public AssessmentQuestion getQuestion() {
        return question;
    }

    public void setQuestion(AssessmentQuestion question) {
        this.question = question;
    }
}
