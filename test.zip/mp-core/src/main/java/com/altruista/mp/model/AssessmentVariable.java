package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Field;

/**
 * Created by mwixson on 2/12/15.
 */
public class AssessmentVariable {
    @Field
    private String refId;
    @Field
    private String name;
    @Field
    private String variableType;
    @Field
    private String formula;

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVariableType() {
        return variableType;
    }

    public void setVariableType(String variableType) {
        this.variableType = variableType;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }
}
