package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 2/12/15.
 */
@Document
@XmlRootElement(name = "Assessment")
public class Assessment extends MPModel {
    @Field
    private String name;
    @Field
    private String careActivityTypeName;
    @Field
    private String runTypeName;
    @Field
    private Long duration;
    @Field
    private Float score;
    @Field
    private Integer numOfQuestions;
    @Field
    private boolean isActive;
    @Field
    private List<AssessmentQuestion> questions;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCareActivityTypeName() {
        return careActivityTypeName;
    }

    public void setCareActivityTypeName(String careActivityTypeName) {
        this.careActivityTypeName = careActivityTypeName;
    }

    public String getRunTypeName() {
        return runTypeName;
    }

    public void setRunTypeName(String runTypeName) {
        this.runTypeName = runTypeName;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public Float getScore() {
        return score;
    }

    public void setScore(Float score) {
        this.score = score;
    }

    public Integer getNumOfQuestions() {
        return numOfQuestions;
    }

    public void setNumOfQuestions(Integer numOfQuestions) {
        this.numOfQuestions = numOfQuestions;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public List<AssessmentQuestion> getQuestions() {
        if (questions == null)
            questions = new ArrayList<AssessmentQuestion>();
        return questions;
    }

    public void setQuestions(List<AssessmentQuestion> questions) {
        this.questions = questions;
    }
}
