package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 7/7/14.
 */
@Document
@XmlRootElement(name = "contact")
public class Contact extends MPModel {
    @Field
    private String contactCode;
    @Field
    private ContactType contactType;
    @Field
    private String company;
    @Field
    private String status;
    @Field
    private String title;
    @Field
    private String salutation;
    @Field
    private String firstName;
    @Field
    private String middleName;
    @Field
    private String lastName;
    @Field
    private String nameSuffix;
    @Field
    private String primaryEmail;
    @Field
    private String alternateEmail;
    @Field
    private String directEmail;
    @Field
    private String daytimePhoneNumber;
    @Field
    private String eveningPhoneNumber;
    @Field
    private String mobilePhoneNumber;
    @Field
    private String primaryLanguage;
    @Field
    private String preferredTimeOfContact;
    @Field
    private Address address;
    @Field
    private String phoneNumber;
    @Field
    private String faxNumber;
    @Field
    private MPDocument photo;
    @Field
    private String ethnicity;
    @Field
    private String gender;
    @Field
    private String maritalStatus;
    @Field
    private String timezone;
    @Field
    private String dob;
    @Field
    private String registrationStatus;
    @Field
    private String relationshipToMember;
    @Field
    private List<String> tags;
    @Field
    private String description;

    public ContactType getContactType() {
        return contactType;
    }

    public void setContactType(ContactType contactType) {
        this.contactType = contactType;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getContactCode() {
        return contactCode;
    }

    public void setContactCode(String contactCode) {
        this.contactCode = contactCode;
    }

    /**
     * Identify if this contact is Active or InActive
     */
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPrimaryEmail() {
        return primaryEmail;
    }

    public void setPrimaryEmail(String primaryEmail) {
        this.primaryEmail = primaryEmail;
    }

    public String getAlternateEmail() {
        return alternateEmail;
    }

    public void setAlternateEmail(String alternateEmail) {
        this.alternateEmail = alternateEmail;
    }

    public String getDirectEmail() {
        return directEmail;
    }

    public void setDirectEmail(String directEmail) {
        this.directEmail = directEmail;
    }

    public String getDaytimePhoneNumber() {
        return daytimePhoneNumber;
    }

    public void setDaytimePhoneNumber(String daytimePhoneNumber) {
        this.daytimePhoneNumber = daytimePhoneNumber;
    }

    public String getEveningPhoneNumber() {
        return eveningPhoneNumber;
    }

    public void setEveningPhoneNumber(String eveningPhoneNumber) {
        this.eveningPhoneNumber = eveningPhoneNumber;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    public String getPrimaryLanguage() {
        return primaryLanguage;
    }

    public void setPrimaryLanguage(String primaryLanguage) {
        this.primaryLanguage = primaryLanguage;
    }

    public String getPreferredTimeOfContact() {
        return preferredTimeOfContact;
    }

    public void setPreferredTimeOfContact(String preferredTimeOfContact) {
        this.preferredTimeOfContact = preferredTimeOfContact;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public MPDocument getPhoto() {
        return photo;
    }

    public void setPhoto(MPDocument photo) {
        this.photo = photo;
    }

    public String getEthnicity() {
        return ethnicity;
    }

    public void setEthnicity(String ethnicity) {
        this.ethnicity = ethnicity;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getRegistrationStatus() {
        return registrationStatus;
    }

    public void setRegistrationStatus(String registrationStatus) {
        this.registrationStatus = registrationStatus;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getRelationshipToMember() {
        return relationshipToMember;
    }

    public void setRelationshipToMember(String relationshipToMember) {
        this.relationshipToMember = relationshipToMember;
    }

    public List<String> getTags() {
        if (tags == null)
            tags = new ArrayList<String>();
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
