package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mwixson on 1/26/15.
 */
@Document
public class TrackerCategory extends MPModel {
    @Field
    private String name;
    @Field
    private Boolean readOnly;
    @Field
    private List<String> conditions;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getReadOnly() {
        return readOnly;
    }

    public void setReadOnly(Boolean readOnly) {
        this.readOnly = readOnly;
    }

    public List<String> getConditions() {
        if (conditions == null)
            conditions = new ArrayList<String>();
        return conditions;
    }

    public void setConditions(List<String> conditions) {
        this.conditions = conditions;
    }
}