package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.joda.time.DateTime;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.UUID;

/**
 * Created by mwixson on 7/17/14.
 */
public class MPModel {
    @Id
    private String id;
    @Version
    private Long version;
    @Field
    private String clientId;
    @Field
    private String clientRefId;
    @Field
    private String refId;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime refCreatedOn;
    @Field
    private String createdBy;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime createdOn;
    @Field
    private String updatedBy;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime updatedOn;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime syncedOn;
    @Field
    private Boolean test;

    public MPModel() {
        this.id = UUID.randomUUID().toString();
        this.refId = null;
        this.createdOn = DateTime.now();
        this.updatedOn = DateTime.now();
        this.test = false;
    }

    public MPModel(String id) {
        this.id = id;
        this.refId = null;
        this.createdOn = DateTime.now();
        this.updatedOn = DateTime.now();
        this.test = false;
    }

    public MPModel(String id, String refId) {
        this.id = id;
        this.refId = refId;
        this.createdOn = DateTime.now();
        this.updatedOn = DateTime.now();
        this.test = false;
    }

    public MPModel(String id, String refId, DateTime createdOn) {
        this.id = id;
        this.refId = refId;
        this.createdOn = createdOn;
        this.updatedOn = DateTime.now();
        this.test = false;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientRefId() {
        return clientRefId;
    }

    public void setClientRefId(String clientRefId) {
        this.clientRefId = clientRefId;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public DateTime getRefCreatedOn() {
        return refCreatedOn;
    }

    public void setRefCreatedOn(DateTime refCreatedOn) {
        this.refCreatedOn = refCreatedOn;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public DateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(DateTime createdOn) {
        this.createdOn = createdOn;
    }

    public DateTime getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(DateTime updatedOn) {
        this.updatedOn = updatedOn;
    }

    public DateTime getSyncedOn() {
        return syncedOn;
    }

    public void setSyncedOn(DateTime syncedOn) {
        this.syncedOn = syncedOn;
    }

    public Boolean getTest() {
        return test;
    }

    public void setTest(Boolean test) {
        this.test = test;
    }
}
