package com.altruista.mp.model;

/**
 * Created by mwixson on 5/22/15.
 */
public enum SyncLogLevelType {
    TRACE, DEBUG, INFO, WARN, ERROR, CRITICAL
}
