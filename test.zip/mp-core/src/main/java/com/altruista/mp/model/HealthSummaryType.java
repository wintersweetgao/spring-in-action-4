package com.altruista.mp.model;

public enum HealthSummaryType {
    NONE, YEAR_TO_DATE, LAST_TWO_YEARS, FULL_HISTORY
}


