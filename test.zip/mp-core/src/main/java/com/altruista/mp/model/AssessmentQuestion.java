package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

/**
 * Created by mwixson on 2/12/15.
 */
@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssessmentQuestion {
    @Field
    private String refId;
    @Field
    private String question;
    @Field
    private String optionType;
    @Field
    private int sequence;
    @Field
    private Boolean isRequired;
    @Field
    private List<AssessmentQuestionOption> options;

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public Boolean getIsRequired() {
        return isRequired;
    }

    public void setIsRequired(Boolean isRequired) {
        this.isRequired = isRequired;
    }

    public List<AssessmentQuestionOption> getOptions() {
        return options;
    }

    public void setOptions(List<AssessmentQuestionOption> options) {
        this.options = options;
    }
}
