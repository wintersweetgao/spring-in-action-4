package com.altruista.mp.model;

/**
 * Created by mwixs_000 on 7/18/2014.
 */
public enum ConditionType {
    MEDICAL, BEHAVIORAL
}
