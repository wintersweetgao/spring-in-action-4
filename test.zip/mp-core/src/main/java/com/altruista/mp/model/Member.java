package com.altruista.mp.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

@Document
@XmlRootElement(name = "member")
public class Member extends MPModel {
    @Field
    private String contactId;
    @Field
    private String contactCode;
    @Field
    private String primaryMedicalProvider;
    @Field
    private String primaryMedicalCondition;
    @Field
    private String primaryBehavioralProvider;
    @Field
    private String primaryBehavioralCondition;
    @Field
    private String careManagerId;
    @Field
    private String careManager;
    @Field
    private Float riskScore;
    @Field
    private String riskLevel;
    @Field
    private float height;
    @Field
    private String heightUnits;
    @Field
    private float weight;
    @Field
    private String weightUnits;

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getContactCode() {
        return contactCode;
    }

    public void setContactCode(String contactCode) {
        this.contactCode = contactCode;
    }

    public String getPrimaryMedicalProvider() {
        return primaryMedicalProvider;
    }

    public void setPrimaryMedicalProvider(String primaryMedicalProvider) {
        this.primaryMedicalProvider = primaryMedicalProvider;
    }

    public String getPrimaryMedicalCondition() {
        return primaryMedicalCondition;
    }

    public void setPrimaryMedicalCondition(String primaryMedicalCondition) {
        this.primaryMedicalCondition = primaryMedicalCondition;
    }

    public String getPrimaryBehavioralProvider() {
        return primaryBehavioralProvider;
    }

    public void setPrimaryBehavioralProvider(String primaryBehavioralProvider) {
        this.primaryBehavioralProvider = primaryBehavioralProvider;
    }

    public String getPrimaryBehavioralCondition() {
        return primaryBehavioralCondition;
    }

    public void setPrimaryBehavioralCondition(String primaryBehavioralCondition) {
        this.primaryBehavioralCondition = primaryBehavioralCondition;
    }

    public String getCareManagerId() {
        return careManagerId;
    }

    public void setCareManagerId(String careManagerId) {
        this.careManagerId = careManagerId;
    }

    public String getCareManager() {
        return careManager;
    }

    public void setCareManager(String careManager) {
        this.careManager = careManager;
    }

    public Float getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(Float riskScore) {
        this.riskScore = riskScore;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public String getHeightUnits() {
        return heightUnits;
    }

    public void setHeightUnits(String heightUnits) {
        this.heightUnits = heightUnits;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public String getWeightUnits() {
        return weightUnits;
    }

    public void setWeightUnits(String weightUnits) {
        this.weightUnits = weightUnits;
    }
}
