package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by mwixson on 2/12/15.
 */
@Document
@XmlRootElement(name = "AssessmentRun")
public class AssessmentRun extends MPModel {
    @Field
    private String assessmentId;
    @Field
    private String assessmentName;
    @Field
    private String memberId;
    @Field
    private String followupRefId;
    @Field
    private String status;
    @Field
    private String careNotes;
    // Newly Added field
    @Field
    private int lastSequence;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime startedOn;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private DateTime endedOn;

    public String getAssessmentId() {
        return assessmentId;
    }

    public void setAssessmentId(String assessmentId) {
        this.assessmentId = assessmentId;
    }

    public String getAssessmentName() {
        return assessmentName;
    }

    public void setAssessmentName(String assessmentName) {
        this.assessmentName = assessmentName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getFollowupRefId() {
        return followupRefId;
    }

    public void setFollowupRefId(String followupRefId) {
        this.followupRefId = followupRefId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCareNotes() {
        return careNotes;
    }

    public void setCareNotes(String careNotes) {
        this.careNotes = careNotes;
    }

    public DateTime getStartedOn() {
        return startedOn;
    }

    public void setStartedOn(DateTime startedOn) {
        this.startedOn = startedOn;
    }

    public DateTime getEndedOn() {
        return endedOn;
    }

    public void setEndedOn(DateTime endedOn) {
        this.endedOn = endedOn;
    }

    public int getLastSequence() {
        return lastSequence;
    }

    public void setLastSequence(int lastSequence) {
        this.lastSequence = lastSequence;
    }
}
