package com.altruista.mp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.joda.time.DateTime;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.UUID;

/**
 * Created by mwixson on 6/19/14.
 */
@Document
@XmlRootElement(name = "program")
public class Program extends MPModel {
    @Field
    private String memberId;
    @Field
    private boolean primary;
    @Field
    private String lob;
    @Field
    private String plan;
    @Field
    private String name;
    @Field
    private Boolean active;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime startOn;
    @Field
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private DateTime endOn;

    public Program(String refId, String memberId, boolean primary, String lob, String plan, String name) {
        super(UUID.randomUUID().toString(), refId);
        this.memberId = memberId;
        this.primary = primary;
        this.lob = lob;
        this.plan = plan;
        this.name = name;
        this.active = true;
    }

    public Program(String memberId, String lob, String plan, String name) {
        super(UUID.randomUUID().toString());
        this.memberId = memberId;
        this.primary = true;
        this.lob = lob;
        this.plan = plan;
        this.name = name;
        this.active = true;
    }

    public Program() {
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public DateTime getStartOn() {
        return startOn;
    }

    public void setStartOn(DateTime startOn) {
        this.startOn = startOn;
    }

    public DateTime getEndOn() {
        return endOn;
    }

    public void setEndOn(DateTime endOn) {
        this.endOn = endOn;
    }
}